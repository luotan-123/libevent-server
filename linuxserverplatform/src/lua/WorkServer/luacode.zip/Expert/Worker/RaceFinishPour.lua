module("RaceFinishPour", package.seeall)

-- 赛事结算触发，跟投
function work(buffer)
	
	local countset = redisItem:smembers(RaceInfoModel.RaceStatusFinishSet, RaceInfoModel.redis_index)
	
	for k,v in pairs(countset) do -- v是赛事id
		
		local raceinfopb = RaceInfoModel.GetRaceInfo(v)
		if raceinfopb == nil then
			LogFile("info", "赛事id:"..v)
			raceinfopb = RaceInfoModel.LoadRaceInfo(v)
		end
		local raceinfo = st_footballgame_pb.MerchantRaceInfoDto()
		raceinfo:ParseFromString(raceinfopb)
		
		local raceResult = raceinfo.winResult
		
		-- 没有结果，不结算
		if raceResult == "0" or raceResult == "" then
			return
		end
		
		
		-- 拉取所有相关玩家
		local orderlist = redisItem:lrange(ExpertModel.PourPlanRaceList..raceinfo.raceId, 0, -1, ExpertModel.redis_index)
		
		for k1,v1 in pairs(orderlist) do -- v1是组合id 
		
			local arr = RaceInfoModel.SplitString(v1, "|")
			local userid = tonumber(arr[1])
			local planid = tonumber(arr[2])
			local planraceid = tonumber(arr[3])
			local orderid = tonumber(arr[4])
			local win = 0
			local pourjetton = 0
			local typescore = ""
			local expertid = 0
			
			-- 查找订单
			local sqlCase = "select typescore,win,pourjetton,expertid from dy_footballorder where orderid="..orderid
			mysqlItem:executeQuery(sqlCase)
			
			local sqlData = mysqlItem:fetch({})
			if sqlData ~= nil then
				
				typescore = sqlData[1]
				win = tonumber(sqlData[2])
				pourjetton = tonumber(sqlData[3])
				expertid = tonumber(sqlData[4])
				
				if RaceInfoModel.IsScoreWin(raceinfo.raceId, raceResult, typescore) then  --赢钱继续，输钱没有后续了
					
					ExpertService.PourPlanNextScore(userid, planid, planraceid, win, expertid)
					
				end
				
			else
				LogFile("error", "跟投失败，订单不存在。orderid="..orderid)
				print("跟投失败，订单不存在。orderid="..orderid)
			end
			
		end
		
		redisItem:del(ExpertModel.PourPlanRaceList..raceinfo.raceId, ExpertModel.redis_index)
		redisItem:srem(RaceInfoModel.RaceStatusFinishSet, v, RaceInfoModel.redis_index)
	end
	
end
