module("RaceCancelPour", package.seeall)


-- 赛事取消触发，跟投
function work(buffer)
	
	local countset = redisItem:smembers(RaceInfoModel.RaceStatusCancelSet, RaceInfoModel.redis_index)
	
	for k,v in pairs(countset) do -- v是赛事id
		
		local raceinfopb = RaceInfoModel.GetRaceInfo(v)
		local raceinfo = st_footballgame_pb.MerchantRaceInfoDto()
		raceinfo:ParseFromString(raceinfopb)
		
		-- 发送公告
		local newsinfo = {}
		newsinfo["title"] = RaceInfoModel.GetMsgByRaceStatus(raceinfo.raceStatus)
		newsinfo["content"] = raceinfo.category.."("..raceinfo.homeTeam..
		":"..raceinfo.visitTeam.." "..TimeUtils.GetTimeString((tonumber(raceinfo.startTime)/1000))..")"..RaceInfoModel.GetMsgByRaceStatus(raceinfo.raceStatus).."，系统撤销所有订单。"
		
		newsinfo["sendtime"] = TimeUtils.GetTimeString()
		newsinfo["sendid"]  = 1
		newsinfo["receiveid"] = 0
		newsinfo["sendstate"] = 0
		newsinfo["newtype"]  = 4
		newsinfo["prechannel"]  = "all"     
		FootballService.raceOrderInfoSendNews(newsinfo)
		
		
		-- 拉取所有相关玩家
		local orderlist = redisItem:lrange(ExpertModel.PourPlanRaceList..raceinfo.raceId, 0, -1, ExpertModel.redis_index)
		
		for k1,v1 in pairs(orderlist) do -- v1是组合id 
		
			local arr = RaceInfoModel.SplitString(v1, "|")
			local userid = tonumber(arr[1])
			local planid = tonumber(arr[2])
			local planraceid = tonumber(arr[3])
			local orderid = tonumber(arr[4])
			local win = 0
			local pourjetton = 0
			local typescore = ""
			local expertid = 0
			
			-- 查找订单
			local sqlCase = "select typescore,win,pourjetton,expertid from dy_footballorder where orderid="..orderid
			mysqlItem:executeQuery(sqlCase)
			
			local sqlData = mysqlItem:fetch({})
			if sqlData ~= nil then
				
				typescore = sqlData[1]
				win = tonumber(sqlData[2])
				pourjetton = tonumber(sqlData[3])
				expertid = tonumber(sqlData[4])
				
				ExpertService.PourPlanNextScore(userid, planid, planraceid, pourjetton, expertid)
				
			else
				LogFile("error", "跟投失败，订单不存在。orderid="..orderid)
				print("跟投失败，订单不存在。orderid="..orderid)
			end
			
		end
		
		redisItem:del(ExpertModel.PourPlanRaceList..raceinfo.raceId, ExpertModel.redis_index)
		redisItem:srem(RaceInfoModel.RaceStatusCancelSet, v, RaceInfoModel.redis_index)
	end
	
end
