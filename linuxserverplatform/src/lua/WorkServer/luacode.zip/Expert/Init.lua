-- proto
require("common.st_expert_pb")
require("common.msg_expert_pb")
require("common.msg_expert2_pb")
require("common.define.ExpertDefine")
require("common.packet.packet_expert")

-- msg
require("Expert.Controller.ExpertAddConcerned")
require("Expert.Controller.ExpertAddNotice")
require("Expert.Controller.ExpertAddPlanConcerned")
require("Expert.Controller.ExpertAllUserList")
require("Expert.Controller.ExpertApplyToExpert")
require("Expert.Controller.ExpertBuyPlan")
require("Expert.Controller.ExpertChangeContent")
require("Expert.Controller.ExpertConcernPlanList")
require("Expert.Controller.ExpertConcernUserList")
require("Expert.Controller.ExpertGetHisPlanList")
require("Expert.Controller.ExpertGetMyPlanInfo")
require("Expert.Controller.ExpertGetOtherPlanInfo")
require("Expert.Controller.ExpertGetUserHitRate")
require("Expert.Controller.ExpertGetUserInfo")
require("Expert.Controller.ExpertGetUserRecords")
require("Expert.Controller.ExpertHotList")
require("Expert.Controller.ExpertHotPlanList")
require("Expert.Controller.ExpertLookMyInfo")
require("Expert.Controller.ExpertMyplanedList")
require("Expert.Controller.ExpertMyplaningList")
require("Expert.Controller.ExpertQueryName")
require("Expert.Controller.ExpertQueryStatus")
require("Expert.Controller.ExpertWeekRankList")
require("Expert.Controller.ExpertWinRankList")
require("Expert.Controller.ExpertCreatePlan")
require("Expert.Controller.GetRacePlan")
require("Expert.Controller.ExpertPourPlan")
require("Expert.Controller.ExpertRelationPlanList")
require("Expert.Controller.ExpertGetRaceStatus")

-- model
require("Expert.Model.ExpertModel")



-- Service
require("Expert.Services.ExpertService")




-- work
require("Expert.Worker.RaceCancelPour")
require("Expert.Worker.RaceFinishPour")


g_redisIndex[ExpertModel.redis_index] = {index = g_redisInfo.redis_six , des = "expert"}