module("ExpertConcernPlanList",package.seeall)

--获取关注的方案
function execute(packetID, operateID, buffer)
	--print("ExpertConcernPlanList")
	
    local cgmsg = msg_expert_pb.cgexpertconcernplanlist()
	local gcmsg = msg_expert_pb.gcexpertconcernplanlist()
	cgmsg:ParseFromString(buffer)
	
	local checkMsg = RedisHelper.CheckRedis(cgmsg.userid,operateID)
	if checkMsg ~= nil then
		LogBehavior.Warning(cgmsg.userid, "expert", "ExpertConcernPlanList", 0,"缓存已存在")
		return cgmsg.userid,0,string.len(checkMsg),checkMsg 
	end	
	
    local pInfo = PlayerModel.GetPlayerInfo(cgmsg.userid)
    if pInfo == nil then
        gcmsg.result = ReturnCode["player_not_exist"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
    end
	
	local time = TimeUtils.GetTime()
	local startPos = (cgmsg.pagenum - 1)*8
	startPos = startPos < 0 and 0 or startPos
	
	local dataList = ExpertModel.GetConcernPlan(cgmsg.userid, startPos, startPos + 7)
	for k,v_planid in ipairs(dataList) do
		
		--查询数据库
		local sqlCase = "select * from ex_plan where planid="..v_planid
		mysqlItem:executeQuery(sqlCase)
		local sqlData = mysqlItem:fetch({})
		if sqlData ~= nil then
			
			local userdata = gcmsg.datas:add()
			
			-- 填充方案信息
			userdata.planid = tonumber(v_planid)
			userdata.expertid = tonumber(sqlData[2])
			userdata.plantitle 	= sqlData[3]
			userdata.rsign 		= tonumber(sqlData[5])
			userdata.plantime 	= sqlData[6]
			userdata.guessprofit = tonumber(sqlData[7])
			userdata.checkstatus = tonumber(sqlData[8])
			userdata.time = sqlData[11]
			userdata.remaintime = tonumber(userdata.plantime) - time
			

			-- 查询选择的比分
			local sqlCase = "select * from ex_planorder where planid="..v_planid
			mysqlItem:executeQuery(sqlCase)
			while true do
				local sqlData = mysqlItem:fetch({})
				if sqlData == nil then
					break
				end
				
				-- 填充比分信息
				local racescore = userdata.orderlist:add()
				
				racescore.rebateId				= sqlData[4]
				racescore.raceId				= sqlData[3]
				racescore.startTime 			= sqlData[5]
				racescore.homeTeam 				= sqlData[7]
				racescore.visitTeam 			= sqlData[8]
				racescore.category 				= sqlData[6]
				racescore.score					= "***" --sqlData[9]
				racescore.rebateRatio			= "***" --sqlData[10]
				racescore.fee					= tonumber(sqlData[11])
				racescore.yieltype  			= tonumber(sqlData[12])
				racescore.planraceid			= sqlData[1]
			end
			
			
			-- 查询专家接口
			local sqlCase = "select * from ex_player where userid="..userdata.expertid
			mysqlItem:executeQuery(sqlCase)
			local sqlData = mysqlItem:fetch({})
			if sqlData ~= nil then
				
				-- 填充专家信息
				userdata.userid = tonumber(sqlData[1])
				userdata.nickname = sqlData[2]
				userdata.face = sqlData[3]
				userdata.level = tonumber(sqlData[5])
				userdata.title = sqlData[6]
				userdata.style = tonumber(sqlData[4])
				--userdata.hitcount = 0 --tonumber(sqlData[8])
				userdata.nearhitrate = tonumber(sqlData[9])
				userdata.wintype = ExpertModel.GetExpertWinType(tonumber(sqlData[8]), tonumber(sqlData[26]), tonumber(sqlData[27]))
				userdata.hitcount = userdata.wintype --tonumber(sqlData[8])
				userdata.averagerate = tonumber(sqlData[10])
				userdata.isauth = tonumber(sqlData[22])
			else   -- 不存该数据，调用取关接口
				ExpertModel.AddConcernedPlan(cgmsg.userid, v_planid, 2, 0)
			end
			
		else  -- 不存该数据，调用取关接口
		
			ExpertModel.AddConcernedPlan(cgmsg.userid, v_planid, 2, 0)
		end
		
	end
	
	
	gcmsg.pagenum = cgmsg.pagenum
	gcmsg.allnum = ExpertModel.GetConcernPlanCount(cgmsg.userid)
	
	gcmsg.result = 0
	return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
end

