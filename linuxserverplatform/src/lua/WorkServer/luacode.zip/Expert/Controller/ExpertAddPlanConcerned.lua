module("ExpertAddPlanConcerned",package.seeall)

--关注方案
function execute(packetID, operateID, buffer)
	--print("ExpertAddPlanConcerned")
	
    local cgmsg = msg_expert_pb.cgexpertaddplanconcerned()
	local gcmsg = msg_expert_pb.gcexpertaddplanconcerned()
	cgmsg:ParseFromString(buffer)
	
	local checkMsg = RedisHelper.CheckRedis(cgmsg.userid,operateID)
	if checkMsg ~= nil then
		LogBehavior.Warning(cgmsg.userid, "expert", "ExpertAddPlanConcerned", 0,"缓存已存在")
		return cgmsg.userid,0,string.len(checkMsg),checkMsg 
	end	
	
    local pInfo = PlayerModel.GetPlayerInfo(cgmsg.userid)
    if pInfo == nil then
        gcmsg.result = ReturnCode["player_not_exist"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
    end
	
	-- 查询方案是否存在
	local expertid = 0
	local sqlCase = "select expertid from ex_plan where planid="..cgmsg.planid
	mysqlItem:executeQuery(sqlCase)
	local sqlData = mysqlItem:fetch({})
	if sqlData ~= nil then
		expertid = tonumber(sqlData[1])
	else
		gcmsg.result = ReturnCode["plan_no_exists"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
	end
	
	
	if expertid == cgmsg.userid then
		
		gcmsg.result = ReturnCode["no_concern_myself_plan"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
	end
	
	ExpertModel.AddConcernedPlan(cgmsg.userid, cgmsg.planid, cgmsg.reqtype, TimeUtils.GetTime())
	
	gcmsg.reqtype = cgmsg.reqtype
	gcmsg.planid = cgmsg.planid
	gcmsg.msg = "成功"
	
	
	gcmsg.result = 0
	return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
end

