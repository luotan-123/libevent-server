module("ExpertGetHisPlanList",package.seeall)

--获取某个专家历史方案
function execute(packetID, operateID, buffer)
	--print("ExpertGetHisPlanList")
	
    local cgmsg = msg_expert_pb.cgexperthisplanlist()
	local gcmsg = msg_expert_pb.gcexperthisplanlist()
	cgmsg:ParseFromString(buffer)
	
	local checkMsg = RedisHelper.CheckRedis(cgmsg.userid,operateID)
	if checkMsg ~= nil then
		LogBehavior.Warning(cgmsg.userid, "expert", "ExpertGetHisPlanList", 0,"缓存已存在")
		return cgmsg.userid,0,string.len(checkMsg),checkMsg 
	end	
	
    local pInfo = PlayerModel.GetPlayerInfo(cgmsg.userid)
    if pInfo == nil then
        gcmsg.result = ReturnCode["player_not_exist"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
    end
	
	
	if ExpertModel.IsExpert(cgmsg.expertid) == false then
		gcmsg.result = ReturnCode["expert_no_exit"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
	end
	

	local time = TimeUtils.GetTime()
	local startPos = (cgmsg.pagenum - 1)*8
	startPos = startPos < 0 and 0 or startPos
	
	
	-- 分页查询
	local sqlCase = "SELECT * FROM ex_plan WHERE planid <=(SELECT planid FROM ex_plan WHERE expertid="..cgmsg.expertid..
	" AND checkstatus=3 ORDER BY planid DESC LIMIT "..startPos..", 1) AND expertid="..cgmsg.expertid..
	" AND checkstatus=3 ORDER BY planid DESC LIMIT 8"
	
	mysqlItem:executeQuery(sqlCase)
	while true do
		local sqlData = mysqlItem:fetch({})
		if sqlData == nil then
			break
		end
		
		local userdata = gcmsg.datas:add()
			
		-- 填充方案信息
		userdata.planid = tonumber(sqlData[1])
		userdata.expertid = tonumber(sqlData[2])
		userdata.plantitle 	= sqlData[3]
		userdata.rsign 		= tonumber(sqlData[5])
		userdata.plantime 	= sqlData[6]
		userdata.guessprofit = tonumber(sqlData[7])
		userdata.checkstatus = tonumber(sqlData[8])
		userdata.time = sqlData[11]
		userdata.failreason = sqlData[9]
		userdata.remaintime = tonumber(userdata.plantime) - time
		
	end
	
	
	
	-- 填充比分信息
	for i=1,#gcmsg.datas do
		-- 查询选择的比分
		local sqlCase = "select * from ex_planorder where planid="..gcmsg.datas[i].planid
		mysqlItem:executeQuery(sqlCase)
		while true do
			local sqlData = mysqlItem:fetch({})
			if sqlData == nil then
				break
			end
			
			-- 填充比分信息
			local racescore = gcmsg.datas[i].orderlist:add()
			
			racescore.rebateId				= sqlData[4]
			racescore.raceId				= sqlData[3]
			racescore.startTime 			= sqlData[5]
			racescore.homeTeam 				= sqlData[7]
			racescore.visitTeam 			= sqlData[8]
			racescore.category 				= sqlData[6]
			racescore.score					= "***" --sqlData[9]
			racescore.rebateRatio			= "***" --sqlData[10]
			racescore.fee					= tonumber(sqlData[11])
			racescore.yieltype  			= tonumber(sqlData[12])
			racescore.planraceid			= sqlData[1]
		end
		
	end

    
	-- 获取总数
	gcmsg.allnum = 8
	local sqlCase = "select COUNT(*) from ex_plan where expertid="..cgmsg.expertid.." and checkstatus=3"
	mysqlItem:executeQuery(sqlCase)
	local sqlData = mysqlItem:fetch({})
	if sqlData ~= nil then
		gcmsg.allnum = tonumber(sqlData[1])
	end
	
	
	gcmsg.pagenum = cgmsg.pagenum
  

	gcmsg.result = 0
	return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
end

