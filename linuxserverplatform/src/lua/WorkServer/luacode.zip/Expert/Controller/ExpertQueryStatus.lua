module("ExpertQueryStatus",package.seeall)


--专家数据统计方法
--[[
1、专家近几场中几场
答案：取专家的个人投注，最近三场已结算的结果
2、专家的三连胜（专家连胜场次）
答案：知道问题1，就可以解决了
3、方案的预期收益
答案：方案所有赛事的平均返利
4、玩家的总盈利
答案：log_player 的 winamount
5、玩家的收益率
近20场的平均收益率
6、玩家的连胜场次
答案：近20场，连胜最多的连续
7、专家的平均赔率
别人投注他方案派彩金额 - 方案投注金额 ）/方案投注金额
8、专家的近期命中率

9、专家的周盈利率

10、周人气值

11、专家的命中率分析图

12、专家的平均赔率分析图
别人投注他方案派彩金额 - 方案投注金额 ）/方案投注金额
13、专家的方案战绩

14、专家查看自己的个人统计，所有内容

15、专家查看自己方案的所有统计，所有内容

]]

--查询状态
function execute(packetID, operateID, buffer)
	--print("ExpertQueryStatus")
	
    local cgmsg = msg_expert_pb.cgexpertquerystatus()
	local gcmsg = msg_expert_pb.gcexpertquerystatus()
	cgmsg:ParseFromString(buffer)
	
	local checkMsg = RedisHelper.CheckRedis(cgmsg.userid,operateID)
	if checkMsg ~= nil then
		LogBehavior.Warning(cgmsg.userid, "expert", "ExpertQueryStatus", 0,"缓存已存在")
		return cgmsg.userid,0,string.len(checkMsg),checkMsg 
	end	
	
    local pInfo = PlayerModel.GetPlayerInfo(cgmsg.userid)
    if pInfo == nil then
        gcmsg.result = ReturnCode["player_not_exist"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
    end
	
	-- 初始化状态值
	gcmsg.isexpert 		= 0
    gcmsg.iscanexpert 	= 0
	gcmsg.checkstatus 	= 0
	gcmsg.failmsg 		= ""
	gcmsg.style 		= 1
	gcmsg.result 		= 0
	gcmsg.status		= 1
	
	if ExpertModel.IsExpert(cgmsg.userid) then
		
		gcmsg.isexpert 		= 1
		
		local sqlCase = "select style,status from ex_player where userid="..cgmsg.userid
		mysqlItem:executeQuery(sqlCase)
		local sqlData = mysqlItem:fetch({})
		if sqlData ~= nil then
			gcmsg.style = tonumber(sqlData[1])
			gcmsg.status = tonumber(sqlData[2])
		end

		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
	end


	-- 不满足条件
	if ExpertModel.IsCanBecomeExpert(cgmsg.userid) == false then
		gcmsg.failmsg = "投注量需要大于或等于50w元,投注场次>=50场,连赢场次>=20场,则可以成为专家"
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
	end
	
	gcmsg.iscanexpert 	= 1
	
	-- 查看审核状态
	local firstapply,checkstatus,failmsg = ExpertModel.QueryExpertCheckStatus(cgmsg.userid)
	
	gcmsg.checkstatus 	= checkstatus
	gcmsg.failmsg 		= failmsg
	
	return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
end

