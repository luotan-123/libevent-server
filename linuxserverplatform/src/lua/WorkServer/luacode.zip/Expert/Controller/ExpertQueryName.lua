module("ExpertQueryName",package.seeall)

--判断名字是否能用
function execute(packetID, operateID, buffer)
	--print("ExpertQueryName")
	
    local cgmsg = msg_expert_pb.cgexpertqueryname()
	local gcmsg = msg_expert_pb.gcexpertqueryname()
	cgmsg:ParseFromString(buffer)
	
	local checkMsg = RedisHelper.CheckRedis(cgmsg.userid,operateID)
	if checkMsg ~= nil then
		LogBehavior.Warning(cgmsg.userid, "expert", "ExpertQueryName", 0,"缓存已存在")
		return cgmsg.userid,0,string.len(checkMsg),checkMsg 
	end	
	
    local pInfo = PlayerModel.GetPlayerInfo(cgmsg.userid)
    if pInfo == nil then
        gcmsg.result = ReturnCode["player_not_exist"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
    end
	
	-- 检查名字
	if ExpertModel.IsIllegalName(cgmsg.nickname) then
		gcmsg.result = ReturnCode["illegal_name"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
	end
  
	gcmsg.result = 0
	return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
end

