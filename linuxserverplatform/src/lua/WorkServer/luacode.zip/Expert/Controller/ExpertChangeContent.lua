module("ExpertChangeContent",package.seeall)

--编辑个人介绍
function execute(packetID, operateID, buffer)
	--print("ExpertChangeContent")
	
    local cgmsg = msg_expert2_pb.cgexpertchangecontent()
	local gcmsg = msg_expert2_pb.gcexpertchangecontent()
	cgmsg:ParseFromString(buffer)
	
	local checkMsg = RedisHelper.CheckRedis(cgmsg.userid,operateID)
	if checkMsg ~= nil then
		LogBehavior.Warning(cgmsg.userid, "expert", "ExpertChangeContent", 0,"缓存已存在")
		return cgmsg.userid,0,string.len(checkMsg),checkMsg 
	end	
	
    local pInfo = PlayerModel.GetPlayerInfo(cgmsg.userid)
    if pInfo == nil then
        gcmsg.result = ReturnCode["player_not_exist"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
    end
	
	if ExpertModel.IsExpert(cgmsg.userid) == false then
		gcmsg.result = ReturnCode["expert_no_exit"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
	end
	
	--直接修改数据
	local sqlCase = "update ex_player set content='"..cgmsg.content.."' where userid="..cgmsg.userid
	mysqlItem:execute(sqlCase)


	gcmsg.result = 0
	return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
end

