module("ExpertGetUserRecords",package.seeall)

--获取专家方案战绩
function execute(packetID, operateID, buffer)
	--print("ExpertGetUserRecords")
	
    local cgmsg = msg_expert_pb.cgexpertgetuserrecords()
	local gcmsg = msg_expert_pb.gcexpertgetuserrecords()
	cgmsg:ParseFromString(buffer)
	
	local checkMsg = RedisHelper.CheckRedis(cgmsg.userid,operateID)
	if checkMsg ~= nil then
		LogBehavior.Warning(cgmsg.userid, "expert", "ExpertGetUserRecords", 0,"缓存已存在")
		return cgmsg.userid,0,string.len(checkMsg),checkMsg 
	end	
	
    local pInfo = PlayerModel.GetPlayerInfo(cgmsg.userid)
    if pInfo == nil then
        gcmsg.result = ReturnCode["player_not_exist"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
    end
	
	
	-- 查询方案赛事
	local sqlCase = "select id,raceresult from ex_planorder where expertid="..cgmsg.expertid.." and checkstatus=3 and raceresult>0 order by id desc limit 20"
	mysqlItem:executeQuery(sqlCase)
	while true do
		local sqlData = mysqlItem:fetch({})
		if sqlData == nil then
			break
		end
		
		local val = tonumber(sqlData[2])
		if val == 1 then -- 胜利
			gcmsg.datas:append(2)
		elseif val == 2 then -- 失败
			gcmsg.datas:append(1)
		end
		
		
	end
  
	
	gcmsg.result = 0
	return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
end

