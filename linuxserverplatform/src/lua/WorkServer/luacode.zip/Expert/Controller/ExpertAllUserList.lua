module("ExpertAllUserList",package.seeall)

--专家---全部，做渠道号区分
function execute(packetID, operateID, buffer)
	--print("ExpertAllUserList")
	
    local cgmsg = msg_expert_pb.cgexpertalluserlist()
	local gcmsg = msg_expert_pb.gcexpertalluserlist()
	cgmsg:ParseFromString(buffer)
	
	local checkMsg = RedisHelper.CheckRedis(cgmsg.userid,operateID)
	if checkMsg ~= nil then
		LogBehavior.Warning(cgmsg.userid, "expert", "ExpertAllUserList", 0,"缓存已存在")
		return cgmsg.userid,0,string.len(checkMsg),checkMsg 
	end	
	
    local pInfo = PlayerModel.GetPlayerInfo(cgmsg.userid)
    if pInfo == nil then
        gcmsg.result = ReturnCode["player_not_exist"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
    end
	
	
	local startPos = (cgmsg.pagenum - 1)*20
	startPos = startPos < 0 and 0 or startPos
	
	local userList = redisItem:zrevrange(ExpertModel.NearHitRate..pInfo.channel, startPos, startPos + 19, ExpertModel.redis_index)
	
	for k,v_userid in ipairs(userList) do
		
		--查询数据库
		local sqlCase = "select * from ex_player where userid="..v_userid
		mysqlItem:executeQuery(sqlCase)
		local sqlData = mysqlItem:fetch({})
		if sqlData ~= nil then
			
			local userdata = gcmsg.userlist:add()
			userdata.expertid = tonumber(v_userid)
			userdata.name = sqlData[2]
			userdata.face = sqlData[3]
			userdata.level = tonumber(sqlData[5])
			userdata.title = sqlData[6]
			
			userdata.rank = startPos + k
			
			--userdata.hitcount = 0 --tonumber(sqlData[8])
			userdata.nearhitrate = sqlData[9]
			userdata.wintype = ExpertModel.GetExpertWinType(tonumber(sqlData[8]), tonumber(sqlData[26]), tonumber(sqlData[27]))
			userdata.hitcount = userdata.wintype --tonumber(sqlData[8])
			userdata.averate = sqlData[10]
			--userdata.winrate = sqlData[12]
			
			userdata.fanscount = tonumber(sqlData[12])
			
			-- 函数内部有查询，放到后面
			userdata.isconcerned = ExpertModel.IsAddConcernedExpert(cgmsg.userid, userdata.expertid) and 1 or 0
			
			-- 从别的表获取数据
			userdata.weekhot = 0	
			userdata.newfans = 0	
			
			
		else
			redisItem:zrem(ExpertModel.NearHitRate..pInfo.channel, v_userid, ExpertModel.redis_index)
		end
		
	end
	
	
	gcmsg.pagenum = cgmsg.pagenum
	gcmsg.allnum = tonumber(redisItem:zcard(ExpertModel.NearHitRate..pInfo.channel, ExpertModel.redis_index) or 0) 
	
	gcmsg.result = 0
	return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
end

