module("ExpertHotPlanList",package.seeall)

--热门专家方案 ，做渠道号区分
function execute(packetID, operateID, buffer)
	--print("ExpertHotPlanList")
	
    local cgmsg = msg_expert_pb.cgexperthotplanlist()
	local gcmsg = msg_expert_pb.gcexperthotplanlist()
	cgmsg:ParseFromString(buffer)
	
	local checkMsg = RedisHelper.CheckRedis(cgmsg.userid,operateID)
	if checkMsg ~= nil then
		LogBehavior.Warning(cgmsg.userid, "expert", "ExpertHotPlanList", 0,"缓存已存在")
		return cgmsg.userid,0,string.len(checkMsg),checkMsg 
	end	
	
    local pInfo = PlayerModel.GetPlayerInfo(cgmsg.userid)
    if pInfo == nil then
        gcmsg.result = ReturnCode["player_not_exist"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
    end
	
	local time = TimeUtils.GetTime()
	local daystarttime = 0
	local dayendtime = 0
	local tTime = TimeUtils.GetTableTime()
	if tTime.hour < 12 then
		daystarttime = time - tTime.hour * 60 * 60 - tTime.min * 60 - tTime.sec - 12 * 60 * 60
	else
		daystarttime = time - tTime.hour * 60 * 60 - tTime.min * 60 -- - tTime.sec + 12 * 60 * 60
	end
	dayendtime = daystarttime +  36 * 60 * 60
	
	
	local startPos = (cgmsg.pagenum - 1)*8
	startPos = startPos < 0 and 0 or startPos
	gcmsg.pagenum = cgmsg.pagenum
	
	
	-- 分页查询
	local sqlCase = "SELECT * FROM ex_plan WHERE score <=(SELECT score FROM ex_plan WHERE channel='"..pInfo.channel..
	"' AND checkstatus=3 AND time>"..daystarttime.." AND time<="..dayendtime.." ORDER BY score DESC LIMIT "..startPos..", 1) AND channel='"..pInfo.channel..
	"' AND checkstatus=3 AND time>"..daystarttime.." AND time<="..dayendtime.." ORDER BY score DESC LIMIT 8"
	
	--local sqlCase = "select * from ex_plan where checkstatus=3 and channel='"..pInfo.channel.."' order by score desc limit 8"
	
	
	mysqlItem:executeQuery(sqlCase)
	while true do
		local sqlData = mysqlItem:fetch({})
		if sqlData == nil then
			break
		end
		
		local userdata = gcmsg.datas:add()
			
		-- 填充方案信息
		userdata.planid = tonumber(sqlData[1])
		userdata.expertid = tonumber(sqlData[2])
		userdata.plantitle 	= sqlData[3]
		userdata.rsign 		= tonumber(sqlData[5])
		userdata.plantime 	= sqlData[6]
		userdata.guessprofit = tonumber(sqlData[7])
		userdata.checkstatus = tonumber(sqlData[8])
		userdata.time = sqlData[11]
		userdata.remaintime = tonumber(userdata.plantime) - time
		userdata.ordercount = tonumber(sqlData[14])
		if RobotService.IsRobot(userdata.expertid) then
			local endtime = tonumber(userdata.plantime) < time and tonumber(userdata.plantime) or time
			userdata.ordercount = math.floor( math.mod(userdata.planid * 3, 7) + (math.mod(userdata.planid, 3) + 1) * (endtime/300 - tonumber(sqlData[11])/300) )
		end
	end
	
	
	
	-- 填充比分信息
	for i=1,#gcmsg.datas do
		-- 查询选择的比分
		local sqlCase = "select * from ex_planorder where planid="..gcmsg.datas[i].planid
		mysqlItem:executeQuery(sqlCase)
		while true do
			local sqlData = mysqlItem:fetch({})
			if sqlData == nil then
				break
			end
			
			-- 填充比分信息
			local racescore = gcmsg.datas[i].orderlist:add()
			
			racescore.rebateId				= sqlData[4]
			racescore.raceId				= sqlData[3]
			racescore.startTime 			= sqlData[5]
			racescore.homeTeam 				= sqlData[7]
			racescore.visitTeam 			= sqlData[8]
			racescore.category 				= sqlData[6]
			racescore.score					= "***"--sqlData[9]
			racescore.rebateRatio			= "***"--sqlData[10]
			racescore.fee					= tonumber(sqlData[11])
			racescore.yieltype  			= tonumber(sqlData[12])
			racescore.planraceid			= sqlData[1]
		end
		
	end
	
	
	
	-- 填充专家信息
	for i=1,#gcmsg.datas do
		local sqlCase = "select * from ex_player where userid="..gcmsg.datas[i].expertid
		mysqlItem:executeQuery(sqlCase)
		local sqlData = mysqlItem:fetch({})
		if sqlData ~= nil then
			
			local userdata = gcmsg.datas[i]
			
			-- 填充专家信息
			userdata.userid = tonumber(sqlData[1])
			userdata.nickname = sqlData[2]
			userdata.face = sqlData[3]
			userdata.level = tonumber(sqlData[5])
			userdata.title = sqlData[6]
			userdata.style = tonumber(sqlData[4])
			--userdata.hitcount = 0 --tonumber(sqlData[8])
			userdata.nearhitrate = tonumber(sqlData[9])
			userdata.wintype = ExpertModel.GetExpertWinType(tonumber(sqlData[8]), tonumber(sqlData[26]), tonumber(sqlData[27]))
			userdata.hitcount = userdata.wintype --tonumber(sqlData[8])
			userdata.averagerate = tonumber(sqlData[10])
			userdata.isauth = tonumber(sqlData[22])
		end
	end
	

	
	-- 获取总数
	gcmsg.allnum = 8
	local sqlCase = "select COUNT(*) from ex_plan where checkstatus=3 and channel='"..pInfo.channel.."'"
	mysqlItem:executeQuery(sqlCase)
	local sqlData = mysqlItem:fetch({})
	if sqlData ~= nil then
		gcmsg.allnum = tonumber(sqlData[1])
	end
	
	
	gcmsg.result = 0
	return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
end
