module("ExpertGetUserHitRate",package.seeall)


--获取专家命中率和赔率
function execute(packetID, operateID, buffer)
	--print("ExpertGetUserHitRate")
	
    local cgmsg = msg_expert_pb.cgexpertgetuserhitrate()
	local gcmsg = msg_expert_pb.gcexpertgetuserhitrate()
	cgmsg:ParseFromString(buffer)
	
	local checkMsg = RedisHelper.CheckRedis(cgmsg.userid,operateID)
	if checkMsg ~= nil then
		LogBehavior.Warning(cgmsg.userid, "expert", "ExpertGetUserHitRate", 0,"缓存已存在")
		return cgmsg.userid,0,string.len(checkMsg),checkMsg 
	end	
	
    local pInfo = PlayerModel.GetPlayerInfo(cgmsg.userid)
    if pInfo == nil then
        gcmsg.result = ReturnCode["player_not_exist"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
    end
	
	
	
	if cgmsg.reqtype == 1 then
		
		local resultarr = {}
		
		-- 查询方案赛事
		local sqlCase = "select raceresult from ex_planorder where expertid="..cgmsg.expertid.." and checkstatus=3 and raceresult>0 order by id desc limit 7"
		mysqlItem:executeQuery(sqlCase)
		while true do
			local sqlData = mysqlItem:fetch({})
			if sqlData == nil then
				break
			end
			
			table.insert(resultarr, tonumber(sqlData[1]))
		end
		
		
		if #resultarr > 0 then
			
			local count = 0
			
			if #resultarr >= 7 then
				count = 4
			elseif #resultarr >= 5 then
				count = 3
			elseif #resultarr >= 3 then
				count = 2
			elseif #resultarr >= 2 then
				count = 1
			end
			
			-- 初始化值
			for i=1,count do
				local datas = gcmsg.info:add()
				datas.x = i
				datas.y = 0
			end
		
			local twohitcount = 0
			local threehitcount = 0
			local fivehitcount = 0
			local sevenhitcount = 0
			
			for i=1,#resultarr do
				
				if i <= 2 and resultarr[i] == 1 then
					twohitcount = twohitcount + 1
				end
				
				if i <= 3 and resultarr[i] == 1 then
					threehitcount = threehitcount + 1
				end
				
				if i <= 5 and resultarr[i] == 1 then
					fivehitcount = fivehitcount + 1
				end
				
				if i <= 7 and resultarr[i] == 1 then
					sevenhitcount = sevenhitcount + 1
				end
				
			end
			
			
			for i=1,#gcmsg.info do
				
				local datas = gcmsg.info[i]
				
				if i == 1 then
					datas.y = twohitcount / 2 --(2 <= #resultarr and 2 or #resultarr)
				elseif i == 2 then
					datas.y = threehitcount / 3 --(3 <= #resultarr and 3 or #resultarr)
				elseif i == 3 then
					datas.y = fivehitcount / 5 --(5 <= #resultarr and 5 or #resultarr)
				elseif i == 4 then
					datas.y = sevenhitcount / 7 --(7 <= #resultarr and 7 or #resultarr)
				end
				
			end
			
			
		end
		
	else
		
		-- 平均赔率
		local time = TimeUtils.GetTime()
		local dayStr = TimeUtils.GetDayString(time - 13 * 24 * 60 * 60)
		local sqlCase = "select dateid,palnordercount,planrebateRatio from log_playerdaily where userid="..cgmsg.expertid.." and dateid>='"..dayStr.."' order by dateid desc"
		mysqlLog:executeQuery(sqlCase)
		while true do
			local sqlData = mysqlLog:fetch({})
			if sqlData == nil then
				break
			end
			
			if tonumber(sqlData[2]) > 0 then
				
				local datas = gcmsg.info:add()
				datas.x = TimeUtils.GetTime(sqlData[1].." 00:00:01")
				datas.y = tonumber(sqlData[3]) / tonumber(sqlData[2])
			end
			
		end
		
	end
	
	
	gcmsg.reqtype = cgmsg.reqtype
	gcmsg.result = 0
	return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
end

