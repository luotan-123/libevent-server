module("ExpertCreatePlan",package.seeall)

--发布方案
function execute(packetID, operateID, buffer)
	--print("ExpertCreatePlan")
	
    local cgmsg = msg_expert2_pb.cgexpertcreateplan()
	local gcmsg = msg_expert2_pb.gcexpertcreateplan()
	cgmsg:ParseFromString(buffer)
	
	local checkMsg = RedisHelper.CheckRedis(cgmsg.userid,operateID)
	if checkMsg ~= nil then
		LogBehavior.Warning(cgmsg.userid, "expert", "ExpertCreatePlan", 0,"缓存已存在")
		return cgmsg.userid,0,string.len(checkMsg),checkMsg 
	end	
	
    local pInfo = PlayerModel.GetPlayerInfo(cgmsg.userid)
    if pInfo == nil then
        gcmsg.result = ReturnCode["player_not_exist"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
    end
	
	if cgmsg.planprice < 0 then
		gcmsg.result = ReturnCode["param_error"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
	end
	
	if cgmsg.planprice > 2000 then
		gcmsg.result = ReturnCode["price_too_much"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
	end
	
	
	-- 从数据库总查找自己的信息
	local style = 1
	local status = 1
	local sqlCase = "select style,status from ex_player where userid="..cgmsg.userid
	mysqlItem:executeQuery(sqlCase)
	local sqlData = mysqlItem:fetch({})
	if sqlData ~= nil then
		style = tonumber(sqlData[1])
		status = tonumber(sqlData[2])
	else
		gcmsg.result = ReturnCode["expert_no_exit"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
	end
	
	if status == 2 then
		gcmsg.result = ReturnCode["expert_forbid"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
	end
	
	local function IsCharacter(mystyle, rate)
		
		if mystyle == 1 then
			if rate > 0.01 then
				return false
			end
		elseif mystyle == 2 then
			if rate > 0.03 then
				return false
			end
		elseif mystyle == 3 then
			if rate > 0.05 then
				return false
			end
		elseif mystyle == 4 then
			if rate > 0.07 then
				return false
			end
		elseif mystyle == 5 then
		else
			return false
		end
		
		return true
	end
	
	
	-- 限定玩家选择32个比分
	if #cgmsg.orderlist > 32 or #cgmsg.orderlist <= 0 then
		gcmsg.result = ReturnCode["score_too_much"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
	end
  

	-- 获取当前时间
	local time = TimeUtils.GetTime()
	
	
	-- 判断是否选择了，已经开赛的比赛
	local laststarttime = 0
	local daystarttime = 0
	local dayendtime = 0
	local plantime = 0
	local allrebateRatio = 0
	for i=1,#cgmsg.orderlist do
		
		local starttime = tonumber(cgmsg.orderlist[i].startTime)
		local rebateratio = tonumber(cgmsg.orderlist[i].rebateRatio)
		
		if i == 1 then
			laststarttime = starttime
			local tTime = TimeUtils.GetTableTime(starttime)
			if tTime.hour < 12 then
				daystarttime = starttime - tTime.hour * 60 * 60 - tTime.min * 60 - tTime.sec - 12 * 60 * 60
			else
				daystarttime = starttime - tTime.hour * 60 * 60 - tTime.min * 60 - tTime.sec + 12 * 60 * 60
			end
			
			dayendtime = daystarttime +  24 * 60 * 60
		else
			
			if math.abs(starttime - laststarttime) < 2 * 60 * 60 then
				gcmsg.result = ReturnCode["two_time_once"]
				return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
			end
			
			laststarttime = starttime
			
			--[[if starttime < daystarttime or starttime > dayendtime then
				gcmsg.result = ReturnCode["rece_one_day"]
				return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
			end--]]
		end
		
		-- 统计数据
		if plantime == 0 then
			plantime = starttime
		elseif  plantime > starttime then
			plantime = starttime
		end
		allrebateRatio = allrebateRatio + rebateratio
		
		
		-- 判断时间是否合法
		if starttime < time then
			gcmsg.result = ReturnCode["race_started"]
			return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
		end
		
		 --单个下注区域的信息 
		local SimpleRebateInfoPB = RaceInfoModel.GetRaceRebateInfo(cgmsg.orderlist[i].raceId, cgmsg.orderlist[i].rebateId)
		
		-- 判断比分是否存在
		if SimpleRebateInfoPB == nil then
			gcmsg.result = ReturnCode["race_not_exists"]
			return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
		end
		
		local SimpleRebateInfo = st_footballgame_pb.SimpleRebateInfo()
		SimpleRebateInfo:ParseFromString(SimpleRebateInfoPB)
		if SimpleRebateInfo.rebateOpenStatus == 0 then
			gcmsg.result = ReturnCode["param_error"]
			return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
		end
		
		--[[-- 查看比分收益是否符合自己的性格
		if IsCharacter(style, rebateratio) == false then
			gcmsg.result = ReturnCode["error_character"]
			return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
		end--]]
		
	end
	
	local checkstatus = 1
	local planid = ExpertModel.GetNewPlanID()
	local guessprofit = allrebateRatio --/ (#cgmsg.orderlist)
	local aveprofit = allrebateRatio / (#cgmsg.orderlist)
	local rsign = 0
	if aveprofit <= 0.01 then
		rsign = 1
	elseif aveprofit <= 0.03 then
		rsign = 2
	elseif aveprofit <= 0.05 then
		rsign = 3
	elseif aveprofit <= 0.07 then
		rsign = 4
	else
		rsign = 5
	end
	
	
	-- 插入数据 ex_plan
	sqlCase = "insert into ex_plan(planid,expertid,plantitle,content,rsign,plantime,guessprofit,checkstatus,channel,time,score,planprice,prechannel) value("..
	planid..","..cgmsg.userid..",'"..cgmsg.title.."','"..cgmsg.content.."',"..rsign..","..
	plantime..","..guessprofit..","..checkstatus..",'"..pInfo.channel.."',"..time..","..planid..","..
	cgmsg.planprice..",'"..AgentModel.GetChannel(pInfo.channel).."')"
	LogModel.GameSqlServer(sqlCase)
	
	-- 插入数据 ex_applytocreateplan
	sqlCase = "insert into ex_applytocreateplan(planid,expertid,title,content,checkstatus,channel,time,planprice,prechannel) value("..
	planid..","..cgmsg.userid..",'"..cgmsg.title.."','"..cgmsg.content.."',"..
	checkstatus..",'"..pInfo.channel.."',"..time..","..
	cgmsg.planprice..",'"..AgentModel.GetChannel(pInfo.channel).."')"
	LogModel.GameSqlServer(sqlCase)
	
	-- 插入数据 ex_planorder
	for i=1,#cgmsg.orderlist do
		
		local racescore = cgmsg.orderlist[i]
		
		sqlCase = "insert into ex_planorder(planid,raceid,rebateid,starttime,category,hometeam,visitteam,score,rebateRatio,fee,yieltype,time,expertid,checkstatus) value("..
		planid..",'"..racescore.raceId.."','"..racescore.rebateId.."',"..racescore.startTime..",'"..racescore.category.."','"..
		racescore.homeTeam.."','"..racescore.visitTeam.."','"..racescore.score.."',"..racescore.rebateRatio..","..
		racescore.fee..","..racescore.yieltype..","..time..","..cgmsg.userid..","..checkstatus..")"
		LogModel.GameSqlServer(sqlCase)
	
	end
	
	
	-- 将方案添加赛事相关集合
	for i=1,#cgmsg.orderlist do
		local racescore = cgmsg.orderlist[i]
		ExpertModel.AddRaceOfPlan(racescore.raceId, planid, 0, time, pInfo.channel)
		
		ExpertModel.AddRaceOfExpert(racescore.raceId, cgmsg.userid, pInfo.channel)
	end
	
	ExpertModel.SysCountPlanNums(pInfo.channel, 1)
	
	gcmsg.result = 0
	return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
end

