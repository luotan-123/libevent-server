module("ExpertApplyToExpert",package.seeall)

--申请成为专家
function execute(packetID, operateID, buffer)
	--print("ExpertApplyToExpert")
	
    local cgmsg = msg_expert_pb.cgexpertapplytoexpert()
	local gcmsg = msg_expert_pb.gcexpertapplytoexpert()
	cgmsg:ParseFromString(buffer)
	
	local checkMsg = RedisHelper.CheckRedis(cgmsg.userid,operateID)
	if checkMsg ~= nil then
		LogBehavior.Warning(cgmsg.userid, "expert", "ExpertApplyToExpert", 0,"缓存已存在")
		return cgmsg.userid,0,string.len(checkMsg),checkMsg 
	end	
	
    local pInfo = PlayerModel.GetPlayerInfo(cgmsg.userid)
    if pInfo == nil then
        gcmsg.result = ReturnCode["player_not_exist"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
    end
	
	if cgmsg.style <= 0 or cgmsg.style > 5 then
		gcmsg.result = ReturnCode["param_error"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
	end
	
	-- 已经是专家
	if ExpertModel.IsExpert(cgmsg.userid) then
		gcmsg.result = ReturnCode["already_expert"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
	end
	
	-- 不满足条件
	if ExpertModel.IsCanBecomeExpert(cgmsg.userid) == false then
		gcmsg.result = ReturnCode["not_become_expert"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
	end
    
	
	-- 检查名字
	if ExpertModel.IsIllegalName(cgmsg.nickname) then
		gcmsg.result = ReturnCode["illegal_name"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
	end
	
	
	local firstapply,checkstatus,failmsg = ExpertModel.QueryExpertCheckStatus(cgmsg.userid)
	
	if checkstatus == 1 then
		gcmsg.result = ReturnCode["applying"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
	end
	
	if checkstatus == 3 then
		gcmsg.result = ReturnCode["already_expert"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
	end
	
	local time = TimeUtils.GetTime()
	local prechannel = AgentModel.GetChannel(pInfo.channel)
	local checkstatus = 1
	
	-- 数据库中插入数据或者更新数据
	if firstapply then --插入数据

		local sqlCase = "insert into ex_applytoexpert(userid,nickname,face,style,checkstatus,channel,prechannel,time,content) value("..
		cgmsg.userid..",'"..cgmsg.nickname.."','"..cgmsg.face.."',"..cgmsg.style..","..checkstatus..
		",'"..pInfo.channel.."','"..prechannel.."',"..time..",'"..cgmsg.content.."')"
		
		LogModel.GameSqlServer(sqlCase)
		
	else -- 重新申请，更新数据
		
		local sqlCase = "update ex_applytoexpert set nickname='"..cgmsg.nickname..
		"',face='"..cgmsg.face..
		"',style="..cgmsg.style..
		",checkstatus="..checkstatus..
		",time="..time..
		",content='"..cgmsg.content.."'"..
		" where userid="..cgmsg.userid
		mysqlItem:execute(sqlCase)
		--LogModel.GameSqlServer(sqlCase)
		
	end
	

	gcmsg.result = 0
	return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
end

