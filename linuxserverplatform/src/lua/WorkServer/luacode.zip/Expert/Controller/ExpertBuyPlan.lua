module("ExpertBuyPlan",package.seeall)

--购买方案
--购买方案之后，默认是否默认就关注了方案
function execute(packetID, operateID, buffer)
	--print("ExpertBuyPlan")
	
    local cgmsg = msg_expert_pb.cgexpertbuyplan()
	local gcmsg = msg_expert_pb.gcexpertbuyplan()
	cgmsg:ParseFromString(buffer)
	
	local checkMsg = RedisHelper.CheckRedis(cgmsg.userid,operateID)
	if checkMsg ~= nil then
		LogBehavior.Warning(cgmsg.userid, "expert", "ExpertBuyPlan", 0,"缓存已存在")
		return cgmsg.userid,0,string.len(checkMsg),checkMsg 
	end	
	
    local pInfo = PlayerModel.GetPlayerInfo(cgmsg.userid)
    if pInfo == nil then
        gcmsg.result = ReturnCode["player_not_exist"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
    end
	if PlayerModel.CheckTestUserLimit(pInfo,g_test_userfunc_limit[2])  then
        --测试用户不能购买方案
        gcmsg.result = ReturnCode["test_user_funclimit"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
    end

	gcmsg.planid = cgmsg.planid
	
	local time = TimeUtils.GetTime()
	local expertid = 0
	local planprice = 0
	local checkstatus = 0
	local plantime = 0
	local plantitle = ""
	
	-- 查询方案是否存在，以及价格
	local sqlCase = "select expertid,checkstatus,planprice,plantime,plantitle from ex_plan where planid="..cgmsg.planid
	mysqlItem:executeQuery(sqlCase)
	local sqlData = mysqlItem:fetch({})
	if sqlData ~= nil then
		expertid = tonumber(sqlData[1])
		checkstatus = tonumber(sqlData[2])
		planprice = tonumber(sqlData[3])
		plantime = tonumber(sqlData[4])
		plantitle = sqlData[5]
	else
		
		gcmsg.result = 0
		gcmsg.returncode = 1
		gcmsg.msg = "方案不存在"
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
	end
	
	
	if time > plantime then
		gcmsg.result = 0
		gcmsg.returncode = 1
		gcmsg.msg = "方案购买时间截止"
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
	end
	
	
	if expertid == cgmsg.userid then
		
		gcmsg.result = 0
		gcmsg.returncode = 1
		gcmsg.msg = "不能购买自己的方案"
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
	end
	
	if checkstatus ~= 3 then
		
		gcmsg.result = 0
		gcmsg.returncode = 1
		gcmsg.msg = "方案没有审核成功"
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
	end
	
	if checkstatus == 4 then
		
		gcmsg.result = 0
		gcmsg.returncode = 1
		gcmsg.msg = "方案已经被下架"
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
	end
	
	-- 判断是否购买过方案
	if ExpertModel.IsBuyPlan(cgmsg.userid, cgmsg.planid) then
		
		gcmsg.result = 0
		gcmsg.returncode = 1
		gcmsg.msg = "已经购买过方案"
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
	end
	
	
	-- 判断身上金币够不够
	if planprice > tonumber(pInfo.jetton) then
		
		gcmsg.result = 0
		gcmsg.returncode = 1
		gcmsg.msg = "您的余额不足"
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
    end
	
	ExpertModel.BuyPlan(cgmsg.userid, cgmsg.planid, time, expertid, planprice)
	
	--扣钱
	PlayerModel.DecJetton(pInfo, planprice, g_expertDefine.game_type, "购买方案")		
	PlayerModel.SendJetton(pInfo)
	local orderid = LogServer.GetNewLogOrderid()
	--生成交易记录
	LogServer.addRecords(pInfo.userid, 2, "购买方案", -planprice, orderid)
	
	--生成操作记录
	local msg = "玩家购买方案id"..cgmsg.planid
	LogServer.GameUserMoney(pInfo, g_expertDefine.game_type, 1, -planprice, msg, 0,0,g_moneyOptType.opt_buy_plan,orderid)
	
	
	--给专家加钱
	local pInfoExpert = PlayerModel.GetPlayerInfo(expertid)
    if pInfoExpert ~= nil then
		PlayerModel.AddJetton(pInfoExpert, planprice, g_expertDefine.game_type, "售卖方案")
		--PlayerModel.SetPlayerInfo(pInfoExpert)
		local orderid = LogServer.GetNewLogOrderid()
		--生成操作记录
		local msg = "售卖方案id"..cgmsg.planid
		LogServer.GameUserMoney(pInfoExpert, g_expertDefine.game_type, 1, planprice, msg, 0,0,g_moneyOptType.opt_sell_plan,orderid)
	
		PlayerModel.SendJetton(pInfoExpert)
		
		--生成交易记录
		LogServer.addRecords(pInfoExpert.userid, 1, "售卖方案", planprice, orderid)
		
		
		AgentModel.UserWinCount(pInfoExpert.userid, planprice)
    end
	
	--生存方案售卖记录
	local sqlCase = "insert into ex_sellplan(expertid,purchaser,planid,plantitle,plantime,price,time) value("..
	expertid..","..cgmsg.userid..","..cgmsg.planid..",'"..plantitle.."',"..plantime..","..
	planprice..","..time..")"
	LogModel.GameSqlServer(sqlCase)
	
	--填充新的比分发送
	-- 查询选择的比分
	local sqlCase = "select * from ex_planorder where planid="..cgmsg.planid
	mysqlItem:executeQuery(sqlCase)
	while true do
		local sqlData = mysqlItem:fetch({})
		if sqlData == nil then
			break
		end
		
		-- 填充比分信息
		local racescore = gcmsg.orderlist:add()
		
		racescore.rebateId				= sqlData[4]
		racescore.raceId				= sqlData[3]
		racescore.startTime 			= sqlData[5]
		racescore.homeTeam 				= sqlData[7]
		racescore.visitTeam 			= sqlData[8]
		racescore.category 				= sqlData[6]
		racescore.score					= sqlData[9]
		racescore.rebateRatio			= sqlData[10]
		racescore.fee					= tonumber(sqlData[11])
		racescore.yieltype  			= tonumber(sqlData[12])
		racescore.planraceid			= sqlData[1]
	end
	
	
	ExpertModel.SysCountBuyPlanInfo(pInfo.channel, planprice)
	

	gcmsg.returncode = 0
	gcmsg.msg = "方案购买成功"
	gcmsg.result = 0
	return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
end

