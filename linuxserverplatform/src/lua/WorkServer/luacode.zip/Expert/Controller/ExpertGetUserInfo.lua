module("ExpertGetUserInfo",package.seeall)

--获取专家简单信息
function execute(packetID, operateID, buffer)
	--print("ExpertGetUserInfo")
	
    local cgmsg = msg_expert_pb.cgexpertgetuserinfo()
	local gcmsg = msg_expert_pb.gcexpertgetuserinfo()
	cgmsg:ParseFromString(buffer)
	
	local checkMsg = RedisHelper.CheckRedis(cgmsg.userid,operateID)
	if checkMsg ~= nil then
		LogBehavior.Warning(cgmsg.userid, "expert", "ExpertGetUserInfo", 0,"缓存已存在")
		return cgmsg.userid,0,string.len(checkMsg),checkMsg 
	end	
	
    local pInfo = PlayerModel.GetPlayerInfo(cgmsg.userid)
    if pInfo == nil then
        gcmsg.result = ReturnCode["player_not_exist"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
    end
	
	
	--查询数据库
	local sqlCase = "select * from ex_player where userid="..cgmsg.expertid
	mysqlItem:executeQuery(sqlCase)
	local sqlData = mysqlItem:fetch({})
	if sqlData ~= nil then
		
		gcmsg.expertid 			= cgmsg.expertid
		gcmsg.nickname			= sqlData[2]
		gcmsg.face 				= sqlData[3]
		gcmsg.level 			= tonumber(sqlData[5])
		gcmsg.title 			= sqlData[6]
		gcmsg.fanscount 		= tonumber(sqlData[12])
		gcmsg.content 			= sqlData[7] or ""
		
		-- 函数内部有查询，放到后面
		gcmsg.isconcerned		= ExpertModel.IsAddConcernedExpert(cgmsg.userid, cgmsg.expertid) and 1 or 0
		
	else
		gcmsg.result = ReturnCode["expert_no_exit"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
	end

	
	gcmsg.result = 0
	return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
end

