module("ExpertAddConcerned",package.seeall)

--关注专家
function execute(packetID, operateID, buffer)
	--print("ExpertAddConcerned")
	
    local cgmsg = msg_expert_pb.cgexpertaddconcerned()
	local gcmsg = msg_expert_pb.gcexpertaddconcerned()
	cgmsg:ParseFromString(buffer)
	
	local checkMsg = RedisHelper.CheckRedis(cgmsg.userid,operateID)
	if checkMsg ~= nil then
		LogBehavior.Warning(cgmsg.userid, "expert", "ExpertAddConcerned", 0,"缓存已存在")
		return cgmsg.userid,0,string.len(checkMsg),checkMsg 
	end	
	
    local pInfo = PlayerModel.GetPlayerInfo(cgmsg.userid)
    if pInfo == nil then
        gcmsg.result = ReturnCode["player_not_exist"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
    end
	
	
	if ExpertModel.IsExpert(cgmsg.expertid) == false then
		gcmsg.result = ReturnCode["expert_no_exit"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
	end
  
    if cgmsg.userid == cgmsg.expertid then
		gcmsg.result = ReturnCode["no_concern_myself"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
	end
	
	ExpertModel.AddConcernedExpert(cgmsg.userid, cgmsg.expertid, cgmsg.reqtype, TimeUtils.GetTime())
	
	ExpertModel.AddWeekPopuRank(cgmsg.expertid, cgmsg.reqtype==1 and 1 or -1, pInfo.channel)
	
	gcmsg.reqtype = cgmsg.reqtype
	gcmsg.expertid = cgmsg.expertid
	gcmsg.msg = "成功"
	
	gcmsg.result = 0
	return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
end

