module("ExpertWeekRankList",package.seeall)

--专家---周榜 ，做渠道号区分
function execute(packetID, operateID, buffer)
	--print("ExpertWeekRankList")
	
    local cgmsg = msg_expert_pb.cgexpertweekranklist()
	local gcmsg = msg_expert_pb.gcexpertweekranklist()
	cgmsg:ParseFromString(buffer)
	
	local checkMsg = RedisHelper.CheckRedis(cgmsg.userid,operateID)
	if checkMsg ~= nil then
		LogBehavior.Warning(cgmsg.userid, "expert", "ExpertWeekRankList", 0,"缓存已存在")
		return cgmsg.userid,0,string.len(checkMsg),checkMsg 
	end	
	
    local pInfo = PlayerModel.GetPlayerInfo(cgmsg.userid)
    if pInfo == nil then
        gcmsg.result = ReturnCode["player_not_exist"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
    end
	
	
	gcmsg.reqtype = cgmsg.reqtype
	
	local keyStr = ""
	local weekStr = TimeUtils.GetWeekString()
	
	
	-- 查询周榜数据
	if cgmsg.reqtype == 1 then --周盈利榜
	
		keyStr = ExpertModel.WeekIncomeRank..pInfo.channel.."_"..weekStr
	else  -- 周人气榜
		keyStr = ExpertModel.WeekPopuRank..pInfo.channel.."_"..weekStr
	end
	
	local userList = redisItem:zrevrange(keyStr, 0, 9, ExpertModel.redis_index, "withscores")
	
	for k,v_item in ipairs(userList) do
		
		--查询数据库
		local sqlCase = "select * from ex_player where userid="..v_item[1]
		mysqlItem:executeQuery(sqlCase)
		local sqlData = mysqlItem:fetch({})
		if sqlData ~= nil then
			
			local userdata = gcmsg.user:add()
			userdata.expertid = tonumber(v_item[1])
			userdata.name = sqlData[2]
			userdata.face = sqlData[3]
			userdata.level = tonumber(sqlData[5])
			userdata.title = sqlData[6]
			
			userdata.rank = k
			
			--userdata.hitcount = 0 --tonumber(sqlData[8])
			userdata.nearhitrate = sqlData[9]
			userdata.wintype = ExpertModel.GetExpertWinType(tonumber(sqlData[8]), tonumber(sqlData[26]), tonumber(sqlData[27]))
			userdata.hitcount = userdata.wintype --tonumber(sqlData[8])
			userdata.averate = sqlData[10]
			userdata.winrate = tostring(v_item[2])
			
			userdata.fanscount = tonumber(sqlData[12])
			
			-- 函数内部有查询，放到后面
			userdata.isconcerned = ExpertModel.IsAddConcernedExpert(cgmsg.userid, userdata.expertid) and 1 or 0
			
			-- 从别的表获取数据
			userdata.weekhot = tonumber(v_item[2])	
			userdata.newfans = tonumber(v_item[2])		
			
			
		else
			redisItem:zrem(keyStr, v_item[1], ExpertModel.redis_index)
		end
		
	end
	
	
	gcmsg.result = 0
	return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
end

