module("ExpertGetOtherPlanInfo",package.seeall)

--查看别人的方案详情
function execute(packetID, operateID, buffer)
	--print("ExpertGetOtherPlanInfo")
	
    local cgmsg = msg_expert_pb.cgexpertgetotherplaninfo()
	local gcmsg = msg_expert_pb.gcexpertgetotherplaninfo()
	cgmsg:ParseFromString(buffer)
	
	local checkMsg = RedisHelper.CheckRedis(cgmsg.userid,operateID)
	if checkMsg ~= nil then
		LogBehavior.Warning(cgmsg.userid, "expert", "ExpertGetOtherPlanInfo", 0,"缓存已存在")
		return cgmsg.userid,0,string.len(checkMsg),checkMsg 
	end	
	
    local pInfo = PlayerModel.GetPlayerInfo(cgmsg.userid)
    if pInfo == nil then
        gcmsg.result = ReturnCode["player_not_exist"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
    end
	
	local time = TimeUtils.GetTime()
	local expertid = 0;
	gcmsg.allincmerate = 0.0
	
	--查询方案
	local sqlCase = "select * from ex_plan where planid="..cgmsg.planid
	mysqlItem:executeQuery(sqlCase)
	local sqlData = mysqlItem:fetch({})
	if sqlData ~= nil then
		
		if tonumber(sqlData[8]) == 4 then
			gcmsg.result = ReturnCode["plan_forbid"]
			return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
		end
		
		expertid = tonumber(sqlData[2])
		
		-- 填充方案信息
		gcmsg.remaintime = tonumber(sqlData[6]) - time
		gcmsg.content = sqlData[4]
		gcmsg.planprice = tonumber(sqlData[12])
		
		gcmsg.isbuy = ExpertModel.IsBuyPlan(cgmsg.userid, cgmsg.planid) and 1 or 0
		gcmsg.isconcerned = ExpertModel.IsAddConcernedExpert(cgmsg.userid, expertid) and 1 or 0
		gcmsg.isconcernedplan = ExpertModel.IsAddConcernedPlan(cgmsg.userid, cgmsg.planid) and 1 or 0
		
	else  -- 不存该数据
		gcmsg.result = ReturnCode["plan_no_exists"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
	end
	
	
	
	-- 查询选择的比分
	local sqlCase = "select * from ex_planorder where planid="..cgmsg.planid
	mysqlItem:executeQuery(sqlCase)
	while true do
		local sqlData = mysqlItem:fetch({})
		if sqlData == nil then
			break
		end
		
		-- 填充比分信息
		local racescore = gcmsg.orderlist:add()
		
		racescore.rebateId				= sqlData[4]
		racescore.raceId				= sqlData[3]
		racescore.startTime 			= sqlData[5]
		racescore.homeTeam 				= sqlData[7]
		racescore.visitTeam 			= sqlData[8]
		racescore.category 				= sqlData[6]
		racescore.score					= sqlData[9]
		racescore.rebateRatio			= sqlData[10]
		racescore.fee					= tonumber(sqlData[11])
		racescore.yieltype  			= tonumber(sqlData[12])
		racescore.planraceid			= sqlData[1]
		
		-- 统计预期收益率
		gcmsg.allincmerate = gcmsg.allincmerate + tonumber(racescore.rebateRatio)
		
		-- 查看是否有赛事已经结束，如果结束，方案跟投时间截止
		if gcmsg.remaintime > 0 then
			local raceinfopb = RaceInfoModel.GetRaceInfo(racescore.raceId)
			if raceinfopb then
				local raceinfo = st_footballgame_pb.MerchantRaceInfoDto()
				raceinfo:ParseFromString(raceinfopb)
				
				if raceinfo.raceStatus ~= 3 then
					gcmsg.remaintime = 0
				end
			end
		end
		
	end
	
	for i=1,#gcmsg.orderlist do
		
		local racescore = gcmsg.orderlist[i]
		
		-- 如果方案没有购买并且没有更投，方案不能查看比分和收益
		if expertid ~= cgmsg.userid and ExpertModel.IsLookPlanScoreInfo(cgmsg.userid, cgmsg.planid, tonumber(racescore.planraceid)) == false then
			
			racescore.score					= "***" 
			racescore.rebateRatio			= "***" 
		end	
	end
	

	--gcmsg.allincmerate = gcmsg.allincmerate / (#gcmsg.orderlist)
	
	
	-- 查询专家接口
	local sqlCase = "select * from ex_player where userid="..expertid
	mysqlItem:executeQuery(sqlCase)
	local sqlData = mysqlItem:fetch({})
	if sqlData ~= nil then
		
		local expertinfo = gcmsg.expert;
		
		-- 填充专家信息
		expertinfo.userid = tonumber(sqlData[1])
		expertinfo.nickname = sqlData[2]
		expertinfo.face = sqlData[3]
		expertinfo.level = tonumber(sqlData[5])
		expertinfo.title = sqlData[6]
		expertinfo.style = tonumber(sqlData[4])
		expertinfo.nearhitrate = tonumber(sqlData[9])
		expertinfo.wintype = ExpertModel.GetExpertWinType(tonumber(sqlData[8]), tonumber(sqlData[26]), tonumber(sqlData[27]))
		expertinfo.hitcount = expertinfo.wintype --tonumber(sqlData[8])
		expertinfo.averagerate = tonumber(sqlData[10])
		
	end
		
	
	gcmsg.result = 0
	return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
end

