module("ExpertHotList",package.seeall)

--热门专家，默认发送8个 ，做渠道号区分
function execute(packetID, operateID, buffer)
	--print("ExpertHotList")
	
    local cgmsg = msg_expert_pb.cgexperthotlist()
	local gcmsg = msg_expert_pb.gcexperthotlist()
	cgmsg:ParseFromString(buffer)
	
	local checkMsg = RedisHelper.CheckRedis(cgmsg.userid,operateID)
	if checkMsg ~= nil then
		LogBehavior.Warning(cgmsg.userid, "expert", "ExpertHotList", 0,"缓存已存在")
		return cgmsg.userid,0,string.len(checkMsg),checkMsg 
	end	
	
    local pInfo = PlayerModel.GetPlayerInfo(cgmsg.userid)
    if pInfo == nil then
        gcmsg.result = ReturnCode["player_not_exist"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
    end
	
	
	local sqlCase = "select userid,nickname,face,score from ex_player where channel='"..pInfo.channel.."' order by score desc limit 8"
	mysqlItem:executeQuery(sqlCase)
	while true do
		local sqlData = mysqlItem:fetch({})
		if sqlData == nil then
			break
		end
		
		-- 添加专家信息
		local user = gcmsg.user:add()
		
		user.expertid = tonumber(sqlData[1])
		user.name = sqlData[2]
		user.face = sqlData[3]
		user.score = tonumber(sqlData[4])
	end
	
	
	gcmsg.pagenum = cgmsg.pagenum
	gcmsg.allnum = 8
	
	gcmsg.result = 0
	return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
end