module("ExpertLookMyInfo",package.seeall)

--查看自己的信息
function execute(packetID, operateID, buffer)
	--print("ExpertLookMyInfo")
	
    local cgmsg = msg_expert2_pb.cgexpertlookmyinfo()
	local gcmsg = msg_expert2_pb.gcexpertlookmyinfo()
	cgmsg:ParseFromString(buffer)
	
	local checkMsg = RedisHelper.CheckRedis(cgmsg.userid,operateID)
	if checkMsg ~= nil then
		LogBehavior.Warning(cgmsg.userid, "expert", "ExpertLookMyInfo", 0,"缓存已存在")
		return cgmsg.userid,0,string.len(checkMsg),checkMsg 
	end	
	
    local pInfo = PlayerModel.GetPlayerInfo(cgmsg.userid)
    if pInfo == nil then
        gcmsg.result = ReturnCode["player_not_exist"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
    end
	
	local weekStr = TimeUtils.GetWeekString()
	
	--查询数据库
	local sqlCase = "select * from ex_player where userid="..cgmsg.userid
	mysqlItem:executeQuery(sqlCase)
	local sqlData = mysqlItem:fetch({})
	if sqlData ~= nil then
		
		gcmsg.expertid 			= cgmsg.userid
		gcmsg.name				= sqlData[2]
		gcmsg.face 				= sqlData[3]
		gcmsg.level 			= tonumber(sqlData[5])
		gcmsg.title 			= sqlData[6]
		gcmsg.style 			= tonumber(sqlData[4])
		gcmsg.concernedcount 	= redisItem:zcard(ExpertModel.ConcernedExpertZSet..cgmsg.userid, ExpertModel.redis_index) or 0
		gcmsg.fanscount 		= tonumber(sqlData[12])
		gcmsg.content 			= sqlData[7]
		
		if sqlData[25] == weekStr then
			--以下都是本周数据
			
			gcmsg.buymoney			= sqlData[15]
			gcmsg.followmoney		= sqlData[16]
			gcmsg.commissionrate	= ExpertModel.GetExpertcommissionType(gcmsg.style)
			
			gcmsg.commissionincome	= tostring(tonumber(gcmsg.followmoney) * gcmsg.commissionrate)
			gcmsg.weekincome		= tostring(tonumber(gcmsg.buymoney) + tonumber(gcmsg.commissionincome))
			
		
		else
			
			--以下都是本周数据
			gcmsg.weekincome		= "0"
			gcmsg.buymoney			= "0"
			gcmsg.followmoney		= "0"
			gcmsg.commissionrate	= 0
			gcmsg.commissionincome	= "0"
			
			-- 记录本周已经清理
			local sqlCase = "update ex_player set weekcleartime='"..weekStr..
			"',allincome=0"..
			",allbuymoney=0"..
			",allfollowmoney=0"..
			",commissionrate=0"..
			",commissionincome=0"..
			" where userid="..cgmsg.userid
			mysqlItem:execute(sqlCase)
			
		end
		
		
	else
		gcmsg.result = ReturnCode["expert_no_exit"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
	end
	
	
	gcmsg.result = 0
	return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
end

