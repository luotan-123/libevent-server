module("ExpertPourPlan",package.seeall)

--获取赛事状态
function execute(packetID, operateID, buffer)
	--print("ExpertPourPlan")
	
    local cgmsg = msg_expert2_pb.cgexpertpourplan()
	local gcmsg = msg_expert2_pb.gcexpertpourplan()
	cgmsg:ParseFromString(buffer)
	
	local checkMsg = RedisHelper.CheckRedis(cgmsg.userid,operateID)
	if checkMsg ~= nil then
		LogBehavior.Warning(cgmsg.userid, "expert", "ExpertPourPlan", 0,"缓存已存在")
		return cgmsg.userid,0,string.len(checkMsg),checkMsg 
	end	
	
    local pInfo = PlayerModel.GetPlayerInfo(cgmsg.userid)
    if pInfo == nil then
        gcmsg.result = ReturnCode["player_not_exist"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
    end
	
	
	local time = TimeUtils.GetTime()
	local expertid = 0
	
	
	--查询方案
	local plantime = 0
	local checkstatus = 0
	local sqlCase = "select plantime,checkstatus,expertid from ex_plan where planid="..cgmsg.planid
	mysqlItem:executeQuery(sqlCase)
	local sqlData = mysqlItem:fetch({})
	if sqlData ~= nil then
		plantime = tonumber(sqlData[1])
		checkstatus = tonumber(sqlData[2])
		expertid = tonumber(sqlData[3])
	else  -- 不存该数据
		gcmsg.result = ReturnCode["plan_no_exists"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
	end
	
	if time > plantime then
		gcmsg.result = ReturnCode["pour_time_end"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
	end
	
	if checkstatus ~= 3 then
		gcmsg.result = ReturnCode["plan_forbid"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
	end
	
	
	-- 判断身上金币够不够
	if cgmsg.pourjetton > tonumber(pInfo.jetton) then
		gcmsg.result = ReturnCode["carryjetton_not_enough"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
    end
	
	if cgmsg.pourjetton > 2000000 then
		gcmsg.result = ReturnCode["pour_limit"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
    end
	
	
	--[[if ExpertModel.IsPourPlan(cgmsg.userid,cgmsg.planid) then
		gcmsg.result = ReturnCode["already_pour_plan"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
	end--]]
	
	
	local count = 0;
	local raceid = ""
	local planraceid = 0
	local orderid = ""
	local dataArr = {}
	-- 查询选择的比分
	local sqlCase = "select id,planid,raceid,rebateid from ex_planorder where planid="..cgmsg.planid.." order by starttime"
	mysqlItem:executeQuery(sqlCase)
	while true do
		local sqlData = mysqlItem:fetch({})
		if sqlData == nil then
			break
		end
		
		local datainfo = {}
		datainfo.planraceid = tonumber(sqlData[1])
		datainfo.planid = tonumber(sqlData[2])
		datainfo.raceid = sqlData[3]
		datainfo.rebateId = sqlData[4]
		
		table.insert(dataArr, datainfo)
	end
		
		
	for i=1,#dataArr do
		
		local datainfo = dataArr[i]
		
		if count == 0 then -- 直接投注
			
			local rebateId = datainfo.rebateId
			raceid = datainfo.raceid
			planraceid = datainfo.planraceid
			
			 --单个下注区域的信息 
			local SimpleRebateInfoPB = RaceInfoModel.GetRaceRebateInfo(raceid, rebateId)
			local SimpleRebateInfo = st_footballgame_pb.SimpleRebateInfo()
			SimpleRebateInfo:ParseFromString(SimpleRebateInfoPB)
	
			local pourinfo = msg_footballgame_pb.cgfootballpourinfo()
			
			
			pourinfo.userid			= cgmsg.userid
			pourinfo.eventid		= raceid
			pourinfo.yieltype		= SimpleRebateInfo.ruleType - 1
			--pourinfo.subtype		= 0
			pourinfo.typescore		= SimpleRebateInfo.score
			pourinfo.baoval			= SimpleRebateInfo.baoval
			pourinfo.tiyan			= SimpleRebateInfo.tiyan
			pourinfo.pourjetton		= tostring(cgmsg.pourjetton)
			pourinfo.typourjetton	= "0"
			pourinfo.rebateId		= rebateId
			pourinfo.isBet			= 0
			--pourinfo.wlpourtype	= 0
			pourinfo.schemeid		= cgmsg.planid
			pourinfo.expertid		= expertid
			pourinfo.planraceid		= planraceid
			pourinfo.isinsertorder	= 0
			--pourinfo.cardid		= ""
			
			orderid = FootballService.dealPlanOrder(pourinfo)
			if tonumber(orderid) == nil then
				print(orderid)
				LogFile("error", "跟投失败, planid="..cgmsg.planid..","..orderid)
			end
			
		else -- 预设投注
			
			--redisItem:rpush(ExpertModel.PourPlanRaceList..raceid, cgmsg.userid.."|"..cgmsg.planid.."|"..planraceid.."|"..orderid, ExpertModel.redis_index)
			
			break
		end
		
		count = count + 1
		
	end
	
	
	-- 记录跟投过
	ExpertModel.RecordPourPlan(cgmsg.userid, cgmsg.planid, time, expertid)
	
	-- 统计系统数据
	ExpertModel.SysCountPourPlanInfo(pInfo.channel, cgmsg.pourjetton)
  
	gcmsg.result = 0
	return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
end

