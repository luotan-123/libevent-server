module("ExpertGetRaceStatus",package.seeall)

--获取赛事状态
function execute(packetID, operateID, buffer)
	--print("ExpertGetRaceStatus")
	
    local cgmsg = msg_expert2_pb.cgexpertgetracestatus()
	local gcmsg = msg_expert2_pb.gcexpertgetracestatus()
	cgmsg:ParseFromString(buffer)
	
	local checkMsg = RedisHelper.CheckRedis(cgmsg.userid,operateID)
	if checkMsg ~= nil then
		LogBehavior.Warning(cgmsg.userid, "expert", "ExpertGetRaceStatus", 0,"缓存已存在")
		return cgmsg.userid,0,string.len(checkMsg),checkMsg 
	end	
	
    local pInfo = PlayerModel.GetPlayerInfo(cgmsg.userid)
    if pInfo == nil then
        gcmsg.result = ReturnCode["player_not_exist"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
    end
	
	
	 --获取赛事信息
    local raceinfopb = RaceInfoModel.GetRaceInfo(cgmsg.raceid)
    
	if raceinfopb == nil then
		gcmsg.result = 0 --ReturnCode["event_not_exit"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
	end

    --解析赛事
    local raceinfo = st_footballgame_pb.MerchantRaceInfoDto()
	raceinfo:ParseFromString(raceinfopb)
	
	gcmsg.winResult = raceinfo.winResult
	gcmsg.raceid = cgmsg.raceid
	gcmsg.racestatus = raceinfo.raceStatus
	gcmsg.tag = cgmsg.tag
	
	gcmsg.result = 0
	return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
end

