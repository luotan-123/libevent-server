module("GetRacePlan",package.seeall)

----获取赛事相关的方案
function execute(packetID, operateID, buffer)
	--print("GetRacePlan")
	
    local cgmsg = msg_expert2_pb.cggetraceplan()
	local gcmsg = msg_expert2_pb.gcgetraceplan()
	cgmsg:ParseFromString(buffer)
	
	local checkMsg = RedisHelper.CheckRedis(cgmsg.userid,operateID)
	if checkMsg ~= nil then
		LogBehavior.Warning(cgmsg.userid, "expert", "GetRacePlan", 0,"缓存已存在")
		return cgmsg.userid,0,string.len(checkMsg),checkMsg 
	end	
	
    local pInfo = PlayerModel.GetPlayerInfo(cgmsg.userid)
    if pInfo == nil then
        gcmsg.result = ReturnCode["player_not_exist"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
    end
	
	local time = TimeUtils.GetTime()
	local count = 0
	local planlist = ExpertModel.GetRaceOfPlan(cgmsg.raceid, 100, pInfo.channel)

	
	for k,planid in ipairs(planlist) do
		
		if count >= 20 then
			break
		end
		
		--查询方案
		local sqlCase = "select * from ex_plan where planid="..planid
		mysqlItem:executeQuery(sqlCase)
		local sqlData = mysqlItem:fetch({})
		if sqlData ~= nil then
		
			local checkstatus = tonumber(sqlData[8])
			if checkstatus == 3 then
				
				local userdata = gcmsg.datas:add()
				
				-- 填充方案信息
				userdata.planid = tonumber(sqlData[1])
				userdata.expertid = tonumber(sqlData[2])
				userdata.plantitle 	= sqlData[3]
				userdata.rsign 		= tonumber(sqlData[5])
				userdata.plantime 	= sqlData[6]
				userdata.guessprofit = tonumber(sqlData[7])
				userdata.checkstatus = checkstatus
				userdata.time = sqlData[11]
				userdata.failreason = sqlData[9]
				userdata.remaintime = tonumber(userdata.plantime) - time
				
				count = count + 1
				
			end
		else
			
			redisItem:zrem(ExpertModel.RaceOfPlanZset..cgmsg.raceid, planid, ExpertModel.redis_index)
		end
	end
	
	
	-- 填充比分信息
	for i=1,#gcmsg.datas do
		-- 查询选择的比分
		local sqlCase = "select * from ex_planorder where planid="..gcmsg.datas[i].planid
		mysqlItem:executeQuery(sqlCase)
		while true do
			local sqlData = mysqlItem:fetch({})
			if sqlData == nil then
				break
			end
			
			-- 填充比分信息
			local racescore = gcmsg.datas[i].orderlist:add()
			
			racescore.rebateId				= sqlData[4]
			racescore.raceId				= sqlData[3]
			racescore.startTime 			= sqlData[5]
			racescore.homeTeam 				= sqlData[7]
			racescore.visitTeam 			= sqlData[8]
			racescore.category 				= sqlData[6]
			racescore.score					= "***" --sqlData[9]
			racescore.rebateRatio			= "***" --sqlData[10]
			racescore.fee					= tonumber(sqlData[11])
			racescore.yieltype  			= tonumber(sqlData[12])
			racescore.planraceid			= sqlData[1]
		end
		
	end

    
	-- 获取总数
	gcmsg.allnum = 20
	gcmsg.pagenum = cgmsg.pagenum
  

	gcmsg.result = 0
	return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
end

