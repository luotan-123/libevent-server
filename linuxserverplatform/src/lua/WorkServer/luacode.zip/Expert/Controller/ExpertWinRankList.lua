module("ExpertWinRankList",package.seeall)

--首页---盈利排行榜(是玩家排行榜) ，做渠道号区分
function execute(packetID, operateID, buffer)
	--print("ExpertWinRankList")
	
    local cgmsg = msg_expert_pb.cgexpertwinranklist()
	local gcmsg = msg_expert_pb.gcexpertwinranklist()
	cgmsg:ParseFromString(buffer)
	
	local checkMsg = RedisHelper.CheckRedis(cgmsg.userid,operateID)
	if checkMsg ~= nil then
		LogBehavior.Warning(cgmsg.userid, "expert", "ExpertWinRankList", 0,"缓存已存在")
		return cgmsg.userid,0,string.len(checkMsg),checkMsg 
	end	
	
    local pInfo = PlayerModel.GetPlayerInfo(cgmsg.userid)
    if pInfo == nil then
        gcmsg.result = ReturnCode["player_not_exist"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
    end
	
	local sqlCase = ""
	
	-- 从log_player表获取排行榜
	if cgmsg.reqtype == 1 then  --收益排行榜
		
		sqlCase = "select userid,nickname,zhanjiamount from log_player where channel='"..pInfo.channel.."' order by zhanjiamount desc limit 10"
		
	elseif cgmsg.reqtype == 2 then --收益率排行榜
		
		sqlCase = "select userid,nickname,incomerate from log_player where channel='"..pInfo.channel.."' order by incomerate desc limit 10"
		
	else -- 连胜场次
		
		sqlCase = "select userid,nickname,winscount from log_player where channel='"..pInfo.channel.."' order by winscount desc limit 10"
		
	end
	
	local rankIndex = 1
	mysqlLog:executeQuery(sqlCase)
	while true do
		local sqlData = mysqlLog:fetch({})
		if sqlData == nil then
			break
		end
		
		local user = gcmsg.user:add()
		user.expertid = tonumber(sqlData[1])
		user.name = sqlData[2] or "nickname"
		user.followcount = 0
		user.rank = rankIndex
		user.num = tonumber(sqlData[3])
		
		rankIndex = rankIndex + 1
	end
	
	-- 填充跟单次数
	for i=1,#gcmsg.user do
		
		sqlCase = "select COUNT(*) from dy_footballorder where userid="..gcmsg.user[i].expertid.." and schemeid>0"
		mysqlItem:executeQuery(sqlCase)
		local sqlData = mysqlItem:fetch({})
		if sqlData ~= nil then
			gcmsg.user[i].followcount = tonumber(sqlData[1])
		end
		
	end
	
	
	gcmsg.reqtype = cgmsg.reqtype
	gcmsg.result = 0
	
	return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
end

