module("ExpertConcernUserList",package.seeall)

--获取关注的玩家
function execute(packetID, operateID, buffer)
	--print("ExpertConcernUserList")
	
    local cgmsg = msg_expert_pb.cgexpertconcernuserlist()
	local gcmsg = msg_expert_pb.gcexpertconcernuserlist()
	cgmsg:ParseFromString(buffer)
	
	local checkMsg = RedisHelper.CheckRedis(cgmsg.userid,operateID)
	if checkMsg ~= nil then
		LogBehavior.Warning(cgmsg.userid, "expert", "ExpertConcernUserList", 0,"缓存已存在")
		return cgmsg.userid,0,string.len(checkMsg),checkMsg 
	end	
	
    local pInfo = PlayerModel.GetPlayerInfo(cgmsg.userid)
    if pInfo == nil then
        gcmsg.result = ReturnCode["player_not_exist"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
    end
	
	
	local startPos = (cgmsg.pagenum - 1)*20
	startPos = startPos < 0 and 0 or startPos
	
	local dataList = ExpertModel.GetConcernUser(cgmsg.userid, startPos, startPos + 19)
	for k,v_userid in ipairs(dataList) do
		
		--查询数据库
		local sqlCase = "select * from ex_player where userid="..v_userid
		mysqlItem:executeQuery(sqlCase)
		local sqlData = mysqlItem:fetch({})
		if sqlData ~= nil then
			
			local userdata = gcmsg.users:add()
			userdata.userid = tonumber(v_userid)
			userdata.nickname = sqlData[2]
			userdata.face = sqlData[3]
			userdata.level = tonumber(sqlData[5])
			userdata.title = sqlData[6]
			userdata.style = tonumber(sqlData[4])
			--userdata.hitcount = 0 --tonumber(sqlData[8])
			userdata.nearhitrate = tonumber(sqlData[9])
			userdata.wintype = ExpertModel.GetExpertWinType(tonumber(sqlData[8]), tonumber(sqlData[26]), tonumber(sqlData[27]))
			userdata.hitcount = userdata.wintype --tonumber(sqlData[8])
			userdata.averagerate = tonumber(sqlData[10])
			
			-- 函数内部有查询，放到后面
			userdata.isaddnotice = ExpertModel.IsAddNotice(cgmsg.userid, v_userid) and 1 or 0
			
		else  --玩家不存在，调用取关接口
			
			ExpertModel.AddConcernedExpert(cgmsg.userid, v_userid, 2, 0)
		end
		
	end
	
	
	gcmsg.pagenum = cgmsg.pagenum
	gcmsg.allnum = ExpertModel.GetConcernUserCount(cgmsg.userid)
	
	gcmsg.result = 0
	return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
end
