module("ExpertAddNotice",package.seeall)

--添加通知
function execute(packetID, operateID, buffer)
	--print("ExpertAddNotice")
	
    local cgmsg = msg_expert_pb.cgexpertaddnotice()
	local gcmsg = msg_expert_pb.gcexpertaddnotice()
	cgmsg:ParseFromString(buffer)
	
	local checkMsg = RedisHelper.CheckRedis(cgmsg.userid,operateID)
	if checkMsg ~= nil then
		LogBehavior.Warning(cgmsg.userid, "expert", "ExpertAddNotice", 0,"缓存已存在")
		return cgmsg.userid,0,string.len(checkMsg),checkMsg 
	end	
	
    local pInfo = PlayerModel.GetPlayerInfo(cgmsg.userid)
    if pInfo == nil then
        gcmsg.result = ReturnCode["player_not_exist"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
    end
	
	if cgmsg.userid == cgmsg.expertid then
		gcmsg.result = ReturnCode["no_notice_myself"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
	end
	
	if ExpertModel.IsExpert(cgmsg.expertid) == false then
		gcmsg.result = ReturnCode["expert_no_exit"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
	end
  
    
	ExpertModel.AddNotice(cgmsg.userid, cgmsg.expertid, cgmsg.reqtype, TimeUtils.GetTime())
	
	gcmsg.reqtype = cgmsg.reqtype
	gcmsg.expertid = cgmsg.expertid
	gcmsg.msg = "成功"
  
	gcmsg.result = 0
	return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
end

