ExpertService = {}


function ExpertService.Init()
	
	print("ExpertService.Init")
	

end


function ExpertService.UtilsLoop()
	
	
	--[[-- 赛事结算触发，跟投
	if g_markTime.curr.sec == 15 then
		processWork("RaceFinishPour","0")
	end
	
	
	-- 赛事取消触发，跟投
	if g_markTime.curr.sec == 45 then
		processWork("RaceCancelPour","0")
	end	--]]

	
end


function ExpertService.PourPlanNextScore(userid, planid, curplanraceid, pourjetton, expertid)
	
	print("PourPlanNextScore:", userid, planid, curplanraceid, pourjetton, expertid)
	
	local count = 0;
	local raceid = ""
	local planraceid = 0
	local orderid = ""
	local dataArr = {}
	-- 查询选择的比分
	local sqlCase = "select id,planid,raceid,rebateid from ex_planorder where planid="..planid.." order by starttime"
	mysqlItem:executeQuery(sqlCase)
	while true do
		local sqlData = mysqlItem:fetch({})
		if sqlData == nil then
			break
		end
		
		local datainfo = {}
		datainfo.planraceid = tonumber(sqlData[1])
		datainfo.planid = tonumber(sqlData[2])
		datainfo.raceid = sqlData[3]
		datainfo.rebateId = sqlData[4]
		
		table.insert(dataArr, datainfo)
	end
	
	for i=1,#dataArr do
		
		local datainfo = dataArr[i]
		
		
		if count == 1 then -- 投注该赛事
			
			-- 获得相关信息
			local rebateId = datainfo.rebateId
			raceid = datainfo.raceid
			planraceid = datainfo.planraceid
		
			-- 判断是否插单
			local isinsertorder = 0
			
			-- 获取赛事信息
			local raceinfopb = RaceInfoModel.GetRaceInfo(raceid)
			if raceinfopb == nil then
				LogFile("info", "赛事id:"..raceid)
				raceinfopb = RaceInfoModel.LoadRaceInfo(raceid)
			end
			local raceinfo = st_footballgame_pb.MerchantRaceInfoDto()
			raceinfo:ParseFromString(raceinfopb)
			
			
			--赛事没有开赛或者赛事进行中才可以跟投
			if raceinfo.raceStatus == 3 or raceinfo.raceStatus == 1 then
				
				if raceinfo.raceStatus == 1 then
					isinsertorder = 1
				end
			
				--单个下注区域的信息 
				local SimpleRebateInfoPB = RaceInfoModel.GetRaceRebateInfo(raceid, rebateId)
				local SimpleRebateInfo = st_footballgame_pb.SimpleRebateInfo()
				SimpleRebateInfo:ParseFromString(SimpleRebateInfoPB)
		
				local pourinfo = msg_footballgame_pb.cgfootballpourinfo()
				
				
				pourinfo.userid			= userid
				pourinfo.eventid		= raceid
				pourinfo.yieltype		= SimpleRebateInfo.ruleType - 1
				--pourinfo.subtype		= 0
				pourinfo.typescore		= SimpleRebateInfo.score
				pourinfo.baoval			= SimpleRebateInfo.baoval
				pourinfo.tiyan			= SimpleRebateInfo.tiyan
				pourinfo.pourjetton		= tostring(pourjetton)
				pourinfo.typourjetton	= "0"
				pourinfo.rebateId		= rebateId
				pourinfo.isBet			= 0
				--pourinfo.wlpourtype	= 0
				pourinfo.schemeid		= planid
				pourinfo.expertid		= expertid
				pourinfo.planraceid		= planraceid
				pourinfo.isinsertorder	= isinsertorder
				--pourinfo.cardid		= ""
				
				orderid = FootballService.dealPlanOrder(pourinfo)
				if tonumber(orderid) == nil then
					print(orderid)
				end
				
				count = count + 1
			
			end
			
		elseif count > 1 then -- 预设投注
			
			redisItem:rpush(ExpertModel.PourPlanRaceList..raceid, userid.."|"..planid.."|"..planraceid.."|"..orderid, ExpertModel.redis_index)
			
			break
		end

		-- 找到这个赛事
		if datainfo.planraceid == curplanraceid then
			count = 1
		end
		
	end
	
	
end
