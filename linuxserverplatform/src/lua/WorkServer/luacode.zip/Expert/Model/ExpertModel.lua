ExpertModel = {}
ExpertModel.redis_index = "redis_expert"
ExpertModel.Expire = 30 * 24 * 60 * 60  				-- 信息过期时间，单位秒
ExpertModel.ExpertIDSet = "expertidset"  				-- 保存专家id集合 无序集合

ExpertModel.ConcernedExpertZSet = "expert_concerned_"  	-- 玩家关注的人
ExpertModel.ExpertFansZSet = "expert_fans_"  			-- 玩家的粉丝

ExpertModel.ConcernedPlanZSet = "concerned_plan_"  		-- 玩家关注的方案
ExpertModel.PlanFansZSet = "paln_fans_"  				-- 方案的粉丝
ExpertModel.BuyPlanZSet = "buy_plan_"  					-- 玩家购买过的方案
ExpertModel.PourPlanZSet = "pour_plan_"  				-- 玩家跟投过的方案

ExpertModel.ExpertNoticeSet = "expert_notice_"  		-- 专家需要通知的玩家

ExpertModel.NewPlanID = "new_planid"  					-- 生成全服唯一方案id索引

ExpertModel.RaceOfPlanZset = "race_of_plan_"  			-- 每个赛事相关的方案，设置生存周期
ExpertModel.RaceOfExpertZset = "race_of_expert_"  		-- 每个赛事相关的专家，设置生存周期


ExpertModel.CheckExpertData = "expert_check_"  			
ExpertModel.CheckDayExpertData = "expert_check_daily_"  	
----------------------------------------------排行榜，分渠道
--生成专家，需要往这里添加数据
--命中率变化需要更新分数值
--最多存放1000个数据
ExpertModel.NearHitRate = "nearhitrate_rank_"  			-- 近期命中率排行（全部专家）
ExpertModel.WeekIncomeRank = "week_income_rank_"  		-- 周盈利榜
ExpertModel.WeekPopuRank = "week_popu_rank_"  			-- 周人气榜
----------------------------------------------
ExpertModel.PourPlanRaceList = "pour_plan_race_"		-- 每个赛事需要更新的玩家和方案 zadd pour_plan_race_[raceid] [planraceid] [userid]|[planid]



--------------------------------------------------
-- redis数据说明
-- 1、专家详情和方案详情不会保存到redis中
-- 2、除以上数据，大部分会保存在redis中


-- 加载专家id
function ExpertModel.LoadExpert()
	
	local sqlCase = "select userid from ex_player"
	mysqlItem:executeQuery(sqlCase)
	
	while true do
		local sqlData = mysqlItem:fetch({})
		if sqlData == nil then
			break
		end
		
		redisItem:sadd(ExpertModel.ExpertIDSet, sqlData[1], ExpertModel.redis_index)
	end
	
end

--判断一个玩家是否是专家
function ExpertModel.IsExpert(userid)
	if not redisItem:exists(ExpertModel.ExpertIDSet, ExpertModel.redis_index) then
		-- 这种情况，可能是缓冲被清理了
		ExpertModel.LoadExpert()
		
	end
	
	return redisItem:sismember(ExpertModel.ExpertIDSet, userid, ExpertModel.redis_index) 
end

--添加一个专家到集合
function ExpertModel.AddExpert(userid)
	redisItem:sadd(ExpertModel.ExpertIDSet, userid, ExpertModel.redis_index) 
end

--判断一个玩家是否，满足成为专家条件
function ExpertModel.IsCanBecomeExpert(userid)
	
	local contiwincount = 0 --连胜场次
	local achamount = 0		--投注量
	local ordercount = 0	--投注场次
	local playcount = 0		--投注赛事场次
	
	-- 查询投注量和投注场次
	local sqlCase = "select achamount,ordercount,playcount from log_player where userid="..userid
	mysqlLog:executeQuery(sqlCase)
	local sqlData = mysqlLog:fetch({})
	if sqlData ~= nil then
		
		achamount = tonumber(sqlData[1]) or 0
		ordercount = tonumber(sqlData[2]) or 0
		playcount = tonumber(sqlData[3]) or 0
	end
	
	--查询连胜场次
	local sqlCase = "select pumpMoney from dy_footballorder where userid="..userid.." and orderstate!=-1 and orderstate!=0 and orderstate!=3 and orderstate!=4 and isBet=0 order by orderid desc limit 100"
	mysqlItem:executeQuery(sqlCase)
	while true do
		local sqlData = mysqlItem:fetch({})
		if sqlData == nil then
			break
		end
		
		local pumpMoney = tonumber(sqlData[1])
		
		if pumpMoney > 0 then
			contiwincount = contiwincount + 1
		else
			contiwincount = 0
		end
		
		if contiwincount >= 20 then
			break
		end
		
	end
	
	
	if achamount >= 50000000 and playcount >= 50 and contiwincount >= 20 then
		return true
	end
	
	return false
end

--查询一个玩家的审核状态
--返回：firstapply,checkstatus，failmsg
function ExpertModel.QueryExpertCheckStatus(userid)
	local firstapply = true --是否第一次申请
	local checkstatus = 0 --审核状态 0：没有发起审核   1：审核中   2：审核失败  3:审核成功
	local failmsg = "" --失败原因
	
	--查询数据库
	local sqlCase = "select checkstatus,remark from ex_applytoexpert where userid="..userid
	mysqlItem:executeQuery(sqlCase)
	local sqlData = mysqlItem:fetch({})
	if sqlData ~= nil then
		firstapply = false
		checkstatus = tonumber(sqlData[1])
		failmsg = sqlData[2]
	end

	return firstapply,checkstatus,failmsg
end


------------关注模块---------------

-- 从数据库加载某个玩家关注的人
function ExpertModel.LoadConcernedExpert(userid)
	
	
	
	--+++++++++++++++++++++
	
	
	
end

-- 从数据库中加载某个玩家的粉丝
function ExpertModel.LoadExpertFans(expertid)
	
	
	
	
	--+++++++++++++++++++++
	
	
end


-- 是否关注过某个玩家
function ExpertModel.IsAddConcernedExpert(userid, expertid)
	
	if not redisItem:exists(ExpertModel.ExpertIDSet, ExpertModel.redis_index) and 
		not redisItem:exists(ExpertModel.ConcernedExpertZSet..userid, ExpertModel.redis_index) then
		
		-- 这种情况，可能是缓冲被清理了 ,加载数据库中数据
		ExpertModel.LoadConcernedExpert(userid)
	end

	--判断是否关注过该专家
	local concernedtime = redisItem:zscore(ExpertModel.ConcernedExpertZSet..userid, expertid, ExpertModel.redis_index) or 0
	
	return tonumber(concernedtime) > 0 and true or false
end

-- 关注或者取关玩家
function ExpertModel.AddConcernedExpert(userid, expertid, optype, time)
	local sqlCase = ""
	if optype == 1 then --关注
		
		if ExpertModel.IsAddConcernedExpert(userid, expertid) then
			return
		end
		
		--插入数据
		sqlCase = "insert into ex_relationuser(userid,beuserid,time) value("..userid..","..expertid..","..time..")"
		LogModel.GameSqlServer(sqlCase)
		
		redisItem:zadd(ExpertModel.ConcernedExpertZSet..userid, time, expertid, ExpertModel.redis_index)
		redisItem:zadd(ExpertModel.ExpertFansZSet..expertid, time, userid, ExpertModel.redis_index)
		
		
		sqlCase = "update ex_player set fanscount=fanscount+1 where userid="..expertid
		LogModel.GameSqlServer(sqlCase)
		
			
		-- 更新ex_player表数据
		if ExpertModel.IsExpert(userid) then
			local concernedcount = redisItem:zcard(ExpertModel.ConcernedExpertZSet..userid, ExpertModel.redis_index)
			sqlCase = "update ex_player set concernedcount="..concernedcount.." where userid="..userid
			LogModel.GameSqlServer(sqlCase)
			
		end
		
	else	--取关
		
		if not ExpertModel.IsAddConcernedExpert(userid, expertid) then
			return
		end
		
		-- 删除数据
		sqlCase = "delete from ex_relationuser where userid="..userid
		LogModel.GameSqlServer(sqlCase)
		
		redisItem:zrem(ExpertModel.ConcernedExpertZSet..userid, expertid, ExpertModel.redis_index)
		redisItem:zrem(ExpertModel.ExpertFansZSet..expertid, userid, ExpertModel.redis_index)
		
		
		sqlCase = "update ex_player set fanscount=fanscount-1 where userid="..expertid
		LogModel.GameSqlServer(sqlCase)
		
		-- 更新ex_player表数据
		if ExpertModel.IsExpert(userid) then
			local concernedcount = redisItem:zcard(ExpertModel.ConcernedExpertZSet..userid, ExpertModel.redis_index)
			sqlCase = "update ex_player set concernedcount="..concernedcount.." where userid="..userid
			LogModel.GameSqlServer(sqlCase)
		end
		
	end
	
end

-- 获取玩家关注的人
function ExpertModel.GetConcernUser(userid, startpos, endpos)
	if not redisItem:exists(ExpertModel.ExpertIDSet, ExpertModel.redis_index) and 
		not redisItem:exists(ExpertModel.ConcernedExpertZSet..userid, ExpertModel.redis_index) then
		
		-- 这种情况，可能是缓冲被清理了 ,加载数据库中数据
		ExpertModel.LoadConcernedExpert(userid)
	end
	
	return redisItem:zrevrange(ExpertModel.ConcernedExpertZSet..userid, startpos, endpos, ExpertModel.redis_index)
end

-- 获取玩家关注的玩家数量
function ExpertModel.GetConcernUserCount(userid)
	return tonumber(redisItem:zcard(ExpertModel.ConcernedExpertZSet..userid, ExpertModel.redis_index) or 0) 
end

-- 加载玩家关注的方案
function ExpertModel.LoadConcernedPlan(userid)
	
	
	
	
	
	--+++++++++++++++++++++
	
	
	
end

-- 是否关注过这个方案
function ExpertModel.IsAddConcernedPlan(userid, planid)
	
	if not redisItem:exists(ExpertModel.ExpertIDSet, ExpertModel.redis_index) 
	and not redisItem:exists(ExpertModel.ConcernedPlanZSet..userid, ExpertModel.redis_index) then
		
		-- 这种情况，可能是缓冲被清理了 ,加载数据库中数据
		ExpertModel.LoadConcernedPlan(userid)
	end
	
	local concernedtime = redisItem:zscore(ExpertModel.ConcernedPlanZSet..userid, planid, ExpertModel.redis_index) or 0
	
	return tonumber(concernedtime) > 0 and true or false
end

-- 关注或者取关方案
function ExpertModel.AddConcernedPlan(userid, planid, optype, time)
	local sqlCase = ""
	if optype == 1 then --关注方案
		
		if ExpertModel.IsAddConcernedPlan(userid, planid) then
			return
		end
		
		--插入数据
		sqlCase = "insert into ex_relationplan(userid,planid,time) value("..userid..","..planid..","..time..")"
		
		redisItem:zadd(ExpertModel.ConcernedPlanZSet..userid, time, planid, ExpertModel.redis_index)
		
	else	--取关方案
		
		if not ExpertModel.IsAddConcernedPlan(userid, planid) then
			return
		end
		
		-- 删除数据
		sqlCase = "delete from ex_relationplan where userid="..userid
		
		redisItem:zrem(ExpertModel.ConcernedPlanZSet..userid, planid, ExpertModel.redis_index)
		
	end
	
	LogModel.GameSqlServer(sqlCase)
end

-- 获取玩家关注的方案
function ExpertModel.GetConcernPlan(userid, startpos, endpos)
	if not redisItem:exists(ExpertModel.ExpertIDSet, ExpertModel.redis_index) 
	and not redisItem:exists(ExpertModel.ConcernedPlanZSet..userid, ExpertModel.redis_index) then
		
		-- 这种情况，可能是缓冲被清理了 ,加载数据库中数据
		ExpertModel.LoadConcernedPlan(userid)
	end
	
	return redisItem:zrevrange(ExpertModel.ConcernedPlanZSet..userid, startpos, endpos, ExpertModel.redis_index)
end

-- 获取玩家关注的方案数量
function ExpertModel.GetConcernPlanCount(userid)
	return tonumber(redisItem:zcard(ExpertModel.ConcernedPlanZSet..userid, ExpertModel.redis_index) or 0) 
end

------------------------------------------
-- 加载玩家购买的方案
function ExpertModel.LoadBuyPlan(userid)
	
	
	
	
	--+++++++++++++++++++++
	
	
	
	
end

-- 是否购买过这个方案
function ExpertModel.IsBuyPlan(userid, planid)
	
	if not redisItem:exists(ExpertModel.ExpertIDSet, ExpertModel.redis_index) 
	and not redisItem:exists(ExpertModel.BuyPlanZSet..userid, ExpertModel.redis_index) then
		
		-- 这种情况，可能是缓冲被清理了 ,加载数据库中数据
		ExpertModel.LoadBuyPlan(userid)
	end
	
	local concernedtime = redisItem:zscore(ExpertModel.BuyPlanZSet..userid, planid, ExpertModel.redis_index) or 0
	
	return tonumber(concernedtime) > 0 and true or false
end

-- 购买方案
function ExpertModel.BuyPlan(userid, planid, time, expertid, planprice)
	
	redisItem:zadd(ExpertModel.BuyPlanZSet..userid, time, planid, ExpertModel.redis_index)
	
	--插入数据
	local sqlCase = "insert into ex_buyplan(userid,planid,time,expertid,planprice) value("..
	userid..","..planid..","..time..","..expertid..","..planprice..")"
	LogModel.GameSqlServer(sqlCase)
	
	--方案数据统计
	sqlCase = "update ex_plan set buycount=buycount+1"..
	",allprofit=allprofit+"..planprice..
	" where planid="..planid
	LogModel.GameSqlServer(sqlCase)
	
	--- 统计专家数据，必定执行步骤
	--查询数据库
	local weekStr = TimeUtils.GetWeekString()
	local sqlCase = "select weekcleartime from ex_player where userid="..expertid
	mysqlItem:executeQuery(sqlCase)
	local sqlData = mysqlItem:fetch({})
	if sqlData ~= nil then
		
		if sqlData[1] ~= weekStr then
			
			-- 记录本周已经清理
			local sqlCase = "update ex_player set weekcleartime='"..weekStr..
			"',allincome=0"..
			",allbuymoney=0"..
			",allfollowmoney=0"..
			",commissionrate=0"..
			",commissionincome=0"..
			" where userid="..expertid
			mysqlItem:execute(sqlCase)
			
		end
		
	end
	
	
	--玩家数据统计
	sqlCase = "update ex_player set allbuymoney=allbuymoney+"..planprice.." where userid="..expertid
	LogModel.GameSqlServer(sqlCase)
	
	--+++++++++++++++++++++
	
	
	
	
	
	
end


------------------------------------------
-- 加载玩家跟投的方案
function ExpertModel.LoadPourPlan(userid)
	
	
	
	
	--+++++++++++++++++++++
	
	
	
	
end

-- 是否跟投过这个方案
function ExpertModel.IsPourPlan(userid, planid)
	
	if not redisItem:exists(ExpertModel.ExpertIDSet, ExpertModel.redis_index) 
	and not redisItem:exists(ExpertModel.PourPlanZSet..userid, ExpertModel.redis_index) then
		
		-- 这种情况，可能是缓冲被清理了 ,加载数据库中数据
		ExpertModel.LoadPourPlan(userid)
	end
	
	local concernedtime = redisItem:zscore(ExpertModel.PourPlanZSet..userid, planid, ExpertModel.redis_index) or 0
	
	return tonumber(concernedtime) > 0 and true or false
end

-- 跟投方案
function ExpertModel.RecordPourPlan(userid, planid, time, expertid)
	
	redisItem:zadd(ExpertModel.PourPlanZSet..userid, time, planid, ExpertModel.redis_index)
	
	--插入数据
	local sqlCase = "insert into ex_pourplan(userid,planid,time,expertid) value("..
	userid..","..planid..","..time..","..expertid..")"
	LogModel.GameSqlServer(sqlCase)
	
end
-----------------------------------------

------------------通知模块----------------
-- 加载玩家添加过的通知
function ExpertModel.LoadNotice(expertid)
	
	
	
	
	--+++++++++++++++++++++
	
	
	
	
end

-- 是否添加过通知
function ExpertModel.IsAddNotice(userid, expertid)
	if not redisItem:exists(ExpertModel.ExpertIDSet, ExpertModel.redis_index) 
	and not redisItem:exists(ExpertModel.ExpertNoticeSet..expertid, ExpertModel.redis_index) then
		
		-- 这种情况，可能是缓冲被清理了 ,加载数据库中数据
		ExpertModel.LoadNotice(expertid)
	end

	return redisItem:sismember(ExpertModel.ExpertNoticeSet..expertid, userid, ExpertModel.redis_index)
end

-- 将玩家添加到专家通知集合
function ExpertModel.AddNotice(userid, expertid, optype, time)
	
	local sqlCase = ""
	if optype == 1 then --添加通知
		
		if ExpertModel.IsAddNotice(userid, expertid) then
			return
		end
		
		--插入数据
		sqlCase = "insert into ex_usernotice(userid,beuserid,time) value("..userid..","..expertid..","..time..")"
		
		redisItem:sadd(ExpertModel.ExpertNoticeSet..expertid, userid, ExpertModel.redis_index)
		
	else	--取消通知
		
		if not ExpertModel.IsAddNotice(userid, expertid) then
			return
		end
		
		-- 删除数据
		sqlCase = "delete from ex_usernotice where userid="..userid
		
		redisItem:srem(ExpertModel.ExpertNoticeSet..expertid, userid, ExpertModel.redis_index)
		
	end
	
	LogModel.GameSqlServer(sqlCase)
end


-- 判断名字是否非法的
function ExpertModel.IsIllegalName(name)
	
	--查询数据库，看看名字是否重复
	local sqlCase = "select userid from ex_player where nickname='"..name.."'"
	mysqlItem:executeQuery(sqlCase)
	local sqlData = mysqlItem:fetch({})
	if sqlData ~= nil then
		return true
	end
	
	return false;
end

-- 生成一个全服唯一方案id
function ExpertModel.GetNewPlanID()
	
    local planid = redisItem:incrby(ExpertModel.NewPlanID, 1, ExpertModel.redis_index)
	
    if planid == 1 then
        --查一下数据库 看看是否是因为清理缓存导致planid变成0
        local sqlCase = "select planid from ex_plan order by planid desc limit 1"
        mysqlItem:executeQuery(sqlCase)
        local sqlData = mysqlItem:fetch()
        if sqlData ~= nil then
            planid = redisItem:incrby(ExpertModel.NewPlanID, sqlData, ExpertModel.redis_index)
        end
    end
	
    return planid
end


-- 更投专家方案
-- userid 玩家id
-- planid 更投的方案id
-- expertid 更投的专家
-- pourjetton 更投的金额
-- pourtype   0：跟投真钱  1：更投体验金  2：跟投保本卡
function ExpertModel.PourPlan(userid, planid, expertid, pourjetton, pourtype)
	
	if expertid <= 0 or planid <= 0 then
		return
	end
	
	-- 方案数据统计
	local sqlCase = "update ex_plan set ordercount=ordercount+1,allordermoney=allordermoney+"..pourjetton..
	" where planid="..planid
	LogModel.GameSqlServer(sqlCase)
	
	
	--统计专家数据执行操作
	--查询数据库
	local weekStr = TimeUtils.GetWeekString()
	local sqlCase = "select weekcleartime from ex_player where userid="..expertid
	mysqlItem:executeQuery(sqlCase)
	local sqlData = mysqlItem:fetch({})
	if sqlData ~= nil then
		
		if sqlData[1] ~= weekStr then
			
			-- 记录本周已经清理
			local sqlCase = "update ex_player set weekcleartime='"..weekStr..
			"',allincome=0"..
			",allbuymoney=0"..
			",allfollowmoney=0"..
			",commissionrate=0"..
			",commissionincome=0"..
			" where userid="..expertid
			mysqlItem:execute(sqlCase)
			
		end
		
	end
	
	
	--玩家数据统计
	sqlCase = "update ex_player set allfollowmoney=allfollowmoney+"..pourjetton.." where userid="..expertid
	LogModel.GameSqlServer(sqlCase)
	
	
	--+++++++++++++++++++++
	
	
	
	
	
end


-- 是否可以查看比分和收益
function ExpertModel.IsLookPlanScoreInfo(userid, planid, planraceid)
	
	if ExpertModel.IsBuyPlan(userid, planid) then
		return true
	end
	
	
	-- 查询数据，判断是否更投过该方案
	local followplan = false
	
	local sqlCase = "select orderid from dy_footballorder where planraceid="..planraceid.." and userid="..userid
	mysqlItem:executeQuery(sqlCase)
	local sqlData = mysqlItem:fetch()
	if sqlData ~= nil then
		followplan = true
	end
		
	
	if followplan then
		return true
	end
	
	return false
end


-----------------------------------排行榜模块-----------------------------------
-- 从数据库中加载到内存
function ExpertModel.LoadNearHitRate()
	
	
	
	
	
	
	--+++++++++++++++++++++
	
	
	
	
	
end

--更新近期命中率，近期命中率排行榜
--新增专家的时候，first才需要传true
function ExpertModel.AddNearHitRate(userid, nearhitrate, first, channel)
	
	redisItem:zadd(ExpertModel.NearHitRate..channel, nearhitrate, userid, ExpertModel.redis_index)
	
	if first then
		
		local count = tonumber(redisItem:zcard(ExpertModel.NearHitRate..channel, ExpertModel.redis_index) or 0) 
		if count > 1000 then
			redisItem:zremrangebyrank(ExpertModel.NearHitRate..channel, 0, 0, ExpertModel.redis_index)
		end
		
	else
		-- 生成sql语句更新数据库
		local sqlCase = "update ex_player set nearhitrate="..nearhitrate.." where userid="..userid
		LogModel.GameSqlServer(sqlCase)
	end
	
end


--更新周盈利，每周需要删除上一周
function ExpertModel.AddWeekIncomeRank(userid, value, channel)
	
	local weekStr = TimeUtils.GetWeekString()
	local keyStr = ExpertModel.WeekIncomeRank..channel.."_"..weekStr
	
	redisItem:zadd(keyStr, value, userid, ExpertModel.redis_index)

	local count = tonumber(redisItem:zcard(keyStr, ExpertModel.redis_index) or 0) 
	if count > 1000 then
		redisItem:zremrangebyrank(keyStr, 0, 0, ExpertModel.redis_index)
	end
end


--更新周人气，每周需要删除上一周
function ExpertModel.AddWeekPopuRank(userid, value, channel)
	
	local weekStr = TimeUtils.GetWeekString()
	local keyStr = ExpertModel.WeekPopuRank..channel.."_"..weekStr
	
	redisItem:zincrby(keyStr, value, userid, ExpertModel.redis_index)

	local count = tonumber(redisItem:zcard(keyStr, ExpertModel.redis_index) or 0) 
	if count > 1000 then
		redisItem:zremrangebyrank(keyStr, 0, 0, ExpertModel.redis_index)
	end
end

---------------------------------------------------------------------------------
-- 加载赛事相关方案
function ExpertModel.LoadRaceOfPlan()
	
	
	
	
	--+++++++++++++++++++++
	
	
	
	
end

-- 获取赛事相关方法 getcount标识需要获取的数量
function ExpertModel.GetRaceOfPlan(raceid, getcount, channel)
	channel = channel or "qmty_bct"
	
	return redisItem:zrevrange(ExpertModel.RaceOfPlanZset..raceid.."_"..channel, 0, getcount, ExpertModel.redis_index)
end

-- 添加赛事相关方案
function ExpertModel.AddRaceOfPlan(raceid, planid, score, time, channel)
	
	channel = channel or "qmty_bct"
	
	local value = tonumber(score) * 100000000000 + tonumber(time)
	
	redisItem:zadd(ExpertModel.RaceOfPlanZset..raceid.."_"..channel, value, planid, ExpertModel.redis_index)

	local count = tonumber(redisItem:zcard(ExpertModel.RaceOfPlanZset..raceid.."_"..channel, ExpertModel.redis_index) or 0) 
	if count > 1000 then
		redisItem:zremrangebyrank(ExpertModel.RaceOfPlanZset..raceid.."_"..channel, 0, 0, ExpertModel.redis_index)
	end
	
	--设置生存周期
	if count == 1 then
		redisItem:expire(ExpertModel.RaceOfPlanZset..raceid.."_"..channel, ExpertModel.Expire, ExpertModel.redis_index)
	end
end

-- 获取赛事相关的专家数量
function ExpertModel.GetRaceOfExpertCount(raceid, channel)
	channel = channel or "qmty_bct"
	
	return redisItem:zcard(ExpertModel.RaceOfExpertZset..raceid.."_"..channel, ExpertModel.redis_index)
end

-- 添加赛事相关的专家
function ExpertModel.AddRaceOfExpert(raceid, userid, channel)
	channel = channel or "qmty_bct"
	
	redisItem:zincrby(ExpertModel.RaceOfExpertZset..raceid.."_"..channel, 1, userid, ExpertModel.redis_index)

	local count = tonumber(redisItem:zcard(ExpertModel.RaceOfExpertZset..raceid.."_"..channel, ExpertModel.redis_index) or 0) 
	
	--设置生存周期
	if count == 1 then
		redisItem:expire(ExpertModel.RaceOfExpertZset..raceid.."_"..channel, ExpertModel.Expire, ExpertModel.redis_index)
	end
end


-- 获取专家的连胜类型
function ExpertModel.GetExpertWinType(threehitcount, fivehitcount, sevenhitcount)
	
	if sevenhitcount == 7 then
		return 7
	end
	
	if fivehitcount == 5 then
		return 5
	end
	
	if threehitcount == 3 then
		return 3
	end
	
	return 0
end

-- 获取专家佣金比例
function ExpertModel.GetExpertcommissionType(style)
	
	if style == 1 then
		return 0.00001
	elseif style == 2 then
		return 0.00003
	elseif style == 3 then
		return 0.00005
	elseif style == 4 then
		return 0.00007
	elseif style == 5 then
		return 0.0001
	end
	
	return 0
end

function ExpertModel.SysCountCheck(channel, dayStr)
	
	local curtime = TimeUtils.GetTime()
	
	-- 总数据
	if not redisItem:exists(ExpertModel.CheckExpertData, ExpertModel.redis_index) then
		local sqlCase = "insert into log_expertdata(channel,prechannel,createtime) "..
		"values('"..channel.."','"..AgentModel.GetChannel(channel).."',"..curtime..")"
		LogModel.LogPlayerPush(sqlCase)
		redisItem:set(ExpertModel.CheckExpertData, 1, ExpertModel.redis_index)
	end
	
	-- 今日数据
	if not redisItem:exists(ExpertModel.CheckDayExpertData..dayStr, ExpertModel.redis_index) then
		
		local sqlCase = "insert into log_expertdatadaily(channel,prechannel,dateid,createtime) "..
		"values('"..channel.."','"..AgentModel.GetChannel(channel).."','"..dayStr.."',"..curtime..")"
		LogModel.LogPlayerPush(sqlCase)--mysqlLog:execute(sqlCase)
		
		redisItem:set(ExpertModel.CheckDayExpertData..dayStr, 1, ExpertModel.redis_index)
		RedisClearModel.AddNormalKey(ExpertModel.CheckDayExpertData..dayStr, 2 * 24 * 60 * 60, ExpertModel.redis_index)
	end
end

-- 统计真人专家发布方案数量
-- num:要增加或者减少的方案数量
function ExpertModel.SysCountPlanNums(channel, plannums)
	
	local dayStr = TimeUtils.GetDayString()
	ExpertModel.SysCountCheck(channel, dayStr)
	
	local sqlCase = "update log_expertdata set plannums=plannums+"..plannums.." where channel='"..channel.."'"
	LogModel.LogPlayerPush(sqlCase)
	
	
	local sqlCase = "update log_expertdatadaily set plannums=plannums+"..plannums.." where channel='"..channel.."' and dateid='"..dayStr.."'"
	LogModel.LogPlayerPush(sqlCase)
	
end

-- 统计购买方案信息
function ExpertModel.SysCountBuyPlanInfo(channel, money)
	
	local dayStr = TimeUtils.GetDayString()
	ExpertModel.SysCountCheck(channel, dayStr)
	
	local sqlCase = "update log_expertdata set buynums=buynums+1,buymoney=buymoney+"..money.." where channel='"..channel.."'"
	LogModel.LogPlayerPush(sqlCase)
	
	
	local sqlCase = "update log_expertdatadaily set buynums=buynums+1,buymoney=buymoney+"..money.." where channel='"..channel.."' and dateid='"..dayStr.."'"
	LogModel.LogPlayerPush(sqlCase)
end

-- 统计跟投方案信息
function ExpertModel.SysCountPourPlanInfo(channel, pourjetton)
	local dayStr = TimeUtils.GetDayString()
	ExpertModel.SysCountCheck(channel, dayStr)
	
	local sqlCase = "update log_expertdata set follownums=follownums+1,followmoney=followmoney+"..pourjetton.." where channel='"..channel.."'"
	LogModel.LogPlayerPush(sqlCase)
	
	
	local sqlCase = "update log_expertdatadaily set follownums=follownums+1,followmoney=followmoney+"..pourjetton.." where channel='"..channel.."' and dateid='"..dayStr.."'"
	LogModel.LogPlayerPush(sqlCase)
end

-- 统计更投总盈亏
function ExpertModel.SysCountWinMoney(channel, winmoney)
	
	local dayStr = TimeUtils.GetDayString()
	ExpertModel.SysCountCheck(channel, dayStr)
	
	local sqlCase = "update log_expertdata set winmoney=winmoney+"..winmoney.." where channel='"..channel.."'"
	LogModel.LogPlayerPush(sqlCase)
	
	
	local sqlCase = "update log_expertdatadaily set winmoney=winmoney+"..winmoney.." where channel='"..channel.."' and dateid='"..dayStr.."'"
	LogModel.LogPlayerPush(sqlCase)
end