FootballModel = {}
FootballModel.redis_index = "redis_football"

FootballModel.OrderNewId = "footballNewOrderId" --足球订单id生成

--所有订单详细信息
FootballModel.OrderInfo = "footballOrderInfo" --足球订单信息

--zadd 玩家有序集合
FootballModel.userOrderidList         = "userOrderidList"           --玩家足球所有订单信息
FootballModel.userWinOrderList        = "userWinOrderList"          --玩家足球盈利订单信息
FootballModel.userLoseOrderList       = "userLoseOrderList"         --玩家足球亏损订单信息
FootballModel.userNorebateOrderList   = "userNorebateOrderList"     --玩家足球未返利订单信息
FootballModel.userRecapitalOrderList1 = "userRecapitalOrderList1"   --玩家足球返还本金订单信息玩家撤单
FootballModel.userRecapitalOrderList2 = "userRecapitalOrderList2"   --玩家足球返还本金订单信息赛事取消


FootballModel.RaceOfOrderInfo = "RaceOfOrderInfo" --赛事的所有足球订单信息


--除了新订单 其它状态的都是已结算订单
FootballModel.userCountOrderList      = "userCountOrderList"      --玩家球已结算订单订单信息

--玩家交易记录保存300条纪录
FootballModel.userRecordInfoList = "userRecordInfoList"  

FootballModel.userNews = "userNews" 
FootballModel.userNews_lock = "userNews_lock" 

--玩家可免费提现额度   
FootballModel.userGetCashFreeAmount = "userGetCashFreeAmount"  

--注册送体验金额度
FootballModel.userTiYanInitAmount = "userTiYanInitAmount"  

--竞猜赛事输赢下注信息
FootballModel.football_pour = "football_pour"
FootballModel.football_pour_user = "football_pour_user"

--竞猜赛事输赢赔率
FootballModel.PourWLRate  = "PourWLRate"

--竞猜输赢订单信息
FootballModel.PourWLorderinfo = "PourWLorderinfo"

--玩家绑定手机上时间戳
FootballModel.userBindPhoneTime = "userBindPhoneTime" 

--玩家赛事关注
FootballModel.userPayAttentionRace = "userPayAttentionRace"

--输赢赛事原始收益
FootballModel.wlchangeRatio  = "wlchangeRatio"

--玩家翻翻乐收益报告信息 保存orderid
FootballModel.userFlipProfitReportInfo  = "userFlipProfitReportInfo"

FootballModel.userRaceRebeatPourjetton = "userRaceRebeatPourjetton" --单个玩家赛事区域下注总额

FootballModel.RaceRebeatPourjetton = "RaceRebeatPourjetton" --所有玩家赛事区域下注总额

FootballModel.RaceRebeatUser = "RaceRebeatUser" --赛事区域下注的玩家 

--profitid 请求生成唯一收益次数
FootballModel.userCreateProfitidCount = "userCreateProfitidCount"

--赛事注单数
FootballModel.raceOrderCount = "raceOrderCount"

FootballModel.UserCountOrderNum = "UserCountOrderNum" --玩家结算order数量(不包含体验金)

FootballModel.UserPourTimes = "UserPourTimes"  --玩家下注次数（不包括体验金下注）

--获取一个新的订单id
function FootballModel.GetNewOrderId()
    local orderid = redisItem:incrby(FootballModel.OrderNewId,1,FootballModel.redis_index)
    if orderid == 1 then
        --查一下数据库 看看是否是因为清理缓存导致orderid变成0
        local sqlCase = "select orderid from dy_footballorder order by  orderid desc limit 1"
        mysqlItem:executeQuery(sqlCase)
        local sqlData = mysqlItem:fetch()
        if sqlData ~= nil then
            orderid = redisItem:incrby(FootballModel.OrderNewId,tonumber(sqlData),FootballModel.redis_index)
        end
    end
    return orderid
end

--设置订单信息
function FootballModel.SetOrderInfo(orderid,orderinfo)
    redisItem:hset(FootballModel.OrderInfo, orderid, orderinfo, FootballModel.redis_index)
end

--根据订单id获取订单信息
function FootballModel.GetOrderInfoByOrderId(orderid)
    if redisItem:hexists(FootballModel.OrderInfo, orderid, FootballModel.redis_index) then
        return redisItem:hget(FootballModel.OrderInfo, orderid, FootballModel.redis_index)
    else
        FootballModel.LoadOrderInfoByOrderId(orderid) 
    end                                                     
end

function FootballModel.LoadOrderInfoByOrderId(orderid)
    local sqlCase = "select * from dy_footballorder where  orderid = '"..orderid.."'"
    mysqlItem:executeQuery(sqlCase)
    --print(sqlCase)
    while true do
        local sqlData = mysqlItem:fetch({})
		if nil == sqlData then
			break
		end
        local orderinfo = msg_footballgame_pb.gcfootballorderdetail()
     
        orderinfo.orderid                   =	    sqlData[1]
        orderinfo.userid	                =	    tonumber(sqlData[2])
        orderinfo.eventtype	                =	    sqlData[3]
        orderinfo.orderyiel.subtype	        =	    tonumber(sqlData[4]) or 0
        orderinfo.orderyiel.yieltype	    =	    tonumber(sqlData[5]) or 0
        orderinfo.orderyiel.typescore	    =	    sqlData[6]
        local yiel	                        =	    sqlData[7] --需要从下注信息中获取 实时的
        orderinfo.orderyiel.baoval	        =	    tonumber(sqlData[8]) or 0
        orderinfo.orderyiel.tiyan	        =	    tonumber(sqlData[9]) or 0
        orderinfo.starttime	                =	    TimeUtils.GetTime(sqlData[10])
        orderinfo.endtime	                =	    sqlData[11] ~=nil and  TimeUtils.GetTime(sqlData[11]) or 0
        orderinfo.ordertime	                =	    TimeUtils.GetTime(sqlData[12])
        orderinfo.orderstate	            =	    tonumber(sqlData[13])
        orderinfo.fee	                    =	    sqlData[14] or "0"
        local	win	                        =	    sqlData[15]
        orderinfo.hometeam	                =	    sqlData[16]
        orderinfo.awayteam	                =	    sqlData[17]
        orderinfo.homescore	                =	    tonumber(sqlData[18]) or 0
        orderinfo.awayscore	                =	    tonumber(sqlData[19]) or 0
        orderinfo.eventid	                =	    sqlData[20]
        orderinfo.rebateId	                =	    sqlData[21]
        orderinfo.pourjetton	            =	    sqlData[22] or "0"
        --local	channel	                    =	    sqlData[23]
        orderinfo.repeatCount	            =	    tonumber(sqlData[24]) or 0 --重复计算次数
        orderinfo.pumpMoney	                =	    tonumber(sqlData[25]) or 0 --订单抽水值
        orderinfo.isBet	                    =	    tonumber(sqlData[26])
        --local	wlpourtype	                =	    sqlData[27]
        --local	raceid	                    =	    sqlData[28]
        --local	wlpourlist1	                =	    sqlData[29]
        --local	wlpourlist2	                =	    sqlData[30]
        --local	wlpourlist3	                =	    sqlData[31]
        --local	prechannel	                =	    sqlData[32]
        --local	ordertype	                =	    sqlData[33]
        orderinfo.schemeid	                =	    tonumber(sqlData[34]) or 0 --方案id
        orderinfo.expertid	                =	    tonumber(sqlData[35]) or 0 --专家id
        orderinfo.expert	                =	    sqlData[36] or ""
        local	baobenmoney	                =	    sqlData[37]
        orderinfo.homelogo	                =	    (sqlData[38] == "" or sqlData[38] == nil)  and  g_footballgameDefine.homeTeamFace  or  sqlData[38]
        orderinfo.awaylogo	                =	    (sqlData[39] == "" or sqlData[39] == nil )   and  g_footballgameDefine.visitTeamFace  or sqlData[39]
        orderinfo.cancletime                =       (tonumber(sqlData[40]) or 0) > 0 and  tonumber(sqlData[40]) or 0
        
        orderinfo.planraceid		= tonumber(sqlData[41]) or 0
	    orderinfo.isinsertorder		= tonumber(sqlData[42]) or 0
	    orderinfo.cardid			=  sqlData[43] or ""
        if  orderinfo.cardid ~= "" then
            local propInfo =  PropService.getPropInfo(orderinfo.userid, orderinfo.cardid)
            if propInfo ~= nil then
                orderinfo.proptype	= propInfo.proptype
	            orderinfo.propname	= propInfo.propname
	            orderinfo.propvalue	= propInfo.propvalue
	            orderinfo.condition	= propInfo.condition
            end

        end
        --[[
        --获取赛事信息
        local raceinfo_pb = RaceInfoModel.GetRaceInfo(orderinfo.eventid)
        local raceinfo = st_footballgame_pb.MerchantRaceInfoDto()
        if raceinfo_pb ~= nil then
            raceinfo:ParseFromString(raceinfo_pb)
        end
        --订单状态 0:未返利(新订单) 1：结算后亏损 2：结算后获利 3：返还本金（玩家撤单） 4：返还本金（赛事取消）5：异常订单
        if orderinfo.orderstate == 0 or orderinfo.orderstate == 3  then
            if raceinfo.winResult ~= "" and raceinfo.winResult ~= "0" then
		        local result_score = FootballUtils.score_split(raceinfo.winResult, "-")
		        orderinfo.homescore		    = tonumber(result_score[1]) 
		        orderinfo.awayscore		    = tonumber(result_score[2])
	        end  
                
        end
        ]]
        if isBet == 1 then
            --猜胜负
            local totalpourlist = {0,0,0}
            local pourlist      = {0,0,0}
            local ratelist      = {0,0,0} 
            --个下注总额
            pourlist[1]	=	tonumber(sqlData[29])
            pourlist[2]	=	tonumber(sqlData[30])
            pourlist[3]	=	tonumber(sqlData[31])

            for s =1,3  do
                --下注区域总额
                totalpourlist[s] = FootballModel.GetPourJetton(orderinfo.eventid, s)
                orderinfo.wlpourlist:append(tostring(pourlist[s]))
                orderinfo.wltotalpourlist:append(tostring(totalpourlist[s]))
            end
            ratelist = FootballUtils.cluWLrate(totalpourlist)
                
            for s =1,3 do
                orderinfo.wlrate:append(tostring(ratelist[s]))
            end
            if  orderinfo.orderstate == 0  then
                --未结算
                win = FootballUtils.cluWLWin(totalpourlist,pourlist,ratelist,tonumber(orderinfo.fee))
                --print(win,orderinfo.fee)
            end
        else
            --猜比分
            if  orderinfo.orderstate == 0 then
                --未结算
                --获取返利信息
                local SimpleRebateInfoPB = RaceInfoModel.GetRaceRebateInfo(orderinfo.eventid, orderinfo.rebateId)
                if SimpleRebateInfoPB ~= nil then
                    local SimpleRebateInfo = st_footballgame_pb.SimpleRebateInfo()
                    SimpleRebateInfo:ParseFromString(SimpleRebateInfoPB)
                    yiel = string.format("%.4f", tonumber(SimpleRebateInfo.rebateRatio))
                    win = tonumber(orderinfo.pourjetton) * (tonumber(yiel)) * (1 - tonumber(orderinfo.fee)) +  tonumber(orderinfo.pourjetton)
                    win = tostring(math.floor(win))
                end
            end
        end
        if orderinfo.orderstate == -1 or orderinfo.orderstate == 3 or orderinfo.orderstate == 4 then
            orderinfo.win	=   tostring(orderinfo.pourjetton)
        else
           orderinfo.win	=   tostring(win)
        end
        --orderinfo.orderyiel.yiel      = yiel 

        --设置到缓存中
        FootballModel.SetOrderInfo(orderid,orderinfo:SerializeToString())       
    end                                                       
end

--获取所有订单
function FootballModel.GetOrderInfoList()
    return redisItem:hgetall(FootballModel.OrderInfo, FootballModel.redis_index)
end

------------------------------------------------------------------------------
--玩家足球所有订单id
function FootballModel.SetUserSortOrder(userid,orderid)
    local score = TimeUtils.GetTime()
    redisItem:zadd(FootballModel.userOrderidList..userid,score,orderid,FootballModel.redis_index)
end
function FootballModel.DelUserSortOrder(userid,orderid)
    redisItem:zrem(FootballModel.userOrderidList..userid,orderid)
end


--玩家足球盈利订单id
function FootballModel.SetUserSortWinOrder(userid,orderid)
    local score = TimeUtils.GetTime()
    redisItem:zadd(FootballModel.userWinOrderList..userid,score,orderid,FootballModel.redis_index)
end
function FootballModel.DelUserSortWinOrder(userid,orderid)
    redisItem:zrem(FootballModel.userWinOrderList..userid,orderid,FootballModel.redis_index)
end

--玩家足球亏损订单id
function FootballModel.SetUserSortLoseOrder(userid,orderid)
    local score = TimeUtils.GetTime()
    redisItem:zadd(FootballModel.userLoseOrderList..userid,score,orderid,FootballModel.redis_index)
end
function FootballModel.DelUserSortLoseOrder(userid,orderid)
    redisItem:zrem(FootballModel.userLoseOrderList..userid,orderid,FootballModel.redis_index)
end

--玩家足球未返利订单id 新订单 未结算订单
function FootballModel.SetUserSortNorebateOrder(userid,orderid)
    local score = TimeUtils.GetTime()
    redisItem:zadd(FootballModel.userNorebateOrderList..userid,score,orderid,FootballModel.redis_index)
end
function FootballModel.DelUserSortNorebateOrder(userid,orderid)
    redisItem:zrem(FootballModel.userNorebateOrderList..userid,orderid,FootballModel.redis_index)
end

--玩家足球返还本金订单信息(玩家撤单)
function FootballModel.SetUserSortRecapitalOrder1(userid,orderid)
    local score = TimeUtils.GetTime()
    redisItem:zadd(FootballModel.userRecapitalOrderList1..userid,score,orderid,FootballModel.redis_index)
end
function FootballModel.DelUserSortRecapitalOrder1(userid,orderid)
    redisItem:zrem(FootballModel.userRecapitalOrderList1..userid,orderid,FootballModel.redis_index)
end


--玩家足球返还本金订单信息(赛事取消)
function FootballModel.SetUserSortRecapitalOrder2(userid,orderid)
    local score = TimeUtils.GetTime()
    redisItem:zadd(FootballModel.userRecapitalOrderList2..userid,score,orderid,FootballModel.redis_index)
end
function FootballModel.DelUserSortRecapitalOrder2(userid,orderid)
    redisItem:zrem(FootballModel.userRecapitalOrderList2..userid,orderid,FootballModel.redis_index)
end


--玩家足球已结算订单id
function FootballModel.SetUserSortCountOrder(userid,orderid)
    local score = TimeUtils.GetTime()
    redisItem:zadd(FootballModel.userCountOrderList..userid,score,orderid,FootballModel.redis_index)
end
function FootballModel.DelUserSortCountOrder(userid,orderid)
    redisItem:zrem(FootballModel.userCountOrderList..userid,orderid,FootballModel.redis_index)
end


--获取玩家足球订单信息
--starttime  endtime 时间戳区间 订单的类型 0：全部订单 1:亏损 2:获利 3:未返利 4:返还本金
--订单的类型 0：全部订单 1:亏损 2:获利 3:未返利 4:返还本金
function FootballModel.GetUserSortOrderInfoByCondition(userid,orderstate,orderid,starttime,endtime,pagenum)
    if orderid ~= nil then
        --根据orderid 查询
        return FootballModel.GetOrderInfoByOrderId(orderid)
    end
    local startscore = starttime == nil and 0 or starttime
    local endtime = (tonumber(endtime) == 0 or endtime == nil) and "+inf" or endtime
    local orderidList = {}
    local orderinfolist = {}
    if orderstate == 0 then
        --全部
       -- print(startscore,endtime)
        orderidList = redisItem:zrangebyscore(FootballModel.userOrderidList..userid, startscore, endtime, FootballModel.redis_index)
    elseif orderstate == 3 then
        --未返利(新订单)
        orderidList = redisItem:zrangebyscore(FootballModel.userNorebateOrderList..userid, startscore, endtime, FootballModel.redis_index)

    elseif orderstate == 1 then
        --结算后亏损
        orderidList = redisItem:zrangebyscore(FootballModel.userLoseOrderList..userid, startscore, endtime, FootballModel.redis_index)
   
    elseif orderstate == 2 then
        --结算后获利
        orderidList = redisItem:zrangebyscore(FootballModel.userWinOrderList..userid, startscore, endtime, FootballModel.redis_index)

    elseif orderstate == 4 then
        -- 3：返还本金（玩家撤单） 
        orderidList = redisItem:zrangebyscore(FootballModel.userRecapitalOrderList1..userid, startscore, endtime, FootballModel.redis_index)
         --4：返还本金（赛事取消）
        local temporderidList = redisItem:zrangebyscore(FootballModel.userRecapitalOrderList2..userid, startscore, endtime, FootballModel.redis_index)
        for k,v in pairs(temporderidList) do
            table.insert(orderidList,v)
        end  
    end

   
    if maxpagenum ~= nil then
        --分页，每页10条
        local templist = {}
        local maxmaxpagenum = maxpagenum > #orderidList and #orderidList or  #orderidList
        for i= maxpagenum * 10 + 1, maxpagenum do
            if orderidList[i] ~= nil and orderidList[i] ~= "" then
                table.insert(templist,orderidList[i])
            end
        end
        for k,v in pairs(templist) do
            local  orderinfo = FootballModel.GetOrderInfoByOrderId(v)
            local orderinfoPB = msg_footballgame_pb.gcfootballorderdetail()
            orderinfoPB:ParseFromString(orderinfo)
            table.insert(orderinfolist,orderinfoPB)
        end
    else
        --不分页
        for k,v in pairs(orderidList) do
            local  orderinfo = FootballModel.GetOrderInfoByOrderId(v)
            local orderinfoPB = msg_footballgame_pb.gcfootballorderdetail()
            orderinfoPB:ParseFromString(orderinfo)
            table.insert(orderinfolist,orderinfoPB)
        end

    end


    return  orderinfolist
end


--结算和未结算
--orderstate 订单的类型 0：全部订单 1:亏损 2:获利 3:未结算 4:返还本金 5：已结算（包含1:亏损 2:获利 4:返还本金）
function FootballModel.GetUserAllSortOrderInfo(userid,orderstate,starttime,endtime,pagenum)

    local startscore = starttime == nil and 0 or starttime
    local endtime = (tonumber(endtime) == 0 or endtime == nil) and "+inf" or endtime
    local orderidList = {}
    local orderinfolist = {}

    if orderstate == 0 then
        orderidList = redisItem:zrangebyscore(FootballModel.userOrderidList..userid, startscore, endtime, FootballModel.redis_index)
    elseif  orderstate == 3  then
        orderidList = redisItem:zrangebyscore(FootballModel.userNorebateOrderList..userid, startscore, endtime, FootballModel.redis_index)
    elseif  orderstate == 5  then
        orderidList = redisItem:zrangebyscore(FootballModel.userCountOrderList..userid, startscore, endtime, FootballModel.redis_index)
    end

    if maxpagenum ~= nil then
        --分页，每页10条
        local templist = {}
        local maxmaxpagenum = maxpagenum > #orderidList and #orderidList or  #orderidList
        for i= maxpagenum * 10 + 1, maxpagenum do
            if orderidList[i] ~= nil and orderidList[i] ~= "" then
                table.insert(templist,orderidList[i])
            end
        end
        for k,v in pairs(templist) do
            local  orderinfo = FootballModel.GetOrderInfoByOrderId(v)
            local orderinfoPB = msg_footballgame_pb.gcfootballorderdetail()
            orderinfoPB:ParseFromString(orderinfo)
            table.insert(orderinfolist,orderinfoPB)
        end
    else
        --不分页
        for k,v in pairs(orderidList) do
            local  orderinfo = FootballModel.GetOrderInfoByOrderId(v)
            local orderinfoPB = msg_footballgame_pb.gcfootballorderdetail()
            orderinfoPB:ParseFromString(orderinfo)
            table.insert(orderinfolist,orderinfoPB)
        end

    end
    return  orderinfolist
end


function FootballModel.SetUserRecords(userid,recordinfo)
    redisItem:lpush(FootballModel.userRecordInfoList..userid, recordinfo:SerializeToString(), FootballModel.redis_index)
    if redisItem:llen(FootballModel.userRecordInfoList..userid, FootballModel.redis_index) > 1000 then
		redisItem:rpop(FootballModel.userRecordInfoList..userid, FootballModel.redis_index)
	end    
end

function FootballModel.GetUserRecords(userid)
    local len = redisItem:llen(FootballModel.userRecordInfoList..userid, FootballModel.redis_index)
    if len == 0 then
        local sqlCase = "select * from log_records where userid = "..userid .." order by id desc  limit 1000"
        mysqlLog:executeQuery(sqlCase)
	    while true do
		    local sqlData = mysqlLog:fetch({})
		    if sqlData == nil then
			    break
		    end
            local recordinfo = msg_footballgame_pb.gcfootballrecords()
            recordinfo.result = 0
            recordinfo.opttype= tonumber(sqlData[3])
            local addrecords = recordinfo.records:add()
            addrecords.amount = sqlData[4]
            addrecords.opttime = TimeUtils.GetTime(sqlData[5])
            addrecords.remark = sqlData[6]
            redisItem:rpush(FootballModel.userRecordInfoList..userid, recordinfo:SerializeToString(), FootballModel.redis_index)
	    end
    end
	return redisItem:lrange(FootballModel.userRecordInfoList..userid, 0, -1, FootballModel.redis_index)
end



function FootballModel.SetUserNews(userid,newsid)
    redisItem:hset(FootballModel.userNews..userid,newsid, 1, FootballModel.redis_index)   
end

function FootballModel.GetUserNews(userid,newsid)
    local val = redisItem:hget(FootballModel.userNews..userid,newsid, FootballModel.redis_index)   
    val = val == nil and 0 or 1
    return val
end

function FootballModel.SetUserNewsLock()
    ---redisItem:set(FootballModel.userNews_lock, state, FootballModel.redis_index) 
    redisItem:setex( FootballModel.userNews_lock, 45 , 1,   FootballModel.redis_index)
end

function FootballModel.GetUserNewsLock()
    local val = redisItem:get(FootballModel.userNews_lock, FootballModel.redis_index)   
    val = val == nil and 0 or tonumber(val)
    return val
end
function FootballModel.DelUserNewsLock()
    redisItem:del(FootballModel.userNews_lock, FootballModel.redis_index)   

end


--取值的话 amount 传 0 就可以了
function FootballModel.SetUserCashFreeAmount(userid,amount)
    if amount == nil then
        amount = 0
    end
    local amount =  redisItem:hincrbyfloat(FootballModel.userGetCashFreeAmount, userid,amount, FootballModel.redis_index)
    return tonumber(amount)
end

function FootballModel.GetCashFreeAmountAllUser()
   return redisItem:hkeys(FootballModel.userGetCashFreeAmount,FootballModel.redis_index)
end

function FootballModel.DelUserCashFreeAmount(userid)
   redisItem:hdel(FootballModel.userGetCashFreeAmount,userid,FootballModel.redis_index)
end


function FootballModel.SetTiYanInitAmount(amount)
    redisItem:set(FootballModel.userTiYanInitAmount,amount, FootballModel.redis_index)
end

function FootballModel.GetTiYanInitAmount()
    local sqlCase = "select dict_value from web_dict where dict_category = 'player_gift_money'" 
    mysqlItem:execute(sqlCase)
    local amount = 0
    local sqlData = mysqlItem:fetch()
    if sqlData == nil then
        amount = 0
    else
        amount =  tonumber(sqlData)
    end
--    amount =  redisItem:get(FootballModel.userTiYanInitAmount, FootballModel.redis_index)
--    amount = amount == nil and 0 or tonumber(amount)
    return amount
end

--竞猜输赢下注
function FootballModel.PourJetton(eventid,pourid,userid,pourjetton)
    redisItem:hincrby(FootballModel.football_pour..eventid, pourid,pourjetton,FootballModel.redis_index)
    redisItem:hincrby(FootballModel.football_pour_user..eventid..pourid,userid,pourjetton,FootballModel.redis_index)
end

--获取各个区域总下注额
function FootballModel.GetPourJetton(eventid,pourid)
    local jetton = redisItem:hget(FootballModel.football_pour..eventid, pourid,FootballModel.redis_index)
    jetton = jetton == nil and 0 or tonumber(jetton)
    return jetton    

end

--获取各个区域玩家下注list信息 key=userid value=jetton
function FootballModel.GetAllUserPourList(eventid,pourid)
    return redisItem:hgetall(FootballModel.football_pour_user..eventid..pourid,FootballModel.redis_index)  
end


--获取玩家各个区域下注额
function FootballModel.GetUserPourJetton(eventid,pourid,userid)
    local jetton = redisItem:hget(FootballModel.football_pour_user..eventid..pourid,userid,FootballModel.redis_index)
    jetton = jetton == nil and 0 or tonumber(jetton)
    return jetton
end

--清除下注记录
function FootballModel.ClearPour(eventid)
    redisItem:del(FootballModel.football_pour..eventid ,FootballModel.redis_index)
    for i=1,3  do
        redisItem:del(FootballModel.football_pour_user..eventid..i,FootballModel.redis_index)
    end
    --清除赔率
    redisItem:del(FootballModel.PourWLRate..eventid ,FootballModel.redis_index)

    --删除这个赛事的订单
    FootballModel.DelPourWLOrderInfo(eventid)
end

--竞猜输赢赔率
function FootballModel.SetPourWLRate(eventid,pourid,rate)
    redisItem:hset(FootballModel.PourWLRate..eventid, pourid, rate, FootballModel.redis_index)
end

function FootballModel.GetPourWLRate(eventid,pourid)
    local rate = redisItem:hget(FootballModel.PourWLRate..eventid, pourid, FootballModel.redis_index)
    rate = rate == nil and 0 or tonumber(rate)
    return rate
end
    
--一场赛事一个玩家一个订单  
function FootballModel.SetPourWLOrderInfo(eventid,userid,orderinfo)
    redisItem:hset(FootballModel.PourWLorderinfo..eventid, userid, orderinfo, FootballModel.redis_index)
end

--获取该场订单信息
function FootballModel.GetPourWLOrderInfo(eventid,userid)
    return redisItem:hget(FootballModel.PourWLorderinfo..eventid, userid, FootballModel.redis_index)
end

--订单是否村子
function FootballModel.isExitPourWLOrderInfo(eventid,userid)
    return redisItem:hexists(FootballModel.PourWLorderinfo..eventid, userid, FootballModel.redis_index)
end

--获取该场赛事的所有订单
function FootballModel.GetPourWLOrderInfoList(eventid)
    return redisItem:hgetall(FootballModel.PourWLorderinfo..eventid, FootballModel.redis_index)
end

--删除该场赛事的订单
function FootballModel.DelPourWLOrderInfo(eventid)
    redisItem:del(FootballModel.PourWLorderinfo..eventid, FootballModel.redis_index)
end


function FootballModel.SetUserBindPhoneTime(userid,time)
    redisItem:hset(FootballModel.userBindPhoneTime, userid,time,FootballModel.redis_index)
end

function FootballModel.GetUserBindPhoneTime(userid)
    if redisItem:hexists(FootballModel.userBindPhoneTime, userid, FootballModel.redis_index) then
       
    else
        FootballModel.LoadUserBindPhoneTime(userid)
    end
    local time = redisItem:hget(FootballModel.userBindPhoneTime, userid, FootballModel.redis_index)
    time = time == nil and 0 or tonumber(time)
    return time
end

function FootballModel.GetAllUserBindPhoneTime()
    local list = redisItem:hgetall(FootballModel.userBindPhoneTime, FootballModel.redis_index)
    if list == nil or #list == 0 then
        FootballModel.LoadUserBindPhoneTime()
    else
        return list
    end
    return redisItem:hgetall(FootballModel.userBindPhoneTime, FootballModel.redis_index)
end

function FootballModel.DelUserBindPhoneTime(userid)
    redisItem:hdel(FootballModel.userBindPhoneTime,userid,FootballModel.redis_index)
end

function FootballModel.LoadUserBindPhoneTime(userid)
    if userid == nil then
        --查询所有
        local sqlCase = " select userid,registertime from dy_tyrewardmgr"
        mysqlItem:executeQuery(sqlCase)
        while true do
		    local sqlData = mysqlItem:fetch({})
		    if sqlData == nil then
			    break
		    end
		    local userid = tonumber(sqlData[1])
		    local registertime = TimeUtils.GetTime(sqlData[2])
            FootballModel.SetUserBindPhoneTime(userid,registertime)
	    end 
    else
        local sqlCase = " select userid,registertime from dy_tyrewardmgr where userid = "..userid
        mysqlItem:executeQuery(sqlCase)
        local sqlData = mysqlItem:fetch({})
        if sqlData ~= nil then
            local userid = tonumber(sqlData[1])
		    local registertime = TimeUtils.GetTime(sqlData[2])
            FootballModel.SetUserBindPhoneTime(userid,registertime)
        end
    end
end

--玩家关注赛事
function FootballModel.LoadUserPayAttentionRace()
    local sqlCase = "select raceid,userid from dy_playerattentionrace"
    mysqlItem:executeQuery(sqlCase)
    while true do
        local sqlData = mysqlItem:fetch({})
        if sqlData == nil then
            break
        end
        local raceid = sqlData[1]
        local userid = tonumber(sqlData[2])
        FootballModel.SetUserPayAttentionRace(raceid,userid)
    end
end

function FootballModel.SetUserPayAttentionRace(raceid,userid)
    redisItem:hset(FootballModel.userPayAttentionRace..raceid, userid,1,FootballModel.redis_index)
    local sqlCase = "insert into dy_playerattentionrace(raceid,userid)values('"..raceid.."',"..userid..")"
    SqlServer.rpush(sqlCase)
end

function FootballModel.ExistUserPayAttentionRace(raceid,userid)
    
--    if redisItem:exists(FootballModel.userPayAttentionRace..raceid,FootballModel.redis_index) then
--        local ret = redisItem:hget(FootballModel.userPayAttentionRace..raceid, userid,FootballModel.redis_index)
--        if tonumber(ret) == 1 then
--            return true
--        end
--    else
--        FootballModel.LoadUserPayAttentionRace()
--        redisItem:hget(FootballModel.userPayAttentionRace..raceid, 1,1,FootballModel.redis_index)
--        local ret = redisItem:hget(FootballModel.userPayAttentionRace..raceid, userid,FootballModel.redis_index)
--        if tonumber(ret) == 1 then
--            return true
--        end     
--    end
    local ret = redisItem:hget(FootballModel.userPayAttentionRace..raceid, userid,FootballModel.redis_index)
    if tonumber(ret) == 1 then
        return true
    end   

    return false 
end

function FootballModel.DelUserPayAttentionRace(raceid,userid)

    redisItem:hdel(FootballModel.userPayAttentionRace..raceid, userid,FootballModel.redis_index)
    local sqlCase = "delete from dy_playerattentionrace where userid = "..userid .." and raceid = '"..raceid.."'"
    SqlServer.rpush(sqlCase)
end

--原始赔率
function FootballModel.SetWlChangeRatio(raceid,wltype,rate)
    redisItem:hset(FootballModel.wlchangeRatio..raceid, wltype,rate,FootballModel.redis_index)
    redisItem:expire(FootballModel.wlchangeRatio..raceid,RaceInfoModel.Expire, FootballModel.redis_index)
end

function FootballModel.GetWlChangeRatio(raceid,wltype)
    local rate = redisItem:hget(FootballModel.wlchangeRatio..raceid, wltype, FootballModel.redis_index)
    rate = rate == nil and 1 or tonumber(rate)
    return rate
end

--玩家翻翻乐收益报告信息
function FootballModel.SetFlipProfitReportInfo(userid,orderid)
    redisItem:lpush(FootballModel.userFlipProfitReportInfo..userid, orderid, FootballModel.redis_index)
end

function FootballModel.GetFlipProfitReportInfoLen(userid)
    return redisItem:llen(FootballModel.userFlipProfitReportInfo..userid, FootballModel.redis_index)
end

--玩家个人赛事 区域下注总额
function FootballModel.AddUserRaceRebeatPourjetton(userid,raceid,rebeatid,pourjetton)
    if false == redisItem:exists(FootballModel.userRaceRebeatPourjetton..userid..raceid,FootballModel.redis_index) then
        redisItem:expire(FootballModel.userRaceRebeatPourjetton..userid..raceid,RaceInfoModel.Expire, FootballModel.redis_index)
    end
    if false == redisItem:exists(FootballModel.RaceRebeatPourjetton..raceid,FootballModel.redis_index) then
        redisItem:expire(FootballModel.RaceRebeatPourjetton..raceid,RaceInfoModel.Expire, FootballModel.redis_index)
    end
    if false == redisItem:exists(FootballModel.RaceRebeatUser..raceid..rebeatid,FootballModel.redis_index)  then
        redisItem:expire(FootballModel.RaceRebeatUser..raceid..rebeatid,RaceInfoModel.Expire, FootballModel.redis_index)
    end

    local userpourjetton = redisItem:hincrby(FootballModel.userRaceRebeatPourjetton..userid..raceid, rebeatid,pourjetton,FootballModel.redis_index)
   
    redisItem:hincrby(FootballModel.RaceRebeatPourjetton..raceid, rebeatid,pourjetton,FootballModel.redis_index)
    redisItem:hset(FootballModel.RaceRebeatUser..raceid..rebeatid, userid,1,FootballModel.redis_index)
    if userpourjetton == 0 then
       --玩家撤单
        redisItem:hdel(FootballModel.RaceRebeatUser..raceid..rebeatid, userid,FootballModel.redis_index)
    end
end

function FootballModel.GetUserRaceRebeatPourjetton(userid,raceid,rebeatid)
    local pourjetton =  redisItem:hget(FootballModel.userRaceRebeatPourjetton..userid..raceid, rebeatid,FootballModel.redis_index)
    pourjetton = pourjetton == nil and 0 or tonumber(pourjetton)
    return pourjetton
end

function FootballModel.GetRaceRebeatPourjetton(raceid,rebeatid)
    local pourjetton =  redisItem:hget(FootballModel.RaceRebeatPourjetton..raceid, rebeatid,FootballModel.redis_index)
    pourjetton = pourjetton == nil and 0 or tonumber(pourjetton)
    return pourjetton
end
function FootballModel.GetRaceRebeatUserCount(raceid,rebeatid)
    local list =  redisItem:hkeys(FootballModel.RaceRebeatUser..raceid..rebeatid,FootballModel.redis_index)
    return tonumber(#list) or 0
end


function FootballModel.AddUserCreateProfitidCount()
    return redisItem:incrby(FootballModel.userCreateProfitidCount,1,FootballModel.redis_index)
end


--设置每一场赛事的具体订单信息
function FootballModel.SetRaceOfOrderInfo(raceId,orderinfo)
    local isNew = redisItem:exists(FootballModel.RaceOfOrderInfo..raceId,FootballModel.redis_index)
    redisItem:hset(FootballModel.RaceOfOrderInfo..raceId, orderinfo.orderid, orderinfo:SerializeToString(), FootballModel.redis_index)
    if isNew == false then
        redisItem:expire(FootballModel.RaceOfOrderInfo..raceId,RaceInfoModel.Expire, FootballModel.redis_index)
    end
end
---获取每一场赛事的具体订单信息
function FootballModel.GetRaceOfOrderInfo(raceId,orderid)
    local orderinfo
    if false == redisItem:hexists(FootballModel.RaceOfOrderInfo..raceId,orderid,FootballModel.redis_index) then
       orderinfo = FootballModel.LoadRaceOfOrderInfo(raceId,orderid)
       if orderinfo ~= nil then
            FootballModel.SetRaceOfOrderInfo(orderinfo.eventid,orderinfo)
            orderinfo = orderinfo:SerializeToString()
       end 
    else
        orderinfo = redisItem:hget(FootballModel.RaceOfOrderInfo..raceId, orderid, FootballModel.redis_index)    
    end
    return orderinfo
end

function FootballModel.LoadRaceOfOrderInfo(raceId,orderid)
    local orderinfo  = nil
    local sqlCase = "select * from dy_footballorder where orderid = '"..orderid.."' and  eventid = '"..raceId.."'"
    mysqlItem:executeQuery(sqlCase)
    local sqlData = mysqlItem:fetch({})
    --print(sqlCase)
    if sqlData ~= nil then
        orderinfo = msg_footballgame_pb.gcfootballorderdetail()
        orderinfo.orderid                   =	    sqlData[1]
        orderinfo.userid	                =	    tonumber(sqlData[2])
        orderinfo.eventtype	                =	    sqlData[3]
        orderinfo.orderyiel.subtype	        =	    tonumber(sqlData[4]) or 0
        orderinfo.orderyiel.yieltype	    =	    tonumber(sqlData[5]) or 0
        orderinfo.orderyiel.typescore	    =	    sqlData[6]
        local yiel	                        =	    sqlData[7] --需要从下注信息中获取 实时的
        orderinfo.orderyiel.baoval	        =	    tonumber(sqlData[8]) or 0
        orderinfo.orderyiel.tiyan	        =	    tonumber(sqlData[9]) or 0
        orderinfo.starttime	                =	    TimeUtils.GetTime(sqlData[10])
        orderinfo.endtime	                =	    sqlData[11] ~=nil and  TimeUtils.GetTime(sqlData[11]) or 0
        orderinfo.ordertime	                =	    TimeUtils.GetTime(sqlData[12])
        orderinfo.orderstate	            =	    tonumber(sqlData[13])
        orderinfo.fee	                    =	    sqlData[14] or "0"
        local	win	                        =	    sqlData[15]
        orderinfo.hometeam	                =	    sqlData[16]
        orderinfo.awayteam	                =	    sqlData[17]
        orderinfo.homescore	                =	    tonumber(sqlData[18]) or 0
        orderinfo.awayscore	                =	    tonumber(sqlData[19]) or 0
        orderinfo.eventid	                =	    sqlData[20]
        orderinfo.rebateId	                =	    sqlData[21]
        orderinfo.pourjetton	            =	    sqlData[22] or "0"
        --local	channel	                    =	    sqlData[23]
        orderinfo.repeatCount	            =	    tonumber(sqlData[24]) or 0 --重复计算次数
        orderinfo.pumpMoney	                =	    tonumber(sqlData[25]) or 0 --订单抽水值
        orderinfo.isBet	                    =	    tonumber(sqlData[26])
        --local	wlpourtype	                =	    sqlData[27]
        --local	raceid	                    =	    sqlData[28]
        --local	wlpourlist1	                =	    sqlData[29]
        --local	wlpourlist2	                =	    sqlData[30]
        --local	wlpourlist3	                =	    sqlData[31]
        --local	prechannel	                =	    sqlData[32]
        --local	ordertype	                =	    sqlData[33]
        orderinfo.schemeid	                =	    tonumber(sqlData[34]) or 0 --方案id
        orderinfo.expertid	                =	    tonumber(sqlData[35]) or 0 --专家id
        orderinfo.expert	                =	    sqlData[36] or ""
        local	baobenmoney	                =	    sqlData[37]
        orderinfo.homelogo	                =	    (sqlData[38] == "" or sqlData[38] == nil)  and  g_footballgameDefine.homeTeamFace  or sqlData[38]
        orderinfo.awaylogo	                =	    (sqlData[39] == "" or sqlData[39] == nil ) and  g_footballgameDefine.visitTeamFace  or sqlData[39]
        orderinfo.cancletime                =       (tonumber(sqlData[40]) or 0) > 0 and  tonumber(sqlData[40]) or 0
        
        orderinfo.planraceid		        =       tonumber(sqlData[41]) or 0
	    orderinfo.isinsertorder		        =       tonumber(sqlData[42]) or 0
	    orderinfo.cardid			        =       sqlData[43] or ""
        if  orderinfo.cardid ~= "" then
            local propInfo =  PropService.getPropInfo(orderinfo.userid, orderinfo.cardid)
            if propInfo ~= nil then
                orderinfo.proptype	= propInfo.proptype
	            orderinfo.propname	= propInfo.propname
	            orderinfo.propvalue	= propInfo.propvalue
	            orderinfo.condition	= propInfo.condition
            end

        end
        
        --获取赛事信息
        local raceinfo_pb = RaceInfoModel.GetRaceInfo(orderinfo.eventid)
        local raceinfo = st_footballgame_pb.MerchantRaceInfoDto()
        if raceinfo_pb ~= nil then
            raceinfo:ParseFromString(raceinfo_pb)
        end
        if isBet == 1 then
            --猜胜负
            local totalpourlist = {0,0,0}
            local pourlist      = {0,0,0}
            local ratelist      = {0,0,0} 
            --个下注总额
            pourlist[1]	=	tonumber(sqlData[29])
            pourlist[2]	=	tonumber(sqlData[30])
            pourlist[3]	=	tonumber(sqlData[31])

            for s =1,3  do
                --下注区域总额
                totalpourlist[s] = FootballModel.GetPourJetton(orderinfo.eventid, s)
                orderinfo.wlpourlist:append(tostring(pourlist[s]))
                orderinfo.wltotalpourlist:append(tostring(totalpourlist[s]))
            end
            ratelist = FootballUtils.cluWLrate(totalpourlist)
                
            for s =1,3 do
                orderinfo.wlrate:append(tostring(ratelist[s]))
            end
            if  orderinfo.orderstate == 0  then
                --未结算
                win = FootballUtils.cluWLWin(totalpourlist,pourlist,ratelist,tonumber(orderinfo.fee))
                --print(win,orderinfo.fee)
            end
        else
            --猜比分
            if  orderinfo.orderstate == 0 and orderinfo.schemeid ~= 0  then
                --未结算
                --获取返利信息
                local SimpleRebateInfoPB = RaceInfoModel.GetRaceRebateInfo(orderinfo.eventid, orderinfo.rebateId)
                if SimpleRebateInfoPB ~= nil then
                    local SimpleRebateInfo = st_footballgame_pb.SimpleRebateInfo()
                    SimpleRebateInfo:ParseFromString(SimpleRebateInfoPB)
                    yiel = string.format("%.4f", tonumber(SimpleRebateInfo.rebateRatio))
                    win = tonumber(orderinfo.pourjetton) * (tonumber(yiel)) * (1 - tonumber(orderinfo.fee)) +  tonumber(orderinfo.pourjetton)
                    win = tostring(math.floor(win))
                end
            end
        end

	    orderinfo.win			      = win
        orderinfo.orderyiel.yiel      = yiel 
       
    end
    --print(orderinfo)
    return orderinfo


end

function FootballModel.SetRaceOrderCount(raceid,num)
   if false ==  redisItem:exists(FootballModel.raceOrderCount..raceid,FootballModel.redis_index)then
       redisItem:setex(FootballModel.raceOrderCount..raceid,RaceInfoModel.Expire,0,FootballModel.redis_index)
   end
   redisItem:incrby(FootballModel.raceOrderCount..raceid,num, FootballModel.redis_index)
end

function FootballModel.GetRaceOrderCount(raceid)
    num =  redisItem:get(FootballModel.raceOrderCount..raceid,FootballModel.redis_index)
    num = num == nil and 0 or tonumber(num)
    return num
end


--玩家结算order数量
function FootballModel.SetUserCountOrderNum(userid,val)
    redisItem:hincrby(FootballModel.UserCountOrderNum,userid,val,FootballModel.redis_index )
end

function FootballModel.GetUserCountOrderNum(userid)
    local val = redisItem:hincrby(FootballModel.UserCountOrderNum,userid,0,FootballModel.redis_index )
    return tonumber(val)
end

  
--玩家下注次数（不包括体验金下注）
function FootballModel.SetUserPourTimes(userid)
    local val = redisItem:hincrby(FootballModel.UserPourTimes,userid,1,FootballModel.redis_index )
    return tonumber(val)
end

function FootballModel.GetUserPourTimes(userid)
    local val = redisItem:hincrby(FootballModel.UserPourTimes,userid,0,FootballModel.redis_index )
    return tonumber(val)
end


