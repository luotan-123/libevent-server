RaceInfoModel = {}
RaceInfoModel.redis_index = "redis_raceinfo"

RaceInfoModel.RaceInfo = "raceInfo_" --比赛信息 string     set raceInfo_123456 {pb}
RaceInfoModel.RaceRebateInfo = "raceRebateInfo_" --返利信息 hash      hset raceRebateInfo_123456  654321 {pb}
RaceInfoModel.Expire = 20 * 24 * 60 * 60  -- 信息过期时间，单位秒 

-- 赛事拉取相关
RaceInfoModel.APPID = 800509
RaceInfoModel.APPKEY = "3rhD5ZBFPc63y0N3vml3YWUkt0Zsb73I"
RaceInfoModel.event_httpUrl = "http://47.75.147.0:9004/"
RaceInfoModel.url_head = "{\"Content-Type\": \"application/json\"}"

RaceInfoModel.fee = 5
RaceInfoModel.betfee = 5
RaceInfoModel.OrderExpire = 5 * 24 * 60 * 60  -- 订单过期时间，单位秒 
RaceInfoModel.tywinmoney = "tywinmoney" --体验金盈利部分


-- 赛事状态发送变化集合，触发投注
RaceInfoModel.RaceStatusCancelSet 	= "race_status_cancel"
RaceInfoModel.RaceStatusFinishSet 	= "race_status_finish"

-- 后台结算赛事
RaceInfoModel.HttpRaceSettle 		= "http_race_settle_"

-- 需要计算预期的比赛，就是有投注的比赛
RaceInfoModel.RaceHavePour 			= "race_have_pour_set"  --无序集合

--[[
拉取更新比赛算法：
1、拉取全部赛事，以开赛时间为分界线，上下拉取几天的就行（30分钟执行一次）
2、从赛事集合中拉取，需要更新的比赛状态（5分钟）
3、从赛事集合中拉取，可下注比赛的，返利信息（5分钟）
--]]


--[[
结算赛事算法：
1、拉取赛事信息的时候对比数据变化
2、如果不需要推送赛事信息变化数据，只需要记录结算状态发送变化的赛事
3、将有变化赛事，记录到集合，然后游戏服务器进行结算
--]]

RaceInfoModel.racePostIndex     = "racePostIndex"

---------------------------------------------------------------------------------------------------
--zadd 热门赛事
RaceInfoModel.raceHotList       = "raceHotList"           --所有赛事信息（时间排序）     zadd raceHotList 1577957935 raceid
---------------------------------------------------------------------------------------------------
--zadd 可竞猜赛事有序集合
RaceInfoModel.raceCanList       = "raceCanList"           --所有赛事信息（时间排序）     zadd raceCanList 1577957935 raceid
---------------------------------------------------------------------------------------------------
--zadd 已进行赛事有序集合(包括比赛中和已经结束)
RaceInfoModel.raceFiningList    = "raceFiningList"        --所有赛事信息（时间排序）     zadd raceFiningList 1577957935 raceid
---------------------------------------------------------------------------------------------------
--可以猜输赢的赛事
RaceInfoModel.raceWinList    	= "raceWinList"        	  --所有赛事信息（时间排序）     zadd raceWinList 1577957935 raceid
---------------------------------------------------------------------------------------------------
-- 订单相关列表 list
RaceInfoModel.raceOrderList		= "raceOrderList"		 -- 订单集合


---------------------------------------------------------------------------------------------------
-- 赛事结算相关集合 zset
-- 全场
RaceInfoModel.needNormalSettle  = "needNormalSettle"     	--需要正常结算的比赛（时间排序）     zadd raceFiningList 1577957935 raceid
RaceInfoModel.raceCancelList  	= "raceCancelList"     		--被取消的赛事
RaceInfoModel.raceRevertSettle  = "raceRevertSettle"     	--从新结算的赛事
RaceInfoModel.realTimeSettle  	= "realTimeSettle"     		--实时结算的赛事（主要是正常进行中的比赛），一直不停结算


-- 半场
RaceInfoModel.needNormalSettleHalf  = "needNormalSettleHalf"    --需要正常结算的比赛（时间排序）     zadd raceFiningList 1577957935 raceid
RaceInfoModel.raceCancelListHalf  	= "raceCancelListHalf"     	--被取消的赛事
RaceInfoModel.raceRevertSettleHalf  = "raceRevertSettleHalf"    --从新结算的赛事
RaceInfoModel.realTimeSettleHalf  	= "realTimeSettleHalf"     	--实时结算的赛事（主要是正常进行中的比赛），一直不停结算


--赛事结算，订单(一个订单是否被结算关键看score)，score=0：未结算的订单  score=1：已经结算的订单 score>=2:计算次数
RaceInfoModel.raceSettleOrder 		= "raceSettleOrder_"	
--赛事结算（半场订单），订单(一个订单是否被结算关键看score)，score=0：未结算的订单  score=1：已经结算的订单 score>=2:计算次数
RaceInfoModel.raceSettleOrderHalf 	= "raceSettleOrderHalf_"	

---------------------------------------------------------------------------------------------------
--文字直播
RaceInfoModel.raceTextInfo = "raceTextInfo"     --zadd
--数据分析
RaceInfoModel.raceDataAnalysis = "raceDataAnalysis" --哈希
----------------------------------------------------------------------------------------------------
function RaceInfoModel.LoadRaceInfo(raceid)
	
	if not redisItem:exists(RaceInfoModel.RaceInfo..raceid, RaceInfoModel.redis_index) then
		
		local raceInfoPB = st_footballgame_pb.MerchantRaceInfoDto()
		
		--查询数据库
		local sqlCase = "select * from dy_raceinfo where id='"..raceid.."'"
		mysqlItem:executeQuery(sqlCase)
		local sqlData = mysqlItem:fetch({})
		if sqlData ~= nil then
			
			raceInfoPB.againSettle		= tonumber(sqlData[22]) or 0
			
			raceInfoPB.category 		= sqlData[2]
			
			--raceInfoPB.createTime  	= tonumber(sqlData[22]) or 0
			
			raceInfoPB.dataSource  	= tonumber(sqlData[21]) or 0
			
			raceInfoPB.endTime  		= tostring(TimeUtils.GetTime(sqlData[5]) * 1000) 
			
			raceInfoPB.halfResult  	= sqlData[17]
			raceInfoPB.halfSettle  	= tonumber(sqlData[24]) or 0
			
			raceInfoPB.halfTime 		= tostring(TimeUtils.GetTime(sqlData[6]) * 1000)
			
			raceInfoPB.homeTeam 		= sqlData[7]
			raceInfoPB.isRecommend 		= tonumber(sqlData[18]) or 0
			--raceInfoPB.isValid 		= tonumber(sqlData[22]) or 0
			--raceInfoPB.lastTime 		= tonumber(sqlData[22]) or 0
			raceInfoPB.openStatus		= tonumber(sqlData[20]) or 0
			raceInfoPB.raceId 			= sqlData[1]
			raceInfoPB.raceStatus 		= tonumber(sqlData[12]) or 0
			--raceInfoPB.remark 			= tonumber(sqlData[22]) or 0
			raceInfoPB.shelvesStatus	= tonumber(sqlData[11]) or 0
			
			raceInfoPB.startTime 		= tostring(TimeUtils.GetTime(sqlData[3]) * 1000)
			--raceInfoPB.updateTime  	= tonumber(sqlData[22]) or 0
			--raceInfoPB.versionAgain 	= tonumber(sqlData[22]) or 0
			--raceInfoPB.versionRoll  	= tonumber(sqlData[22]) or 0
			raceInfoPB.visitTeam 		= sqlData[8]
			raceInfoPB.weight 			= tonumber(sqlData[19]) or 0
			raceInfoPB.winResult 		= sqlData[15]
			raceInfoPB.winTeam 		= sqlData[14]
			raceInfoPB.winType 		= tonumber(sqlData[16]) or 0
			raceInfoPB.totalBet 		= sqlData[35]
			--raceInfoPB.maxYiel			= tonumber(sqlData[22]) or 0
			--raceInfoPB.isGuarantee  	= tonumber(sqlData[22]) or 0
			--raceInfoPB.agentType  		= tonumber(sqlData[22]) or 0
			raceInfoPB.betfee			= tonumber(sqlData[31]) or 0
			raceInfoPB.fee				= tonumber(sqlData[29]) or 0
			raceInfoPB.raceTotalBet	= sqlData[30]
			raceInfoPB.channel			= sqlData[27]
			raceInfoPB.isBet			= tonumber(sqlData[28]) or 0
			raceInfoPB.homeTeamFace 	= sqlData[32]
			raceInfoPB.visitTeamFace 	= sqlData[33]
			raceInfoPB.matchId  		= sqlData[36]
			raceInfoPB.seasonId  		= sqlData[37]
			raceInfoPB.homeId  			= sqlData[38]
			raceInfoPB.visitId  		= sqlData[39]
			
		else
			print("====查询赛事失败,赛事id:"..raceId)
			LogFile("error", "====查询赛事失败,赛事id:"..raceId)
			return
		end
		
		redisItem:set(RaceInfoModel.RaceInfo..raceid, raceInfoPB:SerializeToString(), RaceInfoModel.redis_index)
		RedisClearModel.AddNormalKey(RaceInfoModel.RaceInfo..raceid, RaceInfoModel.Expire, RaceInfoModel.redis_index)
		
		return raceInfoPB:SerializeToString()
	end
	
end

--设置比赛信息  raceInfoPB是序列化之后的字符串
function RaceInfoModel.SetRaceInfo(raceid, raceInfoPB)
    redisItem:set(RaceInfoModel.RaceInfo..raceid, raceInfoPB, RaceInfoModel.redis_index)
	RedisClearModel.AddNormalKey(RaceInfoModel.RaceInfo..raceid, RaceInfoModel.Expire, RaceInfoModel.redis_index)
end


--获取比赛信息
function RaceInfoModel.GetRaceInfo(raceid)
    return redisItem:get(RaceInfoModel.RaceInfo..raceid, RaceInfoModel.redis_index)
end

-- 加载返利信息
function RaceInfoModel.LoadRaceRebateInfo(raceid, rebateId)
	
	if not redisItem:hexists(RaceInfoModel.RaceRebateInfo..raceid, rebateId, RaceInfoModel.redis_index) then
		
		local raceRebateInfoPB = st_footballgame_pb.SimpleRebateInfo()
		
		--查询数据库
		local sqlCase = "select * from dy_racerebateinfo where id='"..rebateId.."'"
		mysqlItem:executeQuery(sqlCase)
		local sqlData = mysqlItem:fetch({})
		if sqlData ~= nil then
			
			local jsonData = luajson.decode(sqlData[3])
			
			raceRebateInfoPB.rebateId				= rebateId
			raceRebateInfoPB.raceId					= raceid
			raceRebateInfoPB.teams					= jsonData['teams']
			raceRebateInfoPB.score					= jsonData['score']
			raceRebateInfoPB.ruleType 				= tonumber(sqlData[4]) or 0
			raceRebateInfoPB.baobenMoney			= sqlData[13]
			raceRebateInfoPB.rebateRatio			= tonumber(jsonData['rebateRatio']) or 0
			raceRebateInfoPB.validAmount			= tonumber(sqlData[7]) or 0
			raceRebateInfoPB.rebateOpenStatus		= tonumber(sqlData[8]) or 0
			raceRebateInfoPB.baoval    				= tonumber(sqlData[11]) or 0
			raceRebateInfoPB.tiyan	  				= tonumber(sqlData[12]) or 0
			raceRebateInfoPB.changeRatio			= 0
			raceRebateInfoPB.isartificial	  		= 0
	
		else
			print("====查询返利失败,赛事id:"..raceId.." 返利id："..rebateId)
			LogFile("error", "====查询返利失败,赛事id:"..raceId.." 返利id："..rebateId)
			return
		end
		
		redisItem:hset(RaceInfoModel.RaceRebateInfo..raceid, rebateId, raceRebateInfoPB:SerializeToString(), RaceInfoModel.redis_index)
		
		RaceInfoModel.SetRaceRebateInfoExpire(raceid)
		
		return raceRebateInfoPB:SerializeToString()
	end
	
end


-- 加载所有返利信息
function RaceInfoModel.LoadAllRaceRebateInfo(raceid)
	
	if not redisItem:exists(RaceInfoModel.RaceRebateInfo..raceid, RaceInfoModel.redis_index) then
		
		local raceRebateInfoPB = st_footballgame_pb.SimpleRebateInfo()
		
		--查询数据库
		local sqlCase = "select * from dy_racerebateinfo where race_id='"..raceid.."'"
		mysqlItem:executeQuery(sqlCase)
		
		while true do
			
			local sqlData = mysqlItem:fetch({})
			if sqlData == nil then
				break
			end
			
			local jsonData = luajson.decode(sqlData[3])
			
			raceRebateInfoPB.rebateId				= sqlData[1]
			raceRebateInfoPB.raceId					= raceid
			raceRebateInfoPB.teams					= jsonData['teams']
			raceRebateInfoPB.score					= jsonData['score']
			raceRebateInfoPB.ruleType 				= tonumber(sqlData[4]) or 0
			raceRebateInfoPB.baobenMoney			= sqlData[13]
			raceRebateInfoPB.rebateRatio			= tonumber(jsonData['rebateRatio']) or 0
			raceRebateInfoPB.validAmount			= tonumber(sqlData[7]) or 0
			raceRebateInfoPB.rebateOpenStatus		= tonumber(sqlData[8]) or 0
			raceRebateInfoPB.baoval    				= tonumber(sqlData[11]) or 0
			raceRebateInfoPB.tiyan	  				= tonumber(sqlData[12]) or 0
			raceRebateInfoPB.changeRatio			= 0
			raceRebateInfoPB.isartificial	  		= 0
			
			redisItem:hset(RaceInfoModel.RaceRebateInfo..raceid, raceRebateInfoPB.rebateId, raceRebateInfoPB:SerializeToString(), RaceInfoModel.redis_index)
			
		end
		
		RaceInfoModel.SetRaceRebateInfoExpire(raceid)
		
	end
	
end


--设置返利信息   raceRebateInfoPB是序列化之后的字符串
function RaceInfoModel.SetRaceRebateInfo(raceid, rebateId, raceRebateInfoPB)
    redisItem:hset(RaceInfoModel.RaceRebateInfo..raceid, rebateId, raceRebateInfoPB, RaceInfoModel.redis_index)
end


--设置返利信息   raceRebateInfoPB是序列化之后的字符串
function RaceInfoModel.SetSrcRaceRebateInfo(raceid, rebateId, srcRaceRebateInfoPB, tiyan)
    
	tiyan = tiyan or 0
	
	local srcRebateInfo = st_footballgame_pb.SimpleRebateInfo()
	srcRebateInfo:ParseFromString(srcRaceRebateInfoPB)


	-- 获取区域详情
	local SimpleRebateInfoPB = RaceInfoModel.GetRaceRebateInfo(raceid, rebateId)
    if SimpleRebateInfoPB ~= nil then
		local info = st_footballgame_pb.SimpleRebateInfo()
		info:ParseFromString(SimpleRebateInfoPB)
		
		info.validAmount = srcRebateInfo.validAmount;
		info.rebateOpenStatus = srcRebateInfo.rebateOpenStatus;
		info.baoval = srcRebateInfo.baoval;
		info.tiyan = tiyan -- == 0 and srcRebateInfo.tiyan or tiyan;
		info.baobenMoney = srcRebateInfo.baobenMoney;
		info.rebateRatio = srcRebateInfo.rebateRatio;
		info.changeRatio = srcRebateInfo.changeRatio;
		info.isartificial = srcRebateInfo.isartificial;
	
		RaceInfoModel.SetRaceRebateInfo(raceid, rebateId, info:SerializeToString())
	end

end


--设置最大收益率
function RaceInfoModel.SetMaxRaceRebate(raceid, maxrebateRatio)
	
	local raceinfo = RaceInfoModel.GetRaceInfo(raceid)
	
    if raceinfo ~= nil then
		local event = st_footballgame_pb.MerchantRaceInfoDto()
		event:ParseFromString(raceinfo)
		
		event.maxYiel = maxrebateRatio;

		RaceInfoModel.SetRaceInfo(raceid, event:SerializeToString())
	end

end

--设置赛事是否推荐
function RaceInfoModel.SetRecommendRace(raceid)
	
	local raceinfo = RaceInfoModel.GetRaceInfo(raceid)
	
    if raceinfo ~= nil then
		local event = st_footballgame_pb.MerchantRaceInfoDto()
		event:ParseFromString(raceinfo)
		
		event.isRecommend = 1;
		
		RaceInfoModel.SetRaceInfo(raceid, event:SerializeToString())
		
		RaceInfoModel.AddRaceListByRaceInfo(event)
	end

end

--设置赛事可下注
function RaceInfoModel.SetRaceCanBet(raceid, orderType,  bet)
	
	local raceinfo = RaceInfoModel.GetRaceInfo(raceid)
	
    if raceinfo ~= nil then
		local event = st_footballgame_pb.MerchantRaceInfoDto()
		event:ParseFromString(raceinfo)
		
		if tonumber(event.totalBet) <= 0 and  orderType == 2 then
			return
		end
		
		if orderType == 1 then
			event.totalBet = tostring(tonumber(event.totalBet) + tonumber(bet));
		else
			event.totalBet = tostring(tonumber(event.totalBet) - tonumber(bet));
		end
		
		
		RaceInfoModel.SetRaceInfo(raceid, event:SerializeToString())
	end

end

--设置自己维护的赛事数据
function RaceInfoModel.SetSrcRaceInfo(raceid, psrcrace)
	
	local raceinfo = RaceInfoModel.GetRaceInfo(raceid)
	
	local raceinfoTemp = st_footballgame_pb.MerchantRaceInfoDto()
	raceinfoTemp:ParseFromString(psrcrace);
		
    if raceinfo ~= nil then
		local event = st_footballgame_pb.MerchantRaceInfoDto()
		event:ParseFromString(raceinfo)
		
		event.totalBet = raceinfoTemp.totalBet;
		event.maxYiel = raceinfoTemp.maxYiel;
		event.fee = raceinfoTemp.fee;
		event.betfee = raceinfoTemp.betfee;
		event.raceTotalBet = raceinfoTemp.raceTotalBet;
		event.channel = raceinfoTemp.channel;
		event.isBet = raceinfoTemp.isBet;
		event.openStatus = raceinfoTemp.openStatus;
		event.shelvesStatus = raceinfoTemp.shelvesStatus;
		event.allfirstrebate = raceinfoTemp.allfirstrebate;
		
		RaceInfoModel.SetRaceInfo(raceid, event:SerializeToString())
		
		RaceInfoModel.AddRaceListByRaceInfo(event)
	end

end


--设置某个赛事下注区域，过期时间
function RaceInfoModel.SetRaceRebateInfoExpire(raceid)
    RedisClearModel.AddNormalKey(RaceInfoModel.RaceRebateInfo..raceid, RaceInfoModel.Expire, RaceInfoModel.redis_index)
end


--获取返利信息，获取所有下注区域
function RaceInfoModel.GetAllRaceRebateInfo(raceid)
    return redisItem:hgetall(RaceInfoModel.RaceRebateInfo..raceid, RaceInfoModel.redis_index)
end


--获取返利信息，获取单个下注区域
function RaceInfoModel.GetRaceRebateInfo(raceid, rebateId)
    return redisItem:hget(RaceInfoModel.RaceRebateInfo..raceid, rebateId, RaceInfoModel.redis_index)
end


--------------------------------------------------------------------------------------------------
-- 拉取可竞猜比赛列表 racetype=0：可竞猜列表  racetype=1：已进行列表  racetype=2：热门赛事   racetype=3：猜输赢赛事 
function RaceInfoModel.GetRaceList(racetype, starttime, endtime, channel)
	if racetype == 0 then
		return redisItem:zrangebyscore(RaceInfoModel.raceCanList..channel, starttime, endtime, RaceInfoModel.redis_index)
	elseif racetype == 1 then
		return redisItem:zrangebyscore(RaceInfoModel.raceFiningList..channel, starttime, endtime, RaceInfoModel.redis_index)
	elseif racetype == 2 then
		return redisItem:zrangebyscore(RaceInfoModel.raceHotList..channel, starttime, endtime, RaceInfoModel.redis_index)
	elseif racetype == 3 then
		return redisItem:zrangebyscore(RaceInfoModel.raceWinList..channel, starttime, endtime, RaceInfoModel.redis_index)
	end
end


-- 根据赛事状态，将赛事添加到相应的集合
function RaceInfoModel.AddRaceListByRaceInfo(raceinfo)
	
	if raceinfo == nil or type(raceinfo) ~= "table" then
		return
	end
	
	local channel = raceinfo.channel
	
	if raceinfo.raceStatus == 3 then
		
		if raceinfo.shelvesStatus == 0 then -- 赛事下架
			RaceInfoModel.RemoveRaceList(0, raceinfo.raceId, channel)
			RaceInfoModel.RemoveRaceList(2, raceinfo.raceId, channel)
			RaceInfoModel.RemoveRaceList(3, raceinfo.raceId, channel)
		elseif raceinfo.isBet == 1 then --猜输赢赛事
			RaceInfoModel.RemoveRaceList(0, raceinfo.raceId, channel)
			RaceInfoModel.RemoveRaceList(2, raceinfo.raceId, channel)
			redisItem:zadd(RaceInfoModel.raceWinList..channel, raceinfo.startTime, raceinfo.raceId, RaceInfoModel.redis_index)
		elseif raceinfo.isRecommend == 1 then --热门赛事
			RaceInfoModel.RemoveRaceList(0, raceinfo.raceId, channel)
			RaceInfoModel.RemoveRaceList(3, raceinfo.raceId, channel)
			redisItem:zadd(RaceInfoModel.raceHotList..channel, raceinfo.startTime, raceinfo.raceId, RaceInfoModel.redis_index)
		else
			RaceInfoModel.RemoveRaceList(2, raceinfo.raceId, channel)
			RaceInfoModel.RemoveRaceList(3, raceinfo.raceId, channel)
			redisItem:zadd(RaceInfoModel.raceCanList..channel, raceinfo.startTime, raceinfo.raceId, RaceInfoModel.redis_index)
		end
		
	else
		RaceInfoModel.RemoveRaceList(0, raceinfo.raceId, channel)
		RaceInfoModel.RemoveRaceList(2, raceinfo.raceId, channel)
		RaceInfoModel.RemoveRaceList(3, raceinfo.raceId, channel)
		redisItem:zadd(RaceInfoModel.raceFiningList..channel, raceinfo.startTime, raceinfo.raceId, RaceInfoModel.redis_index)
	end
	
end


-- 删除
function RaceInfoModel.RemoveRaceList(racetype, raceid, channel)
	if racetype == 0 then
		redisItem:zrem(RaceInfoModel.raceCanList..channel, raceid, RaceInfoModel.redis_index)
	elseif racetype == 1 then
		redisItem:zrem(RaceInfoModel.raceFiningList..channel, raceid, RaceInfoModel.redis_index)
	elseif racetype == 2 then
		redisItem:zrem(RaceInfoModel.raceHotList..channel, raceid, RaceInfoModel.redis_index)
	elseif racetype == 3 then
		redisItem:zrem(RaceInfoModel.raceWinList..channel, raceid, RaceInfoModel.redis_index)
	end
end

--------------------------------------------------------------------------------------------------
-- 赛事结算集合相关操作
-- yieltype 类型 0:全场 1：半场
-- resulttype类型：
-- 1:正常结算赛事
-- 2:赛事被取消
-- 3:重新结算
-- 4:实时结算的赛事
function RaceInfoModel.GetRaceResultList(resulttype, yieltype)
	if yieltype == 0 then
		if resulttype == 1 then
			return redisItem:zrange(RaceInfoModel.needNormalSettle, 0, -1, RaceInfoModel.redis_index)
		elseif resulttype == 2 then
			return redisItem:zrange(RaceInfoModel.raceCancelList, 0, -1, RaceInfoModel.redis_index)
		elseif resulttype == 3 then
			return redisItem:zrange(RaceInfoModel.raceRevertSettle, 0, -1, RaceInfoModel.redis_index)
		else
			return redisItem:zrange(RaceInfoModel.realTimeSettle, 0, -1, RaceInfoModel.redis_index)
		end
	else
		if resulttype == 1 then
			return redisItem:zrange(RaceInfoModel.needNormalSettleHalf, 0, -1, RaceInfoModel.redis_index)
		elseif resulttype == 2 then
			return redisItem:zrange(RaceInfoModel.raceCancelListHalf, 0, -1, RaceInfoModel.redis_index)
		elseif resulttype == 3 then
			return redisItem:zrange(RaceInfoModel.raceRevertSettleHalf, 0, -1, RaceInfoModel.redis_index)
		else
			return redisItem:zrange(RaceInfoModel.realTimeSettleHalf, 0, -1, RaceInfoModel.redis_index)
		end
	end
end

function RaceInfoModel.AddRaceResultList(resulttype, raceid, starttime, yieltype)
	
	starttime = starttime or 0
	
	if yieltype == 0 then
		if resulttype == 1 then
			redisItem:zadd(RaceInfoModel.needNormalSettle, starttime, raceid, RaceInfoModel.redis_index)
			redisItem:zrem(RaceInfoModel.raceCancelList, raceid, RaceInfoModel.redis_index)
			redisItem:zrem(RaceInfoModel.raceRevertSettle, raceid, RaceInfoModel.redis_index)
			redisItem:zrem(RaceInfoModel.realTimeSettle, raceid, RaceInfoModel.redis_index)
		elseif resulttype == 2 then
			redisItem:zadd(RaceInfoModel.raceCancelList, starttime, raceid, RaceInfoModel.redis_index)
			redisItem:zrem(RaceInfoModel.needNormalSettle, raceid, RaceInfoModel.redis_index)
			redisItem:zrem(RaceInfoModel.raceRevertSettle, raceid, RaceInfoModel.redis_index)
			redisItem:zrem(RaceInfoModel.realTimeSettle, raceid, RaceInfoModel.redis_index)
		elseif resulttype == 3 then
			redisItem:zadd(RaceInfoModel.raceRevertSettle, starttime, raceid, RaceInfoModel.redis_index)
			redisItem:zrem(RaceInfoModel.raceCancelList, raceid, RaceInfoModel.redis_index)
			redisItem:zrem(RaceInfoModel.needNormalSettle, raceid, RaceInfoModel.redis_index)
			redisItem:zrem(RaceInfoModel.realTimeSettle, raceid, RaceInfoModel.redis_index)
		else
			redisItem:zadd(RaceInfoModel.realTimeSettle, starttime, raceid, RaceInfoModel.redis_index)
			redisItem:zrem(RaceInfoModel.raceCancelList, raceid, RaceInfoModel.redis_index)
			redisItem:zrem(RaceInfoModel.raceRevertSettle, raceid, RaceInfoModel.redis_index)
			redisItem:zrem(RaceInfoModel.needNormalSettle, raceid, RaceInfoModel.redis_index)
		end
	else
		if resulttype == 1 then
			redisItem:zadd(RaceInfoModel.needNormalSettleHalf, starttime, raceid, RaceInfoModel.redis_index)
			redisItem:zrem(RaceInfoModel.raceCancelListHalf, raceid, RaceInfoModel.redis_index)
			redisItem:zrem(RaceInfoModel.raceRevertSettleHalf, raceid, RaceInfoModel.redis_index)
			redisItem:zrem(RaceInfoModel.realTimeSettleHalf, raceid, RaceInfoModel.redis_index)
		elseif resulttype == 2 then
			redisItem:zadd(RaceInfoModel.raceCancelListHalf, starttime, raceid, RaceInfoModel.redis_index)
			redisItem:zrem(RaceInfoModel.needNormalSettleHalf, raceid, RaceInfoModel.redis_index)
			redisItem:zrem(RaceInfoModel.raceRevertSettleHalf, raceid, RaceInfoModel.redis_index)
			redisItem:zrem(RaceInfoModel.realTimeSettleHalf, raceid, RaceInfoModel.redis_index)
		elseif resulttype == 3 then
			redisItem:zadd(RaceInfoModel.raceRevertSettleHalf, starttime, raceid, RaceInfoModel.redis_index)
			redisItem:zrem(RaceInfoModel.raceCancelListHalf, raceid, RaceInfoModel.redis_index)
			redisItem:zrem(RaceInfoModel.needNormalSettleHalf, raceid, RaceInfoModel.redis_index)
			redisItem:zrem(RaceInfoModel.realTimeSettleHalf, raceid, RaceInfoModel.redis_index)
		else
			redisItem:zadd(RaceInfoModel.realTimeSettleHalf, starttime, raceid, RaceInfoModel.redis_index)
			redisItem:zrem(RaceInfoModel.raceCancelListHalf, raceid, RaceInfoModel.redis_index)
			redisItem:zrem(RaceInfoModel.raceRevertSettleHalf, raceid, RaceInfoModel.redis_index)
			redisItem:zrem(RaceInfoModel.needNormalSettleHalf, raceid, RaceInfoModel.redis_index)
		end
	end
	
end

function RaceInfoModel.RemoveRaceResultList(resulttype, raceid, yieltype)
	if yieltype == 0 then
		if resulttype == 1 then
			redisItem:zrem(RaceInfoModel.needNormalSettle, raceid, RaceInfoModel.redis_index)
		elseif resulttype == 2 then
			redisItem:zrem(RaceInfoModel.raceCancelList, raceid, RaceInfoModel.redis_index)
		elseif resulttype == 3 then
			redisItem:zrem(RaceInfoModel.raceRevertSettle, raceid, RaceInfoModel.redis_index)
		else
			redisItem:zrem(RaceInfoModel.realTimeSettle, raceid, RaceInfoModel.redis_index)
		end
	else
		if resulttype == 1 then
			redisItem:zrem(RaceInfoModel.needNormalSettleHalf, raceid, RaceInfoModel.redis_index)
		elseif resulttype == 2 then
			redisItem:zrem(RaceInfoModel.raceCancelListHalf, raceid, RaceInfoModel.redis_index)
		elseif resulttype == 3 then
			redisItem:zrem(RaceInfoModel.raceRevertSettleHalf, raceid, RaceInfoModel.redis_index)
		else
			redisItem:zrem(RaceInfoModel.realTimeSettleHalf, raceid, RaceInfoModel.redis_index)
		end
	end
	
end

function RaceInfoModel.ClearRaceResultList(resulttype, yieltype)
	if yieltype == 0 then
		if resulttype == 1 then
			redisItem:del(RaceInfoModel.needNormalSettle, RaceInfoModel.redis_index)
		elseif resulttype == 2 then
			redisItem:del(RaceInfoModel.raceCancelList, RaceInfoModel.redis_index)
		elseif resulttype == 3 then
			redisItem:del(RaceInfoModel.raceRevertSettle, RaceInfoModel.redis_index)
		else
			redisItem:del(RaceInfoModel.realTimeSettle, RaceInfoModel.redis_index)
		end
	else
		if resulttype == 1 then
			redisItem:del(RaceInfoModel.needNormalSettleHalf, RaceInfoModel.redis_index)
		elseif resulttype == 2 then
			redisItem:del(RaceInfoModel.raceCancelListHalf, RaceInfoModel.redis_index)
		elseif resulttype == 3 then
			redisItem:del(RaceInfoModel.raceRevertSettleHalf, RaceInfoModel.redis_index)
		else
			redisItem:del(RaceInfoModel.realTimeSettleHalf, RaceInfoModel.redis_index)
		end
	end
end

--------------------------------------------------------------------------------------------------

-- 比较前后两次赛事信息  pb中MerchantRaceInfoDto(非序列化)
-- 比较状态，判断赛事是否需要结算，是否需要加到别的列表
function RaceInfoModel.CompareRaceResult(beforeRaceInfo, nowRaceInfo)
	
	if beforeRaceInfo.raceId ~= nowRaceInfo.raceId then
		return;
	end
	
	if beforeRaceInfo.channel ~= nowRaceInfo.channel then
		LogFile("error", "赛事比较错误:"..beforeRaceInfo.raceId..","..beforeRaceInfo.channel..","..nowRaceInfo.channel)
		return;
	end
	------- 赛事状态变化 --------
	-- 出现了一种新的赛事状态5
	---赛事状态(0:取消(取消的赛事进行撤注操作) 1:正常进行中 2:已经结束(定时任务爬取赛事结果)
	--3:未开始 4:赛事改期5赛事异常 6手动取消 7系统撤单 )
	
	-- 之前是未开始状态
	if beforeRaceInfo.raceStatus == 3 and nowRaceInfo.raceStatus ~= 3 then
		
		
		-- 设置赛事订单过期时间
		RedisClearModel.AddNormalKey(RaceInfoModel.raceSettleOrder..nowRaceInfo.raceId, RaceInfoModel.OrderExpire, RaceInfoModel.redis_index)
		RedisClearModel.AddNormalKey(RaceInfoModel.raceSettleOrderHalf..nowRaceInfo.raceId, RaceInfoModel.OrderExpire, RaceInfoModel.redis_index)
		
		if nowRaceInfo.raceStatus == 0 or nowRaceInfo.raceStatus > 3 then   -- 变成，取消赛事
			RaceInfoModel.AddRaceResultList(2, nowRaceInfo.raceId, nowRaceInfo.startTime, 0)
			RaceInfoModel.AddRaceResultList(2, nowRaceInfo.raceId, nowRaceInfo.startTime, 1)
			
			
		elseif nowRaceInfo.raceStatus == 1 then   -- 变成进行中
		
			if beforeRaceInfo.halfResult ~= nowRaceInfo.halfResult then  -- 结果变了
				RaceInfoModel.AddRaceResultList(4, nowRaceInfo.raceId, nowRaceInfo.startTime, 1)
			end
			
			if beforeRaceInfo.winResult  ~= nowRaceInfo.winResult  then  -- 结果变了
				RaceInfoModel.AddRaceResultList(4, nowRaceInfo.raceId, nowRaceInfo.startTime, 0)
			end
			
		end
		
	end
	
	
	--之前是正常进行中
	if beforeRaceInfo.raceStatus == 1 then
		
		if nowRaceInfo.raceStatus == 0 or nowRaceInfo.raceStatus > 3 then   -- 变成，取消赛事
			RaceInfoModel.AddRaceResultList(2, nowRaceInfo.raceId, nowRaceInfo.startTime, 0)
			RaceInfoModel.AddRaceResultList(2, nowRaceInfo.raceId, nowRaceInfo.startTime, 1)
		end
		
		if nowRaceInfo.raceStatus == 1 then   -- 正常进行中不变，判断半场结算状态
			
			if beforeRaceInfo.halfSettle ~= nowRaceInfo.halfSettle then 	-- 结算状态变了
				-- 半场
				if nowRaceInfo.halfSettle  == 1 or nowRaceInfo.halfSettle  == 2 then  -- 正常结算
					RaceInfoModel.AddRaceResultList(1, nowRaceInfo.raceId, nowRaceInfo.startTime, 1)
				elseif nowRaceInfo.halfSettle  == 3 or nowRaceInfo.halfSettle  == 5 then  --从新结算
					RaceInfoModel.AddRaceResultList(3, nowRaceInfo.raceId, nowRaceInfo.startTime, 1)
				elseif nowRaceInfo.halfSettle  == 4 then  --取消
					RaceInfoModel.AddRaceResultList(2, nowRaceInfo.raceId, nowRaceInfo.startTime, 1)
				end
			end
			
			if beforeRaceInfo.halfResult ~= nowRaceInfo.halfResult then  -- 结果变了
				RaceInfoModel.AddRaceResultList(4, nowRaceInfo.raceId, nowRaceInfo.startTime, 1)
			end
			
			if beforeRaceInfo.winResult  ~= nowRaceInfo.winResult  then  -- 结果变了
				RaceInfoModel.AddRaceResultList(4, nowRaceInfo.raceId, nowRaceInfo.startTime, 0)
			end
			
		end
		
	end
	
	
	-- 状态是已经结束
	if beforeRaceInfo.raceStatus ~= 2 and nowRaceInfo.raceStatus == 2 then   -- 直接变成已经结算
	
		----------- 全场
		if nowRaceInfo.againSettle == 1 or nowRaceInfo.againSettle == 2 or nowRaceInfo.againSettle == 0 then  -- 正常结算
			RaceInfoModel.AddRaceResultList(1, nowRaceInfo.raceId, nowRaceInfo.startTime, 0)
		end
		
		if nowRaceInfo.againSettle == 3 or nowRaceInfo.againSettle == 5 then  --从新结算
			RaceInfoModel.AddRaceResultList(1, nowRaceInfo.raceId, nowRaceInfo.startTime, 0)
		end
		
		if nowRaceInfo.againSettle == 4 then  --取消
			RaceInfoModel.AddRaceResultList(2, nowRaceInfo.raceId, nowRaceInfo.startTime, 0)
		end
		
		
		------------ 半场
		if nowRaceInfo.halfSettle  == 1 or nowRaceInfo.halfSettle  == 2 or nowRaceInfo.halfSettle == 0 then  -- 正常结算
			RaceInfoModel.AddRaceResultList(1, nowRaceInfo.raceId, nowRaceInfo.startTime, 1)
		end
		
		if nowRaceInfo.halfSettle  == 3 or nowRaceInfo.halfSettle  == 5 then  --从新结算
			RaceInfoModel.AddRaceResultList(1, nowRaceInfo.raceId, nowRaceInfo.startTime, 1)
		end
		
		if nowRaceInfo.halfSettle  == 4 then  --取消
			RaceInfoModel.AddRaceResultList(2, nowRaceInfo.raceId, nowRaceInfo.startTime, 1)
		end
		
	end

	-- 状态是已经结束
	if beforeRaceInfo.raceStatus == 2 and nowRaceInfo.raceStatus == 2 then   -- 直接变成已经结算
	
		----------- 全场
		if beforeRaceInfo.againSettle ~= nowRaceInfo.againSettle then
			if nowRaceInfo.againSettle == 3 or nowRaceInfo.againSettle == 5 then  --从新结算
				RaceInfoModel.AddRaceResultList(3, nowRaceInfo.raceId, nowRaceInfo.startTime, 0)
			end
		end

		------------ 半场
		if beforeRaceInfo.halfSettle ~= nowRaceInfo.halfSettle then
			if nowRaceInfo.halfSettle  == 3 or nowRaceInfo.halfSettle  == 5 then  --从新结算
				RaceInfoModel.AddRaceResultList(3, nowRaceInfo.raceId, nowRaceInfo.startTime, 1)
			end
		end
		
	end
	
end



-- 订单相关操作   orderType=1:下单     orderType=2：撤单   yieltype类型 0:全场 1：半场
function RaceInfoModel.PushOrderList(orderID, orderType, raceId, pourjetton, yieltype, rebateId, istiyan, yiel)
	
	-- 把订单添加或者删除到赛事集合
	if orderType == 1 then
		if yieltype == 0 then
			redisItem:zadd(RaceInfoModel.raceSettleOrder..raceId, 0, orderID, RaceInfoModel.redis_index)
		else
			redisItem:zadd(RaceInfoModel.raceSettleOrderHalf..raceId, 0, orderID, RaceInfoModel.redis_index)
		end
	else
		if yieltype == 0 then
			redisItem:zrem(RaceInfoModel.raceSettleOrder..raceId, orderID, RaceInfoModel.redis_index)
		else
			redisItem:zrem(RaceInfoModel.raceSettleOrderHalf..raceId, orderID, RaceInfoModel.redis_index)
		end
	end
	
	-- 记录相关信息
	local win = tonumber(pourjetton) * tonumber(yiel)
	
	RaceInfoModel.SaveRaceRebateTotalbetToDB(rebateId, pourjetton, orderType, istiyan, win)
	
	RaceInfoModel.SaveRaceWinMoneyToDB(raceId, orderType, pourjetton, yieltype, istiyan, win)
end


-- 分割字符串
function RaceInfoModel.SplitString(szFullString, szSeparator) 
	
	local nFindStartIndex = 1  
	local nSplitIndex = 1  
	local nSplitArray = {}  
	while true do  
		local nFindLastIndex = string.find(szFullString, szSeparator, nFindStartIndex)  
		if not nFindLastIndex then  
			nSplitArray[nSplitIndex] = string.sub(szFullString, nFindStartIndex, string.len(szFullString))  
			break  
		end  
		nSplitArray[nSplitIndex] = string.sub(szFullString, nFindStartIndex, nFindLastIndex - 1)  
		nFindStartIndex = nFindLastIndex + string.len(szSeparator)  
		nSplitIndex = nSplitIndex + 1  
	end  
	
	return nSplitArray  
end

-- 处理字符串 dstType=1 目标是字符串， dstType=2：目标是数字
function RaceInfoModel.HandleJson(str, dstType)
	if str == nil then
		if dstType == nil or dstType == 1 then
			return "0"
		else
			return 0
		end
	end
	
	if dstType == 2 then
		return tonumber(str)
	end
	
	if dstType == nil or dstType == 1 then
		return tostring(str)
	end
	
	return str
end


-- 根据json解析之后的table，活动pb table
function RaceInfoModel.GetPbRaceInfoByJson(raceinfo, jsontable)
	
	raceinfo.againSettle	= RaceInfoModel.HandleJson(jsontable.againSettle		,2)
	raceinfo.category 		= RaceInfoModel.HandleJson(jsontable.category 		)
	raceinfo.createTime  	= RaceInfoModel.HandleJson(jsontable.createTime		)
	raceinfo.dataSource  	= RaceInfoModel.HandleJson(jsontable.dataSource  	,2)
	raceinfo.endTime  		= RaceInfoModel.HandleJson(jsontable.endTime  		)
	raceinfo.halfResult  	= RaceInfoModel.HandleJson(jsontable.halfResult  	)
	raceinfo.halfSettle  	= RaceInfoModel.HandleJson(jsontable.halfSettle  	,2)
	raceinfo.halfTime 		= RaceInfoModel.HandleJson(jsontable.halfTime		)
	raceinfo.homeTeam 		= RaceInfoModel.HandleJson(jsontable.homeTeam 		)
	raceinfo.isRecommend 	= RaceInfoModel.HandleJson(jsontable.isRecommend 	,2)
	raceinfo.isValid 		= RaceInfoModel.HandleJson(jsontable.isValid 		,2)
	raceinfo.lastTime 		= RaceInfoModel.HandleJson(jsontable.lastTime 		)
	raceinfo.openStatus		= RaceInfoModel.HandleJson(jsontable.openStatus		,2)
	raceinfo.raceId 		= RaceInfoModel.HandleJson(jsontable.raceId 		)	
	raceinfo.raceStatus 	= RaceInfoModel.HandleJson(jsontable.raceStatus 	,2)
	raceinfo.remark 		= RaceInfoModel.HandleJson(jsontable.remark 		)	
	raceinfo.shelvesStatus	= 1 --RaceInfoModel.HandleJson(jsontable.shelvesStatus	,2)
	raceinfo.startTime 		= RaceInfoModel.HandleJson(jsontable.startTime 		)
	raceinfo.updateTime  	= RaceInfoModel.HandleJson(jsontable.updateTime  	)
	raceinfo.versionAgain 	= RaceInfoModel.HandleJson(jsontable.versionAgain 	,2)
	raceinfo.versionRoll  	= RaceInfoModel.HandleJson(jsontable.versionRoll  	,2)
	raceinfo.visitTeam 		= RaceInfoModel.HandleJson(jsontable.visitTeam 		)
	raceinfo.weight 		= RaceInfoModel.HandleJson(jsontable.weight			,2)
	raceinfo.winResult 		= RaceInfoModel.HandleJson(jsontable.winResult 		)
	raceinfo.winTeam 		= RaceInfoModel.HandleJson(jsontable.winTeam 		)
	raceinfo.winType 		= RaceInfoModel.HandleJson(jsontable.winType 		,2)
	raceinfo.totalBet 		= "0"
	raceinfo.maxYiel		= 0
	raceinfo.isGuarantee  	= RaceInfoModel.HandleJson(jsontable.isGuarantee  	,2)
	raceinfo.agentType  	= RaceInfoModel.HandleJson(jsontable.agentType  	,2)
	raceinfo.betfee  		= RaceInfoModel.betfee
	raceinfo.fee  			= RaceInfoModel.fee
	raceinfo.raceTotalBet	= "100000000"
	raceinfo.isBet			= 0
	raceinfo.matchId 		= RaceInfoModel.HandleJson(jsontable.matchId		)
	raceinfo.seasonId 		= RaceInfoModel.HandleJson(jsontable.seasonId 		)
	raceinfo.homeId 		= RaceInfoModel.HandleJson(jsontable.homeId 		)
	raceinfo.visitId 		= RaceInfoModel.HandleJson(jsontable.visitId 		)
	raceinfo.homeTeamFace 	= RaceInfoModel.HandleJson(jsontable.homeLogo 		)
	raceinfo.visitTeamFace 	= RaceInfoModel.HandleJson(jsontable.visitLogo 		)
	
	return raceinfo
end

-- 将比赛数据插入数据库 optype=1插入 ，optype=2更新
-- raceInfo是pb结构数据
function RaceInfoModel.SaveRaceInfoToDB(raceinfo, optype)

	local sqlCase = ""
	
	if optype == 1 then
		sqlCase = "insert into dy_raceinfo(id,category,start_time,end_time,half_time,home_team,visit_team,create_time,shelves_status,race_status,win_team,win_result,win_type,"..
		"half_result,weight,data_source,again_settle,remark,half_settle,open_status,homeTeamFace,visitTeamFace,matchId,seasonId,homeId,visitId,fee,betfee,is_recommend,channel,prechannel) "..
		"values('"..raceinfo.raceId.."','"..raceinfo.category.."','"..TimeUtils.GetTimeString(math.floor(tonumber(raceinfo.startTime) /1000)).."','"..
		TimeUtils.GetTimeString(math.floor(tonumber(raceinfo.endTime)/1000)).."','"..
		TimeUtils.GetTimeString(math.floor(tonumber(raceinfo.halfTime)/1000)).."','"..raceinfo.homeTeam.."','"..raceinfo.visitTeam.."','"..
		TimeUtils.GetTimeString(math.floor(tonumber(raceinfo.createTime)/1000)).."',"..raceinfo.shelvesStatus..","..raceinfo.raceStatus..",'"..
		raceinfo.winTeam.."','"..raceinfo.winResult.."',"..raceinfo.winType..",'"..raceinfo.halfResult.."',"..raceinfo.weight..","..raceinfo.dataSource..","..
		raceinfo.againSettle..",'"..raceinfo.remark.."',"..raceinfo.halfSettle..","..raceinfo.openStatus..
		",'"..raceinfo.homeTeamFace.."'"..
		",'"..raceinfo.visitTeamFace.."'"..
		",'"..raceinfo.matchId.."'"..
		",'"..raceinfo.seasonId.."'"..
		",'"..raceinfo.homeId.."'"..
		",'"..raceinfo.visitId.."'"..
		",'"..raceinfo.fee.."'"..
		",'"..raceinfo.betfee.."'"..
		",'"..raceinfo.isRecommend.."'"..
		",'"..raceinfo.channel.."'"..
		",'"..AgentModel.GetChannel(raceinfo.channel).."'"..
		")"
	else
		sqlCase = "update dy_raceinfo set "..
		"category='"..raceinfo.category.."',"..
		"start_time='"..TimeUtils.GetTimeString(math.floor(tonumber(raceinfo.startTime) /1000)) .."',"..
		"end_time='"..TimeUtils.GetTimeString(math.floor(tonumber(raceinfo.endTime or 0)/1000)).."',"..
		"half_time='"..TimeUtils.GetTimeString(math.floor(tonumber(raceinfo.halfTime)/1000)).."',"..
		"home_team='"..raceinfo.homeTeam.."',"..
		"visit_team='"..raceinfo.visitTeam.."',"..
		"create_time='"..TimeUtils.GetTimeString(math.floor(tonumber(raceinfo.createTime)/1000)).."',"..
		"shelves_status="..raceinfo.shelvesStatus..","..
		"race_status="..raceinfo.raceStatus..","..
		"win_team='"..raceinfo.winTeam.."',"..
		"win_result='"..raceinfo.winResult.."',"..
		"win_type="..raceinfo.winType..","..
		"half_result='"..raceinfo.halfResult.."',"..
		"weight="..raceinfo.weight..","..
		"data_source="..raceinfo.dataSource..","..
		"again_settle='"..raceinfo.againSettle.."',"..
		"remark='"..raceinfo.remark.."',"..
		"half_settle='"..raceinfo.halfSettle.."', "..
		"homeTeamFace='"..raceinfo.homeTeamFace.."',"..
		"visitTeamFace='"..raceinfo.visitTeamFace.."', "..
		"matchId='"..raceinfo.matchId.."', "..
		"seasonId='"..raceinfo.seasonId.."', "..
		"homeId='"..raceinfo.homeId.."', "..
		"visitId='"..raceinfo.visitId.."', "..
		"fee='"..raceinfo.fee.."', "..
		"betfee='"..raceinfo.betfee.."', "..
		"is_recommend='"..raceinfo.isRecommend.."', "..
		"totalBet='"..raceinfo.totalBet.."', "..
		"channel='"..raceinfo.channel.."', "..
		"prechannel='"..AgentModel.GetChannel(raceinfo.channel).."' "..
		" where id = '"..raceinfo.raceId.."'"
	end
	
	SqlServer.rpush(sqlCase)
end

-- orderType: 1:下单  2：撤单
-- yieltype: 0:全场 1：半场
function RaceInfoModel.SaveRaceWinMoneyToDB(raceId, orderType, pourjetton, yieltype, istiyan, win)
	
	if istiyan then
		return
	end
	
	-- 添加到集合
	redisItem:sadd(RaceInfoModel.RaceHavePour, raceId, RaceInfoModel.redis_index)
	
	
	-- 设置可下注
	RaceInfoModel.SetRaceCanBet(raceId, orderType, pourjetton)
	
	local orderpourjetton = pourjetton
	
	if orderType == 2 then -- 撤单
		win = -win
		orderpourjetton = -orderpourjetton
	end
	
	local sqlCase = ""
	
	if yieltype == 0 then
		sqlCase = "update dy_raceinfo set "..
		"allwinmoney=allwinmoney+"..win..","..
		"totalBet=totalBet+"..orderpourjetton..
		" where id = '"..raceId.."'"
	else
		sqlCase = "update dy_raceinfo set "..
		"halfwinmoney=halfwinmoney+"..win..","..
		"totalBet=totalBet+"..orderpourjetton..
		" where id = '"..raceId.."'"
	end
	
	SqlServer.rpush(sqlCase)
end

-- 将返利数据插入数据库 optype=1插入 ，optype=2更新
-- raceRebate是从http请求获得的数据
function RaceInfoModel.SaveRaceRebateToDB(raceId, raceRebate, optype, rebateRatio, channel)

	local sqlCase = ""
	
	if optype == 1 then
		sqlCase = "insert into dy_racerebateinfo(id,race_id,rule,rule_type,valid_amount,open_status,rebateRatio,channel,prechannel) "..
		"values('"..raceRebate.rebateId.."','"..raceId.."','"..raceRebate.rule.."',"..
		raceRebate.ruleType..","..raceRebate.validAmount..","..raceRebate.rebateOpenStatus..","..rebateRatio..
		",'"..channel.."','"..AgentModel.GetChannel(channel).."'"..
		")"
	else
		sqlCase = "update dy_racerebateinfo set "..
		"race_id='"..raceId.."',"..
		"rule='"..raceRebate.rule.."',"..
		"rule_type="..raceRebate.ruleType..","..
		"valid_amount="..raceRebate.validAmount..","..
		--"open_status="..raceRebate.rebateOpenStatus..","..
		"rebateRatio='"..rebateRatio.."',"..
		"channel='"..channel.."',"..
		"prechannel='"..AgentModel.GetChannel(channel).."'"..
		" where id = '"..raceRebate.rebateId.."'"
	end

	SqlServer.rpush(sqlCase)

end

function RaceInfoModel.SaveRaceRebateRateToDB(rebateId, newrate)
	
	local sqlCase = "update dy_racerebateinfo set "..
	"rebateRatio="..newrate..
	" where id = '"..rebateId.."'"
	
	SqlServer.rpush(sqlCase)

end

function RaceInfoModel.SaveRaceRebateTotalbetToDB(rebateId, totalBet, orderType, istiyan, win)
	totalBet = totalBet or 0
	
	if orderType == 2 then -- 撤单
		totalBet = -totalBet
		win = -win
	end
	
	local sqlCase = ""
	
	if istiyan then
		sqlCase = "update dy_racerebateinfo set "..
		"tytotalBet=tytotalBet+"..totalBet..
		" where id = '"..rebateId.."'"
	else
		sqlCase = "update dy_racerebateinfo set "..
		"totalBet=totalBet+"..totalBet..","..
		"winmoney=winmoney+"..win..
		" where id = '"..rebateId.."'"
	end
	
	
	SqlServer.rpush(sqlCase)
end


-- 增加体验金盈利部分
function RaceInfoModel.AddTyWinMoney(pInfo, money)
	
	redisItem:hincrby(RaceInfoModel.tywinmoney, pInfo.userid, money, RaceInfoModel.redis_index)
	
	PlayerStatsModel.tyjettonmgr(pInfo,2,nil,money)
	
	local dayStr = TimeUtils.GetDayString()
	local weekStr = TimeUtils.GetWeekString()
	local monthStr = TimeUtils.GetMonthString()
	
	local sqlCase = "update log_player set tywincount = tywincount+"..money.." where userid="..pInfo.userid
	mysqlLog:execute(sqlCase)
	
	sqlCase = "update log_playerdaily set tywincount = tywincount+"..money.." where userid="..pInfo.userid.." and dateid='"..dayStr.."'"
	mysqlLog:execute(sqlCase)
	
	sqlCase = "update log_playerweek set tywincount = tywincount+"..money.." where userid="..pInfo.userid.." and dateid='"..weekStr.."'"
	mysqlLog:execute(sqlCase)
	
	sqlCase = "update log_playermonth set tywincount = tywincount+"..money.." where userid="..pInfo.userid.." and dateid='"..monthStr.."'"
	mysqlLog:execute(sqlCase)
	
end

-- 获取某个玩家体验金盈利部分
function RaceInfoModel.GetTyWinMoney(userid)
	return redisItem:hget(RaceInfoModel.tywinmoney, userid, RaceInfoModel.redis_index)
end

function RaceInfoModel.DelTyWinMoney(userid)
	redisItem:hdel(RaceInfoModel.tywinmoney, userid, RaceInfoModel.redis_index)
end
	
function RaceInfoModel.GetMsgByRaceStatus(racestatus)
	if racestatus == 0 then
		return "赛事取消"
	elseif racestatus == 1 then
		return "赛事进行中"
	elseif racestatus == 2 then
		return "赛事结束"
	elseif racestatus == 3 then
		return "赛事未开始"
	elseif racestatus == 4 then
		return "赛事改期"
	elseif racestatus == 5 then
		return "赛事异常"
	elseif racestatus == 6 then
		return "手动取消"
	elseif racestatus == 7 then
		return "系统撤单"
	end
	
	return ""
end


function RaceInfoModel.IsScoreWin(raceId, raceResult, userScore)
	
	if raceResult == userScore then
		return false
	end
	
	if userScore ~= "其他" then
		return true
	end
	
	local raceRebateInfo = RaceInfoModel.GetAllRaceRebateInfo(raceId)
	if next(raceRebateInfo) == nil then
		RaceInfoModel.LoadAllRaceRebateInfo(raceId)
		raceRebateInfo = RaceInfoModel.GetAllRaceRebateInfo(raceId)
	end
	
	if raceRebateInfo ~= nil then
		
		local isHaveResult = false
		
		for k1,v1 in pairs(raceRebateInfo) do
			local aRaceRebateInfo = st_footballgame_pb.SimpleRebateInfo()
			aRaceRebateInfo:ParseFromString(v1)
			
			if aRaceRebateInfo.score == raceResult then
				isHaveResult = true
			end
		end
		
		if isHaveResult then
			return true
		else
			return false
		end

	else
		LogFile("error", "=赛事id不存在:"..raceId)
	end
	
	return true
end


-- 此函数功能：从新计算下注比分的返利率
-- raceId 投注的赛事id
-- rebateId ：投注的区域
-- pourjetton 投注量
-- pourtype   0：真钱  1：体验金  2：保本卡  (也可以不传值)
-- ispourplan 0: 非跟投  1：跟投
-- channel 渠道号
function RaceInfoModel.PourRaceScore(raceId, rebateId, pourjetton, pourtype, ispourplan, channel)
	
	--查询配置
	local pourtouch = 500000
	local pourscoremin = 0.005
	local pourscoremax = 0.02
	local closescore = 0.4
	local pourplanscoremin = 0.001
	local pourplanscoremax = 0.005
	local sqlCase = "select pourtouch,pourscoremin,pourscoremax,closescore,pourplanscoremin,pourplanscoremax from dy_raceconfig where channel='"..channel.."' limit 1"
	mysqlItem:executeQuery(sqlCase)
	local sqlData = mysqlItem:fetch({})
	if sqlData ~= nil then
		pourtouch = tonumber(sqlData[1])
		pourscoremin = tonumber(sqlData[2])
		pourscoremax = tonumber(sqlData[3])
		closescore = tonumber(sqlData[4])
		pourplanscoremin = tonumber(sqlData[5])
		pourplanscoremax = tonumber(sqlData[6])
	end
	if pourtouch <= 0 then
		pourtouch = 500000
	end
	if pourscoremin <= 0 then
		pourscoremin = 0.005
	end
	if pourscoremax <= 0 then
		pourscoremax = 0.02
	end
	if pourscoremin > pourscoremax then
		pourscoremin = 0.005
		pourscoremax = 0.02
	end
	if closescore <= 0 then
		closescore = 0.4
	end
	if pourplanscoremin <= 0 then
		pourplanscoremin = 0.001
	end
	if pourplanscoremax <= 0 then
		pourplanscoremax = 0.005
	end
	if pourplanscoremin > pourplanscoremax then
		pourplanscoremin = 0.001
		pourplanscoremax = 0.005
	end
	
	
	ispourplan = ispourplan or 0
	
	local SimpleRebateInfoPB = RaceInfoModel.GetRaceRebateInfo(raceId, rebateId)
    if SimpleRebateInfoPB == nil then
       return
    end

    local SimpleRebateInfo = st_footballgame_pb.SimpleRebateInfo()
    SimpleRebateInfo:ParseFromString(SimpleRebateInfoPB)
	
	-- 已经关闭自动操盘了
	if SimpleRebateInfo.isartificial == 1 then
		return
	end
	
	
	if SimpleRebateInfo.firstrebateRatio <= 0 then
		SimpleRebateInfo.firstrebateRatio = SimpleRebateInfo.rebateRatio
	end
	
	
	if ispourplan == 1 then -- 跟投
	
		-- 计算下降数量
		SimpleRebateInfo.changeRatio = (-1) * SimpleRebateInfo.rebateRatio * math.myrandom(pourplanscoremin * 100000,pourplanscoremax * 100000)/100000 * pourjetton / pourtouch
		
	else -- 非跟投
	
		-- 计算下降数量
		SimpleRebateInfo.changeRatio = (-1) * SimpleRebateInfo.rebateRatio * math.myrandom(pourscoremin * 100000,pourscoremax * 100000)/100000 * pourjetton / pourtouch
	end
	
	SimpleRebateInfo.rebateRatio = SimpleRebateInfo.rebateRatio + SimpleRebateInfo.changeRatio
	
	
	-- 变化收益率
	if SimpleRebateInfo.rebateRatio > 0 then
		
		-- 封盘
		if SimpleRebateInfo.firstrebateRatio > 0 and SimpleRebateInfo.rebateRatio / SimpleRebateInfo.firstrebateRatio  < closescore then
			SimpleRebateInfo.rebateOpenStatus = 0
		end
	
		-- 保存缓存数据
		RaceInfoModel.SetRaceRebateInfo(raceId, rebateId, SimpleRebateInfo:SerializeToString())
		
		-- 保存到数据库
		RaceInfoModel.SaveRaceRebateRateToDB(rebateId, SimpleRebateInfo.rebateRatio)
	end
	
end

-- 返利率入库系数
function RaceInfoModel.GetRebateRatio(channel)
	
	--查询配置
	local firstratio = 80
	local sqlCase = "select firstratio from dy_raceconfig where channel='"..channel.."' limit 1"
	mysqlItem:executeQuery(sqlCase)
	local sqlData = mysqlItem:fetch({})
	if sqlData ~= nil then
		firstratio = tonumber(sqlData[1])
	end
	
	return firstratio / 100
end

-- 加载一个赛事，没有结算的订单
function RaceInfoModel.LoadRaceNotSettleOrder(raceid)
	
	-- 查询这个赛事没有结算的订单
	local sqlCase = "select orderid,yieltype from dy_footballorder where raceid='"..raceid.."' and orderstate=0"
	mysqlItem:executeQuery(sqlCase)
	while true do
		local sqlData = mysqlItem:fetch({})
		if sqlData == nil then
			break
		end
		
		local orderid = sqlData[1]
		local yieltype = tonumber(sqlData[2]) or 0
		
		if yieltype == 0 then
			redisItem:zadd(RaceInfoModel.raceSettleOrder..raceid, 0, orderid, RaceInfoModel.redis_index)
			
		else
			redisItem:zadd(RaceInfoModel.raceSettleOrderHalf..raceid, 0, orderid, RaceInfoModel.redis_index)
			
		end
		
	end
	
	
	-- 设置赛事订单过期时间
	RedisClearModel.AddNormalKey(RaceInfoModel.raceSettleOrder..raceid, RaceInfoModel.OrderExpire, RaceInfoModel.redis_index)
	RedisClearModel.AddNormalKey(RaceInfoModel.raceSettleOrderHalf..raceid, RaceInfoModel.OrderExpire, RaceInfoModel.redis_index)
	
end