require("FootballGame.Controller.FootballEventList")
require("FootballGame.Controller.FootballEventDetail")
require("FootballGame.Controller.FootballOrderList")
require("FootballGame.Controller.FootballOrderDetail")
require("FootballGame.Controller.FootballOrderCancel")
require("FootballGame.Controller.FootballNews")
require("FootballGame.Controller.FootballPour")
require("FootballGame.Controller.FootballRecords")
require("FootballGame.Controller.NoticeCancelOrder")
require("FootballGame.Controller.FootballAttention")
require("FootballGame.Controller.FlipProfitReport")
require("FootballGame.Controller.FlipProfitReportDetail")
require("FootballGame.Controller.FlipProfitRecords")
require("FootballGame.Controller.FlipProfitDrawLottery")
require("FootballGame.Controller.RaceCurrentScore")
require("FootballGame.Controller.RaceDataAnalysis")
require("FootballGame.Controller.RaceTextInfo")

-- model
require("FootballGame.Model.FootballModel")
require("FootballGame.Model.RaceInfoModel")



-- Service
require("FootballGame.Services.RaceInfoService")
require("FootballGame.Services.FootballUtils")
require("FootballGame.Services.FootballService")



-- work
require("FootballGame.Worker.CleanFreeGetCashWorker")
require("FootballGame.Worker.CheckTyjettonWorker")
require("FootballGame.Worker.CheckWlChangeRatio")
require("FootballGame.Worker.CheckNewsAnnounce")
require("FootballGame.Worker.CleanTyjettonWorker")

require("common.st_footballgame_pb")
require("common.msg_footballgame_pb")
require("common.msg_footballgame2_pb")

require("common.define.FootballGameDefine")
require("common.packet.packet_footballgame")

g_redisIndex[FootballModel.redis_index] = {index = g_redisInfo.redis_one , des = "footballgame"}
g_redisIndex[RaceInfoModel.redis_index] = {index = g_redisInfo.redis_five , des = "raceinfo"}