module("FootballOrderCancel",package.seeall)
--订单取消
function execute(packetID, operateID, buffer)
	--print("FootballOrderCancel")
    local cgmsg = msg_footballgame_pb.cgfootballordercancel()
	local gcmsg = msg_footballgame_pb.gcfootballordercancel()
	
	cgmsg:ParseFromString(buffer)
    --print(cgmsg)
    local pInfo = PlayerModel.GetPlayerInfo(cgmsg.userid)
    if pInfo == nil then
        gcmsg.result = ReturnCode["player_not_exist"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
    end

    local orderinfo = FootballService.GetOrderinfoDetailFromDb(cgmsg.orderid)
    if orderinfo == nil  then
        gcmsg.result = ReturnCode["order_no_exit"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
    end
    --不再从缓存中获取
    --[[ 
    local orderinfoPB =  FootballModel.GetUserSortOrderInfoByCondition(cgmsg.userid,0,cgmsg.orderid)
    if orderinfoPB == nil then
        gcmsg.result = ReturnCode["order_no_exit"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
    end
    local orderinfo = msg_footballgame_pb.gcfootballorderdetail()

    orderinfo:ParseFromString(orderinfoPB)
    ]]
    local nowtime = TimeUtils.GetTime()


    if orderinfo.orderyiel.tiyan == 1 then
        --体验金不给撤单
        gcmsg.result = ReturnCode["tyorder_not_cancle"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
    end

    if orderinfo.isBet == 1 then
        gcmsg.result = ReturnCode["order_cancel_state_error"]
        return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
    end

--    if nowtime - orderinfo.ordertime > g_footballgameDefine.order_cancel_time then
--        gcmsg.result = ReturnCode["order_cancel_time_limit"]
--		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()  
--    end
    local opttype = 0   -- 0计算手续费 1 确定 2 撤单不需要手续费（3分钟）  3:超过三分，比赛未开始 2% 4 ：比赛开始随时间加手续费 
    if orderinfo.orderyiel.yieltype ==  1 and  nowtime - orderinfo.starttime > 42 * 60 then
        --半场
        gcmsg.result = ReturnCode["order_cancel_time_limit"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
    end
    --全场
    if nowtime - orderinfo.starttime > 87 * 60 then
        gcmsg.result = ReturnCode["order_cancel_time_limit"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
    end

    if 0 ~= orderinfo.orderstate then
        gcmsg.result = ReturnCode["order_cancel_state_error"]
        return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
    end

    local chedanfee = 0
    local remaintimes = 0
    --print("nowtime - orderinfo.starttime : "..(nowtime - orderinfo.starttime) )
    if nowtime - orderinfo.starttime >= 0 then
        --比赛已经开始，开始收手续费
        if nowtime - orderinfo.starttime < 60 then
           --开赛0-1分钟 收起 5%
           chedanfee   = 0.05
           remaintimes = 60 - (nowtime - orderinfo.starttime)
        else
            --超过1 min 叠加 2%
            local temp = math.floor((nowtime - orderinfo.starttime)/60)
            local mod  = math.fmod(nowtime - orderinfo.starttime,60)
            if math.fmod(temp,2) == 1 then
	            chedanfee = (math.floor(temp/2)) * 0.02 + 0.05
                remaintimes = 120 - mod
            else
	            chedanfee = (math.floor((temp/2)) - 1) * 0.02 + 0.05
                remaintimes =  60 - mod
            end
        end
        opttype = 4
    else
        --比赛未开始
        opttype = 3
        chedanfee = 0.02
        if nowtime - orderinfo.ordertime < g_footballgameDefine.order_cancel_time then
            --三分钟之内
             chedanfee = 0
             remaintimes = g_footballgameDefine.order_cancel_time - (nowtime - orderinfo.ordertime)
             opttype = 2
        end

        if nowtime - orderinfo.starttime == 1 then
            --开赛前1s收取 2%
            chedanfee = 0.02
            remaintimes = 1
        end

    end


    if cgmsg.opttype == 0 then
        --计算手续费
        local reback = tonumber(orderinfo.pourjetton) * (1 - chedanfee)
        gcmsg.remaintimes = remaintimes
        gcmsg.cancelfee = chedanfee * 100
        gcmsg.rejetton = tostring(reback)
        gcmsg.result = 0
        gcmsg.opttype = opttype
        gcmsg.orderid = cgmsg.orderid
        --print(gcmsg)
        return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
    end
     
    local reback = tonumber(orderinfo.pourjetton) * (1 - chedanfee)
    local sqlCase = "update dy_footballorder set orderstate = " .. 3 .. ", cancletime =  "..TimeUtils.GetTime()..", win = '"..reback .. "', canclefee ="..chedanfee..",counttime ='"..TimeUtils.GetTimeString().. "' where orderid = "..cgmsg.orderid
    local sqlresult =  mysqlItem:execute(sqlCase)

    if sqlresult == 1 then
		--结算时后使用
        RaceInfoModel.PushOrderList(cgmsg.orderid, 2, orderinfo.eventid, tonumber(orderinfo.pourjetton), orderinfo.orderyiel.yieltype, orderinfo.rebateId, orderinfo.orderyiel.tiyan==1, orderinfo.orderyiel.yiel)
		
        --新订单删除
        --FootballModel.DelUserSortNorebateOrder(cgmsg.userid,cgmsg.orderid)
        --玩家足球返还本金订单信息(玩家撤单)添加
        --FootballModel.SetUserSortRecapitalOrder1(cgmsg.userid,cgmsg.orderid)
        --撤单相当于已结算
        --FootballModel.SetUserSortCountOrder(cgmsg.userid,cgmsg.orderid)
        --更新缓存
        --更新订单信息
     
        orderinfo.win = tostring(reback)
        orderinfo.orderstate = 3
        orderinfo.cancletime = TimeUtils.GetTime()
        --FootballModel.SetOrderInfo(cgmsg.orderid,orderinfo:SerializeToString()) 
        FootballModel.SetRaceOfOrderInfo(orderinfo.eventid,orderinfo)
        --给玩家返回金币
        if orderinfo.orderyiel.tiyan == 1 then
            PlayerModel.AddTyJetton(pInfo, tonumber(reback))
        else
            PlayerModel.AddJetton(pInfo, tonumber(reback), "zq", "win")
		    PlayerModel.SetPlayerInfo(pInfo)
		    PlayerModel.SendJetton(pInfo)   --同步分数先
            --AgentModel.CommissionCount(pInfo.userid, tonumber(orderinfo.pourjetton) - tonumber(reback))
        end

       

        local chedan = orderinfo.orderyiel.tiyan == 1 and "体验金撤单" or "撤单"
        LogServer.addRecords(pInfo.userid,1,chedan,reback,orderinfo.orderid)

        local msg = "玩家撤单 ".. orderinfo.eventtype..orderinfo.hometeam.."(主) VS "..orderinfo.awayteam.."(客)"..chedan..orderinfo.orderyiel.typescore..": "..(tonumber(reback) * 0.01) .."元"..",手续费:"..((tonumber(orderinfo.pourjetton) - tonumber(reback)) * 0.01) .."元"
        LogServer.GameUserMoney(pInfo, g_footballgameDefine.game_type, 1, tonumber(reback), msg, 0,0,g_moneyOptType.opt_game_ordercancel,cgmsg.orderid,orderinfo.orderyiel.tiyan == 1,2 )
          
        --玩家个人赛事 区域下注总额
        FootballModel.AddUserRaceRebeatPourjetton(pInfo.userid,orderinfo.eventid,orderinfo.rebateId,0-tonumber(orderinfo.pourjetton))
        
        if orderinfo.cardid ~= "" then
            PropService.reProp(pInfo.userid, orderinfo.cardid)
        end

        local   bet = 0
        local   tybet = 0
        local   betcount = 0
        local   tybetcount = 0  
        if orderinfo.orderyiel.tiyan == 1 then
            tybetcount = -1
            tybet = 0 - tonumber(orderinfo.pourjetton)
        else
            betcount = -1
            bet = 0 - tonumber(orderinfo.pourjetton)
        end
              
        --每天下注量统计
        --LogServer.dailFBBetCount(bet,tybet, orderinfo.ordertime,pInfo)
        LogDispatch.logBetCount(pInfo,bet,tybet,0,1)

        --统计注单数
        local prechannel = GameUtils.GetChannel_login(pInfo.channel)
        LogServer.raceFBRaceCount(orderinfo.eventtype,bet,betcount,tybet,tybetcount,pInfo.channel,prechannel,0,orderinfo.ordertime)

    else
        gcmsg.result =  ReturnCode["order_cancel_state_error"]
        return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
    end
    gcmsg.opttype = cgmsg.opttype
    gcmsg.result = 0
    gcmsg.orderid = cgmsg.orderid
	return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
end