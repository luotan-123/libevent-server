module("FlipProfitReportDetail",package.seeall)
--查看收益明细
function execute(packetID, operateID, buffer)
	--print("FlipProfitReportDetail")
    local cgmsg = msg_footballgame2_pb.cgflipprofitreportdetail()
	local gcmsg = msg_footballgame2_pb.gcflipprofitreportdetail()
	
	cgmsg:ParseFromString(buffer)
    local pInfo = PlayerModel.GetPlayerInfo(cgmsg.userid)
    if pInfo == nil then
        gcmsg.result = ReturnCode["player_not_exist"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
    end
    local sqlCase = "select orderidlist from log_flipprofitreport where profitid='"..cgmsg.profitid.."'"
    mysqlLog:executeQuery(sqlCase)
    --print(sqlCase)
    local sqlData = mysqlLog:fetch()
    if sqlData ~= nil then
        local orderidlist = luajson.decode(sqlData)
        local orderidlist_str = table.concat(orderidlist,",")
        local sqlCase = "select * from dy_footballorder where orderid in ("..orderidlist_str ..") limit  "..10 * (cgmsg.pagenum-1)..",10"
        --print(sqlCase)
        mysqlItem:executeQuery(sqlCase)
        while true do
	        local sqlData = mysqlItem:fetch({})
	        if sqlData == nil then
                break
	        end
            local addH = gcmsg.orderbasic:add()
            addH.isBet          = tonumber(sqlData[26])
            addH.orderid        = sqlData[1]
            addH.eventtype	    = sqlData[3]  --联赛类型
            addH.starttime	    = TimeUtils.GetTime(sqlData[10])	--比赛开始时间戳
            addH.endtime	    = TimeUtils.GetTime(sqlData[11])	--比赛结束时间戳
            addH.win		    = sqlData[15]  
            addH.orderstate     = tonumber(sqlData[13])
            addH.hometeam       = sqlData[16]
            addH.awayteam       = sqlData[17] 
            addH.homescore      = tonumber(sqlData[18]) or 0
            addH.awayscore      = tonumber(sqlData[19]) or 0
            addH.homelogo       = (sqlData[38] == "" or sqlData[38] == nil) and  g_footballgameDefine.homeTeamFace or sqlData[38]
            addH.awaylogo       = (sqlData[39] == "" or sqlData[39] == nil ) and  g_footballgameDefine.visitTeamFace or sqlData[39]
            addH.pourjetton     = sqlData[22]
            addH.ordertime      = TimeUtils.GetTime(sqlData[12]) --下单时间
            addH.expert	        = sqlData[36] or ""
            addH.schemeid	    = tonumber(sqlData[34])
            addH.expertid	    = tonumber(sqlData[35])

            if addH.isBet == 0 then
                --比分订单
                addH.orderyiel.yieltype     = tonumber(sqlData[5]) --类型 0:全场 1：半场
                addH.orderyiel.subtype      = tonumber(sqlData[4]) --0: 主 1:客 2:和
                addH.orderyiel.typescore    = sqlData[6]
                addH.orderyiel.yiel         = sqlData[7]
                addH.orderyiel.baoval       = tonumber(sqlData[8])
                addH.orderyiel.tiyan        = tonumber(sqlData[9])
                addH.orderyiel.rebateId     = sqlData[21]
                addH.orderyiel.baobenMoney  = sqlData[37]

            else
                --输赢订单 

                local totalpourlist = {0,0,0}
                for i = 1, 3  do
                    addH.wlpourlist:append(sqlData[28+i])
                    local totalpourjetton = FootballModel.GetPourJetton(sqlData[28],i )
                    totalpourlist[i] = totalpourjetton
                    addH.wltotalpourlist:append(tostring(totalpourjetton))
                end
                local ratelist = FootballUtils.cluWLrate(totalpourlist)
                
                for s =1,3 do
                    addH.wlrate:append(tostring(ratelist[s]))
                end   
            end
        end
    end
   

    gcmsg.result = 0
    --print(gcmsg)
	return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
end