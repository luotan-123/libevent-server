module("RaceDataAnalysis",package.seeall)
--交易记录
function execute(packetID, operateID, buffer)
	--print("RaceDataAnalysis")
    local cgmsg = msg_footballgame2_pb.cgracedataanalysis()
	local gcmsg = msg_footballgame2_pb.gcracedataanalysis()
    cgmsg:ParseFromString(buffer)
    --print(cgmsg)
--    local pInfo = PlayerModel.GetPlayerInfo(cgmsg.userid)
--    if pInfo == nil then
--        gcmsg.result = ReturnCode["player_not_exist"]
--		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
--    end


    local raceinfopb = RaceInfoModel.GetRaceInfo(cgmsg.raceid)
	if raceinfopb == nil then
        gcmsg.result = ReturnCode["event_not_exit"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
    end

    local raceinfo = st_footballgame_pb.MerchantRaceInfoDto()
	raceinfo:ParseFromString(raceinfopb)
    local matchId = raceinfo.matchId
    local teamId1 = raceinfo.homeId
    local teamId2 = raceinfo.visitId
    

    local datatype
    if cgmsg.datatype == 0 then
        datatype = teamId1 ..teamId2
    elseif cgmsg.datatype == 1 then
        datatype = teamId1
    elseif cgmsg.datatype == 2 then
        datatype = teamId2
    end

    local infolist =  redisItem:hget(RaceInfoModel.raceDataAnalysis..matchId, datatype, RaceInfoModel.redis_index)
    if infolist ~= nil then
        infolist = luajson.decode(infolist)
        for k,v in pairs(infolist) do
            if v ~= nil and v ~= "" and k < 10 then
                local info = v
                local addP = gcmsg.datainfo:add()
                local result_score = FootballUtils.score_split(info.winResult, "-")
                addP.racetime	= TimeUtils.GetTimeString( math.floor(info.matchDate / 1000))
                addP.hometeam	= info.homeTeam
                addP.awayteam	= info.visitTeam
                addP.homescore	= tonumber(result_score[1]) or 0
                addP.awayscore	= tonumber(result_score[2]) or 0
            end
        end
    end
    gcmsg.datatype	= cgmsg.datatype		
    gcmsg.result = 0
	return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
end