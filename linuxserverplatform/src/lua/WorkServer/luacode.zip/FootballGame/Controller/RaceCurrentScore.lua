module("RaceCurrentScore",package.seeall)
--交易记录
function execute(packetID, operateID, buffer)
	--print("RaceCurrentScore")
    local cgmsg = msg_footballgame2_pb.cgcurrentracescore()
	local gcmsg = msg_footballgame2_pb.gccurrentracescore()
	
	cgmsg:ParseFromString(buffer)
    local pInfo = PlayerModel.GetPlayerInfo(cgmsg.userid)
    if pInfo == nil then
        gcmsg.result = ReturnCode["player_not_exist"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
    end
    local nowtime = TimeUtils.GetTime()
    local sqlCase = "select * from dy_footballorder where userid = "..cgmsg.userid.." and orderstate = 0 and starttime < '"..TimeUtils.GetTimeString().."' and starttime > '"..TimeUtils.GetTimeString(nowtime - 90*60).."'"
    mysqlItem:executeQuery(sqlCase)
    local raceCheck = {}
    while true do
        local sqlData = mysqlItem:fetch({})
        if sqlData == nil then
           break
        end
        local eventid = sqlData[20]
        if raceCheck[eventid] ~= 1 then
            raceCheck[tostring(eventid)] = 1
            local addH = gcmsg.curscore:add()
            addH.hometeam   =	    sqlData[16]
            addH.awayteam   =	    sqlData[17]

            addH.starttime = TimeUtils.GetTime(sqlData[10])
            addH.homelogo  = (sqlData[38] == "" or sqlData[38] == nil)  and  g_footballgameDefine.homeTeamFace  or  sqlData[38]
            addH.awaylogo  = (sqlData[39] == "" or sqlData[39] == nil )   and  g_footballgameDefine.visitTeamFace  or sqlData[39]

            local raceinfo_pb = RaceInfoModel.GetRaceInfo(eventid)
            local raceinfo = st_footballgame_pb.MerchantRaceInfoDto()
            if raceinfo_pb ~= nil then
                raceinfo:ParseFromString(raceinfo_pb)
            end
            if raceinfo.winResult ~= "" and raceinfo.winResult ~= "0" then
		        local result_score = FootballUtils.score_split(raceinfo.winResult, "-")
		        addH.homescore	= tonumber(result_score[1]) 
		        addH.awayscore	= tonumber(result_score[2])
            end
        end
    end
    gcmsg.result = 0
	return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
end