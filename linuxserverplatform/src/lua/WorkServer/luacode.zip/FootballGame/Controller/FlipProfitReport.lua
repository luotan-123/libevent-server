module("FlipProfitReport",package.seeall)
--收益报告
function execute(packetID, operateID, buffer)
	--print("FlipProfitReport")
    local cgmsg = msg_footballgame2_pb.cgflipprofitreport()
	local gcmsg = msg_footballgame2_pb.gcflipprofitreport()
	
	cgmsg:ParseFromString(buffer)
    local pInfo = PlayerModel.GetPlayerInfo(cgmsg.userid)
    if pInfo == nil then
        gcmsg.result = ReturnCode["player_not_exist"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
    end
    local prechannel =  GameUtils.GetChannel_login(pInfo.channel)

    local payjetton = 500   --付费价格
    --查询翻牌价格
    local sqlCase = "select dict_value from web_dict where prechannel = '"..prechannel.."' and dict_category = '".."ffl".."'"
    mysqlItem:executeQuery(sqlCase)
    local sqlData = mysqlItem:fetch()

    if sqlData ~= nil then
        payjetton = tonumber(sqlData)
    end

    if  payjetton > tonumber(pInfo.jetton) then
        --翻翻乐不显示报告
        gcmsg.result = 0
	    return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()

    end


    local len = FootballModel.GetFlipProfitReportInfoLen(cgmsg.userid)
    if len > 0  and false == PlayerModel.CheckTestUserLimit(pInfo,g_test_userfunc_limit[5]) then
        --有结算订单 需要生成报告 
        local orderidlist = {}    
        for i=1,len  do
            local orderid = redisItem:rpop(FootballModel.userFlipProfitReportInfo..cgmsg.userid, FootballModel.redis_index)
            if orderid ~= nil then
                table.insert(orderidlist,orderid)
            end
        end
        --test
        --orderidlist = redisItem:lrange(FootballModel.userFlipProfitReportInfo..cgmsg.userid,0,-1, FootballModel.redis_index)
        local orderidlist_str = table.concat( orderidlist,",")
        local flipFreeCount = 0 --免费次数
       
        local flipProfit = 0    --全部收益
        local profitid = FootballUtils.GetNewProfitid(cgmsg.userid)
        local sqlCase = "select orderid,win from dy_footballorder where orderid in ("..orderidlist_str ..")"
        --print(sqlCase)
        mysqlItem:executeQuery(sqlCase)
        while true do
	        local sqlData = mysqlItem:fetch({})
	        if sqlData == nil then
                break
	        end
            if tonumber(sqlData[2]) < 0 then
                flipFreeCount = flipFreeCount + 1
            end
            flipProfit = flipProfit + tonumber(sqlData[2])
            gcmsg.ordercount = gcmsg.ordercount + 1
        end



        --查看公共中奖记录
        local sqlCase = "select userid,prizedesc from log_drawlottoryrecords where category = 0 and state = 1  and prechannel = '"..prechannel.."' order by id desc limit 50"
        --print(sqlCase)
        mysqlLog:executeQuery(sqlCase)
        while true do
            local sqlData = mysqlLog:fetch({})
	        if sqlData == nil then
                break
	        end
            local userid = tonumber(sqlData[1])
            local prizedesc = sqlData[2]
            local awradpInfo = PlayerModel.GetPlayerInfo(userid)
            if awradpInfo ~= nil then
                gcmsg.prizemesage:append(prizedesc)
            end
        end


        local sqlCase = "insert into log_flipprofitreport(profitid,userid,win,freeflipcount,orderidlist,status,channel,prechannel) values('"..profitid.."',"..
        cgmsg.userid..","..flipProfit..","..flipFreeCount..",'"..luajson.encode(orderidlist).."',"..1 ..",'"..pInfo.channel.."','"..prechannel.."')"
        mysqlLog:execute(sqlCase)
        --print(sqlCase)
        gcmsg.profitsum = tostring(flipProfit)
        gcmsg.freeflipcount = flipFreeCount
        gcmsg.payjetton = payjetton
        gcmsg.profitid = profitid

    end

    gcmsg.result = 0
    --print(gcmsg)
	return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
end