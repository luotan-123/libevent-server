module("RaceTextInfo",package.seeall)
--交易记录
function execute(packetID, operateID, buffer)
	--print("RaceTextInfo")
    local cgmsg = msg_footballgame2_pb.cgracetextinfo()
	local gcmsg = msg_footballgame2_pb.gcracetextinfo()
	
	cgmsg:ParseFromString(buffer)
--    local pInfo = PlayerModel.GetPlayerInfo(cgmsg.userid)
--    if pInfo == nil then
--        gcmsg.result = ReturnCode["player_not_exist"]
--		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
--    end
    --print(cgmsg)
    local raceinfopb = RaceInfoModel.GetRaceInfo(cgmsg.raceid)
	if raceinfopb == nil then
        gcmsg.result = ReturnCode["event_not_exit"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
    end
    
    local raceinfo = st_footballgame_pb.MerchantRaceInfoDto()
	raceinfo:ParseFromString(raceinfopb)
    local matchId = raceinfo.matchId
    --print(raceinfo)

    local count = redisItem:zcard(RaceInfoModel.raceTextInfo..matchId, RaceInfoModel.redis_index)
    if cgmsg.startnum <=  cgmsg.endnum and   cgmsg.startnum > 0 and  count >= cgmsg.startnum then
        local endcount = count > cgmsg.endnum  and  cgmsg.endnum or count
        local textinfo = redisItem:zrange(RaceInfoModel.raceTextInfo..matchId,cgmsg.startnum -1 ,endcount - 1 ,RaceInfoModel.redis_index)
        for k,v in pairs(textinfo) do
            if v ~= nil then
                local text = luajson.decode(v)
                local addP = gcmsg.textinfo:add()
                --addP.newstype	--= 1;//消息类型 0 公共 1 主队 2 客队
	            addP.racetime	= text.minute
	            addP.textinfo	= text.sentence
            end
        end
    end

    gcmsg.startnum = cgmsg.startnum
    gcmsg.endnum = cgmsg.endnum
    gcmsg.result = 0
	return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
end