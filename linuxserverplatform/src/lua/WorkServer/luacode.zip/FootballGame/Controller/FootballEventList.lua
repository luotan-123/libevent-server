module("FootballEventList",package.seeall)
--赛事列表
function execute(packetID, operateID, buffer)
	--print("FootballEventList")
    local cgmsg = msg_footballgame_pb.cgfootballeventlist()
	local gcmsg = msg_footballgame_pb.gcfootballeventlist()
	
	cgmsg:ParseFromString(buffer)
    local pInfo = PlayerModel.GetPlayerInfo(cgmsg.userid)
    
    if pInfo == nil then
        gcmsg.result = ReturnCode["player_not_exist"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
    end
    --//请求赛事状态 0: 可竞猜、1: 已进行, 2:热门
    local starttime  = (cgmsg.starttime or 0) * 1000
    local endtime    = cgmsg.endtime == 0 and "+inf" or (cgmsg.endtime*1000)
    local sorttype	 = cgmsg.sorttype   --排序方式0 时间排序 1 收益排序
	local eventstate = cgmsg.eventstate --过滤方式0 不过滤 1 比赛中 2已结束
	local eventtype	 = cgmsg.eventtype  --联赛类型
    --print(cgmsg.reqstate,starttime,endtime)
    local allraceidlist = {}
    if cgmsg.reqstate == 1 then
        local nowstamp = TimeUtils.GetTime()
        local starttime = nowstamp - 2 * 60 * 60
        local endtime = nowstamp + 90 * 60
	    allraceidlist = RaceInfoModel.GetRaceList(1, starttime*1000, endtime*1000, pInfo.channel);
    elseif cgmsg.reqstate == 2 then
        --2 精选赛事（热门）
        local raceinfolist2 = {}
        local allraceidlist2 = RaceInfoModel.GetRaceList(2, starttime, endtime, pInfo.channel)
        --精选赛事需要按照权重排序
        for k,v in pairs(allraceidlist2) do
            local raceinfo = RaceInfoModel.GetRaceInfo(v)
            if raceinfo ~= nil then
                local event = st_footballgame_pb.MerchantRaceInfoDto()
                event:ParseFromString(raceinfo)
                table.insert(raceinfolist2,event)
            end
        end
        --按推荐权重排序
        table.sort(raceinfolist2,function (a,b)
            return a.weight > b.weight
        end)
        --精选赛事
        for k,v in pairs(raceinfolist2) do
            table.insert(allraceidlist,v.raceId)
        end
        local raceExist = {}
        if #allraceidlist < 2 then
            --没有精选赛事时 ，添加猜胜负赛事
            local allraceidlist3 = RaceInfoModel.GetRaceList(3, starttime, endtime, pInfo.channel)
            
            for k,v in pairs(allraceidlist3) do
                if raceExist[tostring(v)] == nil then
                    table.insert(allraceidlist,v)
                    raceExist[tostring(v)] = 1
                end
                if k == 3 then
                   break
                end
            end
        end


        if #allraceidlist < 2 then
            --没有精选赛事时，添加普通赛事
            --0 可竞猜
            local allraceidlist0 =  RaceInfoModel.GetRaceList(0, starttime, endtime, pInfo.channel)
            --可竞猜赛事
            --local raceExist = {}
            for k,v in pairs(allraceidlist0) do
                if raceExist[tostring(v)] == nil then
                    table.insert(allraceidlist,v)
                    raceExist[tostring(v)] = 1
                end
                if k == 3 then
                   break
                end
            end
        end


    elseif  cgmsg.reqstate == 3 then  
        --热门赛事（下注人多的赛事）
        local raceExist = {}
        --3猜胜负 
        allraceidlist = RaceInfoModel.GetRaceList(3, starttime, endtime, pInfo.channel)
        for k,v in pairs(allraceidlist) do
            if raceExist[tostring(v)] == nil then
                raceExist[tostring(v)] = 1
            end
        end

        --2 精选赛事（热门）
        local raceinfolist2 = {}
        local allraceidlist2 = RaceInfoModel.GetRaceList(2, starttime, endtime, pInfo.channel)
        --精选赛事
        for k,v in pairs(raceinfolist2) do
            if raceExist[tostring(v.raceId)] == nil then
                table.insert(allraceidlist,v.raceId)
                raceExist[tostring(v.raceId)] = 1
            end
            
        end
        --0 可竞猜
        local allraceidlist0 =  RaceInfoModel.GetRaceList(0, starttime, endtime, pInfo.channel)
        --可竞猜赛事
        for k,v in pairs(allraceidlist0) do
            if raceExist[tostring(v)] == nil then
                table.insert(allraceidlist,v)
                raceExist[tostring(v)] = 1
            end
        end

        local tempAllraceidlist = {}
        for k = #allraceidlist,1,-1 do
            local num = FootballModel.GetRaceOrderCount(allraceidlist[k])
            local temp = {id=allraceidlist[k],num=num}
            table.insert(tempAllraceidlist,temp)
        end
        


        table.sort(tempAllraceidlist,function (a,b)
           return a.num > b.num
        end)
        allraceidlist = {}
        for i=1,3  do
            if tempAllraceidlist[i] ~= nil then
                table.insert(allraceidlist,tempAllraceidlist[i]["id"])
            end
        end
        
    else
        local raceExist = {}
        --3猜胜负 
        allraceidlist = RaceInfoModel.GetRaceList(3, starttime, endtime, pInfo.channel)
        for k,v in pairs(allraceidlist) do
            if raceExist[tostring(v)] == nil then
                raceExist[tostring(v)] = 1
            end
        end

        --2 精选赛事（热门）
        local raceinfolist2 = {}
        local allraceidlist2 = RaceInfoModel.GetRaceList(2, starttime, endtime, pInfo.channel)
        --精选赛事需要按照权重排序
        for k,v in pairs(allraceidlist2) do
            local raceinfo = RaceInfoModel.GetRaceInfo(v)
            if raceinfo ~= nil then
                local event = st_footballgame_pb.MerchantRaceInfoDto()
                event:ParseFromString(raceinfo)
                table.insert(raceinfolist2,event)
            end
        end
        --按推荐权重排序
        table.sort(raceinfolist2,function (a,b)
            return a.weight > b.weight
        end)

        --0 可竞猜
        local allraceidlist0 =  RaceInfoModel.GetRaceList(0, starttime, endtime, pInfo.channel)

        --精选赛事
        for k,v in pairs(raceinfolist2) do
            if raceExist[tostring(v.raceId)] == nil then
                table.insert(allraceidlist,v.raceId)
                raceExist[tostring(v.raceId)] = 1
            end
            
        end

        --可竞猜赛事
        for k,v in pairs(allraceidlist0) do
            if raceExist[tostring(v)] == nil then
                table.insert(allraceidlist,v)
                raceExist[tostring(v)] = 1
            end
        end

    end

    if cgmsg .attention == 1 then
        for k = #allraceidlist,1,-1 do
            local hexist =  FootballModel.ExistUserPayAttentionRace(allraceidlist[k],pInfo.userid)
            if hexist == false then
                table.remove(allraceidlist,k)
            end
        end
    end

    --allraceidlist 里面的里已经是按时间排序了
    local raceidlist = {}
    local maxpagenum = cgmsg.pagenum * 10 + 10 > #allraceidlist and #allraceidlist or cgmsg.pagenum * 10 + 10
    for i= cgmsg.pagenum * 10 + 1, maxpagenum do
        if allraceidlist[i] ~= nil and allraceidlist[i] ~= "" then
            table.insert(raceidlist,allraceidlist[i])
        end
    end
    
    local raceinfolist = {}
    for k,v in pairs(raceidlist) do
        local raceinfo = RaceInfoModel.GetRaceInfo(v)
        if raceinfo ~= nil then
            local event = st_footballgame_pb.MerchantRaceInfoDto()
            event:ParseFromString(raceinfo)
            table.insert(raceinfolist,event)
        end
    end

    for k,v in pairs(raceinfolist) do
        if v ~= nil then
            local event = v
            local suit = false
            if event.shelvesStatus == 1 then
                gcmsg.eventtypelist:append(event.category)
            end
           
            if event.shelvesStatus == 1 then
                --上架
                suit = true
            end
            --条件满足
            if suit then
                local addTH = gcmsg.eventbasic:add()
                addTH.eventid		= event.raceId
                addTH.eventtype		= event.category
                addTH.state			= event.againSettle
                addTH.starttime		= tonumber(event.startTime)/1000
                addTH.endtime		= (tonumber(event.endTime ) or 0)/1000
                
                addTH.maxyiel		= tostring(event.maxYiel)
                addTH.hometeam		= event.homeTeam
                addTH.awayteam		= event.visitTeam
				
                if event.winResult ~= "" and event.winResult ~= "0" then
					local result_score = FootballUtils.score_split(event.winResult, "-")
					addTH.homescore		= tonumber(result_score[1])
					addTH.awayscore		= tonumber(result_score[2])
				end
               
                addTH.remaincount	= tostring(  ( tonumber(event.raceTotalBet) -   tonumber(event.totalBet) ) * 0.001)
                --addTH.baoval		= event.agentType
                addTH.tiyan			= 0
                addTH.openStatus	= event.openStatus
                addTH.isValid		= event.isValid
                addTH.raceStatus	= event.raceStatus
                addTH.isRecommend	= event.isRecommend
                addTH.isBet         = event.isBet --是否是猜输赢
                --print(event.raceId,addTH.isBet)
                if addTH.isBet == 1 then
                    --体验金赔率
                    local totalPourList = {0,0,0}
                    for m = 1,3  do
	                    local totaljetton = FootballModel.GetPourJetton(event.raceId, m)
	                    totalPourList[m] = totaljetton
                    end
                    local newRateList = FootballUtils.cluWLrate(totalPourList)
                    for m=1,3  do
                        addTH.wlrate:append(tostring(newRateList[m]))
                    end
                end
                local hexist = false
                if cgmsg .attention == 0  then
                    hexist = FootballModel.ExistUserPayAttentionRace(event.raceId,pInfo.userid)
                    addTH.attention = hexist == true and 1 or 0
                else
                    addTH.attention  =  1    
                end
                
               
                --专家人数
                addTH.expertnum = tonumber(ExpertModel.GetRaceOfExpertCount(event.raceId, pInfo.channel)) or 0
                --logo
                addTH.homelogo	= event.homeTeamFace == "0"  and g_footballgameDefine.homeTeamFace or event.homeTeamFace
                addTH.awaylogo	= event.visitTeamFace == "0" and g_footballgameDefine.visitTeamFace or event.visitTeamFace
                
               	local raceRebateInfo = RaceInfoModel.GetAllRaceRebateInfo(event.raceId)
	            if raceRebateInfo ~= nil then
		            for k1,v1 in pairs(raceRebateInfo) do
		                local aRaceRebateInfo = st_footballgame_pb.SimpleRebateInfo()
		                aRaceRebateInfo:ParseFromString(v1)
                        --print(k1,aRaceRebateInfo.baoval)
		                if aRaceRebateInfo.baoval > 0 then
		                    addTH.baoval = aRaceRebateInfo.baoval
                            
		                end

                        if aRaceRebateInfo.tiyan > 0 then
                           addTH.tiyan	= aRaceRebateInfo.tiyan
                        end
	                end
	            end
            end
        end
    end
    gcmsg.tag  = cgmsg.tag
    gcmsg.pagenum  = cgmsg.pagenum
    gcmsg.attention = cgmsg.attention
    gcmsg.reqstate = cgmsg.reqstate
    gcmsg.result = 0
    --print(gcmsg)
	return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
end

