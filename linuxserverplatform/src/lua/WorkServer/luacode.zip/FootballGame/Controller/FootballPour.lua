module("FootballPour",package.seeall)

function execute(packetID, operateID, buffer)
	--print("FootballPour")
    local cgmsg = msg_footballgame_pb.cgfootballpourinfo()
	local gcmsg = msg_footballgame_pb.gcfootballpourinfo()
	
	cgmsg:ParseFromString(buffer)
    --print("cgmsg",cgmsg)
    local pInfo = PlayerModel.GetPlayerInfo(cgmsg.userid)
    
    if pInfo == nil then
        gcmsg.result = ReturnCode["player_not_exist"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
    end
    local prechannel = GameUtils.GetChannel_login(pInfo.channel)
    -------------
    --获取赛事信息
    local raceinfopb = RaceInfoModel.GetRaceInfo(cgmsg.eventid)
    
	if raceinfopb == nil then
		gcmsg.result = ReturnCode["event_not_exit"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
	end

    --解析赛事
    local raceinfo = st_footballgame_pb.MerchantRaceInfoDto()
	raceinfo:ParseFromString(raceinfopb)
    --print(raceinfo)
    if PlayerModel.CheckTestUserLimit(pInfo,4) and cgmsg.isBet  == 1 then
        --测试用户不能猜胜负
        gcmsg.result = ReturnCode["test_user_funclimit"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
    end

    if cgmsg.isBet  == 1 and raceinfo.isBet ~= 1 then
        --赛事不是竞猜模式
        gcmsg.result = ReturnCode["pourtype_not_exit"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
    end

    local nowtime = TimeUtils.GetTime()
    
    if raceinfo.openStatus == 0 or tonumber(nowtime) > (tonumber(raceinfo.startTime) or 0) /1000 then
        --比赛已经开始
        gcmsg.result = ReturnCode["event_has_start"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
    end
    --赛事状态(0:取消(取消的赛事进行撤注操作) 1:正常进行中 2:已经结束(定时任务爬取赛事结果)3:未开始)
    if raceinfo.raceStatus ~= 3 then
        gcmsg.result = ReturnCode["can_not_pour"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
    end

    --是否是猜输赢模式
    local isPourWinLose = (cgmsg.isBet  == 1 and raceinfo.isBet == 1) and true or false
    local ordertype  = 0

    local proptype = -1
    if isPourWinLose == false then
        --猜比分格式
        --print("cgmsg.eventid: "..cgmsg.eventid)
        --获取下注区域信息
	    local raceRebateInfo = RaceInfoModel.GetAllRaceRebateInfo(cgmsg.eventid)
	    if raceRebateInfo == nil then
            --所有的下注区域不存在
		    gcmsg.result = ReturnCode["event_not_exit"]
		    return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
	    end
    
        local nowtime = TimeUtils.GetTime()
        if raceinfo.openStatus == 0 or tonumber(nowtime) > (tonumber(raceinfo.startTime) or 0) /1000 then
            --比赛已经开始
            gcmsg.result = ReturnCode["event_has_start"]
		    return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
        end

       --[[ if  cgmsg.schemeid ~= 0  then
            --跟投
            local sqlCase = "select rebateid from ex_planorder where planid = "..cgmsg.schemeid.." and  raceid = '"..cgmsg.eventid.."'"
            mysqlItem:execute(sqlCase)
            local sqlData = mysqlItem:fetch()
            if sqlData == nil then
                gcmsg.result = ReturnCode["pourtype_not_exit"]
		        return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
            else
                cgmsg.rebateId = tonumber(sqlData)    
            end

        end--]]
        
            
        --单个下注区域的信息 
        --print("cgmsg.rebateId: "..cgmsg.rebateId)
        local SimpleRebateInfoPB = RaceInfoModel.GetRaceRebateInfo(cgmsg.eventid, cgmsg.rebateId)
        if SimpleRebateInfoPB == nil then
            --比赛已经开始
            gcmsg.result = ReturnCode["pourtype_not_exit"]
		    return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
        end

        local SimpleRebateInfo = st_footballgame_pb.SimpleRebateInfo()
        SimpleRebateInfo:ParseFromString(SimpleRebateInfoPB)
        local pourjetton = 0

		if SimpleRebateInfo.rebateOpenStatus == 0 then
			gcmsg.result = ReturnCode["score_close"]
            return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
		end

        local prechannel = GameUtils.GetChannel_login(pInfo.channel)
        local viprulepb =  VipMgrModel.GetVipRule(pInfo.viplevel,prechannel)
        local viprule = st_vipmgr_pb.viprule()

        if cgmsg.tiyan == 1 and SimpleRebateInfo.tiyan == 1 then
            pourjetton = tonumber(cgmsg.typourjetton) or 0
        elseif  cgmsg.tiyan == 0 then
            pourjetton = tonumber(cgmsg.pourjetton) or 0

            --vip 单笔投注限额 
            if viprulepb ~= nil then
                viprule:ParseFromString(viprulepb)
                if pourjetton > viprule.pourlimit then
                    gcmsg.result = ReturnCode["viplevel_not_allow"]
		            return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
                end
            end

        else
            gcmsg.result = ReturnCode["typourtype_error"]
		    return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
        end

        if (cgmsg.tiyan  == 1 and SimpleRebateInfo.tiyan ~= 1)  then
            gcmsg.result = ReturnCode["typourtype_error"]
            return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
        end
   

        if (cgmsg.tiyan  == 1 and SimpleRebateInfo.tiyan ~= 1)  or (cgmsg.baoval  == 1 and  cgmsg.baoval  ~= SimpleRebateInfo.baoval) then
            --校验参数
            gcmsg.result = ReturnCode["pourtype_not_exit"]
            return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
        end
        if tonumber(pourjetton)  < 10000 then
            --猜比分下注不能少于一百
            gcmsg.result = ReturnCode["pour_limit"]
	        return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
        end

        --print("raceinfo.totalBet: "..raceinfo.totalBet)   
        --print("SimpleRebateInfo.validAmount: "..SimpleRebateInfo.validAmount) 
        --print(pourjetton,SimpleRebateInfo.validAmount) 
        local pourtypejettons =  FootballModel.GetRaceRebeatPourjetton(cgmsg.eventid,cgmsg.rebateId)
         
        if tonumber(pourjetton) + pourtypejettons  > (tonumber(SimpleRebateInfo.validAmount) or 0) then
            --下注限制 可竞猜
            gcmsg.result = ReturnCode["pour_limit"]
	        return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
        end
        --[[
        if tonumber(cgmsg.pourjetton)  > (( tonumber(raceinfo.raceTotalBet) -   tonumber(raceinfo.totalBet)) or 0) then
           --下注限制 可竞猜
            gcmsg.result = ReturnCode["pour_limit"]
	        return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
        end

        ]]

        if cgmsg.tiyan == 0 and tonumber(pourjetton) > tonumber(pInfo.jetton) then
            gcmsg.result = ReturnCode["carryjetton_not_enough"]
		    return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
        end

        -- 体验金下注
        if cgmsg.tiyan == 1 and tonumber(pourjetton) > tonumber(pInfo.tyjetton) then
            gcmsg.result = ReturnCode["carryjetton_not_enough"]
		    return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
        end
    
        if cgmsg.yieltype == nil or cgmsg.subtype  == nil or cgmsg.typescore == "" or tonumber(pourjetton) <= 0 then
            gcmsg.result = ReturnCode["param_error"]
            return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
        end
  
  
        if cgmsg.tiyan == 1 and SimpleRebateInfo.tiyan == 1 then
            --体验金下注 判断是否已经过了体验时间
            local sqlCase = "select dict_value from web_dict where dict_category = 'tyj_expire'".. " and channel = '" ..pInfo.channel.."'"
            mysqlItem:execute(sqlCase)
            local amount = 3
            local sqlData = mysqlItem:fetch()
            if sqlData == nil then
                amount = 3
            else
                amount =  tonumber(sqlData)
            end
            

            --local regtime = FootballModel.GetUserBindPhoneTime(pInfo.userid)
            local regtime  = PlayerModel.GetUserUseTycardStamp(pInfo.userid)
            if  PlayerModel.GetUserUseTycardState(pInfo.userid) ~= 1 or nowtime - regtime > amount * 24 * 60 * 60 then
                gcmsg.result = ReturnCode["typourtype_time_error"]
                return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
            end 

        end
        
        --验证卡片
        if cgmsg.cardid ~= "" and cgmsg.cardid ~= nil then
            --全场
            if cgmsg.yieltype ~= 0 then
                gcmsg.result = ReturnCode["cards_not_use_error1"] 
                return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
            end
            local propInfo =  PropService.getPropInfo(cgmsg.userid, cgmsg.cardid)
            if propInfo == nil then
                gcmsg.result = ReturnCode["cards_not_exist"] 
                return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
            end
            --收益
            local yiel = string.format("%.4f", tonumber(SimpleRebateInfo.rebateRatio))
            if tonumber(yiel) >  propInfo.condition * 0.0001  then
                gcmsg.result = ReturnCode["cards_not_use_error2"] 
                return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
            end
            --是否被使用
            if propInfo.state == 1 then
                gcmsg.result = ReturnCode["cards_is_used"] 
                return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
            end
            --是否过有效期
            local nowtime = TimeUtils.GetTime()
            if nowtime - tonumber(propInfo.receivedate) > propInfo.effectivetime * 24 * 60 * 60 then
                gcmsg.result = ReturnCode["cards_is_used"] 
                return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
            end

            --是否超过当前vip等级限制
            if viprulepb ~= nil then
                viprule:ParseFromString(viprulepb)
                local proplimit = viprule.proplimit
                proplimit = luajson.decode(proplimit)
                local exist_proptype = false
                local exist_num = 0
                for p_k,p_v in pairs (proplimit) do
                    if tonumber(propInfo.proptype) == tonumber(p_v["proptype"]) and tonumber(p_v["num"])  > 0 then
                       exist_proptype = true
                       exist_num = tonumber(p_v["num"])
                    end

                end
                

                if exist_proptype == false then
                    gcmsg.result = ReturnCode["viplevel_not_card"] 
                    return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
                end
                local todayusenum = VipMgrModel.GetVipUserCardsUsedCount(cgmsg.userid,propInfo.proptype)
                if exist_num <= todayusenum then
                    gcmsg.result = ReturnCode["viplevel_cardnum_over"] 
                    return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
                end
                proptype = propInfo.proptype
            end


        end

        --开始下注
    
        local ordertime = TimeUtils.GetTime()
        ordertime = TimeUtils.GetTimeString(ordertime)
        local orderid = FootballModel.GetNewOrderId()
   
        local yiel = string.format("%.4f", tonumber(SimpleRebateInfo.rebateRatio))
        local eventtype = raceinfo.category
        local starttime = tonumber(raceinfo.startTime)/1000 --查询赛事开始时间
        starttime = TimeUtils.GetTimeString(starttime)
        local fee = tostring(raceinfo.fee * 0.01 or 0)
 
        local win = tonumber(pourjetton) * (tonumber(yiel)) * (1 - tonumber(fee)) +  tonumber(pourjetton)
        win = tostring(math.floor(win))
        local hometeam = raceinfo.homeTeam
        local awayteam = raceinfo.visitTeam
        local rebateId = SimpleRebateInfo.rebateId
        local typescore = SimpleRebateInfo.score
        ordertype = cgmsg.tiyan == 1 and 1 or 0
        

	    local schemeid		          = cgmsg.schemeid or 0
	    local expertid		          = cgmsg.expertid or 0
        local expert = ""
        
        if expertid ~= 0 then
            local sqlCase = "select nickname from ex_player where userid="..expertid
            mysqlItem:executeQuery(sqlCase)
            local sqlData = mysqlItem:fetch()
            if sqlData ~= nil then
                expert = sqlData
            end
        end  
        local homelogo = raceinfo.homeTeamFace == "0"  and  g_footballgameDefine.homeTeamFace or raceinfo.homeTeamFace
        local awaylogo = raceinfo.visitTeamFace == "0" and  g_footballgameDefine.visitTeamFace or raceinfo.visitTeamFace
        local cardid = cgmsg.cardid or ""
        local sqlCase = "insert into dy_footballorder(orderid,userid,eventtype,subtype,yieltype,typescore,yiel,baoval,tiyan,starttime,ordertime,orderstate,fee,win,hometeam,awayteam,eventid,rebateId,pourjetton,channel,raceid,ordertype,prechannel,schemeid,expertid,expert,homelogo,awaylogo,cardid,ip,usertype,oprsys) values( '"
		    ..orderid.."',"..pInfo.userid..",'"..eventtype.."',"..cgmsg.subtype..","..cgmsg.yieltype..",'"..typescore.."','" .. yiel .."',"..cgmsg.baoval..","..cgmsg.tiyan..",'"..starttime.. "','"..ordertime.."',".. 0 .." , '"..fee.."','"..win.."','"..hometeam.."','"..awayteam.."','"..cgmsg.eventid.."','" ..rebateId.."','"..pourjetton.."','"..pInfo.channel.."','"..cgmsg.eventid.."',"..ordertype..",'"..prechannel.."',"..schemeid..","..expertid..",'"..expert.."','"..homelogo.."','"..awaylogo.."','"..cardid..
            "','"..pInfo.ip.."','"..pInfo.usertype.."','"..pInfo.oprsys.. "')"
             	
	    --luaPrint(" FootballPour sqlCase: "..sqlCase)

        local sqlresult = mysqlItem:execute(sqlCase)
        if sqlresult == 1 then
        
            --订单详细信息
            local orderinfo =  msg_footballgame_pb.gcfootballorderdetail()
            orderinfo.result	                  = 0 
            orderinfo.orderid	                  = tostring(orderid)
            orderinfo.userid	                  = pInfo.userid
            orderinfo.eventtype	                  = eventtype
            orderinfo.starttime	                  = tonumber(raceinfo.startTime)/1000
            orderinfo.win	                      = win	
            orderinfo.orderstate                  = 0
            orderinfo.hometeam	                  = hometeam
            orderinfo.awayteam	                  = awayteam
            orderinfo.ordertime	                  = TimeUtils.GetTime(ordertime)
            orderinfo.orderyiel.subtype           = cgmsg.subtype  
            orderinfo.orderyiel.yieltype          = cgmsg.yieltype
            orderinfo.orderyiel.typescore         = typescore
            orderinfo.orderyiel.yiel              = yiel
            orderinfo.orderyiel.baoval            = cgmsg.baoval
            orderinfo.orderyiel.tiyan	          = cgmsg.tiyan  
            orderinfo.orderyiel.rebateId	      = rebateId
            orderinfo.fee	                      =	fee
            orderinfo.eventid	                  = cgmsg.eventid
            orderinfo.pourjetton                  = tostring(pourjetton)
            orderinfo.rebateId	                  = rebateId
            orderinfo.expert			          = expert  
	        orderinfo.schemeid			          = schemeid
	        orderinfo.expertid			          = expertid
            orderinfo.homelogo			          = raceinfo.homeTeamFace == "0"  and g_footballgameDefine.homeTeamFace or raceinfo.homeTeamFace
	        orderinfo.awaylogo			          = raceinfo.visitTeamFace == "0" and g_footballgameDefine.visitTeamFace or  raceinfo.visitTeamFace
            orderinfo.cardid                      = cardid

            if cardid ~= "" then
               PropService.useProp(pInfo.userid, cardid, orderinfo.orderid)
            end
            --FootballModel.SetOrderInfo(orderid,orderinfo:SerializeToString())
            FootballModel.SetRaceOfOrderInfo(orderinfo.eventid,orderinfo)
            --所有订单
            --FootballModel.SetUserSortOrder(pInfo.userid,orderid)
            --未返利订单(新订单)
            --FootballModel.SetUserSortNorebateOrder(pInfo.userid,orderid)
            --结算时后使用 
            RaceInfoModel.PushOrderList(orderid, 1, cgmsg.eventid, pourjetton, cgmsg.yieltype, rebateId, cgmsg.tiyan==1, orderinfo.orderyiel.yiel)
            FootballModel.SetRaceOrderCount(cgmsg.eventid,1)
            if cgmsg.tiyan == 0 then
             
                PlayerModel.DecJetton(pInfo,tonumber(pourjetton),"fooball","FootballPour")
                PlayerModel.SendJetton(pInfo)
            else
                PlayerModel.AddTyJetton(pInfo, 0-tonumber(pourjetton))
            end
            --玩家个人赛事 区域下注总额
            FootballModel.AddUserRaceRebeatPourjetton(pInfo.userid,cgmsg.eventid,rebateId,tonumber(pourjetton))

            local xiazhu = cgmsg.tiyan == 1 and "体验金下注" or "下注"
            LogServer.addRecords(pInfo.userid,2,xiazhu,0 - tonumber(pourjetton),orderinfo.orderid)

            local season = cgmsg.tiyan == 1 and g_moneyOptType.opt_game_typour or g_moneyOptType.opt_game_pour
            local msg = "玩家在".. orderinfo.eventtype..orderinfo.hometeam.."(主) VS "..orderinfo.awayteam.."(客)".."比赛中的"..typescore.."比分区域"..xiazhu.." : "..(pourjetton * 0.01).."元"
            LogServer.GameUserMoney(pInfo, g_footballgameDefine.game_type, 1, 0-tonumber(pourjetton), msg, 0,0,season,orderinfo.orderid,cgmsg.tiyan == 1,2)

            local bet = 0
            local tybet = 0
            local betcount = 0
            local tybetcount = 0
            if cgmsg.tiyan == 1 then
               tybet = pourjetton
               tybetcount = 1
            else
               bet = pourjetton
               betcount = 1
            end
            --每天下注量统计
            --LogServer.dailFBBetCount(bet,tybet,orderinfo.ordertime,pInfo)
            LogDispatch.logBetCount(pInfo,bet,tybet,0,0)
            --统计注单数
            LogServer.raceFBRaceCount(raceinfo.category,bet,betcount,tybet,tybetcount,pInfo.channel,prechannel,0,orderinfo.ordertime)
            local touzhutype = 0
            if cgmsg.tiyan == 1 then
                 touzhutype  = 1 
            else     
                touzhutype = 0  
            end
            ExpertModel.PourPlan(pInfo.userid, cgmsg.schemeid, cgmsg.expertid, pourjetton, touzhutype)

            RaceInfoModel.PourRaceScore(cgmsg.eventid,rebateId, pourjetton, touzhutype, 0, pInfo.channel)
            if proptype ~= -1 then
                --卡券使用次数
                VipMgrModel.SetVipUserCardsUsedCount(pInfo.userid,1,proptype)
            end
            LogServer.firstPlayer(pInfo.userid,1)

        else
            gcmsg.result = ReturnCode["pour_error"]
            return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
        end
    else
        --猜输赢模式
        gcmsg.isBet = cgmsg.isBet 
        local wlpourtype = cgmsg.wlpourtype
        local pourjetton = tonumber(cgmsg.pourjetton) or 0
        
        if wlpourtype ~= 1 and wlpourtype ~= 2 and wlpourtype ~=  3 then
            gcmsg.result = ReturnCode["pourtype_not_exit"]
		    return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
        end


        if pourjetton <= 0 then
            gcmsg.result = ReturnCode["param_error"]
            return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
        end

        if tonumber(pourjetton) > tonumber(pInfo.jetton) then
            gcmsg.result = ReturnCode["carryjetton_not_enough"]
		    return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
        end
        
        FootballModel.PourJetton(cgmsg.eventid,wlpourtype, cgmsg.userid,tonumber(pourjetton))

        --开始下注
        PlayerModel.DecJetton(pInfo,tonumber(pourjetton),"fooball","FootballPour")
        PlayerModel.SendJetton(pInfo)
        --注单
        local betcount = 0
        --订单信息
        local tempOrderinfoPB = msg_footballgame_pb.gcfootballorderdetail()
        local sqlCase  = ""
        if FootballModel.isExitPourWLOrderInfo(cgmsg.eventid,pInfo.userid) then
            --订单存在 更新订单
            local tempOrderInfo =  FootballModel.GetPourWLOrderInfo(cgmsg.eventid,pInfo.userid)
            tempOrderinfoPB:ParseFromString(tempOrderInfo)
            tempOrderinfoPB.pourjetton  = tostring(tonumber(pourjetton) + (tonumber(tempOrderinfoPB.pourjetton) or 0))
            local wlpourlist = "wlpourlist"..wlpourtype

            sqlCase = "update dy_footballorder set "..wlpourlist.. "="..wlpourlist.." + ".. tonumber(pourjetton)..", pourjetton=pourjetton + "..tonumber(pourjetton).. " where orderid = "..tempOrderinfoPB.orderid
            
        else
            --订单不存在 插入一个新订单
            local hometeam = raceinfo.homeTeam
            local awayteam = raceinfo.visitTeam
            local eventtype = raceinfo.category
            local fee = tostring(raceinfo.betfee * 0.01 or 0)

            local orderid = FootballModel.GetNewOrderId()
            betcount = 1 --插入注单数+1
            tempOrderinfoPB.result	                  = 0 
            tempOrderinfoPB.orderid	                  = tostring(orderid)
            tempOrderinfoPB.userid	                  = pInfo.userid
            tempOrderinfoPB.eventtype	              = eventtype
            tempOrderinfoPB.starttime	              = tonumber(raceinfo.startTime)/1000
            tempOrderinfoPB.orderstate                = 0
            tempOrderinfoPB.hometeam	              = hometeam
            tempOrderinfoPB.awayteam	              = awayteam
            tempOrderinfoPB.ordertime	              = TimeUtils.GetTime()
            tempOrderinfoPB.fee	                      =	fee
            tempOrderinfoPB.eventid	                  = cgmsg.eventid
            tempOrderinfoPB.pourjetton                = tostring(pourjetton)
            tempOrderinfoPB.isBet                     = cgmsg.isBet
            tempOrderinfoPB.homelogo			      = raceinfo.homeTeamFace == "0"  and  g_footballgameDefine.homeTeamFace  or  raceinfo.homeTeamFace
	        tempOrderinfoPB.awaylogo			      = raceinfo.visitTeamFace == "0" and  g_footballgameDefine.visitTeamFace  or raceinfo.visitTeamFace
            tempOrderinfoPB.cardid                    = cgmsg.cardid or ""
            local wlpourlist = "wlpourlist"..wlpourtype
            local cardid = cgmsg.cardid or ""
            sqlCase = "insert into dy_footballorder(orderid,userid,eventtype,starttime,ordertime,orderstate,fee,win,hometeam,awayteam,eventid,"..wlpourlist..",channel,isBet,raceid,ordertype,prechannel,pourjetton,homelogo,awaylogo,cardid,ip,usertype,oprsys) values( '"
		    ..orderid.."',"..pInfo.userid..",'"..eventtype.."','"..TimeUtils.GetTimeString(tempOrderinfoPB.starttime).. "','"..TimeUtils.GetTimeString(tempOrderinfoPB.ordertime).."',".. 0 .." , '"..fee.."','".. 0 .."','"..hometeam.."','"..awayteam.."','"..cgmsg.eventid.."','" ..pourjetton.."','"..pInfo.channel.."',"..cgmsg.isBet..",'"..cgmsg.eventid.."',"..ordertype..",'"..prechannel.. "',"..pourjetton..",'"..tempOrderinfoPB.homelogo.."','"..tempOrderinfoPB.awaylogo.. "','"..cardid ..
            "','"..pInfo.ip.."','"..pInfo.usertype.."','"..pInfo.oprsys.. "')"	 	
       
            FootballModel.SetRaceOrderCount(cgmsg.eventid,1)

            LogServer.firstPlayer(pInfo.userid,1)

        end

        --区域总下注
        local totalPourList = {0,0,0}
        local userPourlist = {0,0,0}
        
        for k = 1,3  do
            --local addH = gcmsg.wlpourlist:add()
            local jetton = FootballModel.GetUserPourJetton(cgmsg.eventid, k, pInfo.userid)
            --个人区域总下注
            gcmsg.wlpourlist:append(tostring(jetton))

            --订单保存信息
            --local addOrderH = tempOrderinfoPB.wlpourlist:add()
            if #tempOrderinfoPB.wlpourlist < 3 then
                tempOrderinfoPB.wlpourlist:append(tostring(jetton))
            else
               tempOrderinfoPB.wlpourlist[k] = (tostring(jetton))     
            end
            

            --区域总下注
            --local addHTotal = gcmsg.wltotalpourlist:add()
            local totaljetton = FootballModel.GetPourJetton(cgmsg.eventid, k)
            gcmsg.wltotalpourlist:append(tostring(totaljetton))

            --订单保存信息
            --local addOrderTotalH = tempOrderinfoPB.wltotalpourlist:add()
            if #tempOrderinfoPB.wltotalpourlist < 3 then
                tempOrderinfoPB.wltotalpourlist:append(tostring(totaljetton))
            else
               tempOrderinfoPB.wltotalpourlist[k] = (tostring(totaljetton))     
            end
           
            --区域总下注
            totalPourList[k] = totaljetton
        end

        --计算赔率
        local newRateList = FootballUtils.cluWLrate(totalPourList)
        for k=1, 3 do
            --设置新的赔率
            FootballModel.SetPourWLRate(cgmsg.eventid,k,newRateList[k])
            --local addRate = gcmsg.wlrate:add()
            gcmsg.wlrate:append(tostring(newRateList[k]))
           
            --订单保存信息
            --local addOrderRate = tempOrderinfoPB.wlrate:add()
            if #tempOrderinfoPB.wlrate < 3 then
                tempOrderinfoPB.wlrate:append(tostring(newRateList[k]))
            else
                tempOrderinfoPB.wlrate[k] =(tostring(newRateList[k]))
            end
            

        end

        local win = FootballUtils.cluWLWin(totalPourlist,userPourlist,rateList)
        tempOrderinfoPB.win	= tostring(win)	
        tempOrderinfoPB.isBet = cgmsg.isBet
        --所有订单
        --FootballModel.SetUserSortOrder(pInfo.userid,tempOrderinfoPB.orderid)
        --未返利订单(新订单)
        --FootballModel.SetUserSortNorebateOrder(pInfo.userid,tempOrderinfoPB.orderid)

        --此处是保存所有模式的订单
        --FootballModel.SetOrderInfo(tempOrderinfoPB.orderid,tempOrderinfoPB:SerializeToString())
        FootballModel.SetRaceOfOrderInfo(tempOrderinfoPB.eventid,tempOrderinfoPB)
        --此处只保存输赢赛事订单
        FootballModel.SetPourWLOrderInfo(cgmsg.eventid,pInfo.userid,tempOrderinfoPB:SerializeToString())
        SqlServer.rpush(sqlCase)
        --print("sqlCase",sqlCase)
        
        local xiazhu = "竞猜输赢下注"
        LogServer.addRecords(pInfo.userid,2,xiazhu,0 - tonumber(pourjetton),tempOrderinfoPB.orderid)

        
        --每天下注量统计
        --LogServer.dailFBBetCount(pourjetton,0, tempOrderinfoPB.ordertime,pInfo)
        LogDispatch.logBetCount(pInfo,pourjetton,0,0,0)
        --统计注单数
        LogServer.raceFBRaceCount(raceinfo.category,pourjetton,betcount,0,0,pInfo.channel,prechannel,0,tempOrderinfoPB.ordertime)

        local season = g_moneyOptType.opt_game_pour
        local msg = "玩家在".. tempOrderinfoPB.eventtype..tempOrderinfoPB.hometeam.."(主) VS "..tempOrderinfoPB.awayteam.."(客)".."比赛中的"..xiazhu.." : "..(pourjetton * 0.01).."元"
        LogServer.GameUserMoney(pInfo, g_footballgameDefine.game_type, 1, 0-tonumber(pourjetton), msg, 0,0,season,tempOrderinfoPB.orderid,false,2)
         
    end
   -- print("gcmsg",gcmsg)
    gcmsg.result = 0
	return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
end