module("FootballNews",package.seeall)
--消息
function execute(packetID, operateID, buffer)
	--print("FootballNews")
    local cgmsg = msg_footballgame_pb.cgfootballnews()
	local gcmsg = msg_footballgame_pb.gcfootballnews()
	
	cgmsg:ParseFromString(buffer)
    --print(cgmsg)
    local pInfo = PlayerModel.GetPlayerInfo(cgmsg.userid)
    if pInfo == nil then
        gcmsg.result = ReturnCode["player_not_exist"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
    end

    if cgmsg.reqtype == 1 then
        --请求类型 1 请求红点 消息数量  

    elseif cgmsg.reqtype == 2 then  
        local sqlCase = "select u.userid,u.newsid,u.newsstate, u.newstype, a.title,a.content, a.sendid , a.sendtime  from log_userannouncement  as u join log_announcement a on a.id = u.newsid  and  u.userid = "..cgmsg.userid.." and  u.newstype = "..cgmsg.newstype.." and u.newsstate < 2 ".. " order by a.id desc limit "..25*(cgmsg.pagenum -1)..", 25"
        mysqlLog:executeQuery(sqlCase)
        --print(sqlCase)
        while true do
            local sqlData = mysqlLog:fetch({})
            if sqlData == nil then
               break
            end
            local addh =  gcmsg.news:add()
            addh.newsid         = tonumber(sqlData[2])
            addh.newsstate		= tonumber(sqlData[3])
            addh.newstype       = tonumber(sqlData[4])
            addh.title          = sqlData[5]
            addh.content        = sqlData[6]
            addh.sendid			= tonumber(sqlData[7])
            addh.sendtime       = TimeUtils.GetTime(sqlData[8])    
        end
        

    elseif cgmsg.reqtype == 3 then     
        --已读
        local  sqlCase = "update log_userannouncement set newsstate = 1 where userid = "..cgmsg.userid.. " and newsid = "..cgmsg.newsid
        mysqlLog:execute(sqlCase)
    elseif cgmsg.reqtype == 4 then        
        --删除 置状态2    0: 未读，1:已读 2:玩家删除不看
        local  sqlCase = "update log_userannouncement set newsstate = 2 where userid = "..cgmsg.userid.. " and newsid = "..cgmsg.newsid
        mysqlLog:execute(sqlCase)
        --print(sqlCase)
    end


    --[[
    local nowtime = TimeUtils.GetTime()
    if cgmsg.newstype ==  1 then
        --获取公告
        local newsInfoList = FootballModel.GetAllPublicNews()
        for k,v in pairs(newsInfoList) do
            local newsInfo =  st_footballgame_pb.newsinfo()
            newsInfo:ParseFromString(v)
            local sendtime = TimeUtils.GetTime(newsInfo.sendtime)
            if nowtime >= sendtime and newsInfo.publishstate == 1 then
                local addh =  gcmsg.news:add()
                addh.newsid		  = newsInfo.newsid		    --id
	            addh.newstype	  = newsInfo.newstype	    --类型 1:公告 2：站内信	
	            addh.title		  = newsInfo.title		    --标题
	            addh.content	  = newsInfo.content	    --内容
	            addh.sendtime	  = newsInfo.sendtime	    --发送时间
	            addh.sendid		  = newsInfo.sendid	        --发送者id
	            addh.sendname	  = "全民足球"	            --发送者name
	            addh.receiveid	  = newsInfo.receiveid	    --接收者id
	            addh.receivename  = newsInfo.receivename    --接收者name
	            addh.newsstate	  = newsInfo.newsstate	    --state 0: 未读，1:已读	
                addh.publishstate = newsInfo.publishstate   --发布状态 0: 未发布，1:已发布
                addh.channel	  = newsInfo.channel	    --渠道  
            end

            	
        end
    elseif cgmsg.newstype  == 2 then

        local newsInfoList = FootballModel.GetUserNews(cgmsg.userid)
        for k,v in pairs(newsInfoList) do
            local newsInfo =  st_footballgame_pb.newsinfo()
            newsInfo:ParseFromString(v)
            local sendtime = TimeUtils.GetTime(newsInfo.sendtime)
            if nowtime >= sendtime and newsInfo.publishstate == 1 then
                local addh =  gcmsg.news:add()
                addh.newsid		  =  newsInfo.newsid		--id
	            addh.newstype	  =  newsInfo.newstype	    --类型 1:公告 2：站内信	
	            addh.title		  =  newsInfo.title		    --标题
	            addh.content	  =  newsInfo.content	    --内容
	            addh.sendtime	  =  newsInfo.sendtime	    --发送时间
	            addh.sendid		  =  newsInfo.sendid	    --发送者id
	            addh.sendname	  =  "admin"	            --发送者name
	            addh.receiveid	  =  newsInfo.receiveid	    --接收者id
	            addh.receivename  =  newsInfo.receivename   --接收者name
	            addh.newsstate	  =  newsInfo.newsstate	    --state 0: 未读，1:已读	
                addh.publishstate =  newsInfo.publishstate  --发布状态 0: 未发布，1:已发布
                addh.channel	  =  newsInfo.channel	    --渠道   
            end           	
        end 
    end
    ]]


    
        for i=1,4  do
            local sqlCase = "select count(*) from log_userannouncement where userid = "..cgmsg.userid.." and newsstate = 0 and newstype = "..i
            mysqlLog:executeQuery(sqlCase)
            local sqlData = mysqlLog:fetch()
            --print(sqlCase)
            gcmsg.unreadcount:append(tonumber(sqlData) or 0)

        end
   

    
    gcmsg.reqtype = cgmsg.reqtype
    gcmsg.newstype = cgmsg.newstype
    gcmsg.pagenum = cgmsg.pagenum
    gcmsg.result = 0
    --print(gcmsg)
	return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
end