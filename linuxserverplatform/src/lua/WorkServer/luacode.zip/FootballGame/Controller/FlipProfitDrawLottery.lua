module("FlipProfitDrawLottery",package.seeall)
--交易记录
function execute(packetID, operateID, buffer)
	--print("FlipProfitDrawLottery")
    local cgmsg = msg_footballgame2_pb.cgflipprofitdrawlottery()
	local gcmsg = msg_footballgame2_pb.gcflipprofitdrawlottery()
	
	cgmsg:ParseFromString(buffer)
    local pInfo = PlayerModel.GetPlayerInfo(cgmsg.userid)
    if pInfo == nil then
        gcmsg.result = ReturnCode["player_not_exist"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
    end
    local   freeflipcount = 0
    local prechannel = GameUtils.GetChannel_login(pInfo.channel)
    local sqlCase = "select freeflipcount from log_flipprofitreport where profitid = '"..cgmsg.profitid.."' and userid ="..cgmsg.userid
    mysqlLog:executeQuery(sqlCase)
    local sqlData = mysqlLog:fetch()
    if sqlData == nil then
        gcmsg.result = ReturnCode["can_not_draw"]   
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString() 
    else
        freeflipcount = tonumber(sqlData)   
    end
    local payjetton = 500
    if cgmsg.payjetton  > 0 then
        --付费模式
        --查询翻牌价格
        
        local sqlCase = "select dict_value from web_dict where prechannel = '"..prechannel.."' and dict_category = '".."ffl".."'"
        mysqlItem:executeQuery(sqlCase)
        local sqlData = mysqlItem:fetch()
        if sqlData ~= nil then
           payjetton = tonumber(sqlData)
        end
        if payjetton ~= cgmsg.payjetton then
            gcmsg.result = ReturnCode["payjetton_error"]   
		    return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
        end

        if payjetton > tonumber(pInfo.jetton) then
            gcmsg.result = ReturnCode["jetton_not_enought"]  
		    return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
        end

            PlayerModel.DecJetton(pInfo,tonumber(payjetton),"fooball","FootballPour")
            PlayerModel.SendJetton(pInfo)
            local orderid = LogServer.GetNewLogOrderid()
            local remark = "翻翻乐翻牌"
            LogServer.addRecords(pInfo.userid,2,remark,0 - tonumber(payjetton),orderid)
           
            local season = g_moneyOptType.opt_pay_ffl
            local msg = "玩家在翻翻乐方案".. cgmsg.profitid.."中翻牌花费: "..(payjetton * 0.01).."元"
            LogServer.GameUserMoney(pInfo, g_footballgameDefine.game_type, 1, 0-tonumber(payjetton), msg, 0,0,season,orderid)
    else
        --免费模式
        if freeflipcount  <= 0 then
            gcmsg.result = ReturnCode["free_count_error"]  
		    return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
        end

        local sqlCase = "update log_flipprofitreport set freeflipcount= freeflipcount ".."-1  where profitid = '"..cgmsg.profitid.."' and userid = "..cgmsg.userid
        local ret = mysqlLog:execute(sqlCase)
        if ret == 1 then
            freeflipcount  = freeflipcount - 1
            local orderid = LogServer.GetNewLogOrderid()
            local remark = "翻翻乐翻牌"
            LogServer.addRecords(pInfo.userid,2,remark,0,orderid)


            local season = g_moneyOptType.opt_pay_ffl
            local msg = "玩家在翻翻乐方案".. cgmsg.profitid.."中消耗1次本轮免费翻牌次数，剩余免费次数: "..(freeflipcount).." 花费: "..(0).."元"
            LogServer.GameUserMoney(pInfo, g_footballgameDefine.game_type, 1, 0, msg, 0,0,season,orderid)
        else
            print("sqlCase",sqlCase)
            gcmsg.result = ReturnCode["free_count_error"]  
		    return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
        end
    end

    if freeflipcount == 0 then
        local sqlCase = "select dict_value from web_dict where prechannel = '"..prechannel.."' and dict_category = '".."ffl".."'"
        mysqlItem:executeQuery(sqlCase)
        local sqlData = mysqlItem:fetch()
        if sqlData ~= nil then
           payjetton = tonumber(sqlData)
        end
    end

    gcmsg.freeflipcount	    = freeflipcount
    gcmsg.payjetton		    = payjetton
    gcmsg.pos				= cgmsg.pos
    


    --开始抽奖
    local propinfo = PropService.receivePrizeList(pInfo.userid, payjetton == 0)
    if propinfo == nil then
        --未中奖
        gcmsg.prizeid			= 0
        gcmsg.prizecount		= 0
        gcmsg.prizedesc		    = ""
        local sqlCase = "insert into log_drawlottoryrecords(userid,drawtime,category,prizeid,prizecount,prizedesc,payjetton,channel,prechannel,state)values("..
        pInfo.userid..",'"..TimeUtils.GetTimeString().."',".. 0 .. ",'"..gcmsg.prizeid.."',"..gcmsg.prizecount..",'"..gcmsg.prizedesc.."',"..cgmsg.payjetton..",'"..
        pInfo.channel.."','"..prechannel.."',"..0 ..")"
        --print(sqlCase)
        mysqlLog:execute(sqlCase)

    else    
        local propid       =    propinfo.propid
        local proptype      =    propinfo.proptype
        local propname      =    propinfo.propname
        local propvalue     =    propinfo.propvalue
        local condition     =    propinfo.condition

        gcmsg.prizecount	= 1
        gcmsg.prizeid	    = proptype
        
        gcmsg.prizedesc		= "恭喜玩家  "..pInfo.nickname.." 获得一张 "..propname..",面额 "..(propvalue * 0.01)
        local sqlCase = "insert into log_drawlottoryrecords(userid,drawtime,category,prizeid,prizecount,prizedesc,payjetton,channel,prechannel,state,propid,proptype,propname,propvalue,conditions)values("..
        pInfo.userid..",'"..TimeUtils.GetTimeString().."',".. 0 .. ",'"..gcmsg.prizeid.."',"..gcmsg.prizecount..",'"..gcmsg.prizedesc.."',"..cgmsg.payjetton..",'"..
        pInfo.channel.."','"..prechannel.."',"..1 ..",'"..propid.."',"..proptype..",'"..propname.."',"..propvalue ..","..condition..")"
        --print(sqlCase)
        mysqlLog:execute(sqlCase)

    end
    gcmsg.result = 0
    --print(gcmsg)
	return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
end