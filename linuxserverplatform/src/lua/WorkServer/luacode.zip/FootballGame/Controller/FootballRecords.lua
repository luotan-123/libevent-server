module("FootballRecords",package.seeall)
--交易记录
function execute(packetID, operateID, buffer)
	--print("FootballRecords")
    local cgmsg = msg_footballgame_pb.cgfootballrecords()
	local gcmsg = msg_footballgame_pb.gcfootballrecords()
	
	cgmsg:ParseFromString(buffer)
    local pInfo = PlayerModel.GetPlayerInfo(cgmsg.userid)
    if pInfo == nil then
        gcmsg.result = ReturnCode["player_not_exist"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
    end
--    local recordlist =  FootballModel.GetUserRecords(cgmsg.userid)
--    for k,v in pairs(recordlist) do

--        local temprecord = msg_footballgame_pb.gcfootballrecords()
--        temprecord:ParseFromString(v)
--        if temprecord.opttype == cgmsg.opttype  or  cgmsg.opttype == 0 then

--            local addH = gcmsg.records:add()
--            addH.amount  = tostring(temprecord.records[1].amount)
--            addH.remark  = tostring(temprecord.records[1].remark)
--            addH.optmsg  = tostring(temprecord.records[1].optmsg)
--            addH.opttime = temprecord.records[1].opttime or 0

--        end
--    end
    local starttime = cgmsg.starttime or 0
    local endtime = cgmsg.endtime or TimeUtils.GetTime()
    local pagenum = cgmsg.pagenum or 1
    local sqlCase = "select * from log_records where userid = "..cgmsg.userid.." and opttype="..cgmsg.opttype.." and opttime >= '"..TimeUtils.GetTimeString(starttime).."' and opttime <= '"..TimeUtils.GetTimeString(endtime).."'  order by id desc limit "..20 * (pagenum -1)..","..20

    if cgmsg.opttype == 0 then
        sqlCase = "select * from log_records where userid = "..cgmsg.userid.." and opttime >= '"..TimeUtils.GetTimeString(starttime).."' and opttime <= '"..TimeUtils.GetTimeString(endtime).."'  order by id desc limit "..20 * (pagenum -1)..","..20

    end

    mysqlLog:executeQuery(sqlCase)
 
	while true do
		local sqlData = mysqlLog:fetch({})
		if sqlData == nil then
			break
		end
        local addH = gcmsg.records:add()
        addH.amount  = sqlData[4]
        addH.remark  = sqlData[6]
        addH.opttime = TimeUtils.GetTime(sqlData[5])
        addH.orderid = (sqlData[7] == nil or sqlData[7] == "") and "" or sqlData[7]
    end

    gcmsg.opttype = cgmsg.opttype
    gcmsg.pagenum = cgmsg.pagenum
    gcmsg.result = 0
	return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
end