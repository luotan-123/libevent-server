module("FlipProfitRecords",package.seeall)
--翻翻乐的中奖情况记录
function execute(packetID, operateID, buffer)
	--print("FlipProfitRecords")
    local cgmsg = msg_footballgame2_pb.cgflipprofitrecords()
	local gcmsg = msg_footballgame2_pb.gcflipprofitrecords()
	
	cgmsg:ParseFromString(buffer)
    local pInfo = PlayerModel.GetPlayerInfo(cgmsg.userid)
    if pInfo == nil then
        gcmsg.result = ReturnCode["player_not_exist"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
    end
    
    local sqlCase = "select * from log_drawlottoryrecords where  category = "..cgmsg.reqtype .." and userid = "..cgmsg.userid.." order by id desc limit  ".. 10*(cgmsg.pagenum-1).." , 10"
    mysqlLog:executeQuery(sqlCase)
    --print(sqlCase)
    while true do
	    local sqlData = mysqlLog:fetch({})
	    if sqlData == nil then
            break
	    end
        if tonumber(sqlData[11])  ==  1 then
            local addH = gcmsg.drawrecoreds:add()
            addH.drawtime   = sqlData[3]
            addH.payjetton  = tonumber(sqlData[7])
            addH.prizedesc  = (sqlData[14] or "").."一张，".."面值"..(tonumber(sqlData[15]) or 0) * 0.01 .."元"
        else
            local addH = gcmsg.drawrecoreds:add()
            addH.drawtime   = sqlData[3]
            addH.payjetton  = tonumber(sqlData[7])
            addH.prizedesc  = "无"
        end


    end
    gcmsg.pagenum = cgmsg.pagenum
    gcmsg.result = 0
    --print(gcmsg)
	return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
end