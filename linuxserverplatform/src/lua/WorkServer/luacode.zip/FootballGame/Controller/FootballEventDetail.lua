module("FootballEventDetail",package.seeall)
--赛事详情
function execute(packetID, operateID, buffer)
	--print("FootballEventDetail")
    local cgmsg = msg_footballgame_pb.cgfootballeventdetail()
	local gcmsg = msg_footballgame_pb.gcfootballeventldetail()
	
	cgmsg:ParseFromString(buffer)
    local pInfo = PlayerModel.GetPlayerInfo(cgmsg.userid)

    if pInfo == nil then
        gcmsg.result = ReturnCode["player_not_exist"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
    end

	local raceinfopb = RaceInfoModel.GetRaceInfo(cgmsg.eventid)
    
	if raceinfopb == nil then
		gcmsg.result = ReturnCode["event_not_exit"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
	end

    local raceinfo = st_footballgame_pb.MerchantRaceInfoDto()
	raceinfo:ParseFromString(raceinfopb)
    --下注区域信息
	local raceRebateInfo = RaceInfoModel.GetAllRaceRebateInfo(cgmsg.eventid)
	if raceRebateInfo == nil then
		gcmsg.result = ReturnCode["event_not_exit"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
	end
  
--    if raceinfo.raceStatus ~= 3  then
--        gcmsg.result = ReturnCode["can_not_pour"]
--		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
--    end


    local nowtime = TimeUtils.GetTime()
--    if raceinfo.openStatus == 0 then
--        gcmsg.result = ReturnCode["can_not_pour"]
--		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
--    end

--    if raceinfo.openStatus == 0 or tonumber(nowtime) > (tonumber(raceinfo.startTime) or 0) /1000 then

--        gcmsg.result = ReturnCode["event_has_start"]
--		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()

--    end

	-- 填充赛事信息
    gcmsg.eventid		= cgmsg.eventid
    gcmsg.eventtype		= raceinfo.category
    gcmsg.state			= raceinfo.againSettle
    gcmsg.starttime		= tonumber(raceinfo.startTime)/1000
    gcmsg.endtime		= (tonumber(raceinfo.endTime ) or 0)/1000
                        
    gcmsg.maxyiel		= string.format("%.4f", tonumber(raceinfo.maxYiel))
    gcmsg.hometeam		= raceinfo.homeTeam
    gcmsg.awayteam		= raceinfo.visitTeam

    gcmsg.matchId  			= raceinfo.matchId  
	gcmsg.seasonId  		= raceinfo.seasonId 
	gcmsg.homeId  			= raceinfo.homeId  	
	gcmsg.visitId  			= raceinfo.visitId  

    if raceinfo.winResult == "0" or raceinfo.winResult == "" then
    
    else
        
        local result_score = FootballUtils.score_split(raceinfo.winResult, "-")
	    gcmsg.homescore	= tonumber(result_score[1])
	    gcmsg.awayscore	= tonumber(result_score[2])

    end
   
	for k,v in pairs(raceRebateInfo) do
		if gcmsg.starttime < nowtime or raceinfo.raceStatus ~= 3  then
		   break
		end
		local aRaceRebateInfo = st_footballgame_pb.SimpleRebateInfo()
		aRaceRebateInfo:ParseFromString(v)
		
		local addS = gcmsg.scoreyiel:add() 
		addS.yieltype = aRaceRebateInfo.ruleType - 1  --全场半场
        --print(k,aRaceRebateInfo.ruleType)
        -- 0: 主 1:客 2:和
        if aRaceRebateInfo.score == "其他" then
           addS.subtype = 2
        else
            local result_score = FootballUtils.score_split(aRaceRebateInfo.score, "-")
            if  tonumber(result_score[1]) > tonumber(result_score[2])  then
                addS.subtype = 0
            elseif tonumber(result_score[1]) == tonumber(result_score[2]) then
                addS.subtype = 2
            else
                addS.subtype = 1
            end
        end
        --print(aRaceRebateInfo.score,aRaceRebateInfo.rebateId)
		addS.typescore 			= aRaceRebateInfo.score
		addS.yiel      			=  string.format("%.4f", tonumber(aRaceRebateInfo.rebateRatio))
        -- print(addS.typescore,addS.yiel)
		addS.baoval    			= aRaceRebateInfo.baoval
		addS.tiyan	  			= aRaceRebateInfo.tiyan
		addS.rebateId	  		= aRaceRebateInfo.rebateId
		addS.rebateOpenStatus	= aRaceRebateInfo.rebateOpenStatus
		addS.totaljetton = tostring(FootballModel.GetUserRaceRebeatPourjetton(pInfo.userid,cgmsg.eventid,aRaceRebateInfo.rebateId))
		addS.changeRatio 		= aRaceRebateInfo.changeRatio
	end
	
    gcmsg.fee			= tostring(raceinfo.fee or 0)
    gcmsg.maxpour		= raceinfo.raceTotalBet
    gcmsg.minpour		= "100"
    gcmsg.openStatus	= raceinfo.openStatus
    gcmsg.isValid		= raceinfo.isValid
    gcmsg.raceStatus	= raceinfo.raceStatus
    gcmsg.isRecommend	= raceinfo.isRecommend


    if cgmsg.isBet == 1 and  cgmsg.isBet == raceinfo.isBet then
        --猜输赢
        gcmsg.isBet = raceinfo.isBet
        for i=1,3  do
            --local addH = gcmsg.wlpourlist:add()       --个人    1：主, 2 平, 3 客
            local jetton = FootballModel.GetUserPourJetton(cgmsg.eventid, i, cgmsg.userid)
            --个人区域总下注
            --addH.append(tostring(jetton))
            gcmsg.wlpourlist:append(tostring(jetton))

            --local addH = gcmsg.wltotalpourlist:add()  --总额    1：主, 2 平, 3 客
            local totaljetton = FootballModel.GetPourJetton(cgmsg.eventid, i)
            --addH.append(tostring(totaljetton))
            gcmsg.wltotalpourlist:append(tostring(totaljetton))


            --local addH = gcmsg.wlrate:add()           --赔率    1：主, 2 平, 3 客
            local rate = FootballModel.GetPourWLRate(cgmsg.eventid,i)
            --addH.append(tostring(rate))
            gcmsg.wlrate:append(tostring(rate))
            local temprate = FootballModel.GetWlChangeRatio(cgmsg.eventid,i)
            gcmsg.wlchangeRatio:append(tostring(tonumber(rate) - temprate ))

        end

    end
    gcmsg.tag	 = cgmsg.tag
    gcmsg.result = 0
	return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
end