module("FootballOrderDetail",package.seeall)
--订单详情
function execute(packetID, operateID, buffer)
	--print("FootballOrderDetail")
    local cgmsg = msg_footballgame_pb.cgfootballorderdetail()
	local gcmsg = msg_footballgame_pb.gcfootballorderdetail()
	cgmsg:ParseFromString(buffer)
    local pInfo = PlayerModel.GetPlayerInfo(cgmsg.userid)
    
    if pInfo == nil then
        gcmsg.result = ReturnCode["player_not_exist"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
    end
    
--    local orderinfo =  FootballModel.GetUserSortOrderInfoByCondition(cgmsg.userid,0,cgmsg.orderid)
--    --luaDump(orderinfo)
--    gcmsg:ParseFromString(orderinfo)
    
    local orderinfo = FootballService.GetOrderinfoDetailFromDb(cgmsg.orderid)
    if orderinfo ~= nil then
       gcmsg = orderinfo
    end

    gcmsg.result = 0
	return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
end