module("FootballOrderList",package.seeall)
--订单列表
function execute(packetID, operateID, buffer)
	--[[
    --print("FootballOrderList")
    local cgmsg = msg_footballgame_pb.cgfootballorderlist()
	local gcmsg = msg_footballgame_pb.gcfootballorderlist()
	cgmsg:ParseFromString(buffer)
   
    local pInfo = PlayerModel.GetPlayerInfo(cgmsg.userid)
    
    if pInfo == nil then
        gcmsg.result = ReturnCode["player_not_exist"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
    end

    local currpour	    = 0 --当前竞猜 只统计未结算赛事的投注流水
    local expectedwin   = 0 --预期收益 只计算未结算赛事的预期收益
    local attcount	    = 0 --竞猜量   只统计已结算赛事的投注流水
    local totalwin	    = 0 --总盈亏   只统计已结算赛事的投注流水和实际收益
    local totalyiel	    = 0 --总收益   只统计已结算赛事的实际收益

    --订单状态 0:未返利(新订单) 1：结算后亏损 2：结算后获利 3：返还本金（玩家撤单） 4：返还本金（赛事取消）
    --local orderInfoList = FootballModel.GetUserSortOrderInfoByCondition(cgmsg.userid,cgmsg.reqtype,nil,cgmsg.starttime,cgmsg.endtime,cgmsg.pagenum)
    --订单的类型 0：全部订单 1:亏损 2:获利 3:未结算 4:返还本金 5：已结算（包含1:亏损 2:获利 4:返还本金）
    local orderInfoList = FootballModel.GetUserAllSortOrderInfo(cgmsg.userid,cgmsg.reqtype,cgmsg.starttime,cgmsg.endtime,cgmsg.pagenum)    
    
    table.sort(orderInfoList,function (a,b)
       return a.ordertime > b.ordertime
    end)
    
    for k,v in pairs(orderInfoList) do
        local addp = gcmsg.orderbasic:add() 
        local totalpourlist = {0,0,0}
        local pourlist = {0,0,0}
        local ratelist = {0,0,0}    
        if v.isBet == 1 then

            for s =1,3  do
                pourlist[s] = FootballModel.GetUserPourJetton(v.eventid, s, pInfo.userid)
                totalpourlist[s] = FootballModel.GetPourJetton(v.eventid, s)
                v.wltotalpourlist[s] = (tostring(totalpourlist[s]))  
                addp.wlpourlist:append(tostring(pourlist[s]))
                addp.wltotalpourlist:append(tostring(totalpourlist[s]))

            end
            ratelist = FootballUtils.cluWLrate(totalpourlist)
                
            for s =1,3 do
                v.wlrate[s] = tostring(ratelist[s])
                addp.wlrate:append(tostring(ratelist[s]))
            end
        end
        
        local raceinfo = RaceInfoModel.GetRaceInfo(v.eventid)
        local event = st_footballgame_pb.MerchantRaceInfoDto()
        if raceinfo ~= nil then
            event:ParseFromString(raceinfo)
        end
        
         
        if v.orderstate == 0 then
            --未结算的订单
            --获取最新的单个下注区域的信息 拿收益 更新收益和预期win 
            if v.isBet == 1 then
                --输赢订单
               
                local win = FootballUtils.cluWLWin(totalpourlist,pourlist,ratelist,v.fee)
                v.win	= tostring(win)	
            else
                --比分订单
                local SimpleRebateInfoPB = RaceInfoModel.GetRaceRebateInfo(v.eventid, v.rebateId)
                if SimpleRebateInfoPB ~= nil then
                    local SimpleRebateInfo = st_footballgame_pb.SimpleRebateInfo()
                    SimpleRebateInfo:ParseFromString(SimpleRebateInfoPB)
                   -- print("v.orderyiel.yiel: "..v.orderyiel.yiel.." v.win: "..v.win.." v.orderid: "..v.orderid.." v.eventid: "..v.eventid.." v.rebateId: "..v.rebateId)

                    local yiel = string.format("%.4f", tonumber(SimpleRebateInfo.rebateRatio))
         
                    local fee = v.fee 
                    local pourjetton = tonumber(v.pourjetton) or  0

                    local win = tonumber(pourjetton) * (tonumber(yiel)) * (1 - tonumber(fee)) +  tonumber(pourjetton)
                    win = tostring(math.floor(win))
                    v.orderyiel.yiel = yiel
                    v.win = win
                    --print("-----------------------------------------")
                    --print("v.orderyiel.yiel: "..v.orderyiel.yiel.." v.win: "..v.win.." v.orderid: "..v.orderid.." v.eventid: "..v.eventid.." v.rebateId: "..v.rebateId)
                end

            end
            --print("v",v)
            FootballModel.SetOrderInfo(v.orderid,v:SerializeToString())
        end
        local pourjetton = tonumber(v.pourjetton) or 0
        addp.isBet 				 = v.isBet
        addp.orderid		     = v.orderid
        addp.eventtype		     = v.eventtype
        addp.orderyiel.yieltype  = v.orderyiel.yieltype
        addp.orderyiel.subtype   = v.orderyiel.subtype
        addp.orderyiel.typescore = v.orderyiel.typescore
        addp.orderyiel.yiel      = v.orderyiel.yiel
        addp.orderyiel.baoval    = v.orderyiel.baoval
        addp.orderyiel.tiyan    = v.orderyiel.tiyan
        addp.starttime		    = v.starttime
        addp.endtime		    = v.endtime
        addp.win			    = v.win

        if event.winResult ~= "" and event.winResult ~= "0" then
		    local result_score = FootballUtils.score_split(event.winResult, "-")
		     addp.homescore		    = tonumber(result_score[1])
		     addp.awayscore		    = tonumber(result_score[2])
	    end

--        if v.orderstate == 2 or v.orderstate == 1 then
--            addp.homescore		    = v.homescore
--            addp.awayscore		    = v.awayscore
--        end
        addp.orderstate	        = v.orderstate
        addp.hometeam		    = v.hometeam
        addp.awayteam		    = v.awayteam
        addp.pourjetton		    = tostring(pourjetton)
        addp.ordertime		    = v.ordertime
        addp.expert		        = v.expert
        addp.schemeid	        = v.schemeid
        addp.expertid	        = v.expertid
        addp.homelogo			= v.homelogo
	    addp.awaylogo			= v.homelogo
        if v.isBet == 0 then
            local sqlCase = "select sum(pourjetton) from dy_footballorder where raceid = '"..v.eventid.."' and subtype="..v.orderyiel.subtype.. " and yieltype="..v.orderyiel.typescore.." and orderstate ~= 3 "
            mysqlItem:executeQuery(sqlCase)
            addp.orderyiel.totaljetton  = "0"
		    local sqlData = mysqlItem:fetch()

		    if sqlData ~= nil then
                addp.orderyiel.totaljetton  = sqlData
		    end

        end
        
        if v.orderstate == 0 then
            currpour = currpour + pourjetton
            expectedwin = expectedwin + tonumber(v.win) - pourjetton
        end

        if v.orderstate == 2   then
            --2：结算后获利
            attcount = attcount + pourjetton
            totalwin = totalwin + tonumber(v.win)
            totalyiel = totalyiel + tonumber(v.win) - pourjetton
        elseif v.orderstate == 1 then
            --1：结算后亏损
            attcount = attcount + pourjetton
            totalwin = totalwin + tonumber(v.win)
            totalyiel = totalyiel + tonumber(v.win)
        end

    end
    gcmsg.reqtype = cgmsg.reqtype
    gcmsg.pagenum  = cgmsg.pagenum
    gcmsg.currpour	  = tostring(currpour)	 
    gcmsg.expectedwin = tostring(expectedwin)
    gcmsg.attcount	  = tostring(attcount)	 
    gcmsg.totalwin	  = tostring(totalwin)	 
    gcmsg.totalyiel	  = tostring(totalyiel)	 
    gcmsg.result = 0
	return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
    ]]
    local cgmsg = msg_footballgame_pb.cgfootballorderlist()
	local gcmsg = msg_footballgame_pb.gcfootballorderlist()
	cgmsg:ParseFromString(buffer)
   
    local pInfo = PlayerModel.GetPlayerInfo(cgmsg.userid)
    
    if pInfo == nil then
        gcmsg.result = ReturnCode["player_not_exist"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
    end

    local currpour	    = 0 --当前竞猜 只统计未结算赛事的投注流水
    local expectedwin   = 0 --预期收益 只计算未结算赛事的预期收益
    local attcount	    = 0 --竞猜量   只统计已结算赛事的投注流水
    local totalwin	    = 0 --总盈亏   只统计已结算赛事的投注流水和实际收益
    local totalyiel	    = 0 --总收益   只统计已结算赛事的实际收益
    local orderstate_str  = "orderstate = 0"
    if cgmsg.reqtype == 3 then
        --未结算
        orderstate_str  = "orderstate = 0"
    elseif cgmsg.reqtype == 5 then
        orderstate_str = "( orderstate = -1 or orderstate > 0 ) "   
    end

    local starttime = cgmsg.starttime == nil and TimeUtils.GetTimeString(0) or  TimeUtils.GetTimeString(cgmsg.starttime) 
    local endtime = (tonumber(cgmsg.endtime) == 0 or cgmsg.endtime == nil) and TimeUtils.GetTimeString() or TimeUtils.GetTimeString(cgmsg.endtime)


    local sqlCase = "select *  from dy_footballorder where userid = "..cgmsg.userid.." and " ..orderstate_str.." and ordertime >= '"..starttime.."' and ordertime <= '"..endtime.."'"..
    " order by orderid desc limit "..10*(cgmsg.pagenum)..", 10"
    mysqlItem:executeQuery(sqlCase)
    ---print(sqlCase)
    local orderInfoList = {}
    local index = 1
    while true do
        local sqlData = mysqlItem:fetch({})
        if sqlData == nil then
            break
        end

        local	orderid     =	    sqlData[1]
        local	userid	    =	    tonumber(sqlData[2])
        local	eventtype	=	    sqlData[3]
        local	subtype	    =	    tonumber(sqlData[4]) or 0
        local	yieltype	=	    tonumber(sqlData[5]) or 0
        local	typescore	=	    sqlData[6] or ""
        local	yiel	    =	    sqlData[7] or ""
        local	baoval	    =	    tonumber(sqlData[8]) or 0
        local	tiyan	    =	    tonumber(sqlData[9]) or 0
        local	starttime	=	    TimeUtils.GetTime(sqlData[10])
        local	endtime	    =	    sqlData[11] ~=nil and  TimeUtils.GetTime(sqlData[11]) or 0
        local	ordertime	=	    TimeUtils.GetTime(sqlData[12])
        local	orderstate	=	    tonumber(sqlData[13])
        local	fee	        =	    tonumber(sqlData[14]) or 0
        local	win	        =	    sqlData[15]
        local	hometeam	=	    sqlData[16]
        local	awayteam	=	    sqlData[17]
        local	homescore	=	    tonumber(sqlData[18]) or 0
        local	awayscore	=	    tonumber(sqlData[19]) or 0
        --local	eventid	    =	    sqlData[20]
        local	rebateId	=	    sqlData[21]
        local	pourjetton	=	    sqlData[22]
        local	channel	    =	    sqlData[23]
        local	repeatCount	=	    sqlData[24]
        local	pumpMoney	=	    sqlData[25]
        local	isBet	    =	    tonumber(sqlData[26])
        --local	wlpourtype	=	    sqlData[27]
        local	raceid	    =	    sqlData[28]
        local	wlpourlist1	=	    sqlData[29]
        local	wlpourlist2	=	    sqlData[30]
        local	wlpourlist3	=	    sqlData[31]
        local	prechannel	=	    sqlData[32]
        local	ordertype	=	    sqlData[33]
        local	schemeid	=	    tonumber(sqlData[34]) or 0
        local	expertid	=	    tonumber(sqlData[35]) or 0
        local	expert	    =	    sqlData[36] or ""
        local	baobenmoney	=	    sqlData[37]
        local	homelogo	=	    (sqlData[38] == "" or sqlData[38] == nil)  and g_footballgameDefine.homeTeamFace  or sqlData[38]
        local	awaylogo	=	    (sqlData[39] == "" or sqlData[39] == nil ) and g_footballgameDefine.visitTeamFace  or sqlData[39]
        --print(orderid,eventtype,homelogo,awaylogo,sqlData[38])
        --获取赛事信息
        local raceinfo_pb = RaceInfoModel.GetRaceInfo(raceid)
        local raceinfo = st_footballgame_pb.MerchantRaceInfoDto()
        if raceinfo_pb ~= nil then
            raceinfo:ParseFromString(raceinfo_pb)
        end
        local addp = gcmsg.orderbasic:add()
        if isBet == 1 then
            --猜胜负
            local totalpourlist = {0,0,0}
            local pourlist      = {0,0,0}
            local ratelist      = {0,0,0} 
            --个下注总额
            pourlist[1]	=	tonumber(sqlData[29])
            pourlist[2]	=	tonumber(sqlData[30])
            pourlist[3]	=	tonumber(sqlData[31])

            for s =1,3  do
                --下注区域总额
                totalpourlist[s] = FootballModel.GetPourJetton(raceid, s)
                addp.wlpourlist:append(tostring(pourlist[s]))
                addp.wltotalpourlist:append(tostring(totalpourlist[s]))
            end
            ratelist = FootballUtils.cluWLrate(totalpourlist)
                
            for s =1,3 do
                addp.wlrate:append(tostring(ratelist[s]))
            end
            if orderstate == 0  then
                --未结算
                win = FootballUtils.cluWLWin(totalpourlist,pourlist,ratelist,fee)
                --print(win,fee)
            end
        else
            --猜比分

            if orderstate == 0 then
                --未结算
                --获取返利信息
                local SimpleRebateInfoPB = RaceInfoModel.GetRaceRebateInfo(raceid, rebateId)
                if SimpleRebateInfoPB ~= nil then
                    local SimpleRebateInfo = st_footballgame_pb.SimpleRebateInfo()
                    SimpleRebateInfo:ParseFromString(SimpleRebateInfoPB)
                    yiel = string.format("%.4f", tonumber(SimpleRebateInfo.rebateRatio))
                    win = tonumber(pourjetton) * (tonumber(yiel)) * (1 - tonumber(fee)) +  tonumber(pourjetton)
                    win = tostring(math.floor(win))

                end

            end

        end
        
        addp.isBet 				 =      isBet
        addp.orderid		     =      orderid
        addp.eventtype		     =      eventtype
        addp.orderyiel.yieltype  =      yieltype
        addp.orderyiel.subtype   =      subtype
        addp.orderyiel.typescore =      typescore 
        addp.orderyiel.yiel      =      yiel 
        addp.orderyiel.baoval    =      baoval
        addp.orderyiel.tiyan     =      tiyan
        addp.starttime		     =      starttime
        addp.endtime		     =      endtime
        if orderstate == -1 or orderstate == 3 or orderstate == 4 then
            addp.win	=   tostring(win)
        else
            addp.win	=   tostring(win)
        end
        
        --print(raceinfo.homeTeam,raceinfo.winResult)
        if orderstate == 0 or orderstate == 3  then
            if raceinfo.winResult ~= "" and raceinfo.winResult ~= "0" then
		        local result_score = FootballUtils.score_split(raceinfo.winResult, "-")
		        addp.homescore		    = tonumber(result_score[1])
		        addp.awayscore		    = tonumber(result_score[2])
	        end  
        else
            addp.homescore  = 	homescore	
            addp.awayscore	=   awayscore
                    
        end
        --if orderstate == 0 then
            addp.racestatus	= raceinfo.raceStatus
        --end
        addp.orderstate	        = orderstate
        addp.hometeam		    = hometeam
        addp.awayteam		    = awayteam
        addp.pourjetton		    = tostring(pourjetton)
        addp.ordertime		    = ordertime
        addp.expert		        = expert
        addp.schemeid	        = schemeid
        addp.expertid	        = expertid
        addp.homelogo			= homelogo
	    addp.awaylogo			= awaylogo
        addp.orderyiel.totaljetton  = "0"
        --后面补充各个区域的下注总额
        local temp = {raceid=raceid,rebateId=rebateId,orderstate=orderstate,isBet=isBet,index=index}
        table.insert(orderInfoList,temp)
        index = index + 1
        --print(addp.orderid,addp)
        --FootballModel.SetRaceOfOrderInfo(raceid,orderinfo)
    end

	gcmsg.reqtype = cgmsg.reqtype
    gcmsg.pagenum  = cgmsg.pagenum
    for k,v in pairs(orderInfoList) do
        if v["isBet"] == 0 then
            local sqlCase = "select sum(pourjetton) from dy_footballorder where raceid = '"..v["raceid"].."' and rebateId='"..v["rebateId"].."' and orderstate != 3 "
            mysqlItem:executeQuery(sqlCase)
		    local sqlData = mysqlItem:fetch()
            --print(sqlCase)
            if sqlData ~= nil then
               --- print(sqlData)
                gcmsg.orderbasic[v["index"]].orderyiel.totaljetton = sqlData
            end
        end


    end
    



--    gcmsg.currpour	  = tostring(currpour)	 
--    gcmsg.expectedwin = tostring(expectedwin)
--    gcmsg.attcount	  = tostring(attcount)	 
--    gcmsg.totalwin	  = tostring(totalwin)	 
--    gcmsg.totalyiel	  = tostring(totalyiel)	 
    gcmsg.result = 0
    --print(gcmsg)
	return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()

end