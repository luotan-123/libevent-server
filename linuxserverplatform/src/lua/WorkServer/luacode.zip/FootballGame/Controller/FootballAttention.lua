module("FootballAttention",package.seeall)
--关注赛事
function execute(packetID, operateID, buffer)
    local cgmsg = msg_footballgame_pb.cgfootballpayattentionevent()
	local gcmsg = msg_footballgame_pb.gcfootballpayattentionevent()
	
	cgmsg:ParseFromString(buffer)

    local pInfo = PlayerModel.GetPlayerInfo(cgmsg.userid)
    if pInfo == nil then
        gcmsg.result = ReturnCode["player_not_exist"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
    end

    --获取赛事信息
    local raceinfopb = RaceInfoModel.GetRaceInfo(cgmsg.eventid)
    
	if raceinfopb == nil then
		gcmsg.result = ReturnCode["event_not_exit"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
	end
    if cgmsg.attention == 0 then
        FootballModel.DelUserPayAttentionRace(cgmsg.eventid,cgmsg.userid)
    else
        FootballModel.SetUserPayAttentionRace(cgmsg.eventid,cgmsg.userid)
    end
    gcmsg.result = 0
    gcmsg.eventid = cgmsg.eventid
    gcmsg.attention = cgmsg.attention

	return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
end