module("NoticeCancelOrder",package.seeall)
--消息
function execute(packetID, operateID, buffer)
	--print("NoticeCancelOrder")
    local cgmsg = msg_footballgame_pb.cgfootballnoticecancelorder()
	local gcmsg = msg_footballgame_pb.gcfootballnoticecancelorder()
	
	cgmsg:ParseFromString(buffer)
    local nowtime = TimeUtils.GetTime()
    local pInfo = PlayerModel.GetPlayerInfo(cgmsg.userid)
    if pInfo == nil then
        gcmsg.result = ReturnCode["player_not_exist"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
    end

    local enttime = TimeUtils.GetTimeString(nowtime - 87 * 60)
    local sqlCase = "select * from dy_footballorder where userid = '"..cgmsg.userid.."' and orderstate = 0  and schemeid = 0 and isBet = 0 and ordertype  = 0 and tiyan = 0 and  starttime < '"..enttime.."'"
    mysqlItem:executeQuery(sqlCase)
    
    while true do
        local sqlData = mysqlItem:fetch({})
        if sqlData == nil then
           break
        end
        orderinfo = msg_footballgame_pb.gcfootballorderdetail()
        orderinfo.orderid                   =	    sqlData[1]
        orderinfo.userid	                =	    tonumber(sqlData[2])
        orderinfo.eventtype	                =	    sqlData[3]
        orderinfo.orderyiel.subtype	        =	    tonumber(sqlData[4]) or 0
        orderinfo.orderyiel.yieltype	    =	    tonumber(sqlData[5]) or 0
        orderinfo.orderyiel.typescore	    =	    sqlData[6]
        local yiel	                        =	    sqlData[7] --需要从下注信息中获取 实时的
        orderinfo.orderyiel.baoval	        =	    tonumber(sqlData[8]) or 0
        orderinfo.orderyiel.tiyan	        =	    tonumber(sqlData[9]) or 0
        orderinfo.starttime	                =	    TimeUtils.GetTime(sqlData[10])
        orderinfo.endtime	                =	    sqlData[11] ~=nil and  TimeUtils.GetTime(sqlData[11]) or 0
        orderinfo.ordertime	                =	    TimeUtils.GetTime(sqlData[12])
        orderinfo.orderstate	            =	    tonumber(sqlData[13])
        orderinfo.fee	                    =	    sqlData[14] or "0"
        local	win	                        =	    sqlData[15]
        orderinfo.hometeam	                =	    sqlData[16]
        orderinfo.awayteam	                =	    sqlData[17]
        orderinfo.homescore	                =	    tonumber(sqlData[18]) or 0
        orderinfo.awayscore	                =	    tonumber(sqlData[19]) or 0
        orderinfo.eventid	                =	    sqlData[20]
        orderinfo.rebateId	                =	    sqlData[21]
        orderinfo.pourjetton	            =	    sqlData[22] or "0"
        orderinfo.repeatCount	            =	    tonumber(sqlData[24]) or 0 --重复计算次数
        orderinfo.pumpMoney	                =	    tonumber(sqlData[25]) or 0 --订单抽水值
        orderinfo.isBet	                    =	    tonumber(sqlData[26])

        orderinfo.schemeid	                =	    tonumber(sqlData[34]) or 0 --方案id
        orderinfo.expertid	                =	    tonumber(sqlData[35]) or 0 --专家id
        orderinfo.expert	                =	    sqlData[36] or ""
        local	baobenmoney	                =	    sqlData[37]
        orderinfo.homelogo	                =	    (sqlData[38] == "" or sqlData[38] == nil)  and  g_footballgameDefine.homeTeamFace  or  sqlData[38]
        orderinfo.awaylogo	                =	    (sqlData[39] == "" or sqlData[39] == nil )   and  g_footballgameDefine.visitTeamFace  or sqlData[39]
        orderinfo.cancletime                =       (tonumber(sqlData[40]) or 0) > 0 and  tonumber(sqlData[40]) or 0
        orderinfo.planraceid		= tonumber(sqlData[41]) or 0
	    orderinfo.isinsertorder		= tonumber(sqlData[42]) or 0
	    orderinfo.cardid			=  sqlData[43] or ""
        if  orderinfo.cardid ~= "" then
            local propInfo =  PropService.getPropInfo(orderinfo.userid, orderinfo.cardid)
            if propInfo ~= nil then
                orderinfo.proptype	= propInfo.proptype
	            orderinfo.propname	= propInfo.propname
	            orderinfo.propvalue	= propInfo.propvalue
	            orderinfo.condition	= propInfo.condition
            end

        end
        
        
        --获取赛事信息
        local raceinfo_pb = RaceInfoModel.GetRaceInfo(orderinfo.eventid)
        local raceinfo = st_footballgame_pb.MerchantRaceInfoDto()
        if raceinfo_pb ~= nil then
            raceinfo:ParseFromString(raceinfo_pb)
        end
        --订单状态 0:未返利(新订单) 1：结算后亏损 2：结算后获利 3：返还本金（玩家撤单） 4：返还本金（赛事取消）5：异常订单
        if orderinfo.orderstate == 0   then
            if raceinfo.winResult ~= "" and raceinfo.winResult ~= "0" then
		        local result_score = FootballUtils.score_split(raceinfo.winResult, "-")
		        orderinfo.homescore		    = tonumber(result_score[1]) 
		        orderinfo.awayscore		    = tonumber(result_score[2])
	        end     
        end
        --猜比分
        if  orderinfo.orderstate == 0 then
            --未结算
            --获取返利信息
            local SimpleRebateInfoPB = RaceInfoModel.GetRaceRebateInfo(orderinfo.eventid, orderinfo.rebateId)
            if SimpleRebateInfoPB ~= nil then
                local SimpleRebateInfo = st_footballgame_pb.SimpleRebateInfo()
                SimpleRebateInfo:ParseFromString(SimpleRebateInfoPB)
                yiel = string.format("%.4f", tonumber(SimpleRebateInfo.rebateRatio))
                win = tonumber(orderinfo.pourjetton) * (tonumber(yiel)) * (1 - tonumber(orderinfo.fee)) +  tonumber(orderinfo.pourjetton)
                win = tostring(math.floor(win))
            end
        end
	    orderinfo.win			      = win
        orderinfo.orderyiel.yiel      = yiel 

        local scoreresult = "0 - 0"
        local timeSuit = fasle
        if orderinfo.orderyiel.yieltype == 0  then
            --全场订单
            scoreresult = raceinfo.winResult
            --raceinfo.raceStatus //赛事状态(0:取消(取消的赛事进行撤注操作) 1:正常进行中 2:已经结束(定时任务爬取赛事结果)3:未开始 4:赛事改期5赛事异常 6手动取消 7系统撤单 )
            --againSettle //全场结算状态(0未结算，1手动结算，2自动结算，3重新结算，4已取消，5赛事回滚) 
            if nowtime - orderinfo.starttime < 87 * 60 and  raceinfo.raceStatus == 1  and   raceinfo.againSettle  == 0  and 
                ((scoreresult == "0 - 0" and nowtime - orderinfo.starttime > 45 * 60) or (scoreresult ~= "0 - 0"))
            then
                timeSuit = true
            end
        else
            --半场订单
            scoreresult = raceinfo.halfResult
            if nowtime - orderinfo.starttime < 42 * 60 and  raceinfo.raceStatus == 1 and   raceinfo.halfSettle  == 0 then
                timeSuit = true
            end
        end
        if scoreresult ==  orderinfo.orderyiel.typescore and  timeSuit then
            local chedanfee = 0
            local remaintimes = 0
            local nextcancelfee = 0
            if nowtime - orderinfo.starttime >= 0 then
                --比赛已经开始，开始收手续费
                if nowtime - orderinfo.starttime < 60 then
                    --开赛0-1分钟 收起 5%
                    chedanfee   = 0.05
                    remaintimes = 60 - (nowtime - orderinfo.starttime)
                    nextcancelfee = 0.07
                else
                    --超过1 min 叠加 2%
                    local temp = math.floor((nowtime - orderinfo.starttime)/60)
                    local mod  = math.fmod(nowtime - orderinfo.starttime,60)
                    if math.fmod(temp,2) == 1 then
	                    chedanfee = (math.floor(temp/2)) * 0.02 + 0.05
                        remaintimes = 120 - mod
                        nextcancelfee = chedanfee + 0.02
                    else
	                    chedanfee = (math.floor((temp/2)) - 1) * 0.02 + 0.05
                        remaintimes =  60 - mod
                        nextcancelfee = chedanfee + 0.02
                    end
                end
            else
            end
            local reback = tonumber(orderinfo.pourjetton) * (1 - chedanfee)
            chedanfee = chedanfee * 100
            nextcancelfee = nextcancelfee * 100      
            local result_score = FootballUtils.score_split(scoreresult, "-")

            local addH =  gcmsg.noticeinfo:add()
            addH.orderid        = orderinfo.orderid
            addH.userid		    = cgmsg.userid              --userid
            addH.hometeam		= orderinfo.hometeam                --主场team
            addH.awayteam		= orderinfo.awayteam                --客场场team
            addH.homescore		= tonumber(result_score[1]) --主场team得分
            addH.awayscore		= tonumber(result_score[2]) --客场team得分
            addH.typescore		= orderinfo.orderyiel.typescore  
            addH.pourjetton	    = orderinfo.pourjetton              --下注金额
            addH.remaintimes    = remaintimes               --剩余时间
            addH.cancelfee		= chedanfee                 --撤单手续费率 15 -> 15%
            addH.rejetton		= tostring(reback)          --可拿回金币
            addH.starttime      = orderinfo.starttime
            addH.win            = orderinfo.win
            addH.nextcancelfee  = nextcancelfee
            addH.yieltype       = orderinfo.orderyiel.yieltype
        end



    end
    --print(sqlCase)


    --[[
    --查询玩家未返利订单 
    local orderInfoList = FootballModel.GetUserSortOrderInfoByCondition(cgmsg.userid,3)
     for k,v in pairs(orderInfoList) do
        if v.orderstate == 0 then
            local raceinfopb = RaceInfoModel.GetRaceInfo(v.eventid)
            if raceinfopb ~= nil then
		        local raceinfo = st_footballgame_pb.MerchantRaceInfoDto()
	            raceinfo:ParseFromString(raceinfopb)
                local scoreresult = "0 - 0"
                local timeSuit = fasle
                if v.orderyiel.yieltype == 0  then
                    --全场订单
                    scoreresult = raceinfo.winResult
                    if nowtime - v.starttime < 87 * 60 and  raceinfo.raceStatus == 1 and   raceinfo.againSettle  == 0 then
                       timeSuit = true
                    end
                else
                    --半场订单
                     scoreresult = raceinfo.halfResult
                    if nowtime - v.starttime < 42 * 60 and  raceinfo.raceStatus == 1 and   raceinfo.halfSettle  == 0 then
                       timeSuit = true
                    end
                end
                
             
                if scoreresult ==  v.orderyiel.typescore and  timeSuit then
                    local chedanfee = 0
                    local remaintimes = 0
                    if nowtime - v.starttime >= 0 then
                        --比赛已经开始，开始收手续费
                        if nowtime - v.starttime < 60 then
                            --开赛0-1分钟 收起 5%
                            chedanfee   = 0.05
                            remaintimes = 60 - (nowtime - v.starttime)
                        else
                            --超过1 min 叠加 2%
                            local temp = math.floor((nowtime - v.starttime)/60)
                            local mod  = math.fmod(nowtime - v.starttime,60)
                            if math.fmod(temp,2) == 1 then
	                            chedanfee = (math.floor(temp/2)) * 0.02 + 0.05
                                remaintimes = 120 - mod
                            else
	                            chedanfee = (math.floor((temp/2)) - 1) * 0.02 + 0.05
                                remaintimes =  60 - mod
                            end
                        end
                    else
                    end
                    local reback = tonumber(v.pourjetton) * (1 - chedanfee)
                    chedanfee = chedanfee * 100
                    
                    local result_score = FootballUtils.score_split(scoreresult, "-")

                    local addH =  gcmsg.noticeinfo:add()
                    addH.orderid        = v.orderid
                    addH.userid		    = cgmsg.userid              --userid
                    addH.hometeam		= v.hometeam                --主场team
                    addH.awayteam		= v.awayteam                --客场场team
                    addH.homescore		= tonumber(result_score[1]) --主场team得分
                    addH.awayscore		= tonumber(result_score[2]) --客场team得分
                    addH.typescore		= v.orderyiel.typescore  
                    addH.pourjetton	    = v.pourjetton              --下注金额
                    addH.remaintimes    = remaintimes               --剩余时间
                    addH.cancelfee		= chedanfee                 --撤单手续费率 15 -> 15%
                    addH.rejetton		= tostring(reback)          --可拿回金币

                end
	        end
        end
    end
    ]]
    gcmsg.result = 0
	return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
end