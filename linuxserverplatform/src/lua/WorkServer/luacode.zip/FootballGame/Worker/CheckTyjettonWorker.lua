module("CheckTyjettonWorker", package.seeall)

--[[
    定时任务 
    --体验金盈利部分转换到金币账户

]]
function work(buffer)
    --print("CheckTyjettonWorker")
    local userlist = PlayerModel.GetAllUserIdList()
    --字典  流水限制 充值限制 体验金券清除时间 体验金全部清除时间
    local dict = {ty_money_limit=800000, ty_recharge_limit=50000, tyj_expire=3, ty_effective_time= 7}
    for k,v in pairs(userlist) do
        --遍历所有玩家
        if v ~= nil then
            local pInfo =  PlayerModel.GetPlayerInfo(v)
            if pInfo ~= nil then
                local prechannel = GameUtils.GetChannel_login(pInfo.channel)
                local sqlCase = "select dict_category,dict_value from web_dict where dict_group  = 'tyj'  and  prechannel = '" ..prechannel.."' and enable_status = ".. 1 ..""
                mysqlItem:execute(sqlCase)
                while true do
                    local sqlData = mysqlItem:fetch({})
                    if sqlData == nil then
                        break
                    end
                    dict[sqlData[1]] = tonumber(sqlData[2])
                end
                local nowstamp      = TimeUtils.GetTime()
                local state         = PlayerModel.GetUserUseTycardState(pInfo.userid)           --使用体验券状态 0 未使用过 1 已使用 2 已清除
                local stamp         = PlayerModel.GetUserUseTycardStamp(pInfo.userid)           --体验金券使用时间戳
                local tyjetton      = PlayerModel.GetUserUseTycardJetton(pInfo.userid)          --使用体验金额额度
                local tywinjetton   = tonumber(RaceInfoModel.GetTyWinMoney(pInfo.userid)) or 0  --体验金盈利部分

                if tywinjetton > 0 then
                    --有盈利部分 判断是否满足转化为正常金币
                    --查询玩家流水和单笔充值最高记录
                    local sqlCase = "select achamount,maxpaynum from log_player where userid = "..pInfo.userid.." and channel = '"..pInfo.channel.."'"
                    local achamount = 0  --玩家流水
                    local maxpaynum = 0  --玩家单笔充值最高记录
                    mysqlLog:executeQuery(sqlCase)
                    local sqlData4 = mysqlLog:fetch({})

                    if sqlData4 ~= nil then
                        achamount = tonumber(sqlData4[1])
                        maxpaynum = tonumber(sqlData4[2]) 
                    end

                    local  jetton = tonumber(pInfo.tyjetton) >= tywinjetton and tywinjetton or  tonumber(pInfo.tyjetton)
                    --print("pInfo.userid: "..pInfo.userid.." jetton: "..jetton.." achamount :"..achamount.."dict.ty_money_limit: "..dict.ty_money_limit.." maxpaynum: "..maxpaynum.." dict.ty_recharge_limit: "..dict.ty_recharge_limit)
                    if achamount >= dict.ty_money_limit  and  maxpaynum >= dict.ty_recharge_limit then
                        --满足转化为正常金币    
                        RaceInfoModel.DelTyWinMoney(pInfo.userid)

                        local sqlCase ="update dy_tyrewardmgr set wintyjetton = 0 where userid = "..pInfo.userid
                        mysqlItem:execute(sqlCase)

                        PlayerModel.AddTyJetton(pInfo, 0-jetton)
         
			            PlayerModel.AddJetton(pInfo, jetton, "football", "win")
			            PlayerModel.SetPlayerInfo(pInfo)
			            PlayerModel.SendJetton(pInfo)   --同步分数先 

                        local orderid = LogServer.GetNewLogOrderid()
                        local remark =  "体验金盈利部分提现" 
                        LogServer.addRecords(pInfo.userid,1,remark,tonumber(jetton),orderid)
                        local msg = "玩家"..pInfo.userid.." 体验金盈利部分提现到金币账户: "..(tonumber(jetton)* 0.01).."元，体验金剩余: "..(tonumber(pInfo.tyjetton) * 0.01).."元"
                        LogServer.GameUserMoney(pInfo, g_footballgameDefine.game_type, 1, tonumber(jetton), msg, 0,0,g_moneyOptType.opt_tytojetton,orderid,false,2)


                        local logupdatesql = "insert into log_tymgrrecord (userid,nickname,phone,wintyjetton,tyjetton,jetton,arch,sendrewardstate,logtype,channel,prechannel)values("..
                        pInfo.userid..",'"..pInfo.nickname.."',"..pInfo.phonenum..","..jetton..","..tonumber(pInfo.tyjetton)..","..tonumber(pInfo.jetton)..","..
                        achamount..",".. 1 ..","..1 ..",'"..pInfo.channel.."','"..prechannel.."')"
                        mysqlLog:execute(logupdatesql)

                        local dayStr = TimeUtils.GetDayString()
                        local weekStr = TimeUtils.GetWeekString()
                        local monthStr = TimeUtils.GetMonthString()
  
                        local sqlCase = "update log_player set tywinamount = tywinamount+"..jetton..",winamount = winamount+ "..jetton.." where userid="..pInfo.userid
                        LogModel.LogUserMoneyList(sqlCase)
  
                        sqlCase = "update log_playerdaily set tywinamount = tywinamount+"..jetton..",winamount = winamount+ "..jetton.." where userid="..pInfo.userid.." and dateid='"..dayStr.."'"
                        LogModel.LogUserMoneyList(sqlCase)
  
                        sqlCase = "update log_playerweek set tywinamount = tywinamount+"..jetton..",winamount = winamount+ "..jetton.." where userid="..pInfo.userid.." and dateid='"..weekStr.."'"
                        LogModel.LogUserMoneyList(sqlCase)
  
                        sqlCase = "update log_playermonth set tywinamount = tywinamount+"..jetton..",winamount = winamount+ "..jetton.." where userid="..pInfo.userid.." and dateid='"..monthStr.."'"
                        LogModel.LogUserMoneyList(sqlCase)


                        --print(logupdatesql)
                            
                    end
                end
            end
        end
    end

    --[[
    local userTimeList = FootballModel.GetAllUserBindPhoneTime()
    if userTimeList == nil then
        return
    end
    --luaDump(userTimeList)
    for k,v in pairs(userTimeList) do
        repeat
            local pInfo = PlayerModel.GetPlayerInfo(k)
            if pInfo ~= nil then
                local nowtime  = TimeUtils.GetTime()
                local achamount = 0  --玩家流水
                local maxpaynum = 0  --玩家单笔充值最高记录
                local prechannel = GameUtils.GetChannel_login(pInfo.channel)
                local sqlCase = "select promotiontype,wintyjetton,registertime from dy_tyrewardmgr  where userid = "..pInfo.userid
                mysqlItem:executeQuery(sqlCase)
                local sqlData0 = mysqlItem:fetch({})

                if sqlData0 == nil then
                    break
                end
                -- 转正类型 : 0 未转正  1 到期自动转正 2  手动转正
                local promotiontype = tonumber(sqlData0[1])
                local wintyjetton = tonumber(sqlData0[2])  -- 体验金盈利金额
                local registertime = TimeUtils.GetTime(sqlData0[3]) --注册时间


                if promotiontype == 0  then
                    local ispromotion = false 
                    local isreward = false
                    --未转正 查询是否需要转正
                    local sqlCase = "select dict_value from web_dict where dict_category = 'ty_effective_time'".." and channnel = '"..pInfo.channel.."'" 
                    mysqlItem:executeQuery(sqlCase)
                    local ty_effective_time = 7 --几天后转正 
                    local sqlData1 = mysqlItem:fetch()
                    if sqlData1 ~= nil then
                        ty_effective_time =  tonumber(sqlData1)
                    end
                    --判断转正
                    if nowtime - tonumber(v) >= ty_effective_time * 24 * 60 * 60  then
                        --满足转正
                        ispromotion  = true
                    end
                    --判断奖励发送 
                    --print("pInfo.tyjetton: "..pInfo.tyjetton.." wintyjetton: "..wintyjetton )
                    if wintyjetton > 0 and (tonumber(pInfo.tyjetton) or 0)> 0 then
                        --有体验金盈利金额 需要发放奖励
                        --判断是否满足发放条件
                        local sqlCase = "select dict_value from web_dict where dict_category = 'ty_money_limit'".." and channnel = '"..pInfo.channel.."'" 
                        mysqlItem:executeQuery(sqlCase)
                        local ty_money_limit = 800000 --流水限制 
                        local sqlData2 = mysqlItem:fetch()
                        if sqlData2 ~= nil then
                            ty_money_limit =  tonumber(sqlData2)
                        end

                        local sqlCase = "select dict_value from web_dict where dict_category = 'ty_money_limit'".." and channnel = '"..pInfo.channel.."'" 
                        mysqlItem:executeQuery(sqlCase)
                        local ty_recharge_limit = 50000 --单笔最高充值记录限制 
                        local sqlData3 = mysqlItem:fetch()
                        if sqlData3 ~= nil then
                            ty_recharge_limit =  tonumber(sqlData3)
                        end 

                        --查询玩家流水和单笔充值最高记录
                        local sqlCase = "select achamount,maxpaynum from log_player where userid = "..pInfo.userid.." and channel = '"..pInfo.channel.."'"

                        mysqlLog:executeQuery(sqlCase)
                        local sqlData4 = mysqlLog:fetch({})

                        if sqlData4 ~= nil then
                            achamount = tonumber(sqlData4[1])
                            maxpaynum = tonumber(sqlData4[2]) 
                        end
                        --print("achamount: "..achamount.." maxpaynum: "..maxpaynum .." ty_money_limit: "..ty_money_limit.." ty_recharge_limit:  "..ty_recharge_limit)
                        if achamount >= ty_money_limit  and  maxpaynum >= ty_recharge_limit then
                            --满足发放奖励
                            isreward = true
                        end
                    end
                    local updatesql = ""
                    --print(ispromotion)
                    if isreward then
                        local remaintyjetton = PlayerModel.AddTyJetton(pInfo, 0-wintyjetton)
                        if remaintyjetton < 0 then
                            PlayerModel.AddTyJetton(pInfo, wintyjetton)
                        else
                            --体验金
			                PlayerModel.AddJetton(pInfo, wintyjetton, "football", "win")
			                PlayerModel.SetPlayerInfo(pInfo)
			                PlayerModel.SendJetton(pInfo)   --同步分数先 
           
                            RaceInfoModel.DelTyWinMoney(pInfo.userid)

                            updatesql = "update dy_tyrewardmgr set wintyjetton = wintyjetton - "..wintyjetton

                            local remark =  "体验金盈利部分提现" 
                            LogServer.addRecords(pInfo.userid,1,remark,tonumber(wintyjetton))
                            local msg = "玩家"..pInfo.userid.." 体验金盈利部分提现到金币账户: "..(tonumber(wintyjetton)* 0.01).."元，体验金剩余: "..(remaintyjetton * 0.01).."元"
                            LogServer.GameUserMoney(pInfo, g_footballgameDefine.game_type, 1, tonumber(wintyjetton), msg, 0,0,g_moneyOptType.opt_tytojetton)
                        
                           
                            local logupdatesql = "insert into log_tymgrrecord (userid,nickname,phone,registertime,wintyjetton,tyjetton,jetton,arch,sendrewardstate,promotiontype,logtype,channel,prechannel)values("..
                            pInfo.userid..",'"..pInfo.nickname.."',"..pInfo.phonenum..",'"..TimeUtils.GetTimeString(registertime).."',"..wintyjetton..","..tonumber(pInfo.tyjetton)..","..tonumber(pInfo.jetton)..","..
                            achamount..",".. 1 ..","..promotiontype..","..1 ..",'"..pInfo.channel.."','"..prechannel.."')"
                            mysqlLog:execute(logupdatesql)
                        
                        
                        end

                    end

                    if ispromotion then
                            local promotiontime = TimeUtils.GetTimeString()
                            local logupdatesql = "insert into log_tymgrrecord (userid,nickname,phone,registertime,promotiontime,tyjetton,jetton,arch,promotiontype,logtype,channel,prechannel)values("..
                            pInfo.userid..",'"..pInfo.nickname.."',"..pInfo.phonenum..",'"..TimeUtils.GetTimeString(registertime).."','"..promotiontime.."',"..tonumber(pInfo.tyjetton)..","..tonumber(pInfo.jetton)..","..
                            achamount..",".. 1 ..",".. 0 ..",'"..pInfo.channel.."','"..prechannel.."')"
                            mysqlLog:execute(logupdatesql)

                        if updatesql == "" then
                            --只转正
                            updatesql = "update dy_tyrewardmgr set promotiontype = 1 where userid = "..pInfo.userid.." and channel = '"..pInfo.channel.."'"
                        else
                            --转正+奖励发放
                            updatesql = updatesql..", promotiontype = 1 where userid = "..pInfo.userid.." and channel = '"..pInfo.channel.."'"


                        end
                    end

                    if updatesql ~= "" then
                        mysqlItem:execute(updatesql)
                    end
                end
            end
        until true
    end

    ]]
end




