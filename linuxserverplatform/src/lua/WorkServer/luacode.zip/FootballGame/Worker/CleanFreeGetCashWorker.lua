module("CleanFreeGetCashWorker", package.seeall)

-- 每周日 23 59 58 清除玩家免费提现额度


function work(buffer)
    --[[
    --print("CleanFreeGetCashWorker")
	local useridlist = FootballModel.GetCashFreeAmountAllUser()
    --大于0 清空 小于 0 等待补满回来
    for k,v in ipairs(useridlist) do
        local amount = FootballModel.SetUserCashFreeAmount(v,0)
        --print(v,amount)
        if amount > 0 then
           FootballModel.SetUserCashFreeAmount(v,0-amount)
        end
    end
    ]]
    
	
	
end




