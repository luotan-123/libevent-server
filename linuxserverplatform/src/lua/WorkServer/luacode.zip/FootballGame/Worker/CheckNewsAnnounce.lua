module("CheckNewsAnnounce", package.seeall)

--[[
    定时任务 实时映射
   消息发布
]]
function work(buffer)
    --print("CheckNewsAnnounce")
 
    if FootballModel.GetUserNewsLock() == 0 then
        FootballModel.SetUserNewsLock()
        local sqlCase = "select * from log_announcement where sendstate = 0 " --未发布的
        mysqlLog:executeQuery(sqlCase)
        --print(sqlCase)
        
        local  newlist = {} --更新
        local  usernewlist = {}
        
        local nowtime = TimeUtils.GetTime()
        while true do
            local sqlData = mysqlLog:fetch({})
            if sqlData == nil then
                break
            end
            local id              = tonumber(sqlData[1])
            local title           = sqlData[2]
            local content         = sqlData[3]
            local sendtime        = sqlData[4]
            local sendid          = tonumber(sqlData[5])
            local receiveid       = sqlData[6]
            local sendstate       = tonumber(sqlData[7])
            local updatetime      = sqlData[8]
            local newtype         = tonumber(sqlData[9])--公共类型，1=通知，2=活动，3=公告，4=赛事
            local prechannel      = sqlData[11]

            
            --print(id,nowtime,TimeUtils.GetTime(sendtime),receiveid)
            if nowtime >= TimeUtils.GetTime(sendtime) then
            --print(receiveid)
                if receiveid == "0" then
                    --发给所有人 此处 映射在线玩家 剩余部分登录的时候映射
                    local onlineList = OnlineModel.GetAllOnline() --所有玩家
	                for k,v_userid in pairs( onlineList ) do
		                local pInfo = PlayerModel.GetPlayerInfo(v_userid)
	                    if pInfo ~= nil  then
                            local user_prechannel = GameUtils.GetChannel_login(pInfo.channel)
                            if FootballModel.GetUserNews(v_userid,id) == 0 and (prechannel == user_prechannel or prechannel == "all") then
--                                local sqlCase = "insert into log_userannouncement (userid ,newsid, newsstate,newstype) values ("..v_userid..","..id ..","..0 ..","..newtype..")"
--                                mysqlLog:execute(sqlCase)
--                                print(sqlCase)
                                FootballModel.SetUserNews(v_userid,id)
                                local temp = {userid= v_userid,id=id,newtype=newtype}
                                table.insert(usernewlist,temp)
                            end 

	                    end	
	                end	
                else
                    --发给指定玩家
                    local userlist = FootballUtils.score_split(receiveid, ",")
	                for k,v_userid in pairs( userlist ) do
                        v_userid = tonumber(v_userid) or 0
		                local pInfo = PlayerModel.GetPlayerInfo(v_userid)
	                    if pInfo ~= nil  then
                            local user_prechannel = GameUtils.GetChannel_login(pInfo.channel)
                            if FootballModel.GetUserNews(v_userid,id) == 0 and (prechannel == user_prechannel or prechannel == "all") then
--                                local sqlCase = "insert into log_userannouncement (userid ,newsid, newsstate,newstype) values ("..v_userid..","..id ..","..0 ..","..newtype..")"
--                                 print(sqlCase)
--                                mysqlLog:execute(sqlCase)
                                FootballModel.SetUserNews(v_userid,id)
                                local temp = {userid= v_userid,id=id,newtype=newtype}
                                table.insert(usernewlist,temp)
                            end 
	                    end	
	                end	
                end
                table.insert(newlist,id)

            end
        end

        --玩家映射
        for k,v in pairs(usernewlist) do
            local sqlCase = "insert into log_userannouncement (userid ,newsid, newsstate,newstype) values ("..v["userid"]..","..v["id"] ..","..0 ..","..v["newtype"]..")"
            --print(sqlCase)
            mysqlLog:execute(sqlCase) 

        end
        
        for k,v in pairs(newlist) do
            local sqlCase = "update log_announcement set sendstate = 1,updatetime = '"..TimeUtils.GetTimeString(nowtime).."' where id = "..v
            mysqlLog:execute(sqlCase)
            --print(k,sqlCase)
        end
       
        FootballModel.DelUserNewsLock()
    end
   
end




