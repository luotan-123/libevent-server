module("CheckWlChangeRatio", package.seeall)

--[[
    定时任务 
    输赢赛事收益增长变化
]]
function work(buffer)
    --print("CheckWlChangeRatio")
	local raceinfolist = {}
	
	local allchannel = AgentModel.GetAllChannel()
	for k,v in pairs(allchannel) do
		
		local channel = v
		
		local raceidlist =  RaceInfoModel.GetRaceList(0, 0, "+inf", channel)
		for k,v in pairs(raceidlist) do
			local raceinfo = RaceInfoModel.GetRaceInfo(v)
			if raceinfo ~= nil then
				local event = st_footballgame_pb.MerchantRaceInfoDto()
				event:ParseFromString(raceinfo)
				table.insert(raceinfolist,event)
			end
		end
	end

    for k,v in pairs(raceinfolist) do
        if v ~= nil then
            local event = v            
            if event.shelvesStatus == 1 and event.isBet == 1 then
                local temprate = {0,0,0}
                local currrate = {1,1,1}
                local totalPourList = {0,0,0}
                for i=1,3 do
                    local rate = FootballModel.GetWlChangeRatio(event.raceId,i)
                    rate = rate == nil and 1 or tonumber(rate)
                    temprate[i] = rate
	                local totaljetton = FootballModel.GetPourJetton(event.raceId, i)
	                totalPourList[i] = totaljetton
                end
                currrate = FootballUtils.cluWLrate(totalPourList)
                for i=1,3  do
                   FootballModel.SetWlChangeRatio(event.raceId,i,currrate[i])
                end
                
            end
		end	
    end
end




