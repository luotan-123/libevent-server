module("CleanTyjettonWorker", package.seeall)

--[[
    一分钟轮询一次
    三天清理体验金券(不包括盈利部分)，七天清除盈利部分
]]

--体验金三天未结算撤单
function orderCancle(orderid,pInfo)

    local orderinfo = FootballService.GetOrderinfoDetailFromDb(orderid)
    if orderinfo == nil  then
		return 
    end

    local nowtime = TimeUtils.GetTime()

    if orderinfo.isBet == 1 then
        return 
    end

    if  orderinfo.orderyiel.tiyan ~= 1  then
       return 
    end

    local chedanfee = 0
    local reback = tonumber(orderinfo.pourjetton)

    local sqlCase = "update dy_footballorder set orderstate = " .. 3 .. ", cancletime =  "..TimeUtils.GetTime()..", win = '"..reback .. "' where orderid = "..orderid
    local sqlresult =  mysqlItem:execute(sqlCase)

    if sqlresult == 1 then
		--结算时后使用
        RaceInfoModel.PushOrderList(orderid, 2, orderinfo.eventid, tonumber(orderinfo.pourjetton), orderinfo.orderyiel.yieltype, orderinfo.rebateId, orderinfo.orderyiel.tiyan==1, orderinfo.orderyiel.yiel)
     
        orderinfo.win = tostring(reback)
        orderinfo.orderstate = 3
        orderinfo.cancletime = TimeUtils.GetTime()
        FootballModel.SetRaceOfOrderInfo(orderinfo.eventid,orderinfo)
        --给玩家返回金币
        if orderinfo.orderyiel.tiyan == 1 then
            PlayerModel.AddTyJetton(pInfo, tonumber(reback))

        end

        --AgentModel.CommissionCount(pInfo.userid, tonumber(orderinfo.pourjetton) - tonumber(reback))

        local chedan =  "体验金有效时间到系统撤单" 
        LogServer.addRecords(pInfo.userid,1,chedan,reback,orderinfo.orderid)

        local msg = "体验金有效时间到系统撤单 ".. orderinfo.eventtype..orderinfo.hometeam.."(主) VS "..orderinfo.awayteam.."(客)"..chedan..orderinfo.orderyiel.typescore..": "..(tonumber(reback) * 0.01) .."元"..",手续费:"..((tonumber(orderinfo.pourjetton) - tonumber(reback)) * 0.01) .."元"
        LogServer.GameUserMoney(pInfo, g_footballgameDefine.game_type, 1, tonumber(reback), msg, 0,0,g_moneyOptType.opt_game_ordercancel,orderinfo.orderid,true)
          
        --玩家个人赛事 区域下注总额
        FootballModel.AddUserRaceRebeatPourjetton(pInfo.userid,orderinfo.eventid,orderinfo.rebateId,0-tonumber(orderinfo.pourjetton))
        
        if orderinfo.cardid ~= "" then
            PropService.reProp(pInfo.userid, orderinfo.cardid)
        end

        local   bet = 0
        local   tybet = 0
        local   betcount = 0
        local   tybetcount = 0  
        if orderinfo.orderyiel.tiyan == 1 then
            tybetcount = -1
            tybet = 0 - tonumber(orderinfo.pourjetton)
        else
            betcount = -1
            bet = 0 - tonumber(orderinfo.pourjetton)
        end
              
        --每天下注量统计
        --LogServer.dailFBBetCount(bet,tybet, orderinfo.ordertime,pInfo)
        LogDispatch.logBetCount(pInfo,bet,tybet,0,1)
        --统计注单数
        local prechannel = GameUtils.GetChannel_login(pInfo.channel)
        LogServer.raceFBRaceCount(orderinfo.eventtype,bet,betcount,tybet,tybetcount,pInfo.channel,prechannel,0,orderinfo.ordertime)

    end

end


function work(buffer)
    --print("CleanTyjettonWorker")
    local userlist = PlayerModel.GetAllUserIdList()
    --luaDump(userlist)
    --字典  流水限制 充值限制 体验金券清除时间 体验金全部清除时间
    local dict = {ty_money_limit=800000, ty_recharge_limit=50000, tyj_expire=3, ty_effective_time= 7}
    for k,v in pairs(userlist) do
        --遍历所有玩家
        if v ~= nil then
            local pInfo =  PlayerModel.GetPlayerInfo(v)
            if pInfo ~= nil then
                local prechannel = GameUtils.GetChannel_login(pInfo.channel)
              
                local sqlCase = "select dict_category,dict_value from web_dict where dict_group  = 'tyj'  and  prechannel = '" ..prechannel.."' and enable_status = ".. 1 ..""
                mysqlItem:execute(sqlCase)
                while true do
                    local sqlData = mysqlItem:fetch({})
                    if sqlData == nil then
                        break
                    end
                    dict[sqlData[1]] = tonumber(sqlData[2])

                end
                local nowstamp      = TimeUtils.GetTime()
                local state         = PlayerModel.GetUserUseTycardState(pInfo.userid)           --使用体验券状态 0 未使用过 1 已使用 2 已清除
                local stamp         = PlayerModel.GetUserUseTycardStamp(pInfo.userid)           --体验金券使用时间戳
                local tyjetton      = PlayerModel.GetUserUseTycardJetton(pInfo.userid)          --使用体验金额额度
                local tywinjetton   = tonumber(RaceInfoModel.GetTyWinMoney(pInfo.userid)) or 0  --体验金盈利部分

                if state == 1 and nowstamp - stamp > dict.tyj_expire * 24 * 60 * 60 then
                    --清除发放的体验券
                    local unsettlelist = {}
                    local sqlCase = "select orderid from dy_footballorder where userid = "..pInfo.userid.." and tiyan = 1 and  orderstate = 0"
                    mysqlItem:executeQuery(sqlCase)
                    while true do
                        local sqlData = mysqlItem:fetch({})
                        if sqlData == nil then
                            break
                        end
                        table.insert(unsettlelist,tonumber(sqlData[1]))

                    end
--                    if #orderCancle  ~= 0 then
--                       for i= 1, #orderCancle do
--                           orderCancle(orderCancle[i],pInfo)
--                       end
--                    end
                   


                    local cleantyjetton = 0
                    if tonumber(pInfo.tyjetton) -  tywinjetton  > 0  then
                        cleantyjetton = tonumber(pInfo.tyjetton) -  tywinjetton 
                    end
                    if cleantyjetton > tyjetton  then
                       cleantyjetton = tyjetton
                    end

                    if cleantyjetton > 0 then
                        local orderid = LogServer.GetNewLogOrderid()
                        --体验金
			            PlayerModel.AddTyJetton(pInfo, 0-tonumber(cleantyjetton))
                        local remark = "体验金下注有效期到"
                        LogServer.addRecords(pInfo.userid,2,remark,0 - tonumber(cleantyjetton),orderid)

                        local season = g_moneyOptType.opt_game_typour 
                        local msg = "体验金下注有效期到,清除体验金"..(cleantyjetton * 0.01).."元"             
                        LogServer.GameUserMoney(pInfo, g_footballgameDefine.game_type, 1, 0-tonumber(cleantyjetton), msg, 0,0,season,orderid,true)
                    end
                    --PlayerModel.SetUserUseTycardState(pInfo.userid,2)
                    PlayerModel.SetUserUseTycard(pInfo.userid,2,0)

                end

                if nowstamp - stamp > dict.ty_effective_time * 24 * 60 * 60   then
                    --清除所有体验金
                    if tywinjetton > 0 then
                        --有盈利部分 判断是否满足转化为正常金币
                        --查询玩家流水和单笔充值最高记录
                        local sqlCase = "select achamount,maxpaynum from log_player where userid = "..pInfo.userid.." and channel = '"..pInfo.channel.."'"
                        local achamount = 0  --玩家流水
                        local maxpaynum = 0  --玩家单笔充值最高记录
                        mysqlLog:executeQuery(sqlCase)
                        local sqlData4 = mysqlLog:fetch({})

                        if sqlData4 ~= nil then
                            achamount = tonumber(sqlData4[1])
                            maxpaynum = tonumber(sqlData4[2]) 
                        end

                        local  jetton = tonumber(pInfo.tyjetton) >= tywinjetton and tywinjetton or  tonumber(pInfo.tyjetton)
                        RaceInfoModel.DelTyWinMoney(pInfo.userid)
                        local sqlCase ="update dy_tyrewardmgr set wintyjetton = 0 where userid = "..pInfo.userid
                        mysqlItem:execute(sqlCase)

                        PlayerModel.AddTyJetton(pInfo, 0-jetton)
                        if achamount >= dict.ty_money_limit  and  maxpaynum >= dict.ty_recharge_limit then
                            --满足转化为正常金币                   
			                PlayerModel.AddJetton(pInfo, jetton, "football", "win")
			                PlayerModel.SetPlayerInfo(pInfo)
			                PlayerModel.SendJetton(pInfo)   --同步分数先 
                            local orderid = LogServer.GetNewLogOrderid()
                            local remark =  "体验金盈利部分提现" 
                            LogServer.addRecords(pInfo.userid,1,remark,tonumber(jetton),orderid)

                            local msg = "玩家"..pInfo.userid.." 体验金盈利部分提现到金币账户: "..(tonumber(jetton)* 0.01).."元，体验金剩余: "..(tonumber(pInfo.tyjetton) * 0.01).."元"
                            
                            LogServer.GameUserMoney(pInfo, g_footballgameDefine.game_type, 1, tonumber(jetton), msg, 0,0,g_moneyOptType.opt_tytojetton,orderi,false,2)

                            local logupdatesql = "insert into log_tymgrrecord (userid,nickname,phone,wintyjetton,tyjetton,jetton,arch,sendrewardstate,logtype,channel,prechannel)values("..
                            pInfo.userid..",'"..pInfo.nickname.."',"..pInfo.phonenum..","..jetton..","..tonumber(pInfo.tyjetton)..","..tonumber(pInfo.jetton)..","..
                            achamount..",".. 1 ..","..1 ..",'"..pInfo.channel.."','"..prechannel.."')"
                            mysqlLog:execute(logupdatesql)

                            local dayStr = TimeUtils.GetDayString()
                            local weekStr = TimeUtils.GetWeekString()
                            local monthStr = TimeUtils.GetMonthString()
  
                            local sqlCase = "update log_player set tywinamount = tywinamount+"..jetton..",winamount = winamount+ "..jetton.." where userid="..pInfo.userid
                            LogModel.LogUserMoneyList(sqlCase)
  
                            sqlCase = "update log_playerdaily set tywinamount = tywinamount+"..jetton..",winamount = winamount+ "..jetton.." where userid="..pInfo.userid.." and dateid='"..dayStr.."'"
                            LogModel.LogUserMoneyList(sqlCase)
  
                            sqlCase = "update log_playerweek set tywinamount = tywinamount+"..jetton..",winamount = winamount+ "..jetton.." where userid="..pInfo.userid.." and dateid='"..weekStr.."'"
                            LogModel.LogUserMoneyList(sqlCase)
  
                            sqlCase = "update log_playermonth set tywinamount = tywinamount+"..jetton..",winamount = winamount+ "..jetton.." where userid="..pInfo.userid.." and dateid='"..monthStr.."'"
                            LogModel.LogUserMoneyList(sqlCase)


                        else
                            local orderid = LogServer.GetNewLogOrderid()
                            local remark =  "体验金清除盈利部分" 
                            LogServer.addRecords(pInfo.userid,2,remark,tonumber(jetton),orderid)

                            local msg = "体验金清除盈利部分 "..(0-tonumber(jetton)* 0.01).."元，体验金剩余: "..(tonumber(pInfo.tyjetton) * 0.01).."元"
                            
                            LogServer.GameUserMoney(pInfo, g_footballgameDefine.game_type, 1,0- tonumber(jetton), msg, 0,0,g_moneyOptType.opt_tytojetton,orderid,true)
                        end
                    end
                end
            end
        end
    end
end




