 FootballUtils = {}

 --拆分字符串
 function FootballUtils.score_split(str, split_char)
        local sub_str_tab = {};
        while (true) do
            local pos = string.find(str, split_char);
            if (not pos) then
                sub_str_tab[#sub_str_tab + 1] = str;
                break;
            end
            local sub_str = string.sub(str, 1, pos - 1);
            sub_str_tab[#sub_str_tab + 1] = sub_str;
            str = string.sub(str, pos + 1, #str);
        end

        return sub_str_tab;
end

--计算竞猜输赢赛事赔率
function FootballUtils.cluWLrate(totalPourlist)
    local rateList = {1,1,1}
    for i=1,3 do
        local curCount = tonumber(totalPourlist[i]) or 0
        local otherCount = 0
        for j=1,3 do
            if i ~= j then
                otherCount = otherCount + (tonumber(totalPourlist[j]) or 0)
            end
        end

        curCount = curCount == 0  and 1 or curCount * 0.01
       
        rateList[i] = math.floor(((otherCount * 0.01) /  curCount) * 10000)*0.0001
    end
    
    return rateList


end

--计算竞猜输赢赛事收益
function FootballUtils.cluWLWin(totalPourlist,userPourlist,rateList,feerate)
    feerate = feerate == nil and 0 or tonumber(feerate)

    local win = 0
    local maxPourCount = tonumber(userPourlist[1]) or 0 
    local maxPourType = 1
    for i=1,3  do
        if userPourlist[i] > maxPourCount then
            maxPourCount = userPourlist[i]
            maxPourType = i
        end
    end
    
    if maxPourCount == 0 then
        return win
    end
       
    win = maxPourCount * rateList[maxPourType]

    return win - win*feerate + userPourlist[maxPourType]

end

function FootballUtils.GetNewProfitid(userid)
    local nowtime = TimeUtils.GetMescTime()
    nowtime = nowtime*10000
    local count = FootballModel.AddUserCreateProfitidCount()
    return nowtime..userid..count
end

