RaceInfoService = {}


function RaceInfoService.Init()
	
	-- 启动拉取一次数据
	
	processWork("PostRaceListAfter","0")
	processWork("PostRaceListBefore","0")
	processWork("PostRaceListHot","0")
	
	print("RaceInfoService.Init")
	
	-- 测试代码
	--processWork("PostRaceRebateList","1152453")
	--processWork("PostRaceListHot","1152453")
end


function RaceInfoService.UtilsLoop()
	
	
end

