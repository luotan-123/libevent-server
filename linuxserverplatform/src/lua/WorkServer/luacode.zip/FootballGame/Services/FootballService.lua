FootballService = {}

function FootballService.Init()
   
end

function FootballService.LoginServerLoop()
    	
	if  g_markTime.curr.min == 45 and g_markTime.curr.sec == 0 then
		--每天统计一次
		processWork("CheckTyjettonWorker","CheckTyjettonWorker")
	end	

    if  g_markTime.curr.sec == 0  then
		--一分钟统计一次
		processWork("CheckWlChangeRatio","CheckWlChangeRatio")
	end	
    
	if g_markTime.curr.sec % 30  == 0 then
	
		processWork("CheckNewsAnnounce","CheckNewsAnnounce")
	end	

    if g_markTime.curr.sec == 10 then
        processWork("CleanTyjettonWorker","CleanTyjettonWorker")
    end
    
end

function FootballService.ServerLoop()

--   --查询是否有公告要发布
--   	local tm = TimeUtils.GetTableTime()	
--    --10s一次
--	if math.mod(tm.sec, 10) == 0 then
--		processWork("FootballWorkPublishNew","FootballWorkPublishNew")
--	end
	if g_markTime.curr.day == 1 and g_markTime.curr.hour == 23 and g_markTime.curr.min == 59 and g_markTime.curr.sec == 58 then
		processWork("CleanFreeGetCashWorker", "CleanFree")
	end

end
--更新玩家输赢状态（mysql and redis）
--state 0:结算 1 撤单
--endtime 比赛结束时间(时间戳) homescore 主队得分 awayscore 客队得分

function FootballService.updateOrderWinAndState(orderid,userid,winCount,state,endtime,homescore,awayscore,repeatCount,yiel,pumpMoney,raceid)
    
   --获取订单
    local orderinfo = msg_footballgame_pb.gcfootballorderdetail()
    --local orderinfoPB =  FootballModel.GetUserSortOrderInfoByCondition(userid,0,orderid)
    local orderinfoPB = FootballModel.GetRaceOfOrderInfo(raceid,orderid)
    local pInfo = PlayerModel.GetPlayerInfo(userid)
    if orderinfoPB == nil then
       return
    end
    orderinfo:ParseFromString(orderinfoPB)

    orderinfo.endtime = endtime /1000
    --订单状态 0:未返利(新订单) 1：结算后亏损 2：结算后获利 3：返还本金（玩家撤单） 4：返还本金（赛事取消）

    --统计免费提现额度 下注量的10%
    if state == 0 then
        --第一次结算  有效 体验金不算 
        if repeatCount == 1 and tonumber(orderinfo.orderyiel.tiyan) == 0 then
            --统计结算订单数
            FootballModel.SetUserCountOrderNum(userid,1)
            LogDispatch.logBetCount(pInfo,0-tonumber(orderinfo.pourjetton),0,0,1)
        elseif repeatCount == 1 and tonumber(orderinfo.orderyiel.tiyan) == 1 then
            LogDispatch.logBetCount(pInfo,0,0-tonumber(orderinfo.pourjetton),0,1)
        end
    elseif state == 1 then
        --撤单
        if tonumber(orderinfo.orderyiel.tiyan) == 0 and  orderinfo.repeatCount == 0 then
            LogDispatch.logBetCount(pInfo,0-tonumber(orderinfo.pourjetton),0,0,1)
        elseif tonumber(orderinfo.orderyiel.tiyan) == 1 and  orderinfo.repeatCount == 0 then
            LogDispatch.logBetCount(pInfo,0,0-tonumber(orderinfo.pourjetton),0,1)
        end
    end
    if homescore ~= nil and awayscore ~= nil then
        orderinfo.homescore = homescore
        orderinfo.awayscore = awayscore
    end
    if state == 1 then
        orderinfo.orderstate = 4
        orderinfo.cancletime = TimeUtils.GetTime()
        --FootballModel.SetUserSortRecapitalOrder2(userid,orderid)
    elseif state == 0 then
        if winCount >= 0 then
            orderinfo.orderstate = 2
           -- FootballModel.SetUserSortWinOrder(userid,orderid)
        else
            orderinfo.orderstate = 1
           -- FootballModel.SetUserSortLoseOrder(userid,orderid)
        end
    end
	
	orderinfo.orderyiel.yiel = string.format("%.5f", tonumber(yiel))
	orderinfo.win = tostring(winCount)
	orderinfo.repeatCount = repeatCount
	orderinfo.pumpMoney = pumpMoney
	local counttime = TimeUtils.GetTimeString()
    --从未结算订单中删除
    --FootballModel.DelUserSortNorebateOrder(userid,orderid)
    --加入已结算
    --FootballModel.SetUserSortCountOrder(userid,orderid)
    --更新订单信息
    --FootballModel.SetOrderInfo(orderid,orderinfo:SerializeToString())      
    FootballModel.SetRaceOfOrderInfo(orderinfo.eventid,orderinfo)
	local sqlCase = "update dy_footballorder set win = '"..orderinfo.win.. "', endtime = '"..TimeUtils.GetTimeString(orderinfo.endtime).."', orderstate = "..orderinfo.orderstate..", homescore = "..homescore..",awayscore = "..awayscore..",yiel = "..orderinfo.orderyiel.yiel..
    ", repeatCount = "..repeatCount..", pumpMoney = "..pumpMoney.. ", cancletime = "..orderinfo.cancletime.. ",counttime = '"..counttime.."' where orderid = '"..orderid.."'"
	--print(sqlCase) 
	SqlServer.rpush(sqlCase)
    --翻翻乐
    FootballModel.SetFlipProfitReportInfo(userid,orderid)

end

--玩家登录的时候映射
function FootballService.checkUserNews(pInfo)
    local prechannel = GameUtils.GetChannel_login(pInfo.channel)
    local sqlCase = "select * from log_announcement where sendstate > 0 and  (prechannel = '"..prechannel.."' or prechannel = 'all' ) and  newtype >= 1 and  receiveid = '0' and sendtime >= '"..pInfo.regdate.."'"
    mysqlLog:executeQuery(sqlCase)
    local usernewlist = {}
    while true do
        local sqlData = mysqlLog:fetch({})
        if sqlData == nil then
            break
        end
        local id              = tonumber(sqlData[1])
        local title           = sqlData[2]
        local content         = sqlData[3]
        local sendtime        = sqlData[4]
        local sendid          = tonumber(sqlData[5])
        local receiveid       = sqlData[6]
        local sendstate       = tonumber(sqlData[7])
        local updatetime      = sqlData[8]
        local newtype         = tonumber(sqlData[9])--公共类型，1=通知，2=活动，3=公告，4=赛事
        local prechannel      = sqlData[11]

        if FootballModel.GetUserNews(pInfo.userid,id) == 0 then
                
            FootballModel.SetUserNews(pInfo.userid,id)
            local temp = {userid= pInfo.userid,id=id,newtype=newtype}
            table.insert(usernewlist,temp)
        end 
    end
    --玩家映射
    for k,v in pairs(usernewlist) do
        local sqlCase = "insert into log_userannouncement (userid ,newsid, newsstate,newstype) values ("..v["userid"]..","..v["id"] ..","..0 ..","..v["newtype"]..")"
        --print(sqlCase)
        mysqlLog:execute(sqlCase) 

    end

end

--从数据库获取订单详情
--返回订单详情gcfootballorderdetail
function FootballService.GetOrderinfoDetailFromDb(orderid)
    local orderinfo  = nil
    local sqlCase = "select * from dy_footballorder where orderid = '"..orderid.."'"
    mysqlItem:executeQuery(sqlCase)
    local sqlData = mysqlItem:fetch({})
    --print(sqlCase)
    if sqlData ~= nil then
        orderinfo = msg_footballgame_pb.gcfootballorderdetail()
        orderinfo.orderid                   =	    sqlData[1]
        orderinfo.userid	                =	    tonumber(sqlData[2])
        orderinfo.eventtype	                =	    sqlData[3]
        orderinfo.orderyiel.subtype	        =	    tonumber(sqlData[4]) or 0
        orderinfo.orderyiel.yieltype	    =	    tonumber(sqlData[5]) or 0
        orderinfo.orderyiel.typescore	    =	    sqlData[6]
        local yiel	                        =	    sqlData[7] --需要从下注信息中获取 实时的
        orderinfo.orderyiel.baoval	        =	    tonumber(sqlData[8]) or 0
        orderinfo.orderyiel.tiyan	        =	    tonumber(sqlData[9]) or 0
        orderinfo.starttime	                =	    TimeUtils.GetTime(sqlData[10])
        orderinfo.endtime	                =	    sqlData[11] ~=nil and  TimeUtils.GetTime(sqlData[11]) or 0
        orderinfo.ordertime	                =	    TimeUtils.GetTime(sqlData[12])
        orderinfo.orderstate	            =	    tonumber(sqlData[13])
        orderinfo.fee	                    =	    sqlData[14] or "0"
        local	win	                        =	    sqlData[15]
        orderinfo.hometeam	                =	    sqlData[16]
        orderinfo.awayteam	                =	    sqlData[17]
        orderinfo.homescore	                =	    tonumber(sqlData[18]) or 0
        orderinfo.awayscore	                =	    tonumber(sqlData[19]) or 0
        orderinfo.eventid	                =	    sqlData[20]
        orderinfo.rebateId	                =	    sqlData[21]
        orderinfo.pourjetton	            =	    sqlData[22] or "0"
        --local	channel	                    =	    sqlData[23]
        orderinfo.repeatCount	            =	    tonumber(sqlData[24]) or 0 --重复计算次数
        orderinfo.pumpMoney	                =	    tonumber(sqlData[25]) or 0 --订单抽水值
        orderinfo.isBet	                    =	    tonumber(sqlData[26])
        --local	wlpourtype	                =	    sqlData[27]
        --local	raceid	                    =	    sqlData[28]
        --local	wlpourlist1	                =	    sqlData[29]
        --local	wlpourlist2	                =	    sqlData[30]
        --local	wlpourlist3	                =	    sqlData[31]
        --local	prechannel	                =	    sqlData[32]
        --local	ordertype	                =	    sqlData[33]
        orderinfo.schemeid	                =	    tonumber(sqlData[34]) or 0 --方案id
        orderinfo.expertid	                =	    tonumber(sqlData[35]) or 0 --专家id
        orderinfo.expert	                =	    sqlData[36] or ""
        local	baobenmoney	                =	    sqlData[37]
        orderinfo.homelogo	                =	    (sqlData[38] == "" or sqlData[38] == nil)    and  g_footballgameDefine.homeTeamFace  or  sqlData[38]
        orderinfo.awaylogo	                =	    (sqlData[39] == "" or sqlData[39] == nil )   and  g_footballgameDefine.visitTeamFace  or sqlData[39]
        orderinfo.cancletime                =       (tonumber(sqlData[40]) or 0) > 0 and  tonumber(sqlData[40]) or 0
        
        orderinfo.planraceid		= tonumber(sqlData[41]) or 0
	    orderinfo.isinsertorder		= tonumber(sqlData[42]) or 0
	    orderinfo.cardid			=  sqlData[43] or ""
        if  orderinfo.cardid ~= "" then
            local propInfo =  PropService.getPropInfo(orderinfo.userid, orderinfo.cardid)
            if propInfo ~= nil then
                orderinfo.proptype	= propInfo.proptype
	            orderinfo.propname	= propInfo.propname
	            orderinfo.propvalue	= propInfo.propvalue
	            orderinfo.condition	= propInfo.condition
            end

        end

        --获取赛事信息
        local raceinfo_pb = RaceInfoModel.GetRaceInfo(orderinfo.eventid)
        local raceinfo = st_footballgame_pb.MerchantRaceInfoDto()
        if raceinfo_pb ~= nil then
            raceinfo:ParseFromString(raceinfo_pb)
        end
        --订单状态 0:未返利(新订单) 1：结算后亏损 2：结算后获利 3：返还本金（玩家撤单） 4：返还本金（赛事取消）5：异常订单
        if orderinfo.orderstate == 0 or orderinfo.orderstate == 3  then
            if raceinfo.winResult ~= "" and raceinfo.winResult ~= "0" then
		        local result_score = FootballUtils.score_split(raceinfo.winResult, "-")
		        orderinfo.homescore		    = tonumber(result_score[1]) 
		        orderinfo.awayscore		    = tonumber(result_score[2])
	        end  
                
        end
        if orderinfo.isBet == 1 then
            --猜胜负
            local totalpourlist = {0,0,0}
            local pourlist      = {0,0,0}
            local ratelist      = {0,0,0} 
            --个下注总额
            pourlist[1]	=	tonumber(sqlData[29])
            pourlist[2]	=	tonumber(sqlData[30])
            pourlist[3]	=	tonumber(sqlData[31])

            for s =1,3  do
                --下注区域总额
                totalpourlist[s] = FootballModel.GetPourJetton(orderinfo.eventid, s)
                orderinfo.wlpourlist:append(tostring(pourlist[s]))
                orderinfo.wltotalpourlist:append(tostring(totalpourlist[s]))
            end
            ratelist = FootballUtils.cluWLrate(totalpourlist)
                
            for s =1,3 do
                orderinfo.wlrate:append(tostring(ratelist[s]))
            end
            if  orderinfo.orderstate == 0  then
                --未结算
                win = FootballUtils.cluWLWin(totalpourlist,pourlist,ratelist,tonumber(orderinfo.fee))
                --print(win,orderinfo.fee)
            end
        else
            --猜比分
            if  orderinfo.orderstate == 0 and orderinfo.schemeid ~= 0  then
                --未结算
                --获取返利信息
                local SimpleRebateInfoPB = RaceInfoModel.GetRaceRebateInfo(orderinfo.eventid, orderinfo.rebateId)
                if SimpleRebateInfoPB ~= nil then
                    local SimpleRebateInfo = st_footballgame_pb.SimpleRebateInfo()
                    SimpleRebateInfo:ParseFromString(SimpleRebateInfoPB)
                    yiel = string.format("%.4f", tonumber(SimpleRebateInfo.rebateRatio))
                    win = tonumber(orderinfo.pourjetton) * (tonumber(yiel)) * (1 - tonumber(orderinfo.fee)) +  tonumber(orderinfo.pourjetton)
                    win = tostring(math.floor(win))
                end
            end
        end
        if orderinfo.orderstate == -1 or orderinfo.orderstate == 3 or orderinfo.orderstate == 4 then
            orderinfo.win	=   tostring(win)
        else
           orderinfo.win	=   tostring(win)
        end

        if orderinfo.orderstate == 0 then
            orderinfo.racestatus = raceinfo.raceStatus
        end

        orderinfo.orderyiel.yiel      = yiel 
        --print(orderinfo)
    end

    return orderinfo
end
--跟投订单处理
--订单结算后处理
function FootballService.dealPlanOrder(pourinfo)
    if pourinfo == nil then
       return "pourinfo is nil"
    end
    if pourinfo.schemeid == 0  then
       return "schemeid is 0"
    end

    local pInfo = PlayerModel.GetPlayerInfo(pourinfo.userid)
    
    if pInfo == nil then
        return "player_not_exist"
    end

    if PlayerModel.CheckTestUserLimit(pInfo,3) then
        return "test_user_funclimit"
    end

    local prechannel = GameUtils.GetChannel_login(pInfo.channel)

    --获取赛事信息
    local raceinfopb = RaceInfoModel.GetRaceInfo(pourinfo.eventid)
    
	if raceinfopb == nil then
		return "event_not_exit"
	end

    --解析赛事
    local raceinfo = st_footballgame_pb.MerchantRaceInfoDto()
	raceinfo:ParseFromString(raceinfopb)

    local nowtime = TimeUtils.GetTime()
    
    --未超过90十分中
    if tonumber(nowtime) - 90 * 60 > (tonumber(raceinfo.startTime) or 0 ) /1000 then
        return  "race time end"
    end
    if raceinfo.raceStatus == 2 then
        return  "race status end"
    end

	local raceRebateInfo = RaceInfoModel.GetAllRaceRebateInfo(pourinfo.eventid)
	if raceRebateInfo == nil then
        --所有的下注区域不存在
		return "pourtype not exit"
	end
   
    --单个下注区域的信息 
    local SimpleRebateInfoPB = RaceInfoModel.GetRaceRebateInfo(pourinfo.eventid, pourinfo.rebateId)
    if SimpleRebateInfoPB == nil then
        --比赛已经开始
        return "pourtype not exit"
    end

    local SimpleRebateInfo = st_footballgame_pb.SimpleRebateInfo()
    SimpleRebateInfo:ParseFromString(SimpleRebateInfoPB)
    local pourjetton = tonumber(pourinfo.pourjetton)

    if (pourinfo.baoval  == 1 and  pourinfo.baoval  ~= SimpleRebateInfo.baoval) then
        --校验参数
        return "pourtype is not bao"
    end

    if tonumber(pourjetton)  < 10000 then
        --猜比分下注不能少于一百
        return  "pour_limit min"
    end

	-- 判断身上金币够不够
	if tonumber(pourjetton) > tonumber(pInfo.jetton) then
		return  "carryjetton_not_enough min"
    end
	

	--[[if SimpleRebateInfo.rebateOpenStatus == 0 then
		return  "score_close"
	end--]]
	
		
    --[[if tonumber(pourjetton)  > (tonumber(SimpleRebateInfo.validAmount) or 0) then
        --下注限制 可竞猜
        return  "pour_limit max"
    end--]]
	
        --[[
        if tonumber(cgmsg.pourjetton)  > (( tonumber(raceinfo.raceTotalBet) -   tonumber(raceinfo.totalBet)) or 0) then
           --下注限制 可竞猜
            gcmsg.result = ReturnCode["pour_limit"]
	        return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
        end

        ]]

    if pourinfo.yieltype == nil or pourinfo.subtype  == nil or pourinfo.typescore == "" or tonumber(pourjetton) <= 0 or pourinfo.planraceid == nil or pourinfo.isinsertorder == nil then
        return "param_error"
    end
  
    --开始下注
    
    local ordertime = TimeUtils.GetTime()
    ordertime = TimeUtils.GetTimeString(ordertime)
    local orderid = FootballModel.GetNewOrderId()
   
    local yiel = string.format("%.4f", tonumber(SimpleRebateInfo.rebateRatio))
    local eventtype = raceinfo.category
    local starttime = tonumber(raceinfo.startTime)/1000 --查询赛事开始时间
    starttime = TimeUtils.GetTimeString(starttime)
    local fee = tostring(raceinfo.fee * 0.01 or 0)
 
    local win = tonumber(pourjetton) * (tonumber(yiel)) * (1 - tonumber(fee)) +  tonumber(pourjetton)
    win = tostring(math.floor(win))
    local hometeam = raceinfo.homeTeam
    local awayteam = raceinfo.visitTeam
    local rebateId = SimpleRebateInfo.rebateId
    local typescore = SimpleRebateInfo.score
    ordertype = pourinfo.tiyan == 1 and 1 or 0
        

	local schemeid		          = pourinfo.schemeid or 0
	local expertid		          = pourinfo.expertid or 0
    local expert = ""
        
    if expertid ~= 0 then
        local sqlCase = "select nickname from ex_player where userid="..expertid
        mysqlItem:executeQuery(sqlCase)
        local sqlData = mysqlItem:fetch()
        if sqlData ~= nil then
            expert = sqlData
        end
    end  
    local homelogo = raceinfo.homeTeamFace == "0"  and  g_footballgameDefine.homeTeamFace or raceinfo.homeTeamFace
    local awaylogo = raceinfo.visitTeamFace == "0" and  g_footballgameDefine.visitTeamFace or raceinfo.visitTeamFace
    local cardid = pourinfo.cardid or ""
    local sqlCase = "insert into dy_footballorder(orderid,userid,eventtype,subtype,yieltype,typescore,yiel,baoval,tiyan,starttime,ordertime,orderstate,fee,win,hometeam,awayteam,eventid,rebateId,pourjetton,channel,raceid,ordertype,prechannel,schemeid,expertid,expert,homelogo,awaylogo,planraceid,isinsertorder,cardid,ip,usertype,oprsys) values( '"
		..orderid.."',"..pInfo.userid..",'"..eventtype.."',"..pourinfo.subtype..","..pourinfo.yieltype..",'"..typescore.."','" .. yiel .."',"..pourinfo.baoval..","..pourinfo.tiyan..",'"..starttime.. "','"..ordertime.."',".. 0 .." , '"..fee.."','"..win.."','"..hometeam.."','"..awayteam.."','"..pourinfo.eventid.."','" ..rebateId.."','"..pourjetton.."','"..pInfo.channel.."','"..pourinfo.eventid.."',"..ordertype..",'"..prechannel.."',"..schemeid..","..expertid..",'"..expert.."','"..homelogo.."','"..awaylogo..
        "',"..pourinfo.planraceid..","..pourinfo.isinsertorder ..",'"..cardid.."','"..pInfo.ip.."','"..pInfo.usertype.."','"..pInfo.oprsys.. "')"	  	
	--luaPrint(" FootballPour sqlCase: "..sqlCase)
    
    local sqlresult = mysqlItem:execute(sqlCase)
    if sqlresult == 1 then
        
        --订单详细信息
        local orderinfo =  msg_footballgame_pb.gcfootballorderdetail()
        orderinfo.result	                  = 0 
        orderinfo.orderid	                  = tostring(orderid)
        orderinfo.userid	                  = pInfo.userid
        orderinfo.eventtype	                  = eventtype
        orderinfo.starttime	                  = tonumber(raceinfo.startTime)/1000
        orderinfo.win	                      = win	
        orderinfo.orderstate                  = 0
        orderinfo.hometeam	                  = hometeam
        orderinfo.awayteam	                  = awayteam
        orderinfo.ordertime	                  = TimeUtils.GetTime(ordertime)
        orderinfo.orderyiel.subtype           = pourinfo.subtype  
        orderinfo.orderyiel.yieltype          = pourinfo.yieltype
        orderinfo.orderyiel.typescore         = typescore
        orderinfo.orderyiel.yiel              = yiel
        orderinfo.orderyiel.baoval            = pourinfo.baoval
        orderinfo.orderyiel.tiyan	          = pourinfo.tiyan  
        orderinfo.orderyiel.rebateId	      = rebateId
        orderinfo.fee	                      =	fee
        orderinfo.eventid	                  = pourinfo.eventid
        orderinfo.pourjetton                  = tostring(pourjetton)
        orderinfo.rebateId	                  = rebateId
        orderinfo.expert			          = expert  
	    orderinfo.schemeid			          = schemeid
	    orderinfo.expertid			          = expertid
        orderinfo.homelogo			          = raceinfo.homeTeamFace == "0"  and g_footballgameDefine.homeTeamFace or raceinfo.homeTeamFace
	    orderinfo.awaylogo			          = raceinfo.visitTeamFace == "0" and g_footballgameDefine.visitTeamFace or  raceinfo.visitTeamFace
        orderinfo.planraceid                  = pourinfo.planraceid
        orderinfo.isinsertorder               = pourinfo.isinsertorder
        orderinfo.cardid                      = cardid
        --FootballModel.SetOrderInfo(orderid,orderinfo:SerializeToString())
        FootballModel.SetRaceOfOrderInfo(orderinfo.eventid,orderinfo)
        --所有订单
        --FootballModel.SetUserSortOrder(pInfo.userid,orderid)
        --未返利订单(新订单)
        --FootballModel.SetUserSortNorebateOrder(pInfo.userid,orderid)
        --结算时后使用 
        RaceInfoModel.PushOrderList(orderid, 1, pourinfo.eventid, pourjetton, pourinfo.yieltype, rebateId, pourinfo.tiyan==1, orderinfo.orderyiel.yiel)
        FootballModel.SetRaceOrderCount(pourinfo.eventid,1)
        if pourinfo.tiyan == 0 then
             
            PlayerModel.DecJetton(pInfo,tonumber(pourjetton),"fooball","FootballPour")
            PlayerModel.SendJetton(pInfo)
        else
            PlayerModel.AddTyJetton(pInfo, 0-tonumber(pourjetton))
        end


        --玩家个人赛事 区域下注总额
        FootballModel.AddUserRaceRebeatPourjetton(pInfo.userid,pourinfo.eventid,rebateId,tonumber(pourjetton))

        local xiazhu = pourinfo.tiyan == 1 and "体验金下注" or "下注"
        LogServer.addRecords(pInfo.userid,2,xiazhu,0 - tonumber(pourjetton),orderinfo.orderid)

        local season = pourinfo.tiyan == 1 and g_moneyOptType.opt_game_typour or g_moneyOptType.opt_game_pour
        local msg = "玩家在".. orderinfo.eventtype..orderinfo.hometeam.."(主) VS "..orderinfo.awayteam.."(客)".."比赛中的"..typescore.."比分区域"..xiazhu.." : "..(pourjetton * 0.01).."元"
        LogServer.GameUserMoney(pInfo, g_footballgameDefine.game_type, 1, 0-tonumber(pourjetton), msg, 0,0,season,orderinfo.orderid,false,2)

        local bet = 0
        local tybet = 0
        local betcount = 0
        local tybetcount = 0
        if pourinfo.tiyan == 1 then
            tybet = pourjetton
            tybetcount = 1
        else
            bet = pourjetton
            betcount = 1
        end
        --每天下注量统计
        --LogServer.dailFBBetCount(bet,tybet,orderinfo.ordertime,pInfo)
        LogDispatch.logBetCount(pInfo,bet,tybet,0,0)
        --统计注单数
        LogServer.raceFBRaceCount(raceinfo.category,bet,betcount,tybet,tybetcount,pInfo.channel,prechannel,0,orderinfo.ordertime)
        local touzhutype = 0
        if pourinfo.tiyan == 1 then
                touzhutype  = 1 
        else     
            touzhutype = 0  
        end
        ExpertModel.PourPlan(pInfo.userid, pourinfo.schemeid, pourinfo.expertid, pourjetton, touzhutype)
        FootballModel.SetRaceOrderCount(pourinfo.eventid,1)

        RaceInfoModel.PourRaceScore(pourinfo.eventid,rebateId,tonumber(pourjetton), touzhutype, 1, pInfo.channel)

        LogServer.firstPlayer(pInfo.userid,1)
    else
        return "pour_error"
    end

    return orderid
end


--[[
    --赛事取消 系统撤单 通知api  
    newsinfo["title"]       标题
    newsinfo["content"]     内容
    newsinfo["sendtime"]    定时发送时间，日期格式 TimeUtils.GetTimeString()
    newsinfo["sendid"]      默认值 1 系统id=1
    newsinfo["receiveid"]   接收者 0=表示所有人，多个人，用逗号分隔
    newsinfo["sendstate"]   0 未发送    
    newsinfo["newtype"]     消息类型，1=通知，2=活动，3=公告，4=赛事   
    newsinfo["prechannel"]  大渠道               
]]

function FootballService.raceOrderInfoSendNews(newsinfo)
        local sqlCase = "insert into log_announcement(title,content,sendtime,sendid,receiveid,sendstate,prechannel,newtype) values('"
        ..newsinfo['title'].."','"..newsinfo['content'].."','"..newsinfo['sendtime'].."','"..newsinfo['sendid'].."','"..newsinfo['receiveid'].."','"..newsinfo['sendstate'].."','"..newsinfo['prechannel'].."','"..newsinfo['newtype'].."')"
        local result =  mysqlLog:execute(sqlCase)
        if result ~= 1 then
           print(sqlCase)
        end
end


function FootballService.PlayerWinBroad()
	
			local gcmsg = msg_human_pb.gcbroadcast()
			gcmsg.broadtypelist:append(g_broadCast.type_sys)
			gcmsg.senderidlist:append(0)
			gcmsg.senderlist:append("系统")
			local msg = {}
			msg[1] = {}
			msg[1]["val"] = "恭喜"
			
			msg[2] = {}
			msg[2]["clr"] = "0x000000"
			msg[2]["val"] = "ssdas"
			
			msg[3] = {}
			msg[3]["val"] = "在"
			
			msg[4] = {}
			msg[4]["clr"] = "0xC80000"
			msg[4]["val"] ="足球"
			
			msg[5] = {}
			msg[5]["val"] = "游戏中, 人品大爆发赢得"
			
			msg[6] = {}
			msg[6]["clr"] = "0xC80000"
			msg[6]["val"] = tostring(1111/100)
			
			msg[7] = {}
			msg[7]["val"] = "金币!"
			
			gcmsg.msglist:append(luajson.encode(msg))
			BroadCastModel.SendToAll(gcmsg)
end



--检测能否使用体验金券
function FootballService.checkUseTyCards(pInfo,propInfo)
    --是否绑定手机
    if pInfo.phonenum == "" then
        return false
    end
    
    if propInfo == nil  or pInfo == nil then
        return false
    end    
    --体验金是否为0
    if tonumber(pInfo.tyjetton) > 0 then
        return false
    end

    --1 保本 2 抽奖 3 体验金 4 添利 5 神偷
    if propInfo.proptype ~= 3 then
        return false
    end

    --玩家是否拥有体验金券
    if pInfo.userid ~= propInfo.userid then
        return false
    end

    local nowtime = TimeUtils.GetTime()
    --是否过期
    if nowtime - propInfo.receivedate > propInfo.effectivetime * 24 * 60 * 60 then
        return false
    end

    --是否已经使用过了
    if propInfo.state == 1 then
        return false
    end

    --是否有未结算的体验金订单
    local sqlCase = "select * from dy_footballorder where userid = "..pInfo.userid.." and tiyan = 1 and  orderstate = 0"
    mysqlItem:executeQuery(sqlCase)
    local sqlData = mysqlItem:fetch({})
    if sqlData ~= nil then
        return false
    end

    return true

end
