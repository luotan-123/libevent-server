
require("RedisClear.Model.RedisClearModel")




require("RedisClear.Services.RedisClearService")


require("RedisClear.Worker.RedisClearKey")
require("RedisClear.Worker.RedisClearHashKey")


g_redisIndex[RedisClearModel.redis_index] = {index = g_redisInfo.redis_two, des = "redisclear_info"}
