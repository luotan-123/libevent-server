g_servername = "run_dwc858" --这是每一个游戏的标志
g_serverid = 1
g_serverip = "192.168.2.121"
g_gamename = "dwcgame"
g_httpport = 6052
g_tcpport = 6101
g_websocketport = 5053
g_udpport = 6103      --目前暂时不支持udp
g_tcptimeout = 6000
g_websockettimeout = 6000
g_tcpmaxthreads = 5
g_httpmaxthreads = 2
g_workmaxthreads = 10
g_websocketmaxthreads = 2
g_serverType = "login"
g_isDebug = 1
g_dbtype = 'mysql'
g_timeOut = 1000    --定时器设置的超时时间，单位是毫秒


g_logonid = 1
g_channelname = "cfyl"
g_webUrl = "http://share.hnxxjkl.com"  --游戏的URL，
g_gservertype = "2"     --游戏服分类，将游戏分别放在不同的端口和ip当中
g_processName = "run_uu_game"   --在系统中运行的执行文件的名字
g_Ratio = 50       --抽水的点数除以1000

g_webUrl = "http://nstest.sgcgame.com"  --游戏的URL，

g_dbHost = 'localhost'
g_dbUser = 'root'
g_dbPassword = "root"
g_dbPort = 3306
g_dbDatabase = 'newframe'

g_db_logHost = 'localhost'
g_db_logUser = 'root'
g_db_logPassword = "root"
g_db_logPort = 3306
g_db_logDatabase = 'newframe'


--[[g_dbHost = '127.0.0.1'
g_dbUser = 'root'
g_dbPassword = ""
g_dbPort = 3306
g_dbDatabase = 'db_dwcgame'--]]


--[[g_dbHost = '119.23.29.164'
g_dbUser = 'gamer'
g_dbPassword = "btc!+ngkp"
g_dbPort = 6006
g_dbDatabase = 'db_dwcgame'--]]

g_qrcodeUrl = ""       --生成二维码的url,调用改接口，生成对应的推广二维码
g_redisInfo = {}
g_redisInfo.redis_one = 1     --玩家属性
g_redisInfo.redis_two = 2     --
g_redisInfo.redis_three = 3   --
g_redisInfo.redis_four = 4    --这个数据是设置历史记录的
g_redisInfo.redis_five = 5    --这个数据是设置历史记录的
g_redisInfo.redis_six = 6    --这个数据是设置历史记录的

g_redisInfo.host = "127.0.0.1"
g_redisInfo.port = 6380
g_redisInfo.pass = ""

g_signKey = "w2ctsethjcyu7r9b"
g_markTime = {}
function ServerInit()  --在函数启动的时候，会调用该函数，获取服务器的配置信息
	--返回以下11个参数
	return g_workmaxthreads,g_timeOut, g_serverid,g_serverip,g_tcpport,g_httpport,g_websocketport,g_udpport,g_tcptimeout,g_websockettimeout,
	g_tcpmaxthreads,g_httpmaxthreads,g_websocketmaxthreads,g_isDebug
end

--以下是Utils服务器的配置，放在同一个配置文件中。

g_utilsTimout = 1000     --这个定时器设置超时间短一些。
g_utilsmaxthreads = 10


function serveUtilsInit()
	return g_utilsTimout, g_utilsmaxthreads,g_isDebug
end

