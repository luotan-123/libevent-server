require("Human.Controller.AccountLogin")
require("Human.Controller.GetPlayerInfo")
require("Human.Controller.Heartbeat")
require("Human.Controller.ReConnect")
require("Human.Controller.GetInitInfo")
require("Human.Controller.GetMailList")
require("Human.Controller.ReadMail")
require("Human.Controller.GetMailGoods")
require("Human.Controller.PlayerStatus")
require("Human.Controller.UpdatePlayerInfo")
require("Human.Controller.AgencyOpt")
require("Human.Controller.EnterTable")
require("Human.Controller.InviteBind")
require("Human.Controller.GetAgencyInfo")
require("Human.Controller.UserAwardInfo")
require("Human.Controller.GetUserAward")
require("Human.Controller.BankSetPassword")
require("Human.Controller.BankLogin")
require("Human.Controller.BankDepositWithdraw")
require("Human.Controller.BankTransfer")
require("Human.Controller.BankTransferHistory")
require("Human.Controller.ExchangeGifts")
require("Human.Controller.CheckBindCode")
require("Human.Controller.BankruptSubsidy")
require("Human.Controller.CommissionGet")
require("Human.Controller.TxInfoGetOrBind")
require("Human.Controller.WithdrawDeposit")
require("Human.Controller.CountHistory")
require("Human.Controller.BindPhone")
require("Human.Controller.LuckWheel")
require("Human.Controller.LuckWheelStart")
require("Human.Controller.ModifyPassword")
require("Human.Controller.ActivityConnections")
require("Human.Controller.ActivityHero")
require("Human.Controller.GetCashWithdrawalList")
require("Human.Controller.GameConnect")
require("Human.Controller.GetGameConnectInfo")
require("Human.Controller.OnLine")
require("Human.Controller.GetHongBaoYu")
require("Human.Controller.RechargeRecord")
require("Human.Controller.GetCashWithdrawalAnalysis")
require("Human.Controller.BindIDCard")
require("Human.Controller.GetIDCard")
require("Human.Controller.SetPassword")
require("Human.Controller.MoneyTradeRecords")
require("Human.Controller.GetPayerOnGame")
require("Human.Controller.GetCpGameHistroy")
require("Human.Controller.GetPlayerActivityState")
require("Human.Controller.GetGameStateList")
--require("Human.Controller.GetCaiPiaoInitInfo")
require("Human.Controller.GetGameTableList")
require("Human.Controller.ReceiveTransferInfo")


require("common.st_human_pb")
require("common.st_human2_pb")
require("common.st_shop_pb")
require("common.msg_shop_pb")
require("common.msg_human_pb")
require("common.msg_human2_pb")
require("common.msg_human3_pb")
require("common.msg_user_pb")
require("common.st_user_pb")

--require("common.st_caipiao_pb")
--require("common.msg_caipiao_pb")
--require("common.msg_caipiao2_pb")
--require("common.define.CaiPiaoDefine")

require("common.define.HumanDefine")
require("common.packet.packet_human")

require("common.data.db_goods")
require("common.data.db_loginaward")
require("common.data.db_signaward")

require("Human.Model.PlayerModel")

require("Human.Model.GoodsModel")
require("Human.Model.OnlineModel")
require("Human.Model.NoticeModel")
require("Human.Model.BroadCastModel")
require("Human.Model.ChatModel")
require("Human.Model.MailModel")
require("Human.Model.AgencyModel")
require("Human.Model.AwardModel")
require("Human.Model.BankModel")
require("Human.Model.RosterModel")
require("Human.Model.GameModel")
require("Human.Model.PlayerStatsModel")
require("Human.Model.LocationModel")
require("Human.Model.HttpSendModel")
require("Human.Model.ActivityModel")

require("Human.Services.TimeCheckService")
require("Human.Services.SysCountService")
require("Human.Services.PlayerStatsService")
require("Human.Services.TransferService")

require("Human.Model.SpecialModel")
require("Human.Model.PushMsgModel")

require("Human.Worker.UserIPCheck")
require("Human.Worker.HttpSendExecute")
require("Human.Worker.NoticeHongBaoYu")
require("Human.Worker.TransferWorker")

require("Http.HttpDebug")
require("Http.HttpGame")
require("Http.HttpPlay")

require("Human.Utils.GameUtils")

g_redisIndex[NoticeModel.redis_index] = {index = g_redisInfo.redis_one, des="notice"}     --系统唯一的邮件

g_redisIndex[OnlineModel.redis_index] = {index = g_redisInfo.redis_one, key = MailModel.mail_list, link = 1}  --每个玩家自己的邮件


g_redisIndex[GoodsModel.redis_index] = {index = g_redisInfo.redis_one, key = MailModel.mail_list, link = 1}  --每个玩家自己的邮件

g_redisIndex[BroadCastModel.redis_index] = {index = g_redisInfo.redis_one, key = MailModel.mail_list, link = 1}  --每个玩家自己的邮件

g_redisIndex[ChatModel.redis_index] = {index = g_redisInfo.redis_one, key = MailModel.mail_list, link = 1}  --每个玩家自己的邮件

g_redisIndex[MailModel.redis_index] = {index = g_redisInfo.redis_one, key = MailModel.mail_list, link = 1}  --每个玩家自己的邮件

g_redisIndex[PlayerModel.redis_index] = {index = g_redisInfo.redis_one, key = MailModel.mail_list, link = 1}  --每个玩家自己的邮件

g_redisIndex[AgencyModel.redis_index] = {index = g_redisInfo.redis_one, key = MailModel.mail_list, link = 1}  --每个玩家自己的邮件

g_redisIndex[RosterModel.redis_index] = {index = g_redisInfo.redis_three, key = MailModel.mail_list, link = 1}  --每个玩家自己的邮件

g_redisIndex[LocationModel.redis_index] = {index = g_redisInfo.redis_one, key = LocationModel.redis_index, link = 1}  --
g_redisIndex[HttpSendModel.redis_index] = {index = g_redisInfo.redis_one, key = HttpSendModel.redis_index, link = 1}  --
g_redisIndex[ActivityModel.redis_index] = {index = g_redisInfo.redis_three, key = HttpSendModel.redis_index, link = 1}  --

g_redisIndex[PushMsgModel.redis_index] = {index = g_redisInfo.redis_six, key = PushMsgModel.redis_index, link = 1}  -- 推送消息model