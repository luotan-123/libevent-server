module("BindIDCard", package.seeall)

function execute(packetID, operateID, buffer)

	local cgmsg = msg_human3_pb.cgbindidcard()
	local gcmsg = msg_human3_pb.gcbindidcard()

	cgmsg:ParseFromString(buffer)
	local checkMsg = RedisHelper.CheckRedis(cgmsg.userid,operateID)
	if checkMsg ~= nil then
		gcmsg:ParseFromString(checkMsg)
		return cgmsg.userid,0,gcmsg:ByteSize(),gcmsg:SerializeToString()
	end
	
	local pInfo = PlayerModel.GetPlayerInfo(cgmsg.userid)
	if pInfo == nil then
		gcmsg.result = ReturnCode["player_not_exist"]
		return cgmsg.userid, 0, gcmsg:ByteSize(), gcmsg:SerializeToString()
	end
	local prechannel = GameUtils.GetChannel_login(pInfo.channel)
	if cgmsg.idcardnumber == "" 
	or cgmsg.idcarda == "" 
	or cgmsg.idcardb == "" 
	or cgmsg.realname == "" 
	or cgmsg.vcode == ""
	or (pInfo.idcardstatus ~= 0 and pInfo.idcardstatus ~= 3) 
      then
		gcmsg.result = ReturnCode["bind_error"]
		return cgmsg.userid, 0, gcmsg:ByteSize(), gcmsg:SerializeToString()
	end
	
	--设置忘记密码 只验证验证码
	local sqlCase = "select * from dy_authcode where phonenum='"..pInfo.phonenum.."' and code="..cgmsg.vcode.." and prechannel = '"..prechannel.."'  order by id desc"
	mysqlItem:executeQuery(sqlCase)
	local sqlData = mysqlItem:fetch({})
	if sqlData == nil then
		gcmsg.result = ReturnCode["phone_code_notexit"]
		return cgmsg.userid, 0, gcmsg:ByteSize(), gcmsg:SerializeToString()
	end

	local state = tonumber(sqlData[5])
    local codeid = tonumber(sqlData[1])

    if state == 1 then
	    gcmsg.result = ReturnCode["phone_code_notexit"]
	    return 0,0,gcmsg:ByteSize(),gcmsg:SerializeToString()
    end
	

	local startTime = tonumber(sqlData[3])
	local nowTime = TimeUtils.GetTime()
	if (nowTime - startTime) > 600 then
		gcmsg.result = ReturnCode["phone_code_pastdue"]
		return cgmsg.userid, 0, gcmsg:ByteSize(), gcmsg:SerializeToString()
	end
	local t = TimeUtils.GetTime()
	local created_at = TimeUtils.GetTimeString(t)
	local prechannel = GameUtils.GetChannel_login(pInfo.channel)
	local sqlCase = "insert into dy_idcardverify(userid,name,idcard,idcard_a,idcard_b,status,channel,prechannel,created_at) values( "
		    ..pInfo.userid..",'"..cgmsg.realname.."','"..cgmsg.idcardnumber.."','"..cgmsg.idcarda.. "','"..cgmsg.idcardb.."',"
			.. 0 .." , '"..pInfo.channel.."','".. prechannel.."','"..created_at.."')" 	
	mysqlItem:execute(sqlCase)
	
	pInfo.idcardstatus = 1 
	PlayerModel.SetPlayerInfo(pInfo)
	local sqlCase = "update dy_player set idcardstatus="..pInfo.idcardstatus.." where userid="..pInfo.userid
	mysqlItem:execute(sqlCase)
	
    local sqlCase = "update  dy_authcode set state = 1 where id = "..codeid
    mysqlItem:execute(sqlCase)

	gcmsg.result = 0
	
	return cgmsg.userid, 0, gcmsg:ByteSize(), gcmsg:SerializeToString()

end