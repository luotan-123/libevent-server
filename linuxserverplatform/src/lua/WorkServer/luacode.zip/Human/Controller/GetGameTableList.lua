
module("GetGameTableList", package.seeall)

function execute(packetID, operateID, buffer)

	local cgmsg = msg_human3_pb.cggetgametablelist()
	local gcmsg = msg_human3_pb.gcgetgametablelist()

	cgmsg:ParseFromString(buffer)
	local checkMsg = RedisHelper.CheckRedis(cgmsg.userid, operateID)
	if checkMsg ~= nil then
		gcmsg:ParseFromString(checkMsg)
		LogBehavior.Warning(cgmsg.userid, "human", "GetGameTableList", 0, "协议号重复"..operateID)
		return cgmsg.userid, 0, gcmsg:ByteSize(), gcmsg:SerializeToString()
	end
	
	if cgmsg.gametype == g_cpdouniuDefine.gametype_friend then 
		--我的牌局
		local tableList = CpDouNiuModel.GetUserTableList(cgmsg.userid)
		for k,v in pairs(tableList) do 
			local tableInfo = gcmsg.tableinfolist:add()
			tableInfo.tableid = tonumber(k)
			local tInfo = CpDouNiuModel.GetTableInfo(tonumber(k))
			if tInfo ~= nil then
				tableInfo.gametype = cgmsg.gametype
				tableInfo.tabletype = tInfo.tabletype
				tableInfo.maxplayernum = tInfo.maxuser
				tableInfo.nowplayernum = #tInfo.situser
				tableInfo.bottomscore = tInfo.bottomscore
				tableInfo.remarks = ""
				if tInfo.characteristic == g_cpdouniuDefine.gametype_classic then
					tableInfo.remarks = tableInfo.remarks.."抢庄牛牛"
				elseif tInfo.characteristic == g_cpdouniuDefine.gametype_friend then
					tableInfo.remarks = tableInfo.remarks.."约局抢庄牛牛"
				end
				
				tableInfo.remarks = tableInfo.remarks.."底分:"..(tInfo.bottomscore/100).." 最大抢庄倍数:"..tInfo.bankermultiple.." 下注:"..tInfo.difen.." 准入:"..(tInfo.minenter/100)
				for k,v in ipairs(tInfo.situser) do 
					tableInfo.useridlist:append(v.userid)
					tableInfo.nicknamelist:append(v.nickname)
					tableInfo.facelist:append(v.faceid)
				end
			else
				CpDouNiuModel.DelUserTableList(cgmsg.userid,tonumber(k))
			end
		end
	else
		--牌桌列表
		local gametablelist = GameModel.getGameTableList(cgmsg.gametype)
		if gametablelist ~= nil then
			for k, v in pairs(gametablelist)do
				local tableInfo = gcmsg.tableinfolist:add()
				tableInfo:ParseFromString(v)
			end
		end
	end
	gcmsg.userid = cgmsg.userid
	gcmsg.gametype = cgmsg.gametype
	gcmsg.result = 0
	return cgmsg.userid, 0, gcmsg:ByteSize(), gcmsg:SerializeToString()
end
