module("GetUserAward", package.seeall)

--获取用户的奖励

function execute(packetID, operateID, buffer)

	local cgmsg = msg_user_pb.cggetuseraward()
	local gcmsg = msg_user_pb.gcgetuseraward()
	cgmsg:ParseFromString(buffer)

	local checkMsg = RedisHelper.CheckRedis(cgmsg.userid, operateID)
	if checkMsg ~= nil then
		gcmsg:ParseFromString(checkMsg)
		LogBehavior.Warning(cgmsg.userid, "mail", "GetMailGoods", 0, "重复发送领取邮件物品协议，mailid="..cgmsg.mailid)
		return cgmsg.userid, 0, gcmsg:ByteSize(), gcmsg:SerializeToString()
	end
	local pInfo = PlayerModel.GetPlayerInfo(cgmsg.userid)
	if pInfo == nil then
		LogBehavior.Error(cgmsg.userid, "mail", "GetMailGoods", ReturnCode["mail_not_exist"], "人物信息不存在，mailid="..cgmsg.mailid)
		return cgmsg.userid, ReturnCode["player_not_exist"], 0, ""
	end
	

	gcmsg.result = 0
	return cgmsg.userid, 0, gcmsg:ByteSize(), gcmsg:SerializeToString()
	
end


