module("LuckWheel", package.seeall)

--打开幸运大转盘
function execute(packetID, operateID, buffer)

    local cgmsg = msg_human2_pb.cgluckwheel()
	local gcmsg = msg_human2_pb.gcluckwheel()
	
	cgmsg:ParseFromString(buffer)
	
	local checkMsg = RedisHelper.CheckRedis(cgmsg.userid, operateID)
	if checkMsg ~= nil then
		gcmsg:ParseFromString(checkMsg)
		LogBehavior.Warning(cgmsg.userid, "pInfo", "LuckWheel", 0, "缓存已存在")
		return cgmsg.userid, 0, gcmsg:ByteSize(), gcmsg:SerializeToString()
	end

	local pInfo = PlayerModel.GetPlayerInfo(cgmsg.userid)
	if pInfo == nil then
		LogBehavior.Error(cgmsg.userid,"pInfo","LuckWheel", ReturnCode["player_not_exist"], "该玩家不存在")
		gcmsg.result = ReturnCode["player_not_exist"]
		return cgmsg.userid, 0, gcmsg:ByteSize(), gcmsg:SerializeToString()
	end

    gcmsg.userid = cgmsg.userid

    --获取玩家抽奖信息 通过接口获取到 周业绩流水值
    local achievement = UnlimitedAward.GetDirAch(cgmsg.userid)

    luaPrint("achievement: "..achievement)
    local lucktype = {1,2,3,4,5,6,7,8,8.88,9}
    local grade = 1
    if achievement >= 1000000 and achievement < 10000000 then
        -- 大于等于1万 小于 10万
        grade =1
    elseif achievement >= 10000000 and achievement < 100000000 then
        -- 大于等于10万 小于 100万
        grade =10
    elseif achievement >= 100000000 and achievement < 1000000000 then
        -- 大于等于100万 小于 1000万
        grade =100
    elseif achievement >= 1000000000 then
        --大于 1000万
        grade =1000
    else
        --没有资格抽奖
        grade = 1
        for k,v in ipairs(lucktype) do
            gcmsg.jettonlist:append(v* grade * 100)   
        end
        gcmsg.result = ReturnCode["luckwheel_error_1"] --由于您的业绩流水不达标，所有无法参与这次活动
        return cgmsg.userid, 0, gcmsg:ByteSize(), gcmsg:SerializeToString()
    end


    --抽奖梯度
    if grade == 1000 then
        lucktype = {88800,100000,200000,300000,400000,500000,600000,700000,800000,900000}
        for k,v in ipairs(lucktype) do
            gcmsg.jettonlist:append(v)   
        end
    else
        for k,v in ipairs(lucktype) do
            gcmsg.jettonlist:append(v* grade * 100)   
        end
    end
   
    --获取当前幸运抽奖期号 可设置在缓存中 由后台设置 
    local luckNum = 1

    --根据LuckWheelInfo数据判断抽奖资格
    local luckinfo = PlayerModel.GetUserLuckWheelInfo(cgmsg.userid,luckNum)
    if luckinfo == nil or (luckinfo ~= nil and luckinfo["restate"] == 1) then
        --可以抽奖
        gcmsg.reState = 1
        gcmsg.achievement = tostring(achievement)
    else
        --已经抽过奖或没有抽奖资格
        if tonumber(luckinfo["restate"]) == 2 then
            gcmsg.result = ReturnCode["luckwheel_error_2"] --您已经抽过了
        else
            gcmsg.result = ReturnCode["luckwheel_error_1"] --由于您的业绩流水不达标，所有无法参与这次活动
        end
        if luckinfo ~= nil then
            gcmsg.rejetton = tonumber(luckinfo["rejetton"])
            gcmsg.achievement = tostring(luckinfo["achievement"])
            gcmsg.reState = tonumber(luckinfo["restate"])
        end
		return cgmsg.userid, 0, gcmsg:ByteSize(), gcmsg:SerializeToString()
    end

    gcmsg.result = 0
    return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()

end
