
module("SetPassword", package.seeall)

--此处只用于 手机+验证码登录的玩家设置密码
function execute(packetID, operateID, buffer)

	local cgmsg = msg_human_pb.cgsetpassword()
	local gcmsg = msg_human_pb.gcsetpassword()

	cgmsg:ParseFromString(buffer)

    local pInfo = PlayerModel.GetPlayerInfo(cgmsg.userid)
    
    if pInfo == nil then
        gcmsg.result = ReturnCode["player_not_exist"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
    end

    if cgmsg.password == nil or cgmsg.password == '' then
        gcmsg.result = ReturnCode["modify_error"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
    end

    local sqlCase = "select password from dy_player where userid="..cgmsg.userid
    mysqlItem:executeQuery(sqlCase)
	local password = mysqlItem:fetch()
    if password == nil or password == ""then
        password = md5(cgmsg.password)
        local sqlCase = "update dy_player set password = '"..password.."' where userid = "..cgmsg.userid
        local ret = mysqlItem:execute(sqlCase)
        if ret == 1 then
            pInfo.password = password
            PlayerModel.SetPlayerInfo(pInfo)
            local tJson = {}
	        table.insert(tJson, pInfo.password)
	        table.insert(tJson, pInfo.userid)
	        redisItem:set("account"..pInfo.account, luajson.encode(tJson), PlayerModel.redis_index)
	        --PlayerModel.SendPlayerInfo(pInfo,{"password"})
            local content = "用户【"..pInfo.userid.."】修改用户【"..pInfo.userid.."】密码"
            local prechannel = GameUtils.GetChannel_login(pInfo.channel)
            local sqlCase = "insert into log_riskaction (userid,action,logintype,opttime,optname,optid,content,channel,prechannel)values("..cgmsg.userid..",".. 2 ..",'"..pInfo.oprsys.."','"..TimeUtils.GetTimeString().."','"..pInfo.nickname.."',"..cgmsg.userid..",'"..content.." ','"..pInfo.channel.."','"..prechannel.."')"
            mysqlLog:execute(sqlCase)
            --print(sqlCase)
            LogBehavior.UserAction(pInfo, 3, content)

            local sqlCase = " insert into log_player_risk(userid,change_pass) values ( " ..pInfo.userid..","..1 ..")  ON DUPLICATE KEY update change_pass=change_pass + ".. 1
            --print(sqlCase)
            LogModel.LogUserGameDetail(sqlCase)	

        else
            gcmsg.result = ReturnCode["modify_error"]
		    return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()    
        end
    else
        gcmsg.result = ReturnCode["modify_error"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
    end
    gcmsg.result = 0
	return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
end