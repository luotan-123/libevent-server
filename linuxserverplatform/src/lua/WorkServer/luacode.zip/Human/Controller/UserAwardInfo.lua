module("UserAwardInfo", package.seeall)

--领取每日登录奖励
function execute(packetID, operateID, buffer)

	local cgmsg = msg_user_pb.cguserawardinfo()
	local gcmsg = msg_user_pb.gcuserawardinfo()
	
	cgmsg:ParseFromString(buffer)
	
	local checkMsg = RedisHelper.CheckRedis(cgmsg.userid, operateID)
	if checkMsg ~= nil then
		gcmsg:ParseFromString(checkMsg)
		LogBehavior.Warning(cgmsg.userid, "pInfo", "UpdatePlayerInfo", 0, "修改玩家信息")
		return cgmsg.userid, 0, gcmsg:ByteSize(), gcmsg:SerializeToString()
	end

	gcmsg.result = 0
	return cgmsg.userid, 0, gcmsg:ByteSize(), gcmsg:SerializeToString()
end
