module("AgencyOpt", package.seeall)


function execute(packetID, operateID, buffer)

	local cgmsg = msg_human_pb.cgagencyopt()
	local gcmsg = msg_human_pb.gcagencyopt()
	
	cgmsg:ParseFromString(buffer)
	
	local pInfo = PlayerModel.GetPlayerInfo(cgmsg.userid)
	if pInfo == nil then
		LogBehavior.Error(cgmsg.userid,"gdmj","GdmjCreate", ReturnCode["player_not_exist"], "该玩家不存在")
		gcmsg.result = ReturnCode["player_not_exist"]
		return cgmsg.userid, gcmsg.result, gcmsg:ByteSize(), gcmsg:SerializeToString()		
	end

	
	return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
end