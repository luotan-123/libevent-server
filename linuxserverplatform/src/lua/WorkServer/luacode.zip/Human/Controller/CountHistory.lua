
module("CountHistory", package.seeall)


function execute(packetID, operateID, buffer)

	local cgmsg = msg_human2_pb.cgcounthistory()
	local gcmsg = msg_human2_pb.gccounthistory()
	
	cgmsg:ParseFromString(buffer)
	local pInfo = PlayerModel.GetPlayerInfo(cgmsg.userid)
	if pInfo == nil then
		gcmsg.result = ReturnCode["player_not_exist"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
	end
	local starttime = cgmsg.starttime or 0
    local endtime = cgmsg.endtime or TimeUtils.GetTime()

    
	--local sqlCase = "select drawmtype, orderid, drawjetton, rsdate, state from ag_drawmoney where userid=".. cgmsg.userid.." order by id desc"
	local sqlCase = "select * from ag_drawmoney where userid=".. cgmsg.userid.." and  rsdate  >= '"..TimeUtils.GetTimeString(starttime) .. "' and  rsdate <= '" ..TimeUtils.GetTimeString(endtime).."' and taketype= 0 order by id desc"

    mysqlItem:executeQuery(sqlCase)
	
	local counter = 1
	local startPos = 20*(cgmsg.pagenum - 1) + 1
	local endPos = 20*cgmsg.pagenum
	while true do
		
		local sqlData = mysqlItem:fetch({})
		if sqlData == nil then
			break
		end
		if counter >= startPos then
			gcmsg.counttype:append(tonumber(sqlData[18]))
			gcmsg.countcode:append(sqlData[17])
			gcmsg.txcount:append(tonumber(sqlData[9]))
			gcmsg.counttime:append(sqlData[22])
			gcmsg.countstate:append(tonumber(sqlData[7]))
			
			if tonumber(sqlData[18]) == 1 then
				gcmsg.nikename:append(tostring(sqlData[19]))
				gcmsg.account:append(tostring(sqlData[13]))
			elseif tonumber(sqlData[18]) == 2 then
				gcmsg.nikename:append(tostring(sqlData[20]))
				gcmsg.account:append(tostring(sqlData[14]))
			end
			gcmsg.servicecharge:append(tonumber(sqlData[24]))
			gcmsg.actualcount:append(tonumber(sqlData[6]))
			gcmsg.applytime:append(tostring(TimeUtils.GetTime(sqlData[8])))
			gcmsg.msg:append(sqlData[23])
			
		end
		if counter >= endPos then
			break
		end
		counter = counter + 1
	end

	gcmsg.result = 0
	return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
end






