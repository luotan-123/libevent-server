
module("BankruptSubsidy", package.seeall)

--1.检查用户是否存在缓存中，如果缓存中有，就从缓存中取需要的数据，如果缓存中
--没有就从数据库拉去，并且保存到缓存中
--2.如果用户资料不存在，则创建用户
--3.对用户登录情况进行统计
function execute(packetID, operateID, buffer)

	local cgmsg = msg_human_pb.cgbankruptsubsidy()
	local gcmsg = msg_human_pb.gcbankruptsubsidy()

	cgmsg:ParseFromString(buffer)

	local pInfo = PlayerModel.GetPlayerInfo(cgmsg.userid)
	if pInfo == nil then
		gcmsg.result = ReturnCode["player_not_exist"]
		return cgmsg.userid, gcmsg.result, gcmsg:ByteSize(), gcmsg:SerializeToString()
	end
	
	--轩辕没有破产补助
	if true then
		gcmsg.result = ReturnCode["race_not_exist"]
		return cgmsg.userid, 0, gcmsg:ByteSize(), gcmsg:SerializeToString()
	end
	
	if cgmsg.requesttype == 1 then
		local brokeNum = redisItem:hget(MissionModel.bankrupt_key, pInfo.userid, MissionModel.redis_index)
		brokeNum = brokeNum == nil and 0 or tonumber(brokeNum)
		gcmsg.residuenum = g_bankruptSubsidy.SubsidyNum - brokeNum
		gcmsg.subsidycount = 1
	else
		local ret, residuenum, subsidycount = MissionModel.BankruptCheck(pInfo)
		if ret ~= 0 then
			gcmsg.result = ret
			return cgmsg.userid, 0, gcmsg:ByteSize(), gcmsg:SerializeToString()
		end
		gcmsg.residuenum = g_bankruptSubsidy.SubsidyNum - residuenum
		gcmsg.subsidycount = subsidycount
	end
	
	gcmsg.result = 0
	gcmsg.userid = cgmsg.userid
	gcmsg.requesttype = cgmsg.requesttype
	
	return cgmsg.userid, 0, gcmsg:ByteSize(), gcmsg:SerializeToString()

end