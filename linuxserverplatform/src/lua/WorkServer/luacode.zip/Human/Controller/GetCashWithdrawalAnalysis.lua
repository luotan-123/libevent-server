module("GetCashWithdrawalAnalysis", package.seeall)

function execute(packetID, operateID, buffer)
    --print("GetCashWithdrawalAnalysis")

	local cgmsg = msg_human2_pb.cggetcashwithdrawalanalysis()
	local gcmsg = msg_human2_pb.gcgetcashwithdrawalanalysis()

	cgmsg:ParseFromString(buffer)
	local checkMsg = RedisHelper.CheckRedis(cgmsg.userid, operateID)
	
	if checkMsg ~= nil then
		gcmsg:ParseFromString(checkMsg)
		LogBehavior.Warning(cgmsg.userid, "pInfo", "GetCashWithdrawalList", 0, "缓存已存在")
		return cgmsg.userid, 0, gcmsg:ByteSize(), gcmsg:SerializeToString()
	end
	
    local pInfo = PlayerModel.GetPlayerInfo(cgmsg.userid)
    if pInfo == nil then
        gcmsg.result = ReturnCode["player_not_exist"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
    end

    if tonumber(cgmsg.fee ) < 0 or  (tonumber(cgmsg.amount ) or 0) < 0  or  (tonumber(cgmsg.amount ) or 0) >  tonumber(pInfo.jetton)  then
        gcmsg.result = 0
	    return cgmsg.userid, 0, gcmsg:ByteSize(), gcmsg:SerializeToString()
    end

    if cgmsg.amount == nil or cgmsg.amount == "" then
        cgmsg.amount  = "0"
    end

    local freeamount = FootballModel.SetUserCashFreeAmount(cgmsg.userid,0)
    local prechannel = GameUtils.GetChannel_login(pInfo.channel)
    local viprulepb =  VipMgrModel.GetVipRule(pInfo.viplevel,prechannel)
    local viprule = st_vipmgr_pb.viprule()
    if viprulepb ~= nil then
        viprule:ParseFromString(viprulepb)
        --freeamount = viprule.freedrawamount
    end
    
    local feecount      =  tonumber(cgmsg.amount) <=  freeamount and 0 or (tonumber(cgmsg.amount) -  freeamount) * tonumber(cgmsg.fee) * 0.01
    local freefeecount  = tonumber(cgmsg.amount) * tonumber(cgmsg.fee) * 0.01 -  feecount
    local getamount     = pInfo.jetton
    local nogetamount   = pInfo.tyjetton
    local cashamount    = tonumber(cgmsg.amount) - feecount

    gcmsg.feecount      =  feecount    
    gcmsg.freefeecount  =  freefeecount
    gcmsg.getamount     =  getamount   
    gcmsg.nogetamount   =  nogetamount 
    gcmsg.cashamount    =  tostring(cashamount)  
    gcmsg.freeamount    = tostring(freeamount)

	gcmsg.result = 0
	return cgmsg.userid, 0, gcmsg:ByteSize(), gcmsg:SerializeToString()
end