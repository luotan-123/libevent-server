module("GetCpGameHistroy", package.seeall)

function execute(packetID, operateID, buffer)

	local cgmsg = msg_human3_pb.cggetcpgamehistroy()
	local gcmsg = msg_human3_pb.gcgetcpgamehistroy()

	cgmsg:ParseFromString(buffer)

    local pInfo = PlayerModel.GetPlayerInfo(cgmsg.userid)
    if pInfo == nil then
        gcmsg.result = ReturnCode["player_not_exist"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
    end
    local starttime = cgmsg.starttime ~= 0 and   cgmsg.starttime or 0
    local endtime = cgmsg.endtime ~= 0 and   cgmsg.endtime or TimeUtils.GetTime()
   
	local sqlCase = ""
	if cgmsg.gametype == 0 then
		sqlCase = "select * from dy_qpgameorder where state=1 and userid = "..pInfo.userid.." and createtime >= "..starttime
			.." and createtime <= "..endtime.." order by id desc limit ".. (20 * (cgmsg.pagenum - 1))..", 20"
	else
		sqlCase = "select * from dy_qpgameorder where state=1 and userid = "..pInfo.userid.." and createtime >= "..starttime
			.." and createtime <= "..endtime .." and gametype="..cgmsg.gametype.." order by id desc limit ".. (20 * (cgmsg.pagenum - 1))..", 20"
	end
    
    mysqlItem:executeQuery(sqlCase)
    while true do
		local sqlData =  mysqlItem:fetch({})
        if sqlData == nil then
			break
        end
		
		gcmsg.gametype:append(tonumber(sqlData[5]))
		gcmsg.gid:append(sqlData[3])
		gcmsg.date:append(sqlData[9])
		gcmsg.pourcount:append(tonumber(sqlData[7]))
		gcmsg.pourdata:append(sqlData[19])
		gcmsg.wincount:append(tonumber(sqlData[11]))
		
	end
		
    gcmsg.userid = cgmsg.userid
    gcmsg.pagenum = cgmsg.pagenum
    gcmsg.starttime = cgmsg.starttime
    gcmsg.endtime = cgmsg.endtime
    gcmsg.result = 0
	return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
end