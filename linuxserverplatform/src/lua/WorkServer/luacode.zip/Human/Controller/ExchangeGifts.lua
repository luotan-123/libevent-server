module("ExchangeGifts", package.seeall)

--获取用户的奖励

function execute(packetID, operateID, buffer)
	
	local cgmsg = msg_user_pb.cgexchangegifts()
	local gcmsg = msg_user_pb.gcexchangegifts()
	cgmsg:ParseFromString(buffer)

	local checkMsg = RedisHelper.CheckRedis(cgmsg.userid, operateID)
	if checkMsg ~= nil then
		gcmsg:ParseFromString(checkMsg)
		LogBehavior.Warning(cgmsg.userid, "mail", "GetMailGoods", 0, "重复发送领取邮件物品协议，mailid="..cgmsg.mailid)
		return cgmsg.userid, 0, gcmsg:ByteSize(), gcmsg:SerializeToString()
	end

	gcmsg.result = 0
	return cgmsg.userid, 0, gcmsg:ByteSize(), gcmsg:SerializeToString()
	
end



