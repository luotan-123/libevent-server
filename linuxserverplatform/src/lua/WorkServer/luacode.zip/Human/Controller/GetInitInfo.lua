
module("GetInitInfo", package.seeall)


function execute(packetID, operateID, buffer)

	local cgmsg = msg_human_pb.cggetinitinfo()
	local gcmsg = msg_human_pb.gcgetinitinfo()
	
	cgmsg:ParseFromString(buffer)
	
	local pInfo = PlayerModel.GetPlayerInfo(cgmsg.userid)
	ShopService.Init(cgmsg,gcmsg)
	local gameStateList = GameModel.GetGameStateList()
	for k,v in pairs(gameStateList) do
        if v ~=  nil then
            local str = luajson.decode(v)
            gcmsg.mdelist:append(tonumber(k))
            if tonumber(str["clientstate"]) == 3 and tonumber(k) >= 9200 and tonumber(k) <= 9232 then
                --热门 彩票
                gcmsg.hotmdelist:append(tonumber(k))
            end

            if pInfo.channel == g_SpecialChannel then
			    gcmsg.modelstatelist:append(1)
		    else
			    gcmsg.modelstatelist:append(tonumber(str["state"]))
                gcmsg.namelist:append(str["gamename"])
		    end
        end

	end
	


	if g_servername == "run_gdmj" or g_servername == "run_test" or g_servername == "run_zsmj" then
		gcmsg.wechatlist:append("gdmj918")
	end
	
	gcmsg.result = 0
	return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
end