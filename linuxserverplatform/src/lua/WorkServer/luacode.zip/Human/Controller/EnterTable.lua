--进入小马快跑


module("EnterTable", package.seeall)

--总共六位数的房间号：100000 ~ 999999  最大数字数这个

--10W ~ 12W   是广东麻将的
--12W ~ 14W   是湖北麻将的
--14W ~ 15W   是牛牛的
--15W ~ 16W   是欢乐赢豆的
--16W ~ 17W   是火锅英雄的
--17W ~ 18W   是竞技场
--18W ~ 19W   是十点半
--19W ~ 20W   是斗牛

function execute(packetID, operateID, buffer)

	local cgmsg = msg_human_pb.cgentertable()
	local gcmsg = msg_human_pb.gcentertable()
	cgmsg:ParseFromString(buffer)
	if cgmsg.entertype == 1 then
		local isFriendRoom = false 
		if cgmsg.tableid >= 2090000 and cgmsg.tableid < 2100000 then	 --牛牛
			isFriendRoom = true
        elseif cgmsg.tableid >= g_lhdDefine.friend_tableid[1] and cgmsg.tableid <= g_lhdDefine.friend_tableid[2] then --龙虎斗
			isFriendRoom = true
		end
		
		if isFriendRoom == false then
			gcmsg.result = ReturnCode["table_not_exist"]
			return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
		end
	end
	local controller = nil
	local retPacketID = 0
	local tempPacketID = 0
	if cgmsg.tableid < 100000 then
		
	elseif cgmsg.tableid < 120000 then
		tempPacketID = 2201
	elseif cgmsg.tableid < 140000 then
		tempPacketID = 2801
	elseif cgmsg.tableid < 150000 then
	elseif cgmsg.tableid < 160000 then
		tempPacketID = 2001
	elseif cgmsg.tableid < 170000 then  --火锅英雄
		tempPacketID = 2701
	elseif cgmsg.tableid < 180000 then  --竞技场
	elseif cgmsg.tableid < 190000 then  --十点半
		tempPacketID = 2901
	elseif cgmsg.tableid < 200000 then  --房卡斗牛
		tempPacketID = 3010
	elseif cgmsg.tableid < 210000 then  --三公
		tempPacketID = 3101
	elseif cgmsg.tableid < 230000 then   --斗地主
		tempPacketID = 3905
	elseif cgmsg.tableid < 2020000 then  --森林舞会
		tempPacketID = 3501 
	elseif cgmsg.tableid < 2030000 then  --水果机
		tempPacketID = 3601
	elseif cgmsg.tableid < 2040000 then  --时时彩
		tempPacketID = 3010
	elseif cgmsg.tableid < 2050000 then  -- 二人梭哈
		tempPacketID = 4110
	elseif cgmsg.tableid < 2060000 then  --百人牛牛
		tempPacketID = 2501
	elseif cgmsg.tableid < 2070000 then -- 百家乐
		tempPacketID = 4401	
	elseif cgmsg.tableid < 2080000 then	-- 奔驰宝马
		tempPacketID = 4202
	elseif cgmsg.tableid < 2090000 then	-- 飞禽走兽
		tempPacketID = 4302
	elseif cgmsg.tableid < 2100000 then	-- 二人牛牛
		tempPacketID = 3010
	elseif cgmsg.tableid < 2120000 then --拼三张
		tempPacketID = 3309	
	elseif cgmsg.tableid < 2130000 then -- 连环夺宝
		tempPacketID = 4501
	elseif cgmsg.tableid < 2140000 then -- 糖果派对
		tempPacketID = 4601
	elseif cgmsg.tableid < 2150000 then -- 李逵劈鱼
		tempPacketID = 4701
	elseif cgmsg.tableid < 2160000 then -- 摇钱树
		tempPacketID = 4901 
    elseif cgmsg.tableid < 2170000 then  --跑得快
        tempPacketID = 5105 
    elseif cgmsg.tableid < 2180000 then -- 红黑大战
		tempPacketID = 3701
    elseif cgmsg.tableid < 2190000 then -- 龙虎斗
		tempPacketID = 5301
    elseif cgmsg.tableid < 2200000 then -- 彩金明牌 2191001
		tempPacketID = 5401
    elseif cgmsg.tableid < 2210000 then -- 骰宝 2201001
		tempPacketID = 5601
    elseif cgmsg.tableid < 2220000 then -- 视讯 2210001
		tempPacketID = 5801
	elseif cgmsg.tableid < 2240000 then  --德州扑克
		tempPacketID = 5701
    elseif cgmsg.tableid < 2260000 then  --彩票类 224w ~ 226W 
        
        if cgmsg.tableid < 2242000 then --幸运飞艇 
            tempPacketID = 6101
        elseif cgmsg.tableid < 2243000  then --香港六合彩
            tempPacketID = 6201
        elseif cgmsg.tableid < 2244000  then --北京赛车
            tempPacketID = 6301 
        end
	elseif cgmsg.tableid < 2270000 then
		tempPacketID = 7101
	elseif cgmsg.tableid < 2280000 then
		tempPacketID = 7201
	elseif cgmsg.tableid < 2290000 then
		tempPacketID = 3101
	elseif cgmsg.tableid < 2300000 then
		tempPacketID = 7401
	elseif cgmsg.tableid < 2400000 then
		tempPacketID = 2201
	elseif cgmsg.tableid < 2500000 then
		tempPacketID = 2801
    elseif cgmsg.tableid < 2510000 then
		tempPacketID = 7501  --百人推筒子
	end


	retPacketID, controller = tcpManager:createController(tempPacketID)

	if controller ~= nil then
		
		local playerID, retCode, retBufferLen, retString, otString = controller.execute(tempPacketID, operateID, buffer, true)
		SendMessage(cgmsg.userid,retPacketID, retBufferLen, retString)
	else
		gcmsg.result = ReturnCode["table_not_exist"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
	end
	return cgmsg.userid, 0 , 0, gcmsg:SerializeToString()
end