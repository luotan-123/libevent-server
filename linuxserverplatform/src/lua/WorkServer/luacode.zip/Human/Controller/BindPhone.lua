

module("BindPhone", package.seeall)

--1.检查用户是否存在缓存中，如果缓存中有，就从缓存中取需要的数据，如果缓存中
--没有就从数据库拉去，并且保存到缓存中
--2.如果用户资料不存在，则创建用户
--3.对用户登录情况进行统计
function execute(packetID, operateID, buffer)

	local cgmsg = msg_human2_pb.cgbindphone()
	local gcmsg = msg_human2_pb.gcbindphone()

	cgmsg:ParseFromString(buffer)
	local checkMsg = RedisHelper.CheckRedis(cgmsg.userid,operateID)
	if checkMsg ~= nil then
		gcmsg:ParseFromString(checkMsg)
		return cgmsg.userid,0,gcmsg:ByteSize(),gcmsg:SerializeToString()
	end
	
	local pInfo = PlayerModel.GetPlayerInfo(cgmsg.userid)
	if pInfo == nil then
		gcmsg.result = ReturnCode["player_not_exist"]
		return cgmsg.userid, 0, gcmsg:ByteSize(), gcmsg:SerializeToString()
	end
	
	if cgmsg.phonenumber == "" or cgmsg.authcode == "" then
		gcmsg.result = ReturnCode["phone_code_notexit"]
		return cgmsg.userid, 0, gcmsg:ByteSize(), gcmsg:SerializeToString()
	end
	
	if pInfo.phonenum ~= "" then
		gcmsg.result = ReturnCode["bin_count_error_2"]
		return cgmsg.userid, 0, gcmsg:ByteSize(), gcmsg:SerializeToString()
	end
	local prechannel =  GameUtils.GetChannel_login(pInfo.channel)
	local sqlCase = "select userid from dy_player where phonenum="..cgmsg.phonenumber.." and prechannel = '"..prechannel.."'"
	mysqlItem:executeQuery(sqlCase)
	
	local sqlData = mysqlItem:fetch()
	
	if sqlData ~= nil then
		gcmsg.result = ReturnCode["phone_bind_error_1"]
		return cgmsg.userid, 0, gcmsg:ByteSize(), gcmsg:SerializeToString()
	end
	
	
	local sqlCase = "select * from dy_authcode where phonenum='"..cgmsg.phonenumber.."' and code="..cgmsg.authcode.." and prechannel = '"..prechannel .. "' order by id desc"

	mysqlItem:executeQuery(sqlCase)
	local sqlData = mysqlItem:fetch({})
	if sqlData == nil then
		gcmsg.result = ReturnCode["phone_code_notexit"]
		return cgmsg.userid, 0, gcmsg:ByteSize(), gcmsg:SerializeToString()
	end

    local state = tonumber(sqlData[5])
    local codeid = tonumber(sqlData[1])

    if state == 1 then
	    gcmsg.result = ReturnCode["phone_code_notexit"]
	    return 0,0,gcmsg:ByteSize(),gcmsg:SerializeToString()
    end
	
	local startTime = tonumber(sqlData[3])
	local nowTime = TimeUtils.GetTime()
	if (nowTime - startTime) > 300 then
		gcmsg.result = ReturnCode["phone_code_pastdue"]
		return cgmsg.userid, 0, gcmsg:ByteSize(), gcmsg:SerializeToString()
	end
	
	
	
	if cgmsg.password == '' then
		--表示密码也需要同步
		local sqlCase = "update dy_player set phonenum="..cgmsg.phonenumber.." where userid="..cgmsg.userid
		mysqlItem:executeQuery(sqlCase)		
	else
		pInfo.password = md5( cgmsg.password )
		local sqlCase = "update dy_player set phonenum="..cgmsg.phonenumber..",password='"..pInfo.password.."' where userid="..cgmsg.userid
		mysqlItem:executeQuery(sqlCase)				
	end
	
    local sqlCase = "update  dy_authcode set state = 1 where id = "..codeid
    mysqlItem:execute(sqlCase)

	pInfo.phonenum = cgmsg.phonenumber
	PlayerModel.SetPlayerInfo(pInfo)
	PlayerModel.SendPlayerInfo(pInfo,{"phonenum"})
	gcmsg.phonenumber = cgmsg.phonenumber
	gcmsg.userid = cgmsg.userid
	gcmsg.result = 0
	
	local tJson = {}
	table.insert(tJson, pInfo.password)
	table.insert(tJson, pInfo.userid)
	redisItem:set("account"..pInfo.account, luajson.encode(tJson), PlayerModel.redis_index)	
	
    --PlayerStatsModel.tyjettonmgr(pInfo,1,TimeUtils.GetTime())
	
    local content = "用户【"..pInfo.userid.."】绑定【"..pInfo.userid.."】手机号"
    local prechannel = GameUtils.GetChannel_login(pInfo.channel)
    local sqlCase = "insert into log_riskaction (userid,action,logintype,opttime,optname,optid,content,channel,prechannel)values("..cgmsg.userid..",".. 1 ..",'"..pInfo.oprsys.."','"..TimeUtils.GetTimeString().."','"..pInfo.nickname.."',"..cgmsg.userid..",'"..content.." ','"..pInfo.channel.."','"..prechannel.."')"
    mysqlLog:execute(sqlCase)
    local sqlCase = " insert into log_player_risk(userid,change_phone) values ( " ..pInfo.userid..","..1 ..")  ON DUPLICATE KEY update change_phone=change_phone + ".. 1
    --print(sqlCase)
    LogModel.LogUserGameDetail(sqlCase)	
    TaskService.checkTask(pInfo,1)
    --绑定手机
    LogDispatch.lognewplayerbehavior(pInfo.userid, 0, 1, 0, 0, 0, 0) 

--    local tyjetton = FootballModel.GetTiYanInitAmount()
--    if tyjetton > 0 then
--        PlayerModel.AddTyJetton(pInfo, tyjetton)

--        local remark = "绑定手机赠送体验金"
--        LogServer.addRecords(pInfo.userid,1,remark,tonumber(tyjetton))

--        local season = g_moneyOptType.opt_tybind
--        local msg = "玩家绑定手机号码赠送体验金"..(tyjetton * 0.01).."元"
--        LogServer.GameUserMoney(pInfo, g_footballgameDefine.game_type, 1, tonumber(tyjetton), msg, 0,0,season)

--    end

	
	--PlayerModel.AddJetton(pInfo, 300, "bind","绑定手机赠送")
	
	--LogDispatch.RegisterAward(pInfo, 300)
	return cgmsg.userid, 0, gcmsg:ByteSize(), gcmsg:SerializeToString()

end