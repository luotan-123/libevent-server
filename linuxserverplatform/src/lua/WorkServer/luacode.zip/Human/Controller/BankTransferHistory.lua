module("BankTransferHistory", package.seeall)

function execute(packetID, operateID, buffer)
	local cgmsg = msg_human_pb.cgbanktransferhistory()
	local gcmsg = msg_human_pb.gcbanktransferhistory()
	cgmsg:ParseFromString(buffer)
	
	repeat
		local pInfo = PlayerModel.GetPlayerInfo(cgmsg.userid)
		if nil == pInfo then
			gcmsg.result = ReturnCode["user_not_exist"]
			break
		end
		
		--[[if 0 == string.len(pInfo.bank_password) then
			gcmsg.result  = ReturnCode["bank_pwd_never_set"]
			break
		end]]
		
		local list = BankModel.GetTransferHistory(cgmsg.userid, cgmsg.pagenum)
		for _, v in ipairs(list) do
			local item = gcmsg.list:add()
			item:ParseFromString(v)
		end
		
		gcmsg.result = 0
		
	until true
	
	return cgmsg.userid, 0, gcmsg:ByteSize(), gcmsg:SerializeToString()
end