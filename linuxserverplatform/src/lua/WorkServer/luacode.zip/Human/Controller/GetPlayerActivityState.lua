
module("GetPlayerActivityState", package.seeall)

function execute(packetID, operateID, buffer)

	local cgmsg = msg_human3_pb.cggetplayeractivitystate()
	local gcmsg = msg_human3_pb.gcgetplayeractivitystate()

	cgmsg:ParseFromString(buffer)
	local checkMsg = RedisHelper.CheckRedis(cgmsg.userid, operateID)
	
	if checkMsg ~= nil then
		gcmsg:ParseFromString(checkMsg)
		return cgmsg.userid, 0, gcmsg:ByteSize(), gcmsg:SerializeToString()
	end
	
	
	for k,v in ipairs(cgmsg.activitylist) do
		gcmsg.activitylist:append(v)
		if v == "schl" then
			--先查看玩家是否又已经充过值
			local sqlCase = "select payamount from log_player where	userid="..cgmsg.userid
			mysqlLog:executeQuery(sqlCase)
			local sqlData = mysqlLog:fetch()
			if tonumber(sqlData) == 0 then
				gcmsg.activitystate:append(0)
			else
				local sqlCase = "select * from log_activity_record where userid="..cgmsg.userid.." and activityname='schl'"
				mysqlLog:executeQuery(sqlCase)
				local sqlData = mysqlLog:fetch()
				if sqlData == nil then
					gcmsg.activitystate:append(2)
				else
					gcmsg.activitystate:append(1)
				end
			end
		else
			gcmsg.activitystate:append(0)
		end
	end
	
	gcmsg.userid = cgmsg.userid
	gcmsg.result = 0
	return cgmsg.userid, 0, gcmsg:ByteSize(), gcmsg:SerializeToString()

end
