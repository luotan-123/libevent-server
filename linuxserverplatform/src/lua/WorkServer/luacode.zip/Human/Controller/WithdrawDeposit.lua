
module("WithdrawDeposit", package.seeall)


function execute(packetID, operateID, buffer)

	local cgmsg = msg_human2_pb.cgwithdrawdeposit()
	local gcmsg = msg_human2_pb.gcwithdrawdeposit()
	
	cgmsg:ParseFromString(buffer)

	local pInfo = PlayerModel.GetPlayerInfo(cgmsg.userid)
	if pInfo == nil then
		gcmsg.result = ReturnCode["player_not_exist"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
	end
	
	local tableid = PlayerModel.GetCurrTableID(cgmsg.userid)
	if tableid ~= 0 then
		gcmsg.result = ReturnCode["function_limit"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
	end
	
	if pInfo.silent == 1 then
		gcmsg.result = ReturnCode["function_limit"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
	end
	

	if PlayerModel.CheckTestUserLimit(pInfo,g_test_userfunc_limit[6])  then
        --测试用户不能提现
        gcmsg.result = ReturnCode["test_user_funclimit"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
    end

    local sqlCase = "select bank_password from dy_player where userid =  "..cgmsg.userid 
    mysqlItem:executeQuery(sqlCase)
    local sqlData1 = mysqlItem:fetch()
    if sqlData1 ~= nil and sqlData1 ~= cgmsg.pwd then
        gcmsg.result =  ReturnCode["bank_pwd_error"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()	
    end
      	 
	
    local sqlCase = "select * from dy_drawconf where state = 1 and drawid = "..cgmsg.infotype
    mysqlItem:executeQuery(sqlCase)
    local sqlData1 = mysqlItem:fetch({})
	if sqlData1 == nil then
		gcmsg.result = ReturnCode["Tx_error_3"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()	
	end
    
    --------------------------------流水和场次限制-----------------------------------------------------------
    local dict = {draw_racearchi_count=0, draw_gamearchi_count=0, draw_race_ordercount=0}

    local prechannel = GameUtils.GetChannel_login(pInfo.channel)
    local sqlCase = "select dict_category,dict_value from web_dict where dict_group  = 'draw' and  prechannel = '" ..prechannel.."' and enable_status = ".. 1 ..""    
    mysqlItem:execute(sqlCase)
    while true do
        local sqlData = mysqlItem:fetch({})
        if sqlData == nil then
            break
        end
        dict[sqlData[1]] = tonumber(sqlData[2])
    end
    ---查询流水和赛事场次
    local sqlCase = "select achamount,achgameamount,ordercount from log_player where userid = "..cgmsg.userid

    mysqlLog:executeQuery(sqlCase)
    local sqlData = mysqlLog:fetch({})
    local achamount = 0     --赛事总流水
    local achgameamount = 0 --游戏总流水
    local ordercount = 0    --赛事总场次
    if sqlData ~= nil then
        achamount     = tonumber(sqlData[1]) or 0
        achgameamount = tonumber(sqlData[2]) or 0
        ordercount    = tonumber(sqlData[3]) or 0   
    end


    local cur_achamount      =  PlayerModel.GetUserLastRechargeRaceAchi(cgmsg.userid)       --最后一次充值后 赛事总流水
    local cur_achgameamount  =  PlayerModel.GetUserLastRechargeGameAchi(cgmsg.userid)       --最后一次充值后 游戏总流水
    local cur_ordercount     =  PlayerModel.GetUserLastRechargeRaceOrdercount(cgmsg.userid) --最后一次充值后 赛事总场次
    local TxCount            =  PlayerModel.GetUserLastRechargeTxCount(cgmsg.userid)        --最后一次充值后 已提现值
    
    local gameachilimit = 0
    if dict.draw_gamearchi_count  > 0 then
        --游戏流水限制
        if (cgmsg.txcount + TxCount) * dict.draw_gamearchi_count > achgameamount - cur_achgameamount then
            --游戏流水不满足
            gameachilimit  = -1
        else
            gameachilimit = 1
        end
    end

    local raceachilimit = 0 
    local ordercountlimit = 0
    if dict.draw_racearchi_count  > 0 then
        --赛事流水限制
        if (cgmsg.txcount + TxCount) * dict.draw_racearchi_count > achamount - cur_achamount then
            --赛事流水不满足
            raceachilimit  = -1
        else
            raceachilimit  = 1
        end
        if raceachilimit == 1 then
            if dict.draw_race_ordercount > 0 then
                if ordercount - cur_ordercount < dict.draw_race_ordercount  then
                    ordercountlimit = -1
                else
                    ordercountlimit = 1
                end
            end
        end
    end

    if (gameachilimit == -1 and raceachilimit ~= 1) or (gameachilimit ~= 1 and raceachilimit == -1) or (gameachilimit == -1 and raceachilimit == -1) then
        gcmsg.result = ReturnCode["archi_not_enought"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
    end

    if raceachilimit == 1 and  ordercountlimit == -1 then
        gcmsg.result = ReturnCode["ordercount_not_enought"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
    end

    ------------------------------------------------------------------------------------------------------------------------
    local sqlCase = "select * from dy_authcode where phonenum='"..pInfo.phonenum.."' and code="..cgmsg.vcode.." and prechannel = '"..prechannel.."' order by id desc"
	mysqlItem:executeQuery(sqlCase)
	local sqlData = mysqlItem:fetch({})
	if sqlData == nil then
		gcmsg.result = ReturnCode["phone_code_notexit"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()	
	end

	local codestate = tonumber(sqlData[5])
    local codeid = tonumber(sqlData[1])

    if codestate == 1 then
	    gcmsg.result = ReturnCode["phone_code_notexit"]
	    return 0,0,gcmsg:ByteSize(),gcmsg:SerializeToString()
    end
    	
	local startTime = tonumber(sqlData[3])
	local nowTime = TimeUtils.GetTime()
	if (nowTime - startTime) > 600 then
		gcmsg.result = ReturnCode["phone_code_pastdue"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()	
	end

    local feerate = 0 --
    local freeamount = FootballModel.SetUserCashFreeAmount(cgmsg.userid,0)
    local prechannel = GameUtils.GetChannel_login(pInfo.channel)
    local viprulepb =  VipMgrModel.GetVipRule(pInfo.viplevel,prechannel)
    local viprule = st_vipmgr_pb.viprule()
    if viprulepb ~= nil then
        viprule:ParseFromString(viprulepb)
        feerate = viprule.drawfee 
        --freeamount = viprule.freedrawamount
    end


    local minjetton = tonumber(sqlData1[13]) -- 最小提现金币 
    --local feerate = tonumber(sqlData1[12]) --手续费
    local retain = tonumber(sqlData1[15]) --最小保留金币


    --提现要留钱
	if tonumber(pInfo.jetton) < (cgmsg.txcount + retain) then
		gcmsg.result = ReturnCode["Tx_error_1"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
	end
    
    --最小提现额度
	if cgmsg.txcount < minjetton then
		gcmsg.result = ReturnCode["Tx_error_1"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
	end
	
    local bindBankacountList = {} --已注册的银行卡账号
	local sqlCase = "select * from ag_player where userid=".. cgmsg.userid
	mysqlItem:executeQuery(sqlCase)


	local sqlData = mysqlItem:fetch({})
	if sqlData == nil then
		gcmsg.result = ReturnCode["Tx_error_2"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
	end
    if sqlData[27] ~= "" then
        --ag_player中的银行卡
        local temp ={bankacount = sqlData[27],
	                 bankname = sqlData[28],
	                 bankaddress = sqlData[29],
	                 bankpayee = sqlData[32],
	                 bankprovince = sqlData[43],
	                 bankcity = sqlData[44],
	                 bankidnumber = sqlData[45]}
        table.insert(bindBankacountList,temp)
    end


    local bankacount = ""
	local bankname = ""
	local bankaddress = ""
	local bankpayee = ""
	local bankprovince = ""
	local bankcity = ""
	local bankidnumber = ""


	if cgmsg.infotype == 1 then
		if sqlData[33] == "" then
			gcmsg.result = ReturnCode["Tx_error_4"]
			return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
		end
		
	else
        --银行卡提现
        local sqlCase = " select  * from dy_extrabanks where userid ="..cgmsg.userid
        mysqlItem:executeQuery(sqlCase) 
        while true do
            local sqlData_ex = mysqlItem:fetch({})
            if sqlData_ex == nil then
                break
            end
            local temp ={
                bankacount   = sqlData_ex[3],
	            bankname     = sqlData_ex[4],
	            bankaddress  = sqlData_ex[5],
	            bankpayee    = sqlData_ex[11],
	            bankprovince = sqlData_ex[6],
	            bankcity     = sqlData_ex[7],
	            bankidnumber = sqlData_ex[8]}
            table.insert(bindBankacountList,temp)

        end
        local bindex = 0
        for k,v in pairs(bindBankacountList) do
            if v["bankacount"] == cgmsg.bankaccount then
                bindex = k
                break
            end
        end

        if bindex == 0 then
            gcmsg.result = ReturnCode["Tx_error_4"]
			return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
        end

        bankacount      =   bindBankacountList[bindex]["bankacount"] 
        bankname        =   bindBankacountList[bindex]["bankname"]
        bankaddress     =   bindBankacountList[bindex]["bankaddress"] or ""
        bankpayee       =   bindBankacountList[bindex]["bankpayee"] 
        bankprovince    =   bindBankacountList[bindex]["bankprovince"] or ""
        bankcity        =   bindBankacountList[bindex]["bankcity"] or ""
        bankidnumber    =   bindBankacountList[bindex]["bankidnumber"] or ""

	end
	
	local userid = cgmsg.userid
	local nickname = pInfo.nickname
	local phone = sqlData[6]
	local wechat = sqlData[7]
	local state = 1
	local drawjetton = cgmsg.txcount
	local realname = ""
	local alipay = sqlData[33]
	local drawmtype = cgmsg.infotype
	local alipaypayee = sqlData[34]
	local drawnum = drawjetton 
	local ratenum = 0

	--计算
    --免费提现额度
    --local freeamount = FootballModel.SetUserCashFreeAmount(cgmsg.userid,0)

    --已减免的手续费
    local freefeecount = 0
    --使用免费提现额度
    local payfreeamount = 0

	--local userDrawNum = GetUserDrawNum(cgmsg.userid) + 1
	--if userDrawNum > 1 then
		--ratenum = cgmsg.txcount * 0.02
        --手续费
        ratenum =  (tonumber(cgmsg.txcount) <=  freeamount) and 0 or (tonumber(cgmsg.txcount) -  freeamount) * feerate * 0.01

        payfreeamount = (tonumber(cgmsg.txcount) <=  freeamount) and tonumber(cgmsg.txcount) or freeamount
        if payfreeamount < 0  then
            payfreeamount = 0
        end

        --实际到账
		drawnum = drawnum - ratenum

        freefeecount  = tonumber(cgmsg.txcount) * feerate * 0.01 -  ratenum

	--end

	local orderid = TimeUtils.GetTime()..cgmsg.userid..math.myrandom(100,999)
	local prechannel = GameUtils.GetChannel_login(pInfo.channel)
	local sqlCase = "insert ag_drawmoney(userid, nickname, phone, wechat, drawnum, state, drawjetton, realname, alipay, bankacount, bankname, bankaddress, orderid, drawmtype, alipaypayee, bankpayee, ratenum, bankprovince, bankcity, bankidnumber,channel,prechannel,freefeecount,payfreeamount) values("
		.."'"..userid.."'"..", ".."'"..nickname.."'"..", ".."'"..phone.."'"..", ".."'"..wechat.."'"..", ".."'"..drawnum.."'"..", "
		.."'"..state.."'"..", ".."'"..drawjetton.."'"..", ".."'"..realname.."'"..", ".."'"..alipay.."'"..", ".."'"..bankacount.."'"..", "
		.."'"..bankname.."'"..", ".."'"..bankaddress.."'"..", ".."'"..orderid.."'"..", ".."'"..drawmtype.."'"..", ".."'"..alipaypayee.."'"..
		", ".."'"..bankpayee.."'"..", ".."'"..ratenum.."'"..",".."'"..bankprovince.."'"..",".."'"..bankcity.."'"..",".."'"..bankidnumber.."','"
		..pInfo.channel.."','"..prechannel.."',"..freefeecount..","..payfreeamount..")"
	mysqlItem:executeQuery(sqlCase)
	
	local sqlCase = "select id from ag_drawmoney where orderid="..orderid
	mysqlItem:executeQuery(sqlCase)
	local sqlData = mysqlItem:fetch()
	if sqlData == nil then
		gcmsg.result = ReturnCode["Tx_error_3"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
	end
    --扣除免费提现额度
    FootballModel.SetUserCashFreeAmount(cgmsg.userid,0-payfreeamount)
	
    --交易记录
    local remark = "申请提现"
    LogServer.addRecords(pInfo.userid,2,remark,0 - tonumber(drawjetton))

	PlayerModel.DecJetton(pInfo,cgmsg.txcount,"WithdrawDeposit","WithdrawDeposit")
	PlayerModel.SetPlayerInfo(pInfo)
	PlayerModel.SendJetton(pInfo)
	
    local sqlCase = "update  dy_authcode set state = 1 where id = "..codeid
    mysqlItem:execute(sqlCase)
    PlayerModel.SetUserLastRechargeTxCount(pInfo.userid,cgmsg.txcount)
	--实时监控系统
	RTMModel.addWithdrawMoneyRecord(pInfo.userid, pInfo.nickname, TimeUtils.GetTime(), orderid, drawmtype, drawjetton)
	LogDispatch.WithDrawCount(pInfo, cgmsg.txcount, orderid)
	gcmsg.userid = cgmsg.userid
	gcmsg.infotype = cgmsg.infotype
	gcmsg.txcount = cgmsg.txcount
	gcmsg.nowjetton = tonumber(pInfo.jetton)
	gcmsg.result = 0
	return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
end

function GetUserDrawNum(userID)
	local num = 0
	local sqlCase = "select count(*) from ag_drawmoney where userid="..userID.." and state!=5 and drawmtype!=3 and to_days(rsdate)=to_days(now())"
	mysqlItem:executeQuery(sqlCase) 
	local sqlData = mysqlItem:fetch()
	if sqlData ~= nil then
		num = tonumber(sqlData) == nil and 0 or  tonumber(sqlData)
	end
	return num
end




