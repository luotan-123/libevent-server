module("GetIDCard", package.seeall)

function execute(packetID, operateID, buffer)

	local cgmsg = msg_human3_pb.cggetidcard()
	local gcmsg = msg_human3_pb.gcgetidcard()

	cgmsg:ParseFromString(buffer)
	local checkMsg = RedisHelper.CheckRedis(cgmsg.userid,operateID)
	if checkMsg ~= nil then
		gcmsg:ParseFromString(checkMsg)
		return cgmsg.userid,0,gcmsg:ByteSize(),gcmsg:SerializeToString()
	end
	
	local pInfo = PlayerModel.GetPlayerInfo(cgmsg.userid)
	if pInfo == nil then
		gcmsg.result = ReturnCode["player_not_exist"]
		return cgmsg.userid, 0, gcmsg:ByteSize(), gcmsg:SerializeToString()
	end

	if pInfo.idcardstatus == 1 then
		local sqlCase = "select name, idcard, idcard_a, idcard_b from dy_idcardverify where userid="..cgmsg.userid.." and status=0"
		mysqlItem:executeQuery(sqlCase)
		
		local sqlData = mysqlItem:fetch({})
		if sqlData ~= nil then
			gcmsg.idcardnumber = sqlData[2] or ""
			gcmsg.idcarda = sqlData[3] or ""
			gcmsg.idcardb = sqlData[4] or ""
			gcmsg.realname = sqlData[1] or ""
		end
		
	elseif pInfo.idcardstatus == 2 then
	
		local sqlCase = "select idcardnumber, idcarda, idcardb, realname from ag_player where userid="..cgmsg.userid
		mysqlItem:executeQuery(sqlCase)
		local sqlData = mysqlItem:fetch({})
		if sqlData ~= nil then
			gcmsg.idcardnumber = sqlData[1] or ""
			gcmsg.idcarda = sqlData[2] or ""
			gcmsg.idcardb = sqlData[3] or ""
			gcmsg.realname = sqlData[4] or ""
		end
	elseif pInfo.idcardstatus == 3 then
	
		local sqlCase = "select name, idcard, idcard_a, idcard_b from dy_idcardverify where userid="..cgmsg.userid.." and status=3 order by id desc"
		mysqlItem:executeQuery(sqlCase)
		
		local sqlData = mysqlItem:fetch({})
		if sqlData ~= nil then
			gcmsg.idcardnumber = sqlData[2] or ""
			gcmsg.idcarda = sqlData[3] or ""
			gcmsg.idcardb = sqlData[4] or ""
			gcmsg.realname = sqlData[1] or ""
		end
	end
	
	gcmsg.result = 0
	return cgmsg.userid, 0, gcmsg:ByteSize(), gcmsg:SerializeToString()

end