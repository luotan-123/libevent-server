
module("GetGameStateList", package.seeall)

function execute(packetID, operateID, buffer)

	local cgmsg = msg_human3_pb.cggetgamestatelist()
	local gcmsg = msg_human3_pb.gcgetgamestatelist()

	cgmsg:ParseFromString(buffer)
	local checkMsg = RedisHelper.CheckRedis(cgmsg.userid, operateID)
	if checkMsg ~= nil then
		gcmsg:ParseFromString(checkMsg)
		LogBehavior.Warning(cgmsg.userid, "human", "GetGameStateList", 0, "协议号重复"..operateID)
		return cgmsg.userid, 0, gcmsg:ByteSize(), gcmsg:SerializeToString()
	end
	
	local SqlCase = "select gametype, clientstate, gamename from dy_gamestate"
	mysqlItem:executeQuery(SqlCase)
	
	while true do 
		local sqlData = mysqlItem:fetch({})
		if sqlData == nil then
			break
		end
		gcmsg.gamelist:append(tonumber(sqlData[1]))
		gcmsg.statelist:append(tonumber(sqlData[2]))
		gcmsg.namelist:append(sqlData[3])
	end
	
	gcmsg.result = 0
	return cgmsg.userid, 0, gcmsg:ByteSize(), gcmsg:SerializeToString()
end
