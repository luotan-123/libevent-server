
module("InviteBind", package.seeall)


function execute(packetID, operateID, buffer)

	local cgmsg = msg_human_pb.cginvitebind()
	local gcmsg = msg_human_pb.gcinvitebind()
	cgmsg:ParseFromString(buffer)

	if cgmsg.userid == tonumber(cgmsg.invitestr) then
		--不能过绑定自己
		gcmsg.result = ReturnCode["bind_not_self"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
	end

	local pInfo = PlayerModel.GetPlayerInfo(cgmsg.userid)
	if pInfo == nil then
		gcmsg.result = ReturnCode["player_not_exist"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
	end

	if cgmsg.invitestr == nil or 0 == string.len(cgmsg.invitestr) then
		gcmsg.result = ReturnCode["agency_bind_error"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
	end
	
	if nil == PlayerModel.GetPlayerInfo(tonumber(cgmsg.invitestr)) then
		gcmsg.result = ReturnCode["agency_not_exist"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
	end
	
	--检查有没有绑定别人
	local sqlCase = "select agent1 from ag_player where userid="..cgmsg.userid
	mysqlItem:executeQuery(sqlCase)
	local sqlData = mysqlItem:fetch()
	if sqlData == nil then
		gcmsg.result = ReturnCode["agency_bind_error"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
	end
	
	if tonumber(sqlData) ~= 0 then
		gcmsg.result = ReturnCode["agency_is_band"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
	end
	
	--获得向上的第二级代理
	local agent2 = 0
	local sqlCase = "select agent1, agent2 from ag_player where userid="..cgmsg.invitestr
	mysqlItem:executeQuery(sqlCase)
	local sqlData = mysqlItem:fetch({})
	
	if sqlData == nil then
		gcmsg.result = ReturnCode["bin_error_2"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
	end
	agent2 = tonumber(sqlData[1]) == nil and 0 or tonumber(sqlData[1])
	
	--绑定的玩家不能是我的下属
	if tonumber(sqlData[1]) == cgmsg.userid or tonumber(sqlData[2]) == cgmsg.userid then
		gcmsg.result = ReturnCode["bin_error_1"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
	end
		
	--绑定我的两级代理
	local sqlCase = "update ag_player set agent1="..cgmsg.invitestr..", agent2="..agent2.." where userid="..cgmsg.userid
	mysqlItem:executeQuery(sqlCase)
	
	--把绑定我的向下一级玩家， 全部绑上向上的第二级代理
	local sqlCase = "update ag_player set agent2="..cgmsg.invitestr.." where agent1="..cgmsg.userid
	mysqlItem:executeQuery(sqlCase)
	
	AgentModel.GetAgentInfo(cgmsg.userid, gcmsg.agyinfo)
	gcmsg.agyinfo.agent1 = tonumber(cgmsg.invitestr)
	gcmsg.agyinfo.agent2 = agent2
	AgentModel.SetAgent(cgmsg.userid, gcmsg.agyinfo)
	gcmsg.result = 0
	return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
end