
module("OnLine", package.seeall)

function execute(packetID, operateID, buffer)

	local cgmsg = msg_human2_pb.cgonline()
	local gcmsg = msg_human2_pb.gconline()

	cgmsg:ParseFromString(buffer)

	local pInfo = PlayerModel.GetPlayerInfo(cgmsg.userid)
	if pInfo == nil then
		gcmsg.result = 1001
		return cgmsg.userid, 0, gcmsg:ByteSize(), gcmsg:SerializeToString()
	end
	
	pInfo.location = "在线"
	OnlineModel.PlayerLogin(pInfo)
	PlayerModel.SetPlayerInfo(pInfo)
	gcmsg.result = 0
	return cgmsg.userid, 0, gcmsg:ByteSize(), gcmsg:SerializeToString()

end