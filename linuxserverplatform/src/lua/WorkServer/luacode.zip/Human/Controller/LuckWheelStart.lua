module("LuckWheelStart", package.seeall)

--开始幸运大转盘
function execute(packetID, operateID, buffer)
  local cgmsg = msg_human2_pb.cgluckwheelstart()
	local gcmsg = msg_human2_pb.gcluckwheelstart()
	
	cgmsg:ParseFromString(buffer)
	
	local checkMsg = RedisHelper.CheckRedis(cgmsg.userid, operateID)
	if checkMsg ~= nil then
		gcmsg:ParseFromString(checkMsg)
		LogBehavior.Warning(cgmsg.userid, "pInfo", "LuckWheel", 0, "缓存已存在")
		return cgmsg.userid, 0, gcmsg:ByteSize(), gcmsg:SerializeToString()
	end

	local pInfo = PlayerModel.GetPlayerInfo(cgmsg.userid)
	if pInfo == nil then
		LogBehavior.Error(cgmsg.userid,"pInfo","LuckWheel", ReturnCode["player_not_exist"], "该玩家不存在")
		gcmsg.result = ReturnCode["player_not_exist"]
		return cgmsg.userid, 0, gcmsg:ByteSize(), gcmsg:SerializeToString()
	end
    gcmsg.userid = cgmsg.userid

    --获取玩家抽奖信息 通过接口获取到 周业绩流水值
    local achievement = UnlimitedAward.GetDirAch(cgmsg.userid)

    luaPrint(" start achievement: "..achievement)

    local lucktype = {1,2,3,4,5,6,7,8,8.88,9}
    local grade = 1
    local luckLevel = 1 --抽奖系数
    if achievement >= 1000000 and achievement < 10000000 then
        -- 大于等于1万 小于 10万
        grade =1
    elseif achievement >= 10000000 and achievement < 100000000 then
        -- 大于等于10万 小于 100万
        grade =10
    elseif achievement >= 100000000 and achievement < 1000000000 then
        -- 大于等于100万 小于 1000万
        grade =100
    elseif achievement >= 1000000000 then
        --大于 1000万
        grade =1000
    else
        --没有资格抽奖
        gcmsg.result = ReturnCode["luckwheel_error_1"] --由于您的业绩流水不达标，所有无法参与这次活动
        return cgmsg.userid, 0, gcmsg:ByteSize(), gcmsg:SerializeToString()
    end
    --抽奖梯度
    local realLuckType = {}
    for k,v in ipairs(lucktype) do
        table.insert(realLuckType,v * grade * 100)
    end

    if grade == 1000 then
        realLuckType = {88800,100000,200000,300000,400000,500000,600000,700000,800000,900000}
    end
    --luaDump(luajson.encode(realLuckType))
    --获取当前幸运抽奖期号 可设置在缓存中 由后台设置 
    local luckNum = 1

    --根据LuckWheelInfo数据判断抽奖资格
    local luckinfo = PlayerModel.GetUserLuckWheelInfo(cgmsg.userid,luckNum)
    local getLuckRejetton = realLuckType[1]
    if luckinfo == nil or (luckinfo ~= nil and luckinfo["restate"] == 1) then
        --可以抽奖
        local randnum  = math.myrandom(1,10000)
        --luaPrint("randnum: "..randnum)
                            --1,    2    3    4    5    6    7     8    8.8   9
       --local randnumlist = {10000,5000,3333,2500,2000,1600,1400,1250, 1136,1100}
        --6以上不发
        local randnumlist = {10000,5000,3333,2500,2000,0,0,0, 0,0}
       
        if randnum <= randnumlist[10] * luckLevel then
            getLuckRejetton = realLuckType[10]
        elseif randnum <= randnumlist[9] * luckLevel  then
            getLuckRejetton = realLuckType[9]
        elseif randnum <= randnumlist[8] * luckLevel  then
            getLuckRejetton = realLuckType[8]
        elseif randnum <= randnumlist[7] * luckLevel then
            getLuckRejetton = realLuckType[7]
        elseif randnum <= randnumlist[6] * luckLevel  then
            getLuckRejetton = realLuckType[6]
        elseif randnum <= randnumlist[5] * luckLevel then
            getLuckRejetton = realLuckType[5]
        elseif randnum <= randnumlist[4] * luckLevel then
            getLuckRejetton = realLuckType[4]
        elseif randnum <= randnumlist[3] * luckLevel  then
            getLuckRejetton = realLuckType[3]
        elseif randnum <= randnumlist[2] * luckLevel  then
            getLuckRejetton = realLuckType[2]
        else
            getLuckRejetton = realLuckType[1]
        end

    else
        --已经抽过奖或没有抽奖资格
        if luckinfo["restate"] == 2 then
            gcmsg.result = ReturnCode["luckwheel_error_2"] --您已经抽过了
        else
            gcmsg.result = ReturnCode["luckwheel_error_1"] --由于您的业绩流水不达标，所有无法参与这次活动
        end
		return cgmsg.userid, 0, gcmsg:ByteSize(), gcmsg:SerializeToString()
    end

    luaPrint("getLuckRejetton:"..getLuckRejetton )
    gcmsg.rejetton = tonumber(getLuckRejetton)
    --更新玩家 抽奖信息 
    gcmsg.result = 0
    
    --插入数据库
    PlayerModel.InsertUserLuckWheelInfo(cgmsg.userid,luckNum,2,luajson.encode(realLuckType),
    getLuckRejetton,achievement)
    
    --玩家添加金币
--	PlayerModel.AddJetton(pInfo, getLuckRejetton, "luckwheel", "win")
--	PlayerModel.SetPlayerInfo(pInfo)
--	PlayerModel.SendJetton(pInfo)   --同步分数先
    --luaPrint("userid: ".. cgmsg.userid.." getLuckRejetton: "..getLuckRejetton)
    
    --通过邮件的形式直接发送
    local addItem = st_human_pb.mailinfo() 
	addItem.title='幸运抽奖'
	addItem.content='幸运抽奖获取金币'..(getLuckRejetton/100)..'请领取!'
	addItem.senderid = 1
	addItem.sender = "系统"
	addItem.receiverid = pInfo.userid
	addItem.receiver = pInfo.nickname
	addItem.senddate = TimeUtils.GetTimeString(currDate)
	addItem.validity = 7
	addItem.externdata = "[[1002,"..(getLuckRejetton).."]]"
	addItem.mailtype = 2
	addItem.mailstate = g_mailState.state_unreadadd
	local tTime = TimeUtils.GetTableTime()
	tTime.hour = 0
	tTime.min = 0
	tTime.sec = 0
	local currSec = TimeUtils.GetTime(tTime)
	currSec = currSec + g_daySeconds*2
	addItem.markdate = TimeUtils.GetDayString(currSec)
	MailModel.AddMail(addItem)
    --红点通知
    NoticeModel.SendNotice(cgmsg.userid, g_noticeType.mail_unread)	

    return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
end
