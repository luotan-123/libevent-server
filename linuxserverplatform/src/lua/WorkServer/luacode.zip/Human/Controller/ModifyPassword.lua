--进入小马快跑


module("ModifyPassword", package.seeall)


function execute(packetID, operateID, buffer)

	local cgmsg = msg_human2_pb.cgmodifypassword()
	local gcmsg = msg_human2_pb.gcmodyfipassword()

	cgmsg:ParseFromString(buffer)
	local checkMsg = RedisHelper.CheckRedis(cgmsg.userid,operateID)
	if checkMsg ~= nil then
		gcmsg:ParseFromString(checkMsg)
		return cgmsg.userid,0,gcmsg:ByteSize(),gcmsg:SerializeToString()
	end


	--首先检查验证码在不在
	local sqlCase = "select * from dy_authcode where phonenum='"..cgmsg.phonenumber.."' and code="..cgmsg.vericode.." order by id desc"
	mysqlItem:executeQuery(sqlCase)
	local sqlData = mysqlItem:fetch()
	if sqlData == nil then
		--验证码不存在
		gcmsg.result = ReturnCode["phone_code_notexit"]
		return cgmsg.userid, 0, gcmsg:ByteSize(), gcmsg:SerializeToString()
	end	
	
    local state = tonumber(sqlData[5])
    local codeid = tonumber(sqlData[1])

    if state == 1 then
	    gcmsg.result = ReturnCode["phone_code_notexit"]
	    return 0,0,gcmsg:ByteSize(),gcmsg:SerializeToString()
    end

	local startTime = tonumber(sqlData[3])
	local nowTime = TimeUtils.GetTime()
	if (nowTime - startTime) > 600 then
		--验证码已经过期
		gcmsg.result = ReturnCode["phone_code_pastdue"]
		return cgmsg.userid, 0, gcmsg:ByteSize(), gcmsg:SerializeToString()
	end	
	
	
	
	
	--if cgmsg.userid == 0 then
		
	sqlCase = "select userid from dy_player where phonenum='"..cgmsg.phonenumber.."'"
	mysqlItem:executeQuery(sqlCase)
	
	sqlData  = mysqlItem:fetch()
	
	if sqlData == nil then
		if cgmsg.userid == 0 then
			gcmsg.result = ReturnCode["player_not_exist"]
		else
			gcmsg.result =  ReturnCode["modify_must_bind"]
		end
		
		return cgmsg.userid, 0, gcmsg:ByteSize(), gcmsg:SerializeToString()
	end		
	--end
	
	
	cgmsg.userid = tonumber(sqlData)

	
	local pInfo =  PlayerModel.GetPlayerInfo(cgmsg.userid)	
	if pInfo == nil then
		gcmsg.result = ReturnCode["player_not_exist"]
		return cgmsg.userid, 0, gcmsg:ByteSize(), gcmsg:SerializeToString()
	end
	

	if pInfo.phonenum ~= "" then
		gcmsg.result = ReturnCode["bin_count_error_2"]
		return cgmsg.userid, 0, gcmsg:ByteSize(), gcmsg:SerializeToString()
	end
	

	 
	if cgmsg.password == '' then
		
		gcmsg.result = ReturnCode["modify_error"]
		mysqlItem:executeQuery(sqlCase)		
	else
		--表示密码也需要同步
		pInfo.password = md5( cgmsg.password )
		local sqlCase = "update dy_player set phonenum="..cgmsg.phonenumber..",password='"..pInfo.password.."' where userid="..cgmsg.userid
		mysqlItem:executeQuery(sqlCase)	
        LogBehavior.UserAction(pInfo,3, "玩家修改密码")			
	end
	
	
	local tJson = {}
	table.insert(tJson, pInfo.password)
	table.insert(tJson, pInfo.userid)
	redisItem:set("account"..pInfo.account, luajson.encode(tJson), PlayerModel.redis_index)	
	

	PlayerModel.SetPlayerInfo(pInfo)
	
	gcmsg.phonenumber = cgmsg.phonenumber
	gcmsg.userid = cgmsg.userid
	gcmsg.result = 0
	
	PlayerModel.AddJetton(pInfo, 300, "bind","绑定手机赠送")
	
	LogDispatch.RegisterAward(pInfo, 300)
	return cgmsg.userid, 0, gcmsg:ByteSize(), gcmsg:SerializeToString()
end