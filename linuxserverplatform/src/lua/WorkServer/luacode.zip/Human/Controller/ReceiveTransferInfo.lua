module("ReceiveTransferInfo", package.seeall)

function execute(packetID, operateID, buffer)
	local cgmsg = msg_human3_pb.cgreceivetransferinfo()
	local gcmsg = msg_human3_pb.gcreceivetransferinfo()
	cgmsg:ParseFromString(buffer)
    PlayerModel.DelUserTransferinfo(cgmsg.userid,cgmsg.transferid)
    return cgmsg.userid, 0, gcmsg:ByteSize(), gcmsg:SerializeToString()
	
end