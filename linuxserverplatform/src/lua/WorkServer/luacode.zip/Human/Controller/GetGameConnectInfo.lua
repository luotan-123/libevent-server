module("GetGameConnectInfo", package.seeall)

--领取每日登录奖励
function execute(packetID, operateID, buffer)

	local cgmsg = msg_user_pb.cggetgameconnectinfo()
	local gcmsg = msg_user_pb.gcgetgameconnectinfo()
	
	cgmsg:ParseFromString(buffer)
	
	local checkMsg = RedisHelper.CheckRedis(cgmsg.userid, operateID)
	if checkMsg ~= nil then
		return cgmsg.userid, 0, string.len(checkMsg), checkMsg
	end
	
	local pInfo = PlayerModel.GetPlayerInfo(cgmsg.userid)
	if pInfo == nil then
		
		gcmsg.result = ReturnCode["player_not_exist"]
		return cgmsg.userid, 0, gcmsg:ByteSize(), gcmsg:SerializeToString()
	end
	
	local signArr = {}
	signArr['timemark'] = TimeUtils.GetTime()
	local signKey = "gametype="..cgmsg.gametype.."&timemark="..signArr['timemark'].."&userid="..cgmsg.userid.."&key="..g_signKey
	signArr['token'] = md5(signKey)
	gcmsg.token = signArr['token']
	gcmsg.gametype = cgmsg.gametype
	
	if cgmsg.isdomestic == 0 then
	
		local sqlCase = "select ip,tcpport,webport from dy_gamestate where id>0 and gametype="..cgmsg.gametype
		mysqlItem:executeQuery(sqlCase)
		local sqlData = mysqlItem:fetch({})
		if sqlData ~= nil then
			gcmsg.ip = sqlData[1]
			gcmsg.port = tonumber(sqlData[2])
			gcmsg.port_web = tonumber(sqlData[3]) == nil and 0 or tonumber(sqlData[3])
			gcmsg.result = 0
			
			-- 保存数据
			GameModel.SetPlayerGameConnect(cgmsg.userid,signArr);
		else
			gcmsg.result = ReturnCode["game_connect_fail"]
		end
	else
		local sqlCase = "select abroadip,abroadtcpport,abroadwebport from dy_gamestate where id>0 and gametype="..cgmsg.gametype
		mysqlItem:executeQuery(sqlCase)
		local sqlData = mysqlItem:fetch({})
		if sqlData ~= nil then
			gcmsg.ip = sqlData[1]
			gcmsg.port = tonumber(sqlData[2])
			gcmsg.port_web = tonumber(sqlData[3]) == nil and 0 or tonumber(sqlData[3])
			gcmsg.result = 0
			
			-- 保存数据
			GameModel.SetPlayerGameConnect(cgmsg.userid,signArr);
		else
			gcmsg.result = ReturnCode["game_connect_fail"]
		end
	end
	
	gcmsg.isdomestic = cgmsg.isdomestic
	
	gcmsg.result = 0
	return cgmsg.userid, 0, gcmsg:ByteSize(), gcmsg:SerializeToString()
end
