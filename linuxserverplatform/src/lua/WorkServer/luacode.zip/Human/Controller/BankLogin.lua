module("BankLogin", package.seeall)

function execute(packetID, operateID, buffer)
	local cgmsg = msg_human_pb.cgbanklogin()
	local gcmsg = msg_human_pb.gcbanklogin()
	cgmsg:ParseFromString(buffer)
	
	repeat
		local pInfo = PlayerModel.GetPlayerInfo(cgmsg.userid)
		if nil == pInfo then
			gcmsg.result = ReturnCode["user_not_exist"]
			break
		end
		
		if 0 == string.len(pInfo.bank_password) then
			gcmsg.result = ReturnCode["bank_pwd_never_set"]
			break
		end

		if cgmsg.password ~= pInfo.bank_password then
			gcmsg.result = ReturnCode["bank_pwd_error"]
			break
		end
		
		gcmsg.result = 0
		gcmsg.jetton = pInfo.bank_jetton
		
	until true
	
	return cgmsg.userid, 0, gcmsg:ByteSize(), gcmsg:SerializeToString()
end
