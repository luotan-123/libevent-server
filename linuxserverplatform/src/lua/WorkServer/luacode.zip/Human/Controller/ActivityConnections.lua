
module("ActivityConnections", package.seeall)

function execute(packetID, operateID, buffer)

	local cgmsg = msg_human2_pb.cgactivityconnections()
	local gcmsg = msg_human2_pb.gcactivityconnections()

	cgmsg:ParseFromString(buffer)
	local checkMsg = RedisHelper.CheckRedis(cgmsg.userid, operateID)
	
	if checkMsg ~= nil then
		gcmsg:ParseFromString(checkMsg)
		LogBehavior.Warning(cgmsg.userid, "mail", "GetMailList", 0, "重复获取邮件列表:optid="..operateID)
		return cgmsg.userid, 0, gcmsg:ByteSize(), gcmsg:SerializeToString()
	end
	

	--[[
	local itemList = redisItem:zrevrange( "activity_playernum", 0, 19, ActivityModel.redis_index, "withscores" )
	local indexCount = 1
	for k,v_item in ipairs( itemList ) do
		
		local pInfo = PlayerModel.GetPlayerInfo(v_item[1])
		if pInfo ~= nil then
			gcmsg.useridlist:append( tonumber(v_item[1]) )
			gcmsg.nicknamelist:append(pInfo.nickname)
			gcmsg.jifenlist:append(v_item[2])
			gcmsg.ranking:append(indexCount)
			indexCount = indexCount+1
			
		end
		
	end
	
	local myRank = redisItem:zrevrank( "activity_playernum", cgmsg.userid, ActivityModel.redis_index )
	gcmsg.selfranking =  myRank == nil and 0 or tonumber(myRank)
	local myScore = redisItem:zscore( "activity_playernum", cgmsg.userid, ActivityModel.redis_index )
	gcmsg.selfjifen =  myScore == nil and '0' or tostring(myScore)
	]]
	
	
	--特殊牌型、对局排行和流水排行奖励活动
	--1 今日牌型奖励
	--3 今日对局奖励
	--4 昨日对局奖励
	--5 今日流水奖励
	--6 昨日流水奖励
	if cgmsg.ctype == 1 then
		
		local list = LogModel.getPrizesList()
		
		if #list > 0 then
			local pos = 1
			for i = #list , 1, -1 do 
				local addUH = st_human_pb.cardtypeprizesinfo()
				addUH:ParseFromString(list[i])
				gcmsg.useridlist:append(addUH.userid)
				gcmsg.nicknamelist:append(addUH.nickname)
				gcmsg.jifenlist:append(addUH.jetton)
				gcmsg.ranking:append(pos)
				pos = pos + 1
			end
		else
			local sqlCase = "select * from log_activity_record where activitytype ="..cgmsg.ctype.." order by id desc limit 20"   --每一次只会取20个
			mysqlItem:executeQuery(sqlCase)
			for i = 1,100 do
				local sqlData = mysqlItem:fetch({})
				if sqlData == nil then
					break
				end		
				gcmsg.useridlist:append(tonumber(sqlData[2]))
				gcmsg.nicknamelist:append(sqlData[3])
				gcmsg.jifenlist:append(sqlData[8])
				gcmsg.ranking:append(i)
			end	
		end
	elseif cgmsg.ctype == 3 or cgmsg.ctype == 4  then
		local date = ""
		if cgmsg.ctype == 3 then
			local tab = LogServer.GetTodayDate()
			date = tab.year..tab.month..tab.day
		elseif cgmsg.ctype == 4 then
			local tab = LogServer.GetYestedayDate()
			date = tab.year..tab.month..tab.day
		end

		local playerlist = LogServer.GetMatchScoreRanking(date)
		for k, v in ipairs(playerlist) do
			local pInfo = PlayerModel.GetPlayerInfo(v[1]) 
			if pInfo ~= nil and k < 101 then
				gcmsg.useridlist:append(pInfo.userid)
				gcmsg.nicknamelist:append(pInfo.nickname)
				gcmsg.jifenlist:append(tostring(v[2]))
				gcmsg.ranking:append(k)
			end
			if tonumber(v[1]) == cgmsg.userid then
				gcmsg.selfranking = k
				gcmsg.selfjifen = tostring(v[2])
				
			end
		end	
	elseif cgmsg.ctype == 5 or cgmsg.ctype == 6 then
		local msg 
		if cgmsg.ctype == 5 then
			msg = LogModel.GelLiushuiRanking_today()
		elseif cgmsg.ctype == 6 then
			msg = LogModel.GetLiushuiRanking_yesterday()
		end
		if msg ~= nil then
			local rankList = st_human_pb.activityliushuiranking()
			rankList:ParseFromString(msg)
			for i = 1, #rankList.userid do
				gcmsg.useridlist:append(rankList.userid[i])
				gcmsg.nicknamelist:append(rankList.nickname[i])
				gcmsg.jifenlist:append(rankList.jifen[i])
				gcmsg.ranking:append(rankList.ranking[i])
				
				if rankList.userid[i] == cgmsg.userid then
					gcmsg.selfranking = rankList.ranking[i]
					gcmsg.selfjifen = tostring(rankList.jifen[i])
				end
			end
		else
			local date = ""
			if cgmsg.ctype == 5 then
				local tab = LogServer.GetTodayDate()
				date = tab.year.."-"..tab.month.."-"..tab.day
			elseif cgmsg.ctype == 6 then
				local tab = LogServer.GetYestedayDate()
				date = tab.year.."-"..tab.month.."-"..tab.day
			end
				
			local sqlCase = "select userid, achamount from log_playerdaily where achamount > 0 and dateid ='"..date.."' order by achamount desc limit 30" 
			mysqlLog:executeQuery(sqlCase)
			for i = 1,100 do
				local sqlData = mysqlLog:fetch({})
				if sqlData == nil then
					break
				end	
				local pInfo = PlayerModel.GetPlayerInfo(sqlData[1])
				if pInfo ~= nil then
					gcmsg.useridlist:append(pInfo.userid)
					gcmsg.nicknamelist:append(pInfo.nickname)
					gcmsg.jifenlist:append(tostring(sqlData[2]))
					gcmsg.ranking:append(i)
				end
				if tonumber(sqlData[1]) == cgmsg.userid then
					gcmsg.selfranking = i
					gcmsg.selfjifen = tostring(sqlData[2])
				end
			end
			
			if gcmsg.selfranking == 0 then
				local sqlCase = "select achamount from log_playerdaily where dateid ='"..date.."'and userid="..cgmsg.userid
				mysqlLog:executeQuery(sqlCase)
				local sqlData = mysqlLog:fetch()
				local slefJifen = sqlData == nil and 0 or tonumber(sqlData)
				if slefJifen ==  0 then
					gcmsg.selfranking = 0
					gcmsg.selfjifen = tostring(slefJifen)
				else
					local sqlCase = "select count(*) from log_playerdaily where dateid ='"..date.."' and achamount>"..slefJifen
					mysqlLog:executeQuery(sqlCase)
					local sqlData = mysqlLog:fetch()
					local pos = tonumber(sqlData) + 1
					if pos > 30 then
						gcmsg.selfranking = pos
						gcmsg.selfjifen = tostring(slefJifen)
					else
						gcmsg.selfranking = 31
						gcmsg.selfjifen = tostring(slefJifen)
					end	
				end
			end
		end
	end
	gcmsg.result = 0
	gcmsg.ctype = cgmsg.ctype
	return cgmsg.userid, 0, gcmsg:ByteSize(), gcmsg:SerializeToString()

end
