module("GetPayerOnGame", package.seeall)

function execute(packetID, operateID, buffer)

	local cgmsg = msg_human3_pb.cggetpayerongame()
	local gcmsg = msg_human3_pb.gcgetpayerongame()

	cgmsg:ParseFromString(buffer)
	local checkMsg = RedisHelper.CheckRedis(cgmsg.userid,operateID)
	if checkMsg ~= nil then
		gcmsg:ParseFromString(checkMsg)
		return cgmsg.userid,0,gcmsg:ByteSize(),gcmsg:SerializeToString()
	end
	
	local pInfo = PlayerModel.GetPlayerInfo(cgmsg.userid)
	if pInfo == nil then
		gcmsg.result = ReturnCode["player_not_exist"]
		return cgmsg.userid, 0, gcmsg:ByteSize(), gcmsg:SerializeToString()
	end

    if PlayerModel.CheckTestUserLimit(pInfo,g_test_userfunc_limit[1])then
        --测试用户不能游戏
        gcmsg.result = ReturnCode["test_user_funclimit"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
    end


	local tableid, gametype = PlayerModel.GetCurrTableID(cgmsg.userid)
	
	gcmsg.tableid = tonumber(tableid)
	gcmsg.gametype = tonumber(gametype)
	gcmsg.userid = cgmsg.userid
	gcmsg.result = 0
	return cgmsg.userid, 0, gcmsg:ByteSize(), gcmsg:SerializeToString()

end