module("GameConnect", package.seeall)

--领取每日登录奖励
function execute(packetID, operateID, buffer)

	local cgmsg = msg_user_pb.cggameconnect()
	local gcmsg = msg_user_pb.gcgameconnect()
	
	cgmsg:ParseFromString(buffer)
	
	--local checkMsg = RedisHelper.CheckRedis(cgmsg.userid, operateID)
	if checkMsg ~= nil then
		return cgmsg.userid, 0, string.len(checkMsg), checkMsg
	end
	
	
	local strGet = GameModel.GetPlayerGameConnect(cgmsg.userid)
	
	if strGet == nil then
		gcmsg.result = ReturnCode["game_connect_game_notexist"]
		return cgmsg.userid, 0, gcmsg:ByteSize(), gcmsg:SerializeToString()
	end
	
	local jsonArr = luajson.decode(strGet)
	local signKey = "gametype="..cgmsg.gametype.."&timemark="..jsonArr['timemark'].."&userid="..cgmsg.userid.."&key="..g_signKey
	
	
	signKey = md5(signKey)
	
	if jsonArr['token'] ~= signKey then
		gcmsg.result = ReturnCode["game_connect_login_fail"]
		return cgmsg.userid, 0, gcmsg:ByteSize(), gcmsg:SerializeToString()		
	end
	
	gcmsg.result = 0
	return cgmsg.userid, 0, gcmsg:ByteSize(), gcmsg:SerializeToString()
end
