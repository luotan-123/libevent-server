--进入小马快跑


module("CheckBindCode", package.seeall)


function execute(packetID, operateID, buffer)

	local cgmsg = msg_user_pb.cgcheckbindcode()
	local gcmsg = msg_user_pb.gccheckbindcode()
	
	cgmsg:ParseFromString(buffer)
	

	if cgmsg.bindcode == nil then
		gcmsg.result = ReturnCode["bind_code_nil"]
		gcmsg.msg = "邀请码不能为空"
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
	end
	gcmsg.result = 0
	local sqlCase = "select userid from ag_player where expandcode='"..cgmsg.bindcode.."'"
	mysqlItem:executeQuery(sqlCase)
	local sqlData = mysqlItem:fetch()
	if sqlData == nil then
		gcmsg.result = ReturnCode["bind_code_error"]
		gcmsg.msg = "邀请码不存在"
	end
	
	return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
end