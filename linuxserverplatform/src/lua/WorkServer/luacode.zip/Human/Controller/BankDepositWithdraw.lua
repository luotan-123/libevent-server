module("BankDepositWithdraw", package.seeall)

function execute(packetID, operateID, buffer)
	local cgmsg = msg_human_pb.cgbankdepositwithdraw()
	local gcmsg = msg_human_pb.gcbankdepositwithdraw()
	cgmsg:ParseFromString(buffer)
	
	repeat
		local pInfo = PlayerModel.GetPlayerInfo(cgmsg.userid)
		if nil == pInfo then
			gcmsg.result = ReturnCode["user_not_exist"]
			break
		end
		
		local tableid = PlayerModel.GetCurrTableID(cgmsg.userid)
		if tableid ~= 0 then
			gcmsg.result = ReturnCode["gameing_limit"]
			break
		end

        if PlayerModel.CheckTestUserLimit(pInfo,g_test_userfunc_limit[7])then
            --测试用户转钱
            gcmsg.result = ReturnCode["test_user_funclimit"]
		    return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
        end
		
		--[[if 0 == string.len(pInfo.bank_password) then
			gcmsg.result = ReturnCode["bank_pwd_never_set"]
			break
		end]]
		if cgmsg.opttype == 0 then
		   --银行
            if 0 >= tonumber(cgmsg.amount) then
			    gcmsg.result = ReturnCode["arg_amount_error"]
			    break
		    end
		
		    if 0 == cgmsg.opt then	-- 存款
			    if tonumber(cgmsg.amount) + g_giveRetainJetton > tonumber(pInfo.jetton) then
				    gcmsg.result = ReturnCode["jetton_not_enough"]
				    break
			    end
			    BankModel.Deposit(pInfo, cgmsg.amount)
			    LogServer.BankDeposit(pInfo, cgmsg.amount)
		    elseif 1 == cgmsg.opt then	-- 取款
			    if tonumber(cgmsg.amount) > tonumber(pInfo.bank_jetton) then
				    gcmsg.result = ReturnCode["bank_jetton_not_enough"]
				    break
			    end
			    BankModel.Withdraw(pInfo, cgmsg.amount)
			    LogServer.BankWithdraw(pInfo, cgmsg.amount)
		    else	-- opt error
			    gcmsg.result = ReturnCode["banktransfer_opt_error"]
			    break
		    end
		
		    gcmsg.result = 0

		    PlayerModel.SendPlayerInfo(pInfo, {"jetton", "bank_jetton"}) 
        elseif cgmsg.opttype == 1 then
        --视讯操作
		     if 0 >= tonumber(cgmsg.amount) then
			    gcmsg.result = ReturnCode["arg_amount_error"]
			    break
		    end
		
		    if 0 == cgmsg.opt then	-- 存款
			    if tonumber(cgmsg.amount)  > tonumber(pInfo.jetton) then
				    gcmsg.result = ReturnCode["jetton_not_enough"]
				    break
			    end
                 luaPrint("cun cgmsg.amount: "..cgmsg.amount.." pInfo.sx_jetton:".. pInfo.sx_jetton)
			    BankModel.SxDeposit(pInfo, cgmsg.amount)
			    LogServer.SxBankDeposit(pInfo, cgmsg.amount)
		    elseif 1 == cgmsg.opt then	-- 取款
			    if tonumber(cgmsg.amount) > tonumber(pInfo.sx_jetton) then
				    gcmsg.result = ReturnCode["sx_jetton_not_enough"]
				    break
			    end
                luaPrint("qu cgmsg.amount: "..cgmsg.amount.." pInfo.sx_jetton:".. pInfo.sx_jetton)
			    BankModel.SxWithdraw(pInfo, cgmsg.amount)
			    LogServer.SxBankWithdraw(pInfo, cgmsg.amount)
		    else	-- opt error
			    gcmsg.result = ReturnCode["banktransfer_opt_error"]
			    break
		    end
		
		    gcmsg.result = 0

		    PlayerModel.SendPlayerInfo(pInfo, {"jetton", "sx_jetton"}) 
        
        
		elseif cgmsg.opttype == 2 then
			
			local tableid, gametype = PlayerModel.GetCurrTableID(cgmsg.userid)
			if tableid ~= nil and tableid ~= 0 then
				gcmsg.result = ReturnCode["majiang_enter_fail"]
				break
			end
			--游戏钱包操作
		     if 0 >= tonumber(cgmsg.amount) then
			    gcmsg.result = ReturnCode["arg_amount_error"]
			    break
		    end
		
		    if 0 == cgmsg.opt then	-- 存款
			    if tonumber(cgmsg.amount)  > tonumber(pInfo.jetton) then
				    gcmsg.result = ReturnCode["jetton_not_enough"]
				    break
			    end
			    BankModel.gamejettonDeposit(pInfo, tonumber(cgmsg.amount))
			    LogServer.ganmejetonDeposit(pInfo, tonumber(cgmsg.amount))
				--写到交易记录
				local remark = "转入游戏钱包"
				LogServer.addRecords(pInfo.userid,2,remark, 0 - tonumber(cgmsg.amount))
				
				--统计转入
				LogDispatch.GamePlayerAndSysSin(pInfo.userid, 0, 0, pInfo.channel,0, tonumber(cgmsg.amount), 0)
		    elseif 1 == cgmsg.opt then	-- 取款
			    if tonumber(cgmsg.amount) > PlayerModel.GetCanUseJetton(pInfo) then
				    gcmsg.result = ReturnCode["jetton_not_enough"]
				    break
			    end
			    BankModel.gamejettonWithdraw(pInfo, cgmsg.amount)
			    LogServer.ganmejetonWithdraw(pInfo, cgmsg.amount)
				--写到交易记录
				local remark = "游戏钱包转出"
				LogServer.addRecords(pInfo.userid,2,remark,cgmsg.amount)
				--统计转出
				LogDispatch.GamePlayerAndSysSin(pInfo.userid, 0, 0, pInfo.channel,0, 0, tonumber(cgmsg.amount))
		    else	-- opt error
			    gcmsg.result = ReturnCode["banktransfer_opt_error"]
			    break
		    end
		    gcmsg.result = 0
		    PlayerModel.SendPlayerInfo(pInfo, {"jetton", "gamejetton"}) 
        elseif cgmsg.opttype == 3 then
			--彩票钱包操作
            local tableid, gametype = PlayerModel.GetCurrTableID(cgmsg.userid)
			if tableid ~= nil and tableid ~= 0 then
				gcmsg.result = ReturnCode["majiang_enter_fail"]
				break
			end


		     if 0 >= tonumber(cgmsg.amount) then
			    gcmsg.result = ReturnCode["arg_amount_error"]
			    break
		    end
		
		    if 0 == cgmsg.opt then	-- 存款
			    if tonumber(cgmsg.amount)  > tonumber(pInfo.jetton) then
				    gcmsg.result = ReturnCode["jetton_not_enough"]
				    break
			    end

			    BankModel.cpjettonDeposit(pInfo, cgmsg.amount)
			    LogServer.cpjetonDeposit(pInfo, cgmsg.amount)

                --写到交易记录
				local remark = "转入彩票钱包"
				LogServer.addRecords(pInfo.userid,2,remark, 0 - tonumber(cgmsg.amount))

		    elseif 1 == cgmsg.opt then	-- 取款
			    if tonumber(cgmsg.amount) > tonumber(pInfo.cpjetton) then
				    gcmsg.result = ReturnCode["jetton_not_enough"]
				    break
			    end
                
			    BankModel.cpjettonWithdraw(pInfo, cgmsg.amount)
			    LogServer.cpjetonWithdraw(pInfo, cgmsg.amount)

                --写到交易记录
				local remark = "彩票钱包转出"
				LogServer.addRecords(pInfo.userid,2,remark,cgmsg.amount)

		    else	-- opt error
			    gcmsg.result = ReturnCode["banktransfer_opt_error"]
			    break
		    end
		    gcmsg.result = 0
		    PlayerModel.SendPlayerInfo(pInfo, {"jetton", "cpjetton"}) 

        end

		
		
	until true
	return cgmsg.userid, 0, gcmsg:ByteSize(), gcmsg:SerializeToString()
end