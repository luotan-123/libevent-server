
module("TxInfoGetOrBind", package.seeall)


function execute(packetID, operateID, buffer)

	local cgmsg = msg_human2_pb.cgtxinfogetorbind()
	local gcmsg = msg_human2_pb.gctxinfogetorbind()
	
	cgmsg:ParseFromString(buffer)
	local pInfo = PlayerModel.GetPlayerInfo(cgmsg.userid)
	if pInfo == nil then
		gcmsg.result = ReturnCode["player_not_exist"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
	end
	local banklist = {} --银行卡信息
    
    --获取信息
	local agyinfo = AgentModel.GetAgentInfo(cgmsg.userid)

    --获取银行卡信息 支付宝信息 agyinfo 中就可以获取到
    --银行卡信息 连表查询
    local sqlCase = " select  bankacount, bankpayee , bankname from ag_player where userid ="..cgmsg.userid.." UNION ALL select  bankacount, bankpayee , bankname from dy_extrabanks where userid="..cgmsg.userid
    mysqlItem:executeQuery(sqlCase)
    while true do
	    local sqlData =  mysqlItem:fetch({})
        if sqlData == nil then
            break
        end
        if sqlData[1] ~= "" and  sqlData[2] ~= "" and  sqlData[3] ~= "" then
            local bankinfo = {bankacount=sqlData[1], bankpayee=sqlData[2], bankname=sqlData[3] }
            table.insert(banklist,bankinfo)
        end
    end

    if cgmsg.requesttype == 2 then
		--查看该玩家是否是代理 绑定信息
        --验证码
        local inChannel = GameUtils.GetChannel_login(pInfo.channel)
        local sqlCase = "select * from dy_authcode where phonenum='"..cgmsg.phonenum.."' and code='"..cgmsg.vcode.."' and prechannel = '"..inChannel.. "' order by id desc"
		mysqlItem:executeQuery(sqlCase)
		local sqlData = mysqlItem:fetch({})
		if sqlData == nil then
			gcmsg.result = ReturnCode["phone_code_notexit"]
			return 0,0,gcmsg:ByteSize(),gcmsg:SerializeToString()
		end

        local state = tonumber(sqlData[5])
        local codeid = tonumber(sqlData[1])

        if state == 1 then
	        gcmsg.result = ReturnCode["phone_code_notexit"]
	        return 0,0,gcmsg:ByteSize(),gcmsg:SerializeToString()
        end

		local timeMark = tonumber(sqlData[3])
		local currTime = TimeUtils.GetTime()
		local diffTime = TimeUtils.DifferentTime(timeMark, currTime)
		if diffTime > 600 then
			gcmsg.result = ReturnCode["phone_code_pastdue"]
			return 0,0,gcmsg:ByteSize(),gcmsg:SerializeToString()
		end	

        if cgmsg.infotype == 1 then
            --绑定支付宝
            local sqlCase = "select aliaccount from ag_player where userid=".. cgmsg.userid
		    mysqlItem:executeQuery(sqlCase)
	
		    local sqlData = mysqlItem:fetch({})
		    if sqlData == nil then
			    gcmsg.result = ReturnCode["bin_count_error_1"]
			    return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
		    end

            if sqlData[1] ~= "" then
				gcmsg.result = ReturnCode["bin_count_error_2"]
				return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
			end
			if cgmsg.aliaccount == "" or cgmsg.alipayee == "" then
				gcmsg.result = ReturnCode["bin_count_error_3"]
				return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
			end
			local sqlCase = "update ag_player set aliaccount=".."'"..cgmsg.aliaccount.."'"
				..", alipayee=".."'"..cgmsg.alipayee.."'".." where userid=".. cgmsg.userid
			mysqlItem:executeQuery(sqlCase)
			agyinfo.alipay = cgmsg.aliaccount
			AgentModel.SetAgent(cgmsg.userid, agyinfo)

            local content = "用户【"..pInfo.userid.."】绑定【"..pInfo.userid.."】支付宝 "..cgmsg.aliaccount
            local prechannel = GameUtils.GetChannel_login(pInfo.channel)
            local sqlCase = "insert into log_riskaction (userid,action,logintype,opttime,optname,optid,content,channel,prechannel)values("..cgmsg.userid..",".. 4 ..",'"..pInfo.oprsys.."','"..TimeUtils.GetTimeString().."','"..pInfo.nickname.."',"..cgmsg.userid..",'"..content.." ','"..pInfo.channel.."','"..prechannel.."')"
            mysqlLog:execute(sqlCase)
			LogBehavior.UserAction(pInfo,4, content)

            local sqlCase = " insert into log_player_risk(userid,change_alipay) values ( " ..pInfo.userid..","..1 ..")  ON DUPLICATE KEY update change_alipay=change_alipay + ".. 1
            --print(sqlCase)
            LogModel.LogUserGameDetail(sqlCase)	

        elseif cgmsg.infotype == 2 then --银行卡
            if cgmsg.bankaccount == "" or cgmsg.bankpayee == "" or cgmsg.bankname == "" then
				gcmsg.result = ReturnCode["bin_count_error_3"]
				return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
			end


			if pInfo.channel ~= "dblm_bct" then
				local sqlCase = "select realname from ag_player where userid=".. cgmsg.userid
				mysqlItem:executeQuery(sqlCase)
				local sqlData = mysqlItem:fetch()
				if sqlData == nil or sqlData ~=  cgmsg.bankpayee then
					gcmsg.result = ReturnCode["bin_count_error_4"]
					return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
				end
			end
            
            for i=1,#banklist do
                if cgmsg.bankaccount == banklist[i]["bankacount"] then
                    gcmsg.result = ReturnCode["bin_count_error_2"] --重复账号
				    return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
                end
            end
            local sqlCase = ""
            if agyinfo.bankaccount == "" or agyinfo.bankaccount == nil then
                --绑定到默认里面
                sqlCase = "update ag_player set bankacount=".."'"..cgmsg.bankaccount.."'"..", bankpayee=".."'"..cgmsg.bankpayee.."'"..
				", bankname=".."'"..cgmsg.bankname.."'"..", bankaddress=".."'"..cgmsg.bankaddress.."'"..
				", bankprovince=".."'"..cgmsg.bankprovince.."'"..", bankcity=".."'"..cgmsg.bankcity.."'"..
				", bankidnumber=".."'"..cgmsg.bankidnumber.."' where userid=".. cgmsg.userid
                
                agyinfo.bankaccount = cgmsg.bankaccount
			    AgentModel.SetAgent(cgmsg.userid, agyinfo)
            else
                local prechannel = GameUtils.GetChannel_login(pInfo.channel)
                sqlCase = "insert into dy_extrabanks(userid,bankacount,bankname,bankpayee,channel,prechannel)values("..cgmsg.userid..",'"..cgmsg.bankaccount.."','"..
                cgmsg.bankname.."','"..cgmsg.bankpayee.."','"..pInfo.channel.."','"..prechannel.."')"
            end

            local bankinfo = {bankacount= cgmsg.bankaccount, bankpayee=cgmsg.bankpayee, bankname=cgmsg.bankname }
            table.insert(banklist,bankinfo)
            mysqlItem:execute(sqlCase)
            local content = "用户【"..pInfo.userid.."】绑定【"..pInfo.userid.."】银行卡:"..cgmsg.bankaccount
            local prechannel = GameUtils.GetChannel_login(pInfo.channel)
            local sqlCase = "insert into log_riskaction (userid,action,logintype,opttime,optname,optid,content,channel,prechannel)values("..cgmsg.userid..",".. 5 ..",'"..pInfo.oprsys.."','"..TimeUtils.GetTimeString().."','"..pInfo.nickname.."',"..cgmsg.userid..",'"..content.." ','"..pInfo.channel.."','"..prechannel.."')"
            mysqlLog:execute(sqlCase)
            LogBehavior.UserAction(pInfo,4, content)

            local sqlCase = " insert into log_player_risk(userid,change_bank) values ( " ..pInfo.userid..","..1 ..")  ON DUPLICATE KEY update change_bank=change_bank + ".. 1
            --print(sqlCase)
            LogModel.LogUserGameDetail(sqlCase)
        end
        local sqlCase = "update  dy_authcode set state = 1 where id = "..codeid
        mysqlItem:execute(sqlCase)

	end
	if cgmsg.infotype == 1 then
		gcmsg.aliaccount = agyinfo.alipay
	elseif cgmsg.infotype == 2 then
        for i=1,#banklist do
            gcmsg.bankaccount:append(banklist[i]["bankacount"]) 
            gcmsg.bankpayee:append(banklist[i]["bankpayee"])
            gcmsg.bankname:append(banklist[i]["bankname"])
        end
	end
	
	gcmsg.userid = cgmsg.userid
	gcmsg.infotype = cgmsg.infotype
	gcmsg.requesttype = cgmsg.requesttype
	gcmsg.result = 0
	return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
end






