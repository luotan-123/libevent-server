module("BankSetPassword", package.seeall)

function execute(packetID, operateID, buffer)
	local cgmsg = msg_human_pb.cgbanksetpassword()
	local gcmsg = msg_human_pb.gcbanksetpassword()
	cgmsg:ParseFromString(buffer)
	
	repeat
        --[[
		local pInfo = PlayerModel.GetPlayerInfo(cgmsg.userid)
		if nil == pInfo then
			gcmsg.result = ReturnCode["user_not_exist"]
			break
		end
		
		if 0 ~= string.len(pInfo.bank_password) then
			gcmsg.result = ReturnCode["bank_pwd_already_set"]
			break
		end

		pInfo.bank_password = cgmsg.pwd
		PlayerModel.SetPlayerInfo(pInfo)
		local sqlCase = "update dy_player set bank_password="..cgmsg.pwd.." where userid="..cgmsg.userid
		SqlServer.rpush(sqlCase)
		
		gcmsg.result = 0
		]]

        if cgmsg.pwd == "" then
			gcmsg.result = ReturnCode["phone_code_notexit"]
			break
		end
		
		local pInfo = PlayerModel.GetPlayerInfo(cgmsg.userid)
		if nil == pInfo then
			gcmsg.result = ReturnCode["user_not_exist"]
			break
		end
        local codeid = ""
        local prechannel = GameUtils.GetChannel_login(pInfo.channel)
        if cgmsg.opttype == 0 then
            --设置忘记密码 只验证验证码
		    local sqlCase = "select * from dy_authcode where phonenum='"..pInfo.phonenum.."' and code="..cgmsg.vcode.." and prechannel = '"..prechannel.."' order by id desc"
		    mysqlItem:executeQuery(sqlCase)
		    local sqlData = mysqlItem:fetch({})
		    if sqlData == nil then
			    gcmsg.result = ReturnCode["phone_code_notexit"]
			    break
		    end
		    local state = tonumber(sqlData[5])
            codeid = tonumber(sqlData[1])
            if state == 1 then
	            gcmsg.result = ReturnCode["phone_code_notexit"]
	            break
            end

		    local startTime = tonumber(sqlData[3])
		    local nowTime = TimeUtils.GetTime()
		    if (nowTime - startTime) > 600 then
			    gcmsg.result = ReturnCode["phone_code_pastdue"]
			    break
		    end
        elseif cgmsg.opttype ==  1 then
            --修改密码 
		    if pInfo.bank_password ~= cgmsg.prepwd  then
		        gcmsg.result =  ReturnCode["bank_pwd_error"]
			    break
		    end

            local sqlCase = "select * from dy_authcode where phonenum='"..pInfo.phonenum.."' and code="..cgmsg.vcode.." and prechannel = '"..prechannel.."' order by id desc"
		    mysqlItem:executeQuery(sqlCase)
		    local sqlData = mysqlItem:fetch({})
		    if sqlData == nil then
			    gcmsg.result = ReturnCode["phone_code_notexit"]
			    break
		    end

		    local state = tonumber(sqlData[5])
            codeid = tonumber(sqlData[1])
            if state == 1 then
	            gcmsg.result = ReturnCode["phone_code_notexit"]
	            break
            end

		    local startTime = tonumber(sqlData[3])
		    local nowTime = TimeUtils.GetTime()
		    if (nowTime - startTime) > 600 then
			    gcmsg.result = ReturnCode["phone_code_pastdue"]
			    break
		    end


        end
        if md5(cgmsg.pwd) == pInfo.password then
            gcmsg.result = ReturnCode["bank_user_pwd_clash"]
			break
        end

		--写一条修改密码记录
		local pInfo = PlayerModel.GetPlayerInfo(cgmsg.userid)
		local msg = "id为"..cgmsg.userid.."的玩家修改了资金密码"
		LogBehavior.Info(pInfo, "payPwd", "payPwdModify", 0, msg)
        
        local content = "用户【"..pInfo.userid.."】修改用户【"..pInfo.userid.."】资金密码"
        local prechannel = GameUtils.GetChannel_login(pInfo.channel)
        local sqlCase = "insert into log_riskaction (userid,action,logintype,opttime,optname,optid,content,channel,prechannel)values("..cgmsg.userid..",".. 3 ..",'"..pInfo.oprsys.."','"..TimeUtils.GetTimeString().."','"..pInfo.nickname.."',"..cgmsg.userid..",'"..content.." ','"..pInfo.channel.."','"..prechannel.."')"
        mysqlLog:execute(sqlCase)

		pInfo.bank_password = cgmsg.pwd
		PlayerModel.SetPlayerInfo(pInfo)
		local sqlCase = "update dy_player set bank_password='"..cgmsg.pwd.."' where userid="..cgmsg.userid
		mysqlItem:execute(sqlCase)
		PlayerModel.SendPlayerInfo(pInfo,{"bank_password"})
		gcmsg.result = 0
        LogBehavior.UserAction(pInfo,4, content)	

        local sqlCase = "update  dy_authcode set state = 1 where id = "..codeid
        mysqlItem:execute(sqlCase)

        local sqlCase = " insert into log_player_risk(userid,change_money_pass) values ( " ..pInfo.userid..","..1 ..")  ON DUPLICATE KEY update change_money_pass=change_money_pass + ".. 1
        --print(sqlCase)
        LogModel.LogUserGameDetail(sqlCase)	

	until true
	
	return cgmsg.userid, 0, gcmsg:ByteSize(), gcmsg:SerializeToString()
end
