
module("MoneyTradeRecords", package.seeall)

--交易记录 充值 提现 转账 
function execute(packetID, operateID, buffer)

	local cgmsg = msg_human3_pb.cgmoneytraderecordslist()
	local gcmsg = msg_human3_pb.gcmoneytraderecordslist()

	cgmsg:ParseFromString(buffer)

    local pInfo = PlayerModel.GetPlayerInfo(cgmsg.userid)
    
    if pInfo == nil then
        gcmsg.result = ReturnCode["player_not_exist"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
    end
    local prechannel = GameUtils.GetChannel_login(pInfo.channel)
    local starttime = cgmsg.starttime ~= 0 and   cgmsg.starttime or 0
    local endtime = cgmsg.endtime ~= 0 and   cgmsg.endtime or TimeUtils.GetTime()
    local recordinfolist = {}
    if cgmsg.opttype == 1 then
        --充值记录
        --vip充值
        local sqlCase = "select orderid,amount,recharge_id,optremark,add_time, status,type from log_recharge where userid = "..pInfo.userid.." and type < 9 and  channel =  '"..pInfo.channel.."' and add_time >= "..starttime.." and add_time <= "..endtime .. " limit ".. (20 * (cgmsg.pagenum - 1))..", 20"
        mysqlLog:executeQuery(sqlCase)
        while true do
            local sqlData =  mysqlLog:fetch({})
            if sqlData == nil then
                break
            end
            --类型【（0 用户充值  1 后台vip充值 2 赠送 3 提现扣款  4 普通扣款）被遗弃】5-系统赠送，6-优秀代理，7-充值补发，8-异常资金
            local remark = ""
            if tonumber(sqlData[7]) == 5 then
                remark = "系统优惠"
            elseif tonumber(sqlData[7]) == 6 then
                 remark = "优秀代理"
            elseif tonumber(sqlData[7]) == 7 then
                 remark = "充值补发"
            elseif tonumber(sqlData[7]) == 8 then
                 remark = "异常资金"
            end
            -- 1:订单id  2:日期  3:充值金额  4: 状态（0 待处理  1 成功 2 失败） 5: 充值方式 1银行卡 2 支付宝 3 vip充值 4 微信转账 6:收款人 7:备注
            local addrecord  = {id = sqlData[1],orderid=sqlData[1], time=sqlData[5], jetton=sqlData[2], state=tonumber(sqlData[6]), method=3,  payee=pInfo.userid,  remark = sqlData[4] or "",paytype="" }
            table.insert(recordinfolist,addrecord)

        end

        ---汇款转账
        local sqlCase = "select * from dy_order_offline where userid = "..pInfo.userid.." and channel =  '"..pInfo.channel.."' and rsdate >= '"..TimeUtils.GetTimeString(starttime).."' and rsdate <= '"..TimeUtils.GetTimeString(endtime).."'".. " limit ".. (20 * (cgmsg.pagenum - 1))..", 20"
        mysqlItem:executeQuery(sqlCase)
        --print(sqlCase)
        while true do
            local sqlData =  mysqlItem:fetch({})
            if sqlData == nil then
                break
            end

            local state = 0 -- 状态 （充值 0 待处理  1 成功 2 失败）
            -- 1：发起，2：审核中，3：成功，4：失败
            if tonumber(sqlData[13]) <  3 then
                state = 0
            elseif tonumber(sqlData[13]) ==  3 then
                state = 1
            elseif tonumber(sqlData[13]) ==  4 then
                state = 2
            end

            local method = 1 -- 1 支付宝 2 微信 3 银行卡  
            --充值方式 1银行卡 2 支付宝 3 vip充值 4 微信转账
            if tonumber(sqlData[4]) == 1 then
                method = 2
            elseif tonumber(sqlData[4]) == 2 then
                method = 4
            elseif tonumber(sqlData[4]) == 3 then
                method = 1
            end

            -- 1:订单id  2:日期  3:充值金额  4: 状态（0 待处理  1 成功 2 失败） 5: 充值方式 1银行卡 2 支付宝 3 vip充值 4 微信转账 6:收款人 7:备注
            local addrecord  = {id = sqlData[1], orderid=sqlData[15], time=sqlData[14], jetton=sqlData[21], state=state, method=method,  payee=pInfo.userid,  remark = sqlData[17],paytype="" }
            table.insert(recordinfolist,addrecord)
        end
       
        
        local sqlCase = "select * from dy_orderinfo where userid = "..pInfo.userid.." and channel =  '"..pInfo.channel.."' and ctreatedate >= '"..TimeUtils.GetTimeString(starttime).."' and ctreatedate <= '"..TimeUtils.GetTimeString(endtime).."'".. " limit ".. (20 * (cgmsg.pagenum - 1))..", 20"
        mysqlItem:executeQuery(sqlCase)
        while true do
            local sqlData =  mysqlItem:fetch({})
            if sqlData == nil then
                break
            end
            local state = 0 -- 状态 （充值 0 待处理  1 成功 2 失败）
             --0:发起支付请求;1:收到支付回调，支付成功 (加金币后 状态转为2)，-1：返回失败 
           
            if tonumber(sqlData[10])  == -1 then
                state = 2 
            elseif tonumber(sqlData[10])  <= 1 then
                state = 0 
            elseif tonumber(sqlData[10])  == 2 then
                state = 1 
            end
            --充值方式 1银行卡 2 支付宝 3 vip充值 4 微信转账
                --[['101' => '支付宝H5',
                '102' => '支付宝扫码',
                '103' => '微信H5',
                '104' => '微信扫码',
                '110' => '云闪付',
                '111' => '银行卡'
                ]]
            local method = 1

            if tonumber(sqlData[16]) ==101 or tonumber(sqlData[16]) == 102  then
                method = 2
            elseif  tonumber(sqlData[16]) ==103 or tonumber(sqlData[16]) == 104  then
                method = 4
            elseif  tonumber(sqlData[16]) ==110 or tonumber(sqlData[16]) == 111  then
                method = 1
            end

            -- 1:订单id  2:日期  3:充值金额  4: 状态（0 待处理  1 成功 2 失败） 5: 充值方式 1银行卡 2 支付宝 3 vip充值 4 微信转账 6:收款人 7:备注
            local addrecord  = {id = sqlData[1], orderid=sqlData[4], time=sqlData[11], jetton=sqlData[9], state=state, method=method,  payee=pInfo.userid,  remark = sqlData[14],paytype = sqlData[15] or "",out_trade_no=sqlData[12] or "",plat_order_id=sqlData[17] or "" }
            table.insert(recordinfolist,addrecord)

                   
        end

        table.sort(recordinfolist,function(a,b)
             return TimeUtils.GetTime(a.time) >  TimeUtils.GetTime(b.time)
        end)

        local sqlCase = "select dict_value from web_dict where dict_category = '".."im_pay_url".."' and prechannel = '"..prechannel.."'"
        local url = ""
        mysqlItem:executeQuery(sqlCase)
        local sqlData =  mysqlItem:fetch()
        if sqlData ~= nil  then
            url = sqlData
        end
        --print(sqlCase,url)
        for i=1,20  do
            if recordinfolist[i] ~= nil then
                
               local addH = gcmsg.records:add()
               addH.orderid		    = recordinfolist[i]["orderid"]
               addH.time			= recordinfolist[i]["time"]
               addH.jetton			= recordinfolist[i]["jetton"]
               addH.state			= recordinfolist[i]["state"]
               addH.method			= recordinfolist[i]["method"]
               addH.payee			= tostring(recordinfolist[i]["payee"])
               addH.remark			= recordinfolist[i]["remark"] or ""
               if recordinfolist[i]["paytype"]  == "钱包支付" and url ~= "" then
                  addH.url = url.."?id="..recordinfolist[i]["id"].."&orderid="..recordinfolist[i]["orderid"].."&out_trade_no="..recordinfolist[i]["out_trade_no"].."&plat_order_id="..recordinfolist[i]["plat_order_id"]
               end
            end

        end
        
    elseif cgmsg.opttype == 2 then
        --提现记录
        local sqlCase = "select * from ag_drawmoney where userid = "..pInfo.userid.." and channel =  '"..pInfo.channel.."' and rsdate >= '"..TimeUtils.GetTimeString(starttime).."' and rsdate <= '"..TimeUtils.GetTimeString(endtime).."'".. " limit ".. (20 * (cgmsg.pagenum - 1))..", 20"
        mysqlItem:executeQuery(sqlCase)
        while true do
            local sqlData =  mysqlItem:fetch({})
            if sqlData == nil then
                break
            end
            local payee = tostring(pInfo.userid)
            local accountname =""
            local account = ""
            if tonumber(sqlData[18]) == 1 then
                --支付宝
                payee = tostring(sqlData[19])
                accountname =sqlData[13]
                account = sqlData[13]
            elseif tonumber(sqlData[18]) == 2 then
                --银行卡
                payee = tostring(sqlData[20])
                accountname =sqlData[15]
                account = sqlData[14]
            end
            

            -- 1:订单id  2:日期  3:充值金额  4: 状态（1发起提款，2审核中，3成功，4失败，5驳回） 5: 提现方式 (1提现到支付宝，2提现到银行卡，3提现到余额) 6:收款人 7:备注, 8:银行或支付宝名称 9 支付宝或银行卡账号
            local addrecord  = {orderid=sqlData[17], time=sqlData[8], jetton=sqlData[9], state=tonumber(sqlData[7]), method=tonumber(sqlData[18]),  payee=payee,  remark = sqlData[23],accountname=accountname,account=account }
            table.insert(recordinfolist,addrecord)

        end
        table.sort(recordinfolist,function(a,b)
             return TimeUtils.GetTime(a.time) >  TimeUtils.GetTime(b.time)
        end)

        for i=1,20  do
            if recordinfolist[i] ~= nil then
                
               local addH = gcmsg.records:add()
               addH.orderid		    = recordinfolist[i]["orderid"]
               addH.time			= recordinfolist[i]["time"]
               addH.jetton			= recordinfolist[i]["jetton"]
               addH.state			= recordinfolist[i]["state"]
               addH.method			= recordinfolist[i]["method"]
               addH.payee			= tostring(recordinfolist[i]["payee"])
               addH.remark			= recordinfolist[i]["remark"] or ""
	           addH.bankername		= recordinfolist[i]["accountname"]
	           addH.bankernum		= recordinfolist[i]["account"]
            end

        end

    elseif cgmsg.opttype == 3 then
        local sqlCase = "select * from log_records where userid = "..pInfo.userid.." and opttime >= '"..TimeUtils.GetTimeString(starttime).."' and opttime <= '"..TimeUtils.GetTimeString(endtime).."' and msg = '"..'transfer'.. "' limit ".. (20 * (cgmsg.pagenum - 1))..", 20"
        mysqlLog:executeQuery(sqlCase)
        --print(sqlCase)
        while true do
            local sqlData =  mysqlLog:fetch({})
            if sqlData == nil then
                break
            end
            local payee = tostring(pInfo.userid)
            
            local addrecord  = {orderid=sqlData[7], time=sqlData[5], jetton=sqlData[4], state=3,payee=payee,  remark = sqlData[6] }
            table.insert(recordinfolist,addrecord)

        end
        table.sort(recordinfolist,function(a,b)
             return TimeUtils.GetTime(a.time) >  TimeUtils.GetTime(b.time)
        end)

        for i=1,20  do
            if recordinfolist[i] ~= nil then
               local addH = gcmsg.records:add()
               addH.orderid		    = recordinfolist[i]["orderid"]
               addH.time			= recordinfolist[i]["time"]
               addH.jetton			= recordinfolist[i]["jetton"]
               addH.state			= recordinfolist[i]["state"]
               addH.payee			= tostring(recordinfolist[i]["payee"])
               addH.remark			= recordinfolist[i]["remark"] or ""
            end
        end
    end
    gcmsg.opttype = cgmsg.opttype
    gcmsg.result = 0
	return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
end