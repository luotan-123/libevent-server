
module("ActivityHero", package.seeall)

--1.检查用户是否存在缓存中，如果缓存中有，就从缓存中取需要的数据，如果缓存中
--没有就从数据库拉去，并且保存到缓存中
--2.如果用户资料不存在，则创建用户
--3.对用户登录情况进行统计
function execute(packetID, operateID, buffer)
	
	local cgmsg = msg_human2_pb.cgactivityhero()
	local gcmsg = msg_human2_pb.gcactivityhero()

	cgmsg:ParseFromString(buffer)
	local checkMsg = RedisHelper.CheckRedis(cgmsg.userid, operateID)
	
	if checkMsg ~= nil then
		gcmsg:ParseFromString(checkMsg)
		return cgmsg.userid, 0, gcmsg:ByteSize(), gcmsg:SerializeToString()
	end
	
	local pInfo = PlayerModel.GetPlayerInfo(cgmsg.userid)	
	if pInfo == nil then
		gcmsg.result = 0
		gcmsg:ParseFromString(checkMsg)
		return cgmsg.userid, 0, gcmsg:ByteSize(), gcmsg:SerializeToString()
	end
	
	
	if cgmsg.ctype == 1 then
		ActivityModel.achaward(cgmsg.userid, gcmsg, true)
	else
		ActivityModel.achaward(cgmsg.userid, gcmsg, true)
	end
	
	gcmsg.result = 0 
	gcmsg.ctype = cgmsg.ctype
	return cgmsg.userid, 0, gcmsg:ByteSize(), gcmsg:SerializeToString()

end