module("GetCashWithdrawalList", package.seeall)

function execute(packetID, operateID, buffer)
	
	
	
	local cgmsg = msg_human2_pb.cggetcashwithdrawallist()
	local gcmsg = msg_human2_pb.gcgetcashwithdrawallist()

	cgmsg:ParseFromString(buffer)
	local checkMsg = RedisHelper.CheckRedis(cgmsg.userid, operateID)
	
	if checkMsg ~= nil then
		gcmsg:ParseFromString(checkMsg)
		LogBehavior.Warning(cgmsg.userid, "pInfo", "GetCashWithdrawalList", 0, "缓存已存在")
		return cgmsg.userid, 0, gcmsg:ByteSize(), gcmsg:SerializeToString()
	end

    local pInfo = PlayerModel.GetPlayerInfo(cgmsg.userid)
    if pInfo == nil then
        gcmsg.result = ReturnCode["player_not_exist"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
    end
	
	local sqlCase = "select * from dy_drawconf where state=1"
	mysqlItem:executeQuery(sqlCase)
	--local freeamount = FootballModel.SetUserCashFreeAmount(cgmsg.userid,0)
    local feerate = 0
    local prechannel = GameUtils.GetChannel_login(pInfo.channel)
    local viprulepb =  VipMgrModel.GetVipRule(pInfo.viplevel,prechannel)
    local viprule = st_vipmgr_pb.viprule()
    if viprulepb ~= nil then
        viprule:ParseFromString(viprulepb)
        --freeamount  = viprule.freedrawamount
        feerate     = viprule.drawfee
    end



	while true do
		local sqlData = mysqlItem:fetch({})
		if sqlData == nil then
			break
		end
		local addList = gcmsg.conflist:add()
		addList.id = tonumber(sqlData[2])
		addList.cashwithdrawaltype = tonumber(sqlData[2])
		addList.name = sqlData[5]
		addList.des = sqlData[6]
		addList.state = tonumber(sqlData[11])
        addList.feerate = tonumber(feerate) --tonumber(sqlData[12])
        addList.minjetton = tonumber(sqlData[13])
        addList.retain = tonumber(sqlData[15])

	end
    local freeamount =  FootballModel.SetUserCashFreeAmount(cgmsg.userid,0)
	gcmsg.freeamount = tostring(freeamount)
    gcmsg.cashamount = pInfo.jetton
	gcmsg.result = 0
	
	return cgmsg.userid, 0, gcmsg:ByteSize(), gcmsg:SerializeToString()
end