
module("PlayerStatus", package.seeall)

--玩家退到后台已经从后台进入的时候发送该协议
--同时检查玩家是否在牌桌中
--
function execute(packetID, operateID, buffer)
	
	local cgmsg = msg_human_pb.cgplayerstatus()
	local gcmsg = msg_human_pb.gcplayerstatus()
	cgmsg:ParseFromString(buffer)
	
	gcmsg.userid = cgmsg.userid
	gcmsg.status = cgmsg.status
	
	

	return cgmsg.userid, 0, 0, gcmsg:SerializeToString()  --这里是不用给他自己发的
end
