module("RechargeRecord", package.seeall)


function execute(packetID, operateID, buffer)

	local cgmsg = msg_human2_pb.cgrechargerecord()
	local gcmsg = msg_human2_pb.gcrechargerecord()
	
	cgmsg:ParseFromString(buffer)
	local pInfo = PlayerModel.GetPlayerInfo(cgmsg.userid)
	if pInfo == nil then
		gcmsg.result = ReturnCode["player_not_exist"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
	end
	--在线充值记录
	local RecordList = {}
	local sqlCase = "select * from dy_orderinfo where userid=".. cgmsg.userid.." and state= 2 order by id desc limit 20"

	mysqlItem:executeQuery(sqlCase)
	while true do
		
		local sqlData = mysqlItem:fetch({})
		if sqlData == nil then
			break
		end
		local tmp = {}
		tmp["orderid"] = sqlData[17]
		tmp["date"] = TimeUtils.GetTime(sqlData[7])
		tmp["state"] = 2
		tmp["paytype"] = tonumber(sqlData[16])
		tmp["count"] = sqlData[9]
		table.insert(RecordList, tmp)
	end
	
	
	--Vip充值记录
	local sqlCase = "select * from log_recharge where userid=".. cgmsg.userid.." and type=0 and status= 1 order by id desc limit 20"
	mysqlLog:executeQuery(sqlCase)
	while true do
		local sqlData = mysqlLog:fetch({})
		if sqlData == nil then
			break
		end
		local tmp = {}
		tmp["orderid"] = sqlData[9]
		tmp["date"] = sqlData[7]
		tmp["state"] = 2
		tmp["paytype"] = g_shopType.pay_VIP
		tmp["count"] = sqlData[3]
		table.insert(RecordList, tmp)
	end
	--得出最新的20条
	if #RecordList >= 2  then
		table.sort(RecordList, function(a,b)
			if tonumber(a["date"]) > tonumber(b["date"]) then
				return true
			end	
		end)
	end
	local maxNum = #RecordList > 20 and 20 or #RecordList
	for i = 1, maxNum do 
		gcmsg.orderid:append(RecordList[i]["orderid"])
		gcmsg.date:append(tostring(RecordList[i]["date"]))
		gcmsg.state:append(RecordList[i]["state"])
		gcmsg.paytype:append(RecordList[i]["paytype"])
		gcmsg.count:append(tonumber(RecordList[i]["count"]))
		
	end
	
	gcmsg.result = 0
	gcmsg.userid = cgmsg.userid
	gcmsg.page = cgmsg.page
	return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
end






