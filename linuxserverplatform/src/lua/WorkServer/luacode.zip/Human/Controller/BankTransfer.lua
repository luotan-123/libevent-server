module("BankTransfer", package.seeall)

function execute(packetID, operateID, buffer)
	local cgmsg = msg_human_pb.cgbanktransfer()
	local gcmsg = msg_human_pb.gcbanktransfer()
	cgmsg:ParseFromString(buffer)
	if cgmsg.opttype == 0 then
	    repeat
		    if cgmsg.userid == cgmsg.touserid then
			    gcmsg.result = ReturnCode["arg_amount_error"]
			    break
		    end
		
		    local pSelf = PlayerModel.GetPlayerInfo(cgmsg.userid)
		    local pInfo = PlayerModel.GetPlayerInfo(cgmsg.touserid)
		    if nil == pSelf or nil == pInfo then
			    gcmsg.result = ReturnCode["user_not_exist"]
			    break
		    end
		
		    local tableid = PlayerModel.GetCurrTableID(cgmsg.userid)
		    if tableid ~= 0 then
			    gcmsg.result = ReturnCode["function_limit"]
			    break
		    end
		
		    if pSelf.silent == 1 then
			    gcmsg.result = ReturnCode["function_limit"]
			    break
		    end
		
		    --[[if 0 == string.len(pSelf.bank_password) then
			    gcmsg.result = ReturnCode["bank_pwd_never_set"]
			    break
		    end]]
		    -- 
		    if 0 >= tonumber(cgmsg.amount) then
			    gcmsg.result = ReturnCode["arg_amount_error"]
			    break
		    end
		
		    if tonumber(cgmsg.amount) > tonumber(pSelf.bank_jetton) then
			    gcmsg.result = ReturnCode["bank_jetton_not_enough"]
			    break
		    end
		
		    BankModel.JettonTransfer(pSelf, pInfo, cgmsg.amount)
		    PlayerModel.SendPlayerInfo(pSelf, {"jetton", "bank_jetton"})
		    PlayerModel.SendPlayerInfo(pInfo, {"jetton", "bank_jetton"})
		
		    gcmsg.result = 0
		    gcmsg.record.userid = pInfo.userid
		    gcmsg.record.nickname = pInfo.nickname or ""
		    gcmsg.record.amount = cgmsg.amount
		    gcmsg.record.timemark = TimeUtils.GetTimeString()
		
		
		    LogServer.TransferCount(pInfo,pSelf,cgmsg.amount)
		    --发送邮件通知被赠送的玩家
		    local addItem = st_human_pb.mailinfo() 
		    addItem.senderid = cgmsg.userid
		    addItem.sender = pSelf.nickname
		    addItem.receiverid = cgmsg.touserid
		    addItem.receiver = pInfo.nickname
		    addItem.senddate = TimeUtils.GetTimeString(TimeUtils.GetTime())
		    addItem.validity = 7
		    addItem.mailtype = g_mailType.SYS_Player
		    addItem.mailstate = g_mailState.state_unread
		    addItem.title='转账通知'
		    addItem.content='老板好，您收到ID: '..cgmsg.userid..'的好友赠送的'..(cgmsg.amount/100)..'金币'..
		    '请前往“保险柜”领取。祝老板发大财！'

		    local tTime = TimeUtils.GetTableTime()
	        tTime.hour = 0
	        tTime.min = 0
	        tTime.sec = 0
	        local currSec = TimeUtils.GetTime(tTime)
	        currSec = currSec + g_daySeconds*2
	        addItem.markdate = TimeUtils.GetDayString(currSec)	
		    MailModel.AddMail(addItem)		
		    --红点通知
		    NoticeModel.SendNotice(cgmsg.touserid, g_noticeType.mail_unread)	

	    until true
	
	    return cgmsg.userid, 0, gcmsg:ByteSize(), gcmsg:SerializeToString()
    elseif cgmsg.opttype == 1 then
        repeat
            if cgmsg.userid == cgmsg.touserid then
			    gcmsg.result = ReturnCode["transfer_error_1"]
			    break
		    end

		    local pSelf = PlayerModel.GetPlayerInfo(cgmsg.userid)
		    local pInfo = PlayerModel.GetPlayerInfo(cgmsg.touserid)
		    if nil == pSelf or nil == pInfo then
			    gcmsg.result = ReturnCode["user_not_exist"]
			    break
		    end

--            local tableid = PlayerModel.GetCurrTableID(cgmsg.userid)
--		    if tableid ~= 0 then
--			    gcmsg.result = ReturnCode["function_limit"]
--			    break
--		    end
		

            if pSelf.silent == 1 then
			    gcmsg.result = ReturnCode["function_limit"]
			    break
		    end

            if 0 >= tonumber(cgmsg.amount) then
			    gcmsg.result = ReturnCode["transfer_error_2"]
			    break
		    end

            if tonumber(cgmsg.amount) > tonumber(pSelf.jetton) then
			    gcmsg.result = ReturnCode["carryjetton_not_enough"]
			    break
		    end
            if pSelf.transfer ~= 1 then
                gcmsg.result = ReturnCode["function_limit"]
			    break
            end
            local nowstamp = TimeUtils.GetTime()
            --扣钱
            PlayerModel.DecJetton(pSelf,tonumber(cgmsg.amount),"transfer","transfer")
            PlayerModel.SendJetton(pSelf)


            local remark = "向玩家"..pInfo.userid.."转账"
            LogServer.addRecords(pSelf.userid,2,remark,0 - tonumber(cgmsg.amount),pSelf.userid..pInfo.userid..nowstamp,"transfer")

            --加钱
			PlayerModel.AddJetton(pInfo, tonumber(cgmsg.amount), "transfer", "transfer")
			PlayerModel.SetPlayerInfo(pInfo)
			--PlayerModel.SendJetton(pInfo)  
            local gcUpdate = msg_human_pb.gcupdateplayerinfo()
            gcUpdate.typelist:append("jetton")
            gcUpdate.valuelist:append(tostring(pInfo.jetton))
            gcUpdate.result = 0
            PushMsgModel.PushMsg(OnlineModel.GetUserLogonID(pInfo.userid) or 1, pInfo.userid, PacketCode[1026].client, gcUpdate:ByteSize(), gcUpdate:SerializeToString())
            
             
            remark = "收到玩家"..pSelf.userid.."转账"
            LogServer.addRecords(pInfo.userid,1,remark,tonumber(cgmsg.amount),pSelf.userid..pInfo.userid..nowstamp,"transfer")

            
            local transferinfo = msg_human3_pb.gctransferinfo()
            transferinfo.userid = pInfo.userid
            transferinfo.fuserid = pSelf.userid
            transferinfo.fnickname = pSelf.nickname
            transferinfo.amount = tostring(cgmsg.amount)
            transferinfo.transferid = pSelf.userid..pInfo.userid..nowstamp
            PlayerModel.SetUserTransferinfo(pInfo.userid, transferinfo)
            --推送给玩家
            --SendMessage(pInfo.userid,PacketCode[8716].client,transferinfo:ByteSize(),transferinfo:SerializeToString())


            gcmsg.result = 0
		    gcmsg.record.userid = pInfo.userid
		    gcmsg.record.nickname = pInfo.nickname or ""
		    gcmsg.record.amount = cgmsg.amount
		    gcmsg.record.timemark = TimeUtils.GetTimeString()
	
		    LogServer.TransferCount(pInfo,pSelf,cgmsg.amount,"钱包转账")

        until true;

        return cgmsg.userid, 0, gcmsg:ByteSize(), gcmsg:SerializeToString()
	end
	
end