
module("CommissionGet", package.seeall)


function execute(packetID, operateID, buffer)

	local cgmsg = msg_human2_pb.cgcommissionget()
	local gcmsg = msg_human2_pb.gccommissionget()
	
	cgmsg:ParseFromString(buffer)
	local pInfo = PlayerModel.GetPlayerInfo(cgmsg.userid)
	if pInfo == nil then
		gcmsg.result = ReturnCode["player_not_exist"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
	end
	
	if cgmsg.requesttype == 2 then
		local sqlCase = "select agent1count, agent2count from ag_player where userid="..cgmsg.userid
		mysqlItem:executeQuery(sqlCase)
		local sqlData = mysqlItem:fetch({})
		if sqlData == nil then
			gcmsg.result = ReturnCode["get_commission_error_1"]
			return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
		end
		
		local agent1count = sqlData[1] == nil and 0 or tonumber(sqlData[1])
		local agent2count = sqlData[2] == nil and 0 or tonumber(sqlData[2])
		local CommissionCount = agent1count + agent2count
		
		if CommissionCount == 0 then
			gcmsg.result = ReturnCode["get_commission_error_1"]
			return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
		end
		
		
		PlayerModel.AddJetton(pInfo, CommissionCount,"CommissionGet","CommissionGet")
		PlayerModel.SetPlayerInfo(pInfo)
		PlayerModel.SendJetton(pInfo)

		gcmsg.getcommission = CommissionCount
		local sqlCase = "update ag_player set agent1count=agent1count-"..agent1count.. ", agent2count=agent2count-"..agent2count..", allmoney=allmoney+"..CommissionCount.." where userid="..cgmsg.userid
		
		mysqlItem:executeQuery(sqlCase)
	end
	
	local sqlCase = "select * from ag_player where userid="..cgmsg.userid
	mysqlItem:executeQuery(sqlCase)
	
	local sqlData = mysqlItem:fetch({})
	if sqlData ~= nil then
		gcmsg.subordinatecount_1 = tonumber(sqlData[30]) == nil and 0 or tonumber(sqlData[30])
		gcmsg.subordinatecount_2 = tonumber(sqlData[31]) == nil and 0 or tonumber(sqlData[31])
		gcmsg.commissioncount = tonumber(sqlData[15]) == nil and 0 or tonumber(sqlData[15])

		gcmsg.subordinatenum = AgentModel.GetUserDirUserLen(cgmsg.userid)
	end
	gcmsg.userid = cgmsg.userid
	gcmsg.requesttype = cgmsg.requesttype
	gcmsg.result = 0
	return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
end






