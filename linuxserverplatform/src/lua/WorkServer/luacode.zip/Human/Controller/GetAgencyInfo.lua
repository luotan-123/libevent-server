
module("GetAgencyInfo", package.seeall)


function execute(packetID, operateID, buffer)

	local cgmsg = msg_human_pb.cggetagencyinfo()
	local gcmsg = msg_human_pb.gcgetagencyinfo()
	
	cgmsg:ParseFromString(buffer)
	local pInfo = PlayerModel.GetPlayerInfo(cgmsg.userid)
	if pInfo == nil then
		gcmsg.result = ReturnCode["player_not_exist"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
	end
	
	local agyinfo = AgentModel.GetAgentInfo(cgmsg.userid)
	if agyinfo ~= nil then
		gcmsg.agyinfo.userid = agyinfo.userid
		gcmsg.agyinfo.invitestr = agyinfo.invitestr
		gcmsg.agyinfo.level = agyinfo.level
		gcmsg.agyinfo.soleagent = agyinfo.soleagent
		gcmsg.agyinfo.agent1 = agyinfo.agent1
		gcmsg.agyinfo.agent2 = agyinfo.agent2
		gcmsg.agyinfo.agent3 = agyinfo.agent3
		gcmsg.agyinfo.agent4 = agyinfo.agent4
		gcmsg.agyinfo.qrcodeurl = agyinfo.qrcodeurl
		gcmsg.agyinfo.datemark = agyinfo.datemark
		gcmsg.agyinfo.moneymark = agyinfo.moneymark
		gcmsg.agyinfo.weekmoney = agyinfo.weekmoney
		gcmsg.agyinfo.exclusiveurl = agyinfo.exclusiveurl
		gcmsg.agyinfo.alipay = agyinfo.alipay
		gcmsg.agyinfo.bankaccount = agyinfo.bankaccount
	end
	gcmsg.result = 0
	return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
end
