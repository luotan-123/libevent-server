module("GetHongBaoYu", package.seeall)

--红包处理
function execute(packetID, operateID, buffer)
    local cgmsg = msg_human2_pb.cghongbaoyu()
	local gcmsg = msg_human2_pb.gchongbaoyu()
	
	cgmsg:ParseFromString(buffer)
	
	local checkMsg = RedisHelper.CheckRedis(cgmsg.userid, operateID)
	if checkMsg ~= nil then
		gcmsg:ParseFromString(checkMsg)
		LogBehavior.Warning(cgmsg.userid, "pInfo", "GetHongBaoYu", 0, "缓存已存在")
		return cgmsg.userid, 0, gcmsg:ByteSize(), gcmsg:SerializeToString()
	end

	local pInfo = PlayerModel.GetPlayerInfo(cgmsg.userid)
	if pInfo == nil then
		LogBehavior.Error(cgmsg.userid,"pInfo","GetHongBaoYu", ReturnCode["player_not_exist"], "该玩家不存在")
		gcmsg.result = ReturnCode["player_not_exist"]
		return cgmsg.userid, 0, gcmsg:ByteSize(), gcmsg:SerializeToString()
	end
    gcmsg.userid = cgmsg.userid

    
    --查询活动是否存在
	local sqlCase = "select * from dy_activity where activityid ="..110
	mysqlItem:executeQuery(sqlCase)
	local sqlData = mysqlItem:fetch({})
	if sqlData == nil then
		gcmsg.result = ReturnCode["activity_no_exit"]
		return cgmsg.userid, 0, gcmsg:ByteSize(), gcmsg:SerializeToString()
	end	


    local state = tonumber(sqlData[6])
	local startTime = sqlData[9] == nil and "" or sqlData[9]
	local endTime = sqlData[10] == nil and "" or sqlData[10]
	if startTime ~= "" then
		startTime = TimeUtils.GetTime(startTime)
	end
	if endTime ~= "" then
		endTime = TimeUtils.GetTime(endTime)
	end

	if startTime == "" or endTime == "" then
		gcmsg.result = ReturnCode["activity_no_exit"]
		return cgmsg.userid, 0, gcmsg:ByteSize(), gcmsg:SerializeToString()
	end
	
	local nowTime = TimeUtils.GetTime()
	if startTime > nowTime 
	or endTime < nowTime 
	or state ~= 1 then
		gcmsg.result = ReturnCode["activity_end"]
		return cgmsg.userid, 0, gcmsg:ByteSize(), gcmsg:SerializeToString()
	end

    --是否已经领取
    
    if PlayerModel.isHongBaoYuUserGotListExit(cgmsg.userid) then
        gcmsg.result = ReturnCode["activity_has_got"]
		return cgmsg.userid, 0, gcmsg:ByteSize(), gcmsg:SerializeToString()
    end

    --红包雨领取的流水限制
    local archi_limit = PlayerModel.getHongBaoArchiLimit()
    local arch = 0
    --今天的流水
	local today = PlayerStatsService.GetTodayDate()
	local to = today.year.."-"..today.month.."-"..today.day	--今天
	local sqlCase = "select achamount from log_playerdaily where userid="..cgmsg.userid .." and dateid='"..to.."'"
	mysqlLog:executeQuery(sqlCase)
	local sqlData = mysqlLog:fetch()
	if sqlData ~= nil then
        arch = tonumber(sqlData)
	end	

    if arch <  archi_limit then
        --流水不满足
        gcmsg.result = ReturnCode["luckwheel_error_1"]
	   return cgmsg.userid, 0, gcmsg:ByteSize(), gcmsg:SerializeToString()
    end


    local hongbaonum = PlayerModel.countHongBaoNum(-1)
    if hongbaonum < 0 then
       gcmsg.result = ReturnCode["nohongbao"]
	   return cgmsg.userid, 0, gcmsg:ByteSize(), gcmsg:SerializeToString()
    end

    --领取
    local hongbaovalue = PlayerModel.getHongBaovalue()
    gcmsg.jettons = hongbaovalue
    gcmsg.result = 0

    --写派奖记录
	local activitytype = 110
	local sqlCase = "insert into log_activity_record(userid,nickname,activitytype,rewardjetton) values("
	..pInfo.userid..",'"..pInfo.nickname.."',"..activitytype..","..hongbaovalue..")" 
	mysqlItem:execute(sqlCase)

    PlayerModel.addHongBaoYuUserGotList(pInfo.userid)
    --玩家添加金币
	PlayerModel.AddJetton(pInfo, hongbaovalue, "award", "win")
	PlayerModel.SetPlayerInfo(pInfo)
	PlayerModel.SendJetton(pInfo)   --同步分数先
    --luaPrint("userid: ".. cgmsg.userid.." hongbaovalue: "..hongbaovalue)
    LogDispatch.MailAward(pInfo, hongbaovalue)

    --通过邮件通知
    local addItem = st_human_pb.mailinfo() 
	addItem.title='红包雨'
	addItem.content='您在红包雨中抢到'..(hongbaovalue/100)..'金币'
	addItem.senderid = 1
	addItem.sender = "系统"
	addItem.receiverid = pInfo.userid
	addItem.receiver = pInfo.nickname
	addItem.senddate = TimeUtils.GetTimeString(currDate)
	addItem.validity = 7
	--addItem.externdata = "[[1002,"..(getLuckRejetton).."]]"
	addItem.mailtype = g_mailType.SYS_Player
	addItem.mailstate = g_mailState.state_unread
	local tTime = TimeUtils.GetTableTime()
	tTime.hour = 0
	tTime.min = 0
	tTime.sec = 0
	local currSec = TimeUtils.GetTime(tTime)
	currSec = currSec + g_daySeconds*2
	addItem.markdate = TimeUtils.GetDayString(currSec)
	MailModel.AddMail(addItem)
    --红点通知
    --NoticeModel.SendNotice(cgmsg.userid, g_noticeType.mail_unread)	

    return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
end
