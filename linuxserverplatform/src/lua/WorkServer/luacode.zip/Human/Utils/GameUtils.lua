

GameUtils = {}



function GameUtils.GetGameName(gameType)
	
	
	local gameNameList = {}
	gameNameList[g_footballgameDefine.game_type] = "足球赛事"
	
	local gameName = gameNameList[gameType] == nil and  gameType or gameNameList[gameType]
	return gameName
end

function GameUtils.GetTableName(gameType,tableType)
	

	local tGradeList = {"初级场","中级场","高级场","至尊场","富贵场","百赢场"}
	tGradeList[0] = "房卡场"
	
	tableType = math.mod(tableType, #tGradeList)
    if gameType == g_footballgameDefine.game_type  then
        return ""
    end

	--[[
	if gameType == g_gdmjType.type_tdh_jbc then
		
	elseif gameType == g_barccatatDefine.game_type then
		
		tGradeList = {"荣耀厅01","荣耀厅02","传奇厅01","传奇厅02","富贵厅01","富贵厅02"}
	elseif gameType == g_bcbmDefine.game_type then
		tGradeList = {"荣耀厅01","荣耀厅02","传奇厅01","传奇厅02","富贵厅01","富贵厅02"}
	elseif gameType == g_brnnDefine.game_type then
		tGradeList = {"荣耀厅01","荣耀厅02","传奇厅01","传奇厅02","富贵厅01","富贵厅02"}
		
	elseif gameType == g_DdzDefine.game_type then
		
	elseif gameType == g_douNiuDefine.game_type then
		
	elseif gameType == g_forestDefine.game_type then
		return "森林舞会"
	elseif gameType == g_fqzsDefine.game_type then
		tGradeList = {"荣耀厅01","荣耀厅02","传奇厅01","传奇厅02","富贵厅01","富贵厅02"}

	elseif gameType == g_hongheiDefine.game_type then
		tGradeList = {"荣耀厅01","荣耀厅02","荣耀厅03","荣耀厅04","荣耀厅05","荣耀厅06"}
	elseif gameType == g_lhdbDefine.game_type then
		
	elseif gameType == g_lhdDefine.game_type then
		tGradeList = {"荣耀厅01","荣耀厅02","荣耀厅03","荣耀厅04","荣耀厅05","荣耀厅06","好友房"}

	elseif gameType == g_PszDefine.game_type then
		
	elseif gameType == g_sicboDefine.game_type then
		tGradeList = {"荣耀厅01","荣耀厅02","传奇厅01","传奇厅02","富贵厅01","富贵厅02"}
	elseif gameType == g_yqsDefine.game_type then
		tGradeList = {"0.01底分","0.1底分","1底分","5底分","10底分","20底分"}
	end
    ]]

	return tGradeList[tableType]
end


function GameUtils.GetTableInfoByID(tableID)
	
	local gameType = 0
	local tableType = 1
	local tempPacketID = 0
	if tableID < 100000 then
		
	elseif tableID < 120000 then
		
		tempPacketID = 2201
		
	elseif tableID < 140000 then
		tempPacketID = 2801
	elseif tableID < 150000 then
	elseif tableID< 160000 then
		tempPacketID = 2001
	elseif tableID < 170000 then  --火锅英雄
		tempPacketID = 2701
	elseif tableID < 180000 then  --竞技场
	elseif tableID < 190000 then  --十点半
		tempPacketID = 2901
	elseif tableID < 200000 then  --房卡斗牛
		tempPacketID = 3010
	elseif tableID < 210000 then  --三公
		tempPacketID = 3101
	elseif tableID < 230000 then   --斗地主
		tempPacketID = 3905
	elseif tableID < 2020000 then  --森林舞会
		
		local tInfo = ForestModel.GetTableInfo( tableID )
		
		if tInfo ~= nil then
			gameType = g_forestDefine.game_type
			tableType = tInfo.tabletype
		end
		
	elseif tableID < 2030000 then   --水果机
		
		local tInfo = FruitModel.GetTableInfo( tableID )
		if tInfo ~= nil then
			gameType = g_fruitDefine.game_type
			tableType = tInfo.tabletype			
		end
		
	elseif tableID < 2040000 then  --时时彩
		
		local tInfo = SscaiModel.GetTableInfo( tableID )
		if tInfo ~= nil then
			gameType = tInfo.gametype
			tableType = tInfo.tabletype
		end
		
	elseif tableID < 2050000 then -- 二人梭哈
		local tInfo = ErshModel.GetTableInfo( tableID )
		if tInfo ~= nil then
			gameType = g_ErshDefine.game_type
			tableType = tInfo.tabletype
		end		
	elseif tableID < 2060000 then  --百人牛牛
		
		local tInfo = BrnnModel.GetTableInfo( tableID )
		if tInfo ~= nil then
			gameType = g_brnnDefine.game_type
			tableType = tInfo.tabletype			
		end
		
	elseif tableID < 2070000 then -- 百家乐
		local tInfo = BarccatatModel.GetTableInfo( tableID )
		if tInfo ~= nil then
			gameType = g_barccatatDefine.game_type
			tableType = tInfo.tabletype				
		end
		
	elseif tableID < 2080000 then	-- 奔驰宝马
		local tInfo = BcbmModel.GetTableInfo( tableID )
		if tInfo ~= nil then
			gameType = g_bcbmDefine.game_type
			tableType = tInfo.tabletype						
		end
	elseif tableID < 2090000 then	-- 飞禽走兽
		
		local tInfo = FqzsModel.GetTableInfo(tableID)
		if tInfo ~= nil then
			gameType = g_fqzsDefine.game_type
			tableType = tInfo.tabletype				
		end
		
	elseif tableID < 2100000 then	-- 二人牛牛
		local tInfo = ErnnModel.GetTableInfo( tableID )
		
		if tInfo ~= nil then
			gameType = g_ernnDefine.game_type
			tableType = tInfo.tabletype				
		end
		
	elseif tableID < 2120000 then   --拼三张
		local tInfo = PszModel.GetTableInfo( tableID )
		
		if tInfo ~= nil then
			gameType = g_PszDefine.game_type
			tableType = tInfo.tabletype				
		end	
	elseif tableID < 2130000 then -- 连环夺宝
		local tInfo = LhdModel.GetTableInfo( tableID )
		
		if tInfo ~= nil then
			gameType = g_lhdbDefine.game_type
			tableType = tInfo.tabletype				
		end
	elseif tableID < 2140000 then -- 糖果派对
		local tInfo = TgpdModel.GetTableInfo( tableID )
		
		if tInfo ~= nil then
			gameType = g_tgpdDefine.game_type
			tableType = tInfo.tabletype				
		end
	elseif tableID < 2150000 then -- 李逵劈鱼
		local tInfo = LkpyModel.GetTableInfo( tableID )
		
		if tInfo ~= nil then
			gameType = g_lkpyDefine.game_type
			tableType = tInfo.tabletype				
		end
	elseif tableID < 2160000 then -- 摇钱树
		local tInfo = YqsModel.GetTableInfo( tableID )
		
		if tInfo ~= nil then
			gameType = g_yqsDefine.game_type
			tableType = tInfo.tabletype				
		end
    elseif tableID < 2180000 then -- 红黑大战
		local tInfo = HongHeiModel.GetTableInfo( tableID )
		
		if tInfo ~= nil then
			gameType = g_hongheiDefine.game_type
			tableType = tInfo.tabletype				
		end
    elseif tableID < 2190000 then -- 龙虎斗
		local tInfo = LhdModel.GetTableInfo( tableID )
		
		if tInfo ~= nil then
			gameType = g_lhdDefine.game_type
			tableType = tInfo.tabletype				
		end
    elseif tableID < 2200000 then -- 彩金明牌 2191001
		local tInfo = CjmpModel.GetTableInfo( tableID )
		
		if tInfo ~= nil then
			gameType = g_cjmpDefine.game_type
			tableType = tInfo.tabletype				
		end
    elseif tableID < 2210000 then -- 骰宝 2201001
		local tInfo = SicboModel.GetTableInfo( tableID )
		
		if tInfo ~= nil then
			gameType = g_sicboDefine.game_type
			tableType = tInfo.tabletype				
		end
	elseif tableID < 2240000 then  --德州扑克
		local tInfo = TexasModel.GetTableInfo( tableID )
		
		if tInfo ~= nil then
			gameType = g_TexasDefine.game_type
			tableType = tInfo.tabletype				
		end
    elseif tableID < 2260000 then  --彩票类 224w ~ 226W 
        
        if tableID < 2242000 then --幸运飞艇 
			local tInfo = CaiPiaoXyftModel.GetTableInfo( tableID )
			
			if tInfo ~= nil then
				gameType = g_caipiaoDefine.xyft_game_type
				tableType = tInfo.tabletype				
			end
        elseif tableID < 2243000  then --香港六合彩
			local tInfo = CaiPiaoLhcModel.GetTableInfo( tableID )
			
			if tInfo ~= nil then
				gameType = g_caipiaoDefine.lhc_game_type
				tableType = tInfo.tabletype				
			end
        elseif tableID < 2244000  then --北京赛车
			local tInfo = CaiPiaoBjscModel.GetTableInfo( tableID )
			
			if tInfo ~= nil then
				gameType = g_caipiaoDefine.bjsc_game_type
				tableType = tInfo.tabletype				
			end
        end
	elseif tableID < 2270000 then
		local tInfo = SlhbModel.GetTableInfo( tableID )
		
		if tInfo ~= nil then
			gameType = g_slhbDefine.game_type
			tableType = tInfo.tabletype				
		end
	end	

	
	return GameUtils.GetGameName(gameType),GameUtils.GetTableName( gameType, tableType )
	
end

function GameUtils.GetChannel_login(channel)
	local pos = string.find(channel, '_')
	if pos == nil then
		return channel
	end
	
	return string.sub( channel, 1, pos - 1 )
end

