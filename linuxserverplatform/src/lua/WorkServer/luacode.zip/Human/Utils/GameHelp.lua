--这里是需要调用http的函数，生成推广的二维码


module("MakeCode", package.seeall)

function work(buffer)

	local sendUrl = g_webUrl.."/index.php/"..g_gamename.."/client/makecode?bindcode="..buffer.."&platfromid="..g_gamename
	HttpGet(sendUrl)   --向网页端申请生成二维码。只生成一次。一定要注意这里的	
end


