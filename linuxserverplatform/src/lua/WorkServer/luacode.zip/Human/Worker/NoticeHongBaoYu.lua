
module("NoticeHongBaoYu", package.seeall)
--红包雨通知
function work(buffer)
	
    --print("NoticeHongBaoYu")
	local hongbaostartime = buffer
    local sqlCase = "select * from dy_activity where activityid ="..110
    mysqlItem:executeQuery(sqlCase)
	local sqlData = mysqlItem:fetch({})
	if sqlData == nil or  (tonumber(sqlData[6])  ~= 1 or tonumber(sqlData[6]) < 0) or sqlData[12] == nil  then
		--活动不存在或活动已关闭
        return
	end

    local data = sqlData[12]
    local startime = TimeUtils.GetTime(data["starttime"])
    if tonumber(hongbaostartime) ~=  tonumber(startime) then
        return 
    end
    --获取玩家
    local onlineList = OnlineModel.GetAllOnline()
    local onlinenum = 0
    local userlist = {}
	for k,v_userid in pairs( onlineList ) do
		local pInfo = PlayerModel.GetPlayerInfo(v_userid)
	    if pInfo ~= nil then
            onlinenum = onlinenum + 1
            userlist[onlinenum] = v_userid
	    end	
	end	
   
    if onlinenum == 0 then
       --没有玩家在线
       return
    end
    --发红包雨次数
    local sqlCase = "update dy_activity set times=times+"..1 .." where activityid="..110
    mysqlItem:execute(sqlCase)

    local gcmsg = msg_human2_pb.gcnoticehongbaoyu()
    gcmsg.state = 1
    gcmsg.result = 0
    
    PlayerModel.delHongBaoYuUserGotList()
    --PlayerModel.setHongBaovalue(tonumber(sqlData[11]))
    --初始化红包数量
    PlayerModel.countHongBaoNum(onlinenum,true)
    for i=1,onlinenum do
        gcmsg.userid = tonumber(userlist[i])
        SendMessage(userlist[i], PacketCode[1088].client,gcmsg:ByteSize(),gcmsg:SerializeToString())    
    end
end




