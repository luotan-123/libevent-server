--没天凌晨的时候，这个线程来处理分佣的工作。


module("UserIPCheck", package.seeall)

function work(buffer)
	--通知下注的这里，不需要加入锁，这里只是一个通知的过程

	--暂时不考虑分段来处理，后面看业务量的多少来觉得，是否需要用到limit

	
	
	local userData = luajson.decode(buffer)
	
	local sqlCase = "update dy_player set ip='"..userData['ip'].."' where userid="..userData['userid']

	mysqlItem:execute(sqlCase)
	
	local pInfo = PlayerModel.GetPlayerInfo( userData['userid'] )
	pInfo.ip = userData['ip']
	PlayerModel.SetPlayerInfo(pInfo)
	
	--[[
	local userData = luajson.decode(buffer)
    local sqlCase = "select * from db_ipcode where inet_aton(startindex) <= inet_aton( '"..userData['ip'].."') and inet_aton(endindex) >= inet_aton( '"..userData['ip'].."');"
    mysqlItem:executeQuery(sqlCase)
	
	local sqlData = mysqlItem:fetch({})

	if sqlData ~= nil then
		--表示数据库中有数据的
        sqlCase = "update dy_player set ip='"..userData['ip'].."',province='"..sqlData[4].."',city='"..sqlData[5].."',nickname='"..
		sqlData[4]..sqlData[5].."' where userid="..userData['userid']

        mysqlItem:execute(sqlCase)
	    local pInfo = PlayerModel.GetPlayerInfo(userData['userid'])
	    pInfo.ip = userData['ip']
	    pInfo.nickname = sqlData[4]..sqlData[5]
	    PlayerModel.SetPlayerInfo(pInfo)
	    PlayerModel.SendPlayerInfo(pInfo, {"nickname"})
        
    end
	]]   --这里不用IP库去处理
--	local url = "http://ip.taobao.com/service/getIpInfo.php?ip="..userData['ip']
--	local getStr = HttpGet(url)
--	if true then

--        return
--	end
	--luaDump(getStr)
--	local getArr = luajson.decode(getStr)
--	if getArr['code']  == nil and getArr['code'] ~= 0 then

--		return
--	end

--	local sqlCase = "update dy_player set ip='"..userData['ip'].."',province='"..getArr['data']['region'].."',city='"..getArr['data']['city'].."',nickname='"..
--		getArr['data']['region']..getArr['data']['city'].."' where userid="..userData['userid']
	--SqlServer.rpush(sqlCase)

--	mysqlItem:execute(sqlCase)
--	local pInfo = PlayerModel.GetPlayerInfo(userData['userid'])
--	pInfo.ip = userData['ip']
--	pInfo.nickname = getArr['data']['region']..getArr['data']['city']
--	PlayerModel.SetPlayerInfo(pInfo)

--	PlayerModel.SendPlayerInfo(pInfo, {"nickname"})
	--执行完毕
end




