
module("TransferWorker", package.seeall)

function work(buffer)
    ---print("TransferWorker")
    local len = redisItem:llen(PlayerModel.userTransfer..g_processName, PlayerModel.redis_index )     
    if len > 0 then
       	for i=1,len  do
            local strGet = redisItem:lpop( PlayerModel.userTransfer..g_processName, PlayerModel.redis_index  )
            if strGet ~= nil then
                local transferinfo = msg_human3_pb.gctransferinfo()
                transferinfo:ParseFromString(strGet)
                SendMessage(transferinfo.userid,PacketCode[8716].client,transferinfo:ByteSize(),transferinfo:SerializeToString())
            end
        end
    end
end


