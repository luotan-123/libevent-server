--没天凌晨的时候，这个线程来处理分佣的工作。


module("AgencyDayCheck", package.seeall)

function work(buffer)
	--通知下注的这里，不需要加入锁，这里只是一个通知的过程

	--暂时不考虑分段来处理，后面看业务量的多少来觉得，是否需要用到limit


	
	
	
	
	local sqlCase = "select agent1, agent2, agent3, moneymark,userid from ag_player where moneymark>1000"
	mysqlItem:executeQuery(sqlCase)
	
	local userFirList = {}   --直属玩家的更新列表。
	local userSecList = {}   --二级玩家的更新列表。
	local userThrList = {}   --二级玩家的更新列表。
	local checkList = {}
	local takeList = {}
	while true do
		local sqlData = mysqlItem:fetch({})
		if sqlData == nil then
			break
		end
		
		--这里开始分账了
		local moneyMark = tonumber(sqlData[4])
		
		userFirList[sqlData[1]] = userFirList[sqlData[1]] == nil and math.floor(moneyMark*40/100) or (userFirList[sqlData[1]] + math.floor(moneyMark*40/100))
		userSecList[sqlData[2]] = userSecList[sqlData[2]] == nil and math.floor(moneyMark*20/100) or (userSecList[sqlData[2]] + math.floor(moneyMark*20/100))
		userThrList[sqlData[3]] = userThrList[sqlData[3]] == nil and math.floor(moneyMark*10/100) or (userThrList[sqlData[3]] + math.floor(moneyMark*10/100))
		
		checkList[sqlData[5]] = sqlData[5]
		
		takeList[sqlData[1]] = takeList[sqlData[1]] == nil and userFirList[sqlData[1]] or ( takeList[sqlData[1]] + userFirList[sqlData[1]] )
		takeList[sqlData[2]] = takeList[sqlData[2]] == nil and userFirList[sqlData[2]] or ( takeList[sqlData[2]] + userFirList[sqlData[2]] )
		takeList[sqlData[3]] = takeList[sqlData[3]] == nil and userFirList[sqlData[3]] or ( takeList[sqlData[3]] + userFirList[sqlData[3]] )
		
		--在这里还需要插入记录的log
	end

	
	for k,v in takeList do
		local sqlCase = "update ag_player set takemoney=takemoney+"..v
		if userFirList[k] ~= nil then
			sqlCase = sqlCase..",agent1count=agent1count+"..userFirList[k]
			userFirList[k] = nil
		end

		if userSecList[k] ~= nil then
			sqlCase = sqlCase..",agent2count=agent2count+"..userSecList[k]
			userSecList[k] = nil
		end	

		if userThrList[k] ~= nil then
			sqlCase = sqlCase..",agent3count=agent3count+"..userThrList[k]
			userThrList[k] = nil
		end
		if checkList[k] ~= nil then
			sqlCase = sqlCase..",moneymark = 0"
			checkList[k] = nil
		end
		sqlCase = sqlCase.." userid="..k
		mysqlItem:execute(sqlCase)
		
	end
	

	for k,v in ipairs(checkList) do
		local sqlCase = "update ag_player set moneymark=0 where userid="..k
		mysqlItem:execute(sqlCase)
	end
	--执行完毕
end




