--这里是需要调用http的函数，生成推广的二维码


module("HttpSendExecute", package.seeall)

function work(buffer)

	
	for i = 1,100 do
		
		local strGet = redisItem:lpop( HttpSendModel.httpsend_list..g_processName, HttpSendModel.redis_index )
		
		if strGet == nil then
			break
		end
		local getArr = luajson.decode( strGet )
		
		local getType = tonumber(getArr['type'])
		
		if getType == HttpSendModel.send_type['msg'] then
			
			local pInfo = PlayerModel.GetPlayerInfo( getArr['userid'] )
			if pInfo ~= nil then
				PlayerModel.SendPlayerInfo(pInfo, luajson.decode(getArr['data']))
			end
		elseif getType == HttpSendModel.send_type['kituser'] then
			--踢出玩家，
			
			if OnlineModel.CheckOnline( getArr['userid'] ) then
				--把这个玩家踢走
				local gckit = msg_human_pb.gckitplayer()
				gckit.result = 0
				gckit.kittype = 1
				gckit.msg = getArr['data']
				SendMessage(getArr['userid'], PacketCode[1008].client, gckit:ByteSize(), gckit:SerializeToString())
			end
		end
		
		
	end
	
end


