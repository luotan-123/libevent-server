BankModel = {}
BankModel.redis_index = "redis_bank"
BankModel.bank_transfer = "bank_transfer_"

--[[
	??-??
	@param pInfo: st_bank_pb_.playerinfo		??
	@param amount: number						??
]]
function BankModel.Withdraw(pInfo, amount)
	local initialJetton, initialBankJetton = pInfo.jetton, pInfo.bank_jetton
	pInfo.bank_jetton = tostring(tonumber(pInfo.bank_jetton) - tonumber(amount))
	
	PlayerModel.AddJetton(pInfo, tonumber(amount), "bank", "从银行取出来")
	
	PlayerModel.SetPlayerInfo(pInfo)
	PlayerModel.IncrBankJetton(pInfo.userid, 0 - tonumber(amount))
	local sqlCase = "update dy_player set bank_jetton=bank_jetton-"..amount.." where userid="..pInfo.userid
	SqlServer.rpush(sqlCase)
	
	PlayerModel.InsertCurrencyChangedRecord(pInfo.userid, initialBankJetton, amount, g_currencyType.bankjetton, g_currencyOptType.bankWithdraw, "withdraw")
	--PlayerModel.InsertCurrencyChangedRecord(pInfo.userid, initialJetton, amount, g_currencyType.jetton, g_currencyOptType.bankWithdraw, "withdraw")

end

--[[
	??-??
	@param pInfo: st_bank_pb_.playerinfo		??
	@param amount: number						??
]]
function BankModel.Deposit(pInfo, amount)
	local initialJetton, initialBankJetton = pInfo.jetton, pInfo.bank_jetton
	
	pInfo.bank_jetton = tostring(tonumber(pInfo.bank_jetton) + tonumber(amount))
	
	PlayerModel.DecJetton(pInfo, tonumber(amount), "bank", "存到银行中")
	
	PlayerModel.SetPlayerInfo(pInfo)
	PlayerModel.IncrBankJetton(pInfo.userid, tonumber(amount))
	local sqlCase = "update dy_player set bank_jetton=bank_jetton+"..amount.." where userid="..pInfo.userid
	SqlServer.rpush(sqlCase)
	
	PlayerModel.InsertCurrencyChangedRecord(pInfo.userid, initialJetton, amount, g_currencyType.jetton, g_currencyOptType.bankDeposit, "deposit")
	--PlayerModel.InsertCurrencyChangedRecord(pInfo.userid, initialJetton, - amount, g_currencyType.jetton, g_currencyOptType.bankDeposit, "deposit")
end

local function LoadTransferHistory(userID)
	local sqlCase = "select * from log_currencychangedrecord where currency_type="..g_currencyType.bankjetton.." AND opt_type="..g_currencyOptType.bankTransferTo.." AND userid="..userID
	mysqlLog:executeQuery(sqlCase)
	while true do
		local sqlData = mysqlLog:fetch({})
		if nil == sqlData then
			break
		end
		
		local record = st_human_pb.banktransferrecord()
		record.userid = userID
		record.amount = sqlData[5]
		record.timemark = sqlData[6]

		local pInfo = PlayerModel.GetPlayerInfo(record.userid)
		if nil ~= pInfo then
			record.nickname = pInfo.nickname or ''
		end
		
		-- ????
		BankModel.AddTransferHistory(userID, record, true)
	end
end

--[[
	????
	@param userID: number
	@param pageNum: number
]]
function BankModel.GetTransferHistory(userID, pageNum)
	local redisKey = BankModel.bank_transfer..userID
	if not redisItem:exists(redisKey, BankModel.redis_index) then
		LoadTransferHistory(userID)
	end
	return redisItem:lrange(redisKey, (pageNum - 1) * 10, pageNum * 10 - 1, BankModel.redis_index)
end

--[[
	??????
	@param userID: number
	@param record:
	@param notLoadFromSql: boolean
]]
function BankModel.AddTransferHistory(userID, record, notLoadFromSql)
	local redisKey = BankModel.bank_transfer..userID
	if not notLoadFromSql then
		if not redisItem:exists(redisKey, BankModel.redis_index) then
			LoadTransferHistory(userID)
		end
	end
	redisItem:lpush(redisKey, record:SerializeToString(), BankModel.redis_index)
end

--[[
	????
	@param pSrcInfo: st_bank_pb_.playerinfo		???
	@param pDstInfo: st_human_pb.playerinfo		????
	@param amount: number						????
	
]]
function BankModel.JettonTransfer(pSrcInfo, pDstInfo, amount)
	local initial = pSrcInfo.bank_jetton
	pSrcInfo.bank_jetton = tostring(tonumber(pSrcInfo.bank_jetton) - tonumber(amount))
	local sqlCase = "update dy_player set bank_jetton=bank_jetton-"..amount.." where userid="..pSrcInfo.userid
	SqlServer.rpush(sqlCase)
	
	
	PlayerModel.IncrBankJetton(pSrcInfo.userid, 0- tonumber(amount))
	PlayerModel.SetPlayerInfo(pSrcInfo)
	--local remark = "transfer to:"..pDstInfo.userid
	--PlayerModel.InsertCurrencyChangedRecord(pSrcInfo.userid, initial, - amount, g_currencyType.bankjetton, g_currencyOptType.bankTransferTo, remark)
	
	--------------
	initial = pDstInfo.bank_jetton
	pDstInfo.bank_jetton = tostring(tonumber(pDstInfo.bank_jetton) + tonumber(amount))
	sqlCase = "update dy_player set bank_jetton=bank_jetton+"..amount.." where userid="..pDstInfo.userid
	SqlServer.rpush(sqlCase)
	
	PlayerModel.IncrBankJetton(pDstInfo.userid, tonumber(amount))
	PlayerModel.SetPlayerInfo(pDstInfo)
	--remark = "transfer from:"..pSrcInfo.userid
	--PlayerModel.InsertCurrencyChangedRecord(pDstInfo.userid, initial, amount, g_currencyType.bankjetton, g_currencyOptType.bankTransferFrom, remark)
	
	local record = st_human_pb.banktransferrecord()
	record.userid = pDstInfo.userid
	record.amount = amount
	record.timemark = TimeUtils.GetTimeString()
	record.nickname = pDstInfo.nickname or ''
	BankModel.AddTransferHistory(pSrcInfo.userid, record)
	--写入数据库
	PlayerModel.InsertCurrencyChangedRecord(pSrcInfo.userid, pSrcInfo.bank_jetton, amount, g_currencyType.bankjetton, g_currencyOptType.bankTransferTo, pDstInfo.userid)
end

--视讯账号
function BankModel.SxWithdraw(pInfo, amount)
	local initialJetton, initialSxJetton = pInfo.jetton, pInfo.sx_jetton
	pInfo.sx_jetton = tostring(tonumber(pInfo.sx_jetton) - tonumber(amount))
	
	PlayerModel.AddJetton(pInfo, tonumber(amount), "sxbank", "从视讯账号取出来")
	
	PlayerModel.SetPlayerInfo(pInfo)
	PlayerModel.IncrSxJetton(pInfo.userid, 0 - tonumber(amount))
	local sqlCase = "update dy_player set sx_jetton=sx_jetton-"..amount.." where userid="..pInfo.userid
	SqlServer.rpush(sqlCase)
	
	PlayerModel.InsertCurrencyChangedRecord(pInfo.userid, initialSxJetton, amount, g_currencyType.sxjetton, g_currencyOptType.sxWithdraw, "withdraw")
	--PlayerModel.InsertCurrencyChangedRecord(pInfo.userid, initialJetton, amount, g_currencyType.jetton, g_currencyOptType.bankWithdraw, "withdraw")

end


function BankModel.SxDeposit(pInfo, amount)
	local initialJetton, initialSxJetton = pInfo.jetton, pInfo.sx_jetton
	pInfo.sx_jetton = tostring(tonumber(pInfo.sx_jetton) + tonumber(amount))
	
	PlayerModel.DecJetton(pInfo, tonumber(amount), "sxbank", "存到视讯账号中")
	
	PlayerModel.SetPlayerInfo(pInfo)
	PlayerModel.IncrSxJetton(pInfo.userid, tonumber(amount))
	local sqlCase = "update dy_player set sx_jetton=sx_jetton+"..amount.." where userid="..pInfo.userid
	SqlServer.rpush(sqlCase)
	
	PlayerModel.InsertCurrencyChangedRecord(pInfo.userid, initialJetton, amount, g_currencyType.jetton, g_currencyOptType.sxDeposit, "deposit")
	--PlayerModel.InsertCurrencyChangedRecord(pInfo.userid, initialJetton, - amount, g_currencyType.jetton, g_currencyOptType.bankDeposit, "deposit")
end

function BankModel.gamejettonWithdraw(pInfo, amount)

	PlayerModel.DecGameJetton(pInfo, tonumber(amount))
	PlayerModel.AddJetton(pInfo, tonumber(amount), "gamejetton", "从游戏钱包取出来")
	
	PlayerModel.SetPlayerInfo(pInfo)
	PlayerModel.InsertCurrencyChangedRecord(pInfo.userid, pInfo.jetton, amount, g_currencyType.gamejetton, g_currencyOptType.gamejettonWithdraw, "withdraw")
end

function BankModel.gamejettonDeposit(pInfo, amount)

	PlayerModel.AddGameJetton(pInfo, tonumber(amount))
	PlayerModel.DecJetton(pInfo, tonumber(amount), "gamejetton", "存到游戏钱包中")
	
	PlayerModel.SetPlayerInfo(pInfo)
	PlayerModel.InsertCurrencyChangedRecord(pInfo.userid, pInfo.jetton, amount, g_currencyType.jetton, g_currencyOptType.gamejettonDeposit, "deposit")
end


--视讯账号加减
function BankModel.SxBankCal(pInfo, amount)
    local initialJetton, initialSxJetton = pInfo.jetton, pInfo.sx_jetton
	pInfo.sx_jetton = tostring(tonumber(pInfo.sx_jetton) + tonumber(amount))
	PlayerModel.SetPlayerInfo(pInfo)
	PlayerModel.IncrSxJetton(pInfo.userid, tonumber(amount))
	local sqlCase = "update dy_player set sx_jetton=sx_jetton+"..amount.." where userid="..pInfo.userid
	SqlServer.rpush(sqlCase)
	local opt = amount > 0 and  g_currencyOptType.sxDeposit or g_currencyOptType.sxWithdraw
    local remark = amount > 0 and "sxDeposit" or "sxWithdraw"
	PlayerModel.InsertCurrencyChangedRecord(pInfo.userid, initialJetton, amount, g_currencyType.jetton, opt, remark)

end

--彩票钱包 从彩票钱包取出来
function BankModel.cpjettonWithdraw(pInfo, amount)

	PlayerModel.AddCpJetton(pInfo, 0 - tonumber(amount))
	PlayerModel.AddJetton(pInfo, tonumber(amount), "cpjetton", "从彩票钱包取出来")
	
	PlayerModel.SetPlayerInfo(pInfo)
	PlayerModel.InsertCurrencyChangedRecord(pInfo.userid, pInfo.jetton, amount, g_currencyType.cpjetton, g_currencyOptType.cpjettonDeposit, "withdraw")
end
--存到彩票钱包中
function BankModel.cpjettonDeposit(pInfo, amount)

	PlayerModel.AddCpJetton(pInfo, tonumber(amount))
	PlayerModel.DecJetton(pInfo, tonumber(amount), "cpjetton", "存到彩票钱包中")
	
	PlayerModel.SetPlayerInfo(pInfo)
	PlayerModel.InsertCurrencyChangedRecord(pInfo.userid, pInfo.jetton, amount, g_currencyType.cpjetton, g_currencyOptType.cpjettonDeposit, "deposit")
end
