
OnlineModel = {}
OnlineModel.redisKey = "onlinelist"
OnlineModel.redis_index = "redis_online"
OnlineModel.online_max = "online_max"
OnlineModel.online_gameserver = "online_gameserver"
OnlineModel.active_player = "active_player"   -- 当日活跃玩家，每天凌晨5天清空
OnlineModel.online_logonserver = "online_logonserver"

OnlineModel.app_user_online  = "app_user_online"     -- 玩家在线app
OnlineModel.game_user_online = "game_user_online"   -- 玩家在线game


function OnlineModel.Init()
	redisItem:del("onlinelist",OnlineModel.redis_index)
	
	redisItem:del(OnlineModel.online_gameserver..g_processName, OnlineModel.redis_index)
end

--获取玩家创建角色时需要初始化的成就列表
function OnlineModel.GetOnlineList(pageNum)
	if pageNum == nil or pageNum == 0 then
		LogBehavior.Error(110,"online","GetOnlineList",-1,"pageNum type="..type(pageNum))
		pageNum = 1
	end
	local startPos = pageNum <= 0 and 0 or (pageNum - 1)*12
	local endPos = pageNum <= 0 and -1 or (startPos + 11)

	return redisItem:zrange(OnlineModel.redisKey,startPos, endPos, OnlineModel.redis_index)
end


function OnlineModel.GetAllOnline()
	return redisItem:zrange(OnlineModel.redisKey,0, -1, OnlineModel.redis_index)
end


function OnlineModel.PlayerLogin(pInfo)
    local prechannel = GameUtils.GetChannel_login(pInfo.channel)
	redisItem:zadd(OnlineModel.redisKey, 100-pInfo.viplevel, pInfo.userid, OnlineModel.redis_index)
	--保存玩家所在服务器
	redisItem:hset(OnlineModel.online_gameserver..g_processName, pInfo.userid, 1, OnlineModel.redis_index)
	
	redisItem:hset(OnlineModel.online_logonserver, pInfo.userid, g_logonid, OnlineModel.redis_index)
	
    redisItem:zadd(OnlineModel.redisKey..prechannel, 100-pInfo.viplevel, pInfo.userid, OnlineModel.redis_index)

	-- 记录为活跃用户
	OnlineModel.AddActivePlayer(pInfo.userid)
    --记录玩家app上线
	OnlineModel.SetAppUserOnline(pInfo.userid)

    PlayerModel.SendUserTransferinfo(pInfo.userid)
	-- 生成sql语句记录登录服务器人数
	local logonuserCount = redisItem:hlen(OnlineModel.online_gameserver..g_processName, OnlineModel.redis_index)
	local sqlCase = "update du_server set peoplecount="..logonuserCount.." where logonid="..(g_logonid or "0")
	LogModel.GameSqlServer(sqlCase)
	
end

function OnlineModel.PlayerExit(userID)
    
    local pInfo = PlayerModel.GetPlayerInfo(userID)
    local prechannel = GameUtils.GetChannel_login(pInfo.channel)
	--两个列表都删除就不会出错了
	if 0 == redisItem:srem(PlayerModel.kit_userList, userID, OnlineModel.redis_index) then
		--如果有玩家被踢下线后，先保存到被踢的列表，如果被踢的列表没有记录，再从在线列表中删除
		redisItem:zrem(OnlineModel.redisKey, userID, OnlineModel.redis_index)
        redisItem:zrem(OnlineModel.redisKey..prechannel, userID, OnlineModel.redis_index)
	end
	
	redisItem:hdel(OnlineModel.online_gameserver..g_processName, userID, OnlineModel.redis_index)
	
	redisItem:hdel(OnlineModel.online_logonserver, userID, OnlineModel.redis_index)
	
	--RaceModel.PlayExit(userID)
	--这里是整个游戏退出的，对于正在牌桌里面的玩家，不处理退出，然后从新进入牌桌的时候恢复
	--在这里做退出的控制
    --CaiPiaoModel.UserExit(userID)
	--local pInfo = PlayerModel.GetPlayerInfo(userID)
	PlayerModel.SynOneDayOnlineTimes(pInfo)
	LogDispatch.PlayerLogout(pInfo)
	LogBehavior.UserAction(pInfo, 2, "玩家退出游戏")
	
    --记录玩家app下线
	OnlineModel.DelAppUserOnline(pInfo.userid)

	-- 生成sql语句记录登录服务器人数
	local logonuserCount = redisItem:hlen(OnlineModel.online_gameserver..g_processName, OnlineModel.redis_index)
	local sqlCase = "update du_server set peoplecount="..logonuserCount.." where logonid="..(g_logonid or "0")
	LogModel.GameSqlServer(sqlCase)
end

function OnlineModel.CheckGameOnline(userID)
	return redisItem:hexists(OnlineModel.online_gameserver..g_processName, userID, OnlineModel.redis_index)
end

function OnlineModel.CheckOnline(userID)
	return redisItem:zrank(OnlineModel.redisKey, userID, OnlineModel.redis_index)
end

function OnlineModel.GetOnlineNum()
	return tonumber(redisItem:zcard(OnlineModel.redisKey, OnlineModel.redis_index))
end

function OnlineModel.UpdateMaxOnline()
	local maxOnline = redisItem:get( OnlineModel.online_max, OnlineModel.redis_index )
	local currNum = OnlineModel.GetOnlineNum()
	
	maxOnline = maxOnline == nil and 0 or tonumber(maxOnline)
	
	if currNum > maxOnline then
		redisItem:set(OnlineModel.online_max, currNum, OnlineModel.redis_index )
		local sqlCase = "update log_sysdaily set maxonline="..currNum.." where id > 0 and dateid='"..TimeUtils.GetDayString().."' and channel='"..g_channelname.."'"
	
		LogModel.LogSysdailyPush(sqlCase)
	end
end


function OnlineModel.InitMaxOnline()
	redisItem:del(OnlineModel.online_max, OnlineModel.redis_index)
end


function OnlineModel.AddActivePlayer(userID)
	redisItem:sadd(OnlineModel.active_player, userID, OnlineModel.redis_index)
end

function OnlineModel.IsActivePlayer(userID)
	return redisItem:sismember(OnlineModel.active_player, userID, OnlineModel.redis_index)
	
end

function OnlineModel.ClearActivePlayer()
	redisItem:del(OnlineModel.active_player, OnlineModel.redis_index)
end

function OnlineModel.GetUserLogonID(userid)
	return redisItem:hget(OnlineModel.online_logonserver, userid, OnlineModel.redis_index)
end

---------------------------------------------------------------------------------------
--玩家app上线
function OnlineModel.SetAppUserOnline(userid)
    local pInfo = PlayerModel.GetPlayerInfo(userid)
    if pInfo == nil then
       return 
    end
    local prechannel = GameUtils.GetChannel_login(pInfo.channel)
    redisItem:sadd(OnlineModel.app_user_online, userid,OnlineModel.redis_index)
    redisItem:sadd(OnlineModel.app_user_online..prechannel, userid,OnlineModel.redis_index)
end

--玩家app下线
function OnlineModel.DelAppUserOnline(userid)
    local pInfo = PlayerModel.GetPlayerInfo(userid)
    if pInfo == nil then
       return 
    end
    local prechannel = GameUtils.GetChannel_login(pInfo.channel)
    redisItem:srem(OnlineModel.app_user_online, userid,OnlineModel.redis_index)
    redisItem:srem(OnlineModel.app_user_online..prechannel, userid,OnlineModel.redis_index)
end

--玩家app是否上线 返回 true or false
function OnlineModel.CheckAppUserOnline(userid)
    return redisItem:sismember(OnlineModel.app_user_online, userid,OnlineModel.redis_index)
end

--获取app中 所有渠道的在线玩家数量
function OnlineModel.getAppAllOnLineUserNum()
    return  redisItem:scard(OnlineModel.app_user_online,OnlineModel.redis_index)
end

--根据渠道获取app中的在线人数
function OnlineModel.getAppAllOnLineUserNumByPrechannel(prechannel)
    return redisItem:scard(OnlineModel.app_user_online..prechannel,OnlineModel.redis_index)
end


--玩家game上线
function OnlineModel.SetGameUserOnline(userid)
    local pInfo = PlayerModel.GetPlayerInfo(userid)
    if pInfo == nil then
       return 
    end
    local prechannel = GameUtils.GetChannel_login(pInfo.channel)
    redisItem:sadd(OnlineModel.game_user_online, userid,OnlineModel.redis_index)
    redisItem:sadd(OnlineModel.game_user_online..prechannel, userid,OnlineModel.redis_index)
end

--玩家game下线
function OnlineModel.DelGameUserOnline(userid)
    local pInfo = PlayerModel.GetPlayerInfo(userid)
    if pInfo == nil then
       return 
    end
    local prechannel = GameUtils.GetChannel_login(pInfo.channel)
    redisItem:srem(OnlineModel.game_user_online, userid,OnlineModel.redis_index)
    redisItem:srem(OnlineModel.game_user_online..prechannel, userid,OnlineModel.redis_index)
end

--玩家game是否上线 返回 true or false
function OnlineModel.CheckGameUserOnline(userid)
    return redisItem:sismember(OnlineModel.game_user_online, userid,OnlineModel.redis_index)
end

--获取game 中所有渠道的在线玩家数量
function OnlineModel.getGameAllOnLineUserNum()
    return  redisItem:scard(OnlineModel.game_user_online,OnlineModel.redis_index)
end

--根据渠道获取game中的在线人数
function OnlineModel.getGameAllOnLineUserNumByPrechannel(prechannel)
    return redisItem:scard(OnlineModel.game_user_online..prechannel,OnlineModel.redis_index)
end

-----------------------------------------------------------------------------------------------------------------

--根据渠道获取 app+game中的在线人数
function OnlineModel.getAppGameAllOnLineUserNumByPrechannel(prechannel)
    return OnlineModel.getGameAllOnLineUserNumByPrechannel(prechannel) + OnlineModel.getAppAllOnLineUserNumByPrechannel(prechannel)
end

--判断玩家当前是否在线 返回 true or fasle
function OnlineModel.CheckUserAppOrGameOnline(userid)
   return (OnlineModel.CheckAppUserOnline(userid) or OnlineModel.CheckGameUserOnline(userid))
end

---------------------------------------------------------------------------------------