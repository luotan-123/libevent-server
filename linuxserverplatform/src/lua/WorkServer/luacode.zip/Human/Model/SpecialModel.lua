
SpecialModel = {}
SpecialModel.redis_index = "redis_special"
SpecialModel.redis_index = "special_"

function SpecialModel.GetSpecialInfo(userID, sInfo)
	
	if sInfo == nil then
		sInfo = st_human_pb.specialinfo()
	end
	
	local strGet = redisItem:get(SpecialModel.redis_index..userID, SpecialModel.redis_index)
	
	if strGet ~= nil then
		sInfo:ParseFromString(strGet)
	else
		SpecialModel.LoadSpecialInfo(userID, sInfo)
	end
	
	local currTime = TimeUtils.GetTime()
	if currTime > sInfo.endtime and sInfo.state > 0 then
		--超过时间了
		--只有大于0的情况下，才会去修改里面的值，如果小于0，表示已经删除了
		local sqlCase = "update ag_special set state = 0 where userid="..userID
		mysqlItem:execute(sqlCase)
		sInfo.state = 0
		redisItem:set(SpecialModel.redis_index..userID, sInfo:SerializeToString(), SpecialModel.redis_index)
	end
	return sInfo
end

function SpecialModel.LoadSpecialInfo(userID, sInfo)
	if sInfo == nil then
		sInfo = st_human_pb.specialinfo()
	end

	local sqlCase = "select * from ag_special where state > 0 and userid="..userID
	
	mysqlItem:executeQuery(sqlCase)
	local sqlData = mysqlItem:fetch({})
	
	if sqlData ~= nil then
		sInfo.userid = userID
		sInfo.starttime = TimeUtils.GetTime(sqlData[4])
		sInfo.endtime = TimeUtils.GetTime(sqlData[5])
		sInfo.rate = tonumber(sqlData[6])
		sInfo.state = tonumber(sqlData[7])
		if sqlData[10] ~= nil and string.len(sqlData[10]) > 1 then
			local gameList = luajson.decode(sqlData[10])
			for k,v in ipairs(gameList) do
				sInfo.gametype:append(tonumber(v))
			end
		end
		
	else
		sInfo.userid = userID
		sInfo.state = 0
	end
	redisItem:set(SpecialModel.redis_index..userID, sInfo:SerializeToString(), SpecialModel.redis_index)
	return sInfo
end

function SpecialModel.SetSpecialInfo(sInfo)
	redisItem:set(SpecialModel.redis_index..sInfo.userid, sInfo:SerializeToString(), SpecialModel.redis_index)
end


function SpecialModel.NiuNiuCard(userID, getList, cardList, playNum)
	--
 	local sInfo = SpecialModel.GetSpecialInfo(userID)
	if sInfo == nil or sInfo.state ~= 1 then
		return 0
	end
	
	local ranNum = math.myrandom(1,10000)
	if ranNum > 40000 then
		--一般的概率
		--在这个区间内
		return 0
	end
	
	local maxRate = sInfo.rate
	maxRate = maxRate > 30 and 30 or maxRate
	
	local maxPlayNum = math.floor(playNum*maxRate/100)
	
	if sInfo.peinum >= maxPlayNum then
		--超过数量了
		return 0
	end

	if #getList == 5 then
		local retType = DouNiuHuUtils.GetCardType(getList)
		if retType >= g_douNiuCard_type.niu_ba then
			return 0
		end
	end

	--看看是补充牛八还是牛九,还是牛牛
	local lastList, cardType = SpecialModel.GetCardType(getList)
	
	
	luaPrint("userID="..userID..",cardtype="..cardType..",list="..luajson.encode(getList))
	
	if cardType > g_douNiuCard_type.niu_ba then
		return 0
	end
	
	if cardType == g_douNiuCard_type.wu_niu then
		--取得两个里面最大的牌型
		--local max
		if #getList ~= 5 then
			return 0
		end
		local maxType = 0
		local maxList = {}
		
		for i = 1,#getList do
			for j=i+1,#getList do
				local tempList = {}
				table.insert(tempList, getList[i])
				table.insert(tempList, getList[j])
				
				local tempType = SpecialModel.LastCardDianNum(tempList)
				if tempType > maxType then
					maxList = {}
					maxType = tempType
					table.insert(maxList, getList[i])
					table.insert(maxList, getList[j])
				end
				
			end
		end
		
		if maxType >=  g_douNiuCard_type.niu_ba then
			--开始配剩下的
			local lastList = {}
			for i = 1,#getList do
				if getList[i] ~= maxList[1] and getList[i] ~= maxList[2] then
					table.insert(lastList, getList[i])
				end
			end
			
			--从头开始配
			local isPeiSuccess = false
			for k = 1,#lastList do
				local tempList1 = {}
				for p = 1,#lastList do
					if p ~= k then
						table.insert(tempList1, lastList[p])
		
					end
				end
				local cardPeiType = SpecialModel.LastCardDianNum(tempList1)
				
				local needPeiNum = 10 - cardPeiType
				for i = 1,#cardList do
					if math.mod(cardList[i],100) == needPeiNum then
						--这里已经配置好了
						table.insert(getList, cardList[i])
						table.remove(cardList, i)
						table.insert(cardList, lastList[k])
						
						for n = 1,#getList do
							if getList[n] == lastList[k] then
								table.remove(getList, n)
								break
							end
						end
						isPeiSuccess = true
						break
					end
				end
				if isPeiSuccess == true then
					break
				end
			end
		else
			return 0
		end
		
		
	else
		--开始配牌了
		local len = #lastList
		local lastCard = getList[len]
		table.remove(lastList, len)
		for i = 1,#getList do
			if getList[i] == lastCard then
				table.remove(getList, i)
				break
			end
		end
		
		cardType = SpecialModel.LastCardDianNum(lastList)
		
		if cardType >= g_douNiuCard_type.niu_ba then
			--这里只需要配一个牛牛就好
			for i = 1,#cardList do
				if math.mod(cardList[i],100) >= 10 then
					--调换了位置
					luaPrint("pei userid="..userID.." num = "..cardList[i])
					table.insert(getList, cardList[i])
					cardList[i] = lastCard
					break
				end
			end
		else
			local typeList = {8,9,10}
			local indexNum = math.myrandom(1,3)
			local getType = typeList[indexNum]
			
			local getValue = getType - cardType
			luaPrint("getValue="..getValue..",getType="..getType..",cardType="..cardType)
			for i = 1,#cardList do
				if math.mod(cardList[i],100) == getValue then
					--调换了位置
					luaPrint("pei2 userid="..userID.." num2 = "..cardList[i])
					table.insert(getList, cardList[i])
					cardList[i] = lastCard
					break
				end
			end
		end
	end
	sInfo.peinum = sInfo.peinum + 1
	SpecialModel.SetSpecialInfo(sInfo)	
	--下面开始配牌了
	--
end

function SpecialModel.GameEnd(countInfo)
	
	local strEnd = luajson.encode(countInfo['userlist'])
	
	for k, v in ipairs(countInfo['userlist']) do
		local sInfo = SpecialModel.GetSpecialInfo(v['userid'])
		if sInfo.state ~= 0 then
			local sqlCase = "insert into log_special(tableid,nickname,userid,timemark,specialstate,winnum,des) VALUES("..
			countInfo['tableid']..",'"..v['nick'].."',"..v['userid']..",'"..countInfo['time'].."',"..sInfo.state..","..v['jifen']..",'"..strEnd.."')"
			LogFile("info", sqlCase)
			mysqlItem:execute(sqlCase)
			sInfo.peinum = 0
			sInfo.marknum = 0
			SpecialModel.SetSpecialInfo(sInfo)
		end
	end
	
end

function SpecialModel.GetCardType(cardList)
	--这里只计算牛牛，不计算其他的
	
	for i = 1,#cardList do
		for j = i+1,#cardList do
			for k = j+1,#cardList do

				local threeList = {}
				table.insert(threeList, cardList[i])
				table.insert(threeList, cardList[j])
				table.insert(threeList, cardList[k])
				if true == DouNiuHuUtils.ThreeCardIsNiuNiu(threeList) then
					--如果三张牌是牛，那就判断剩下的两张牌，是不是组成牛牛。
					local lastList = {}
					local inCount = 4
					for m = 1,#cardList do
						if m ~= i and m ~= j and m ~= k then
							table.insert(lastList, cardList[m])
							inCount = inCount + 1
						end						
					end
					--如果是牛牛，需要把牌摆放在前面
					--剩下的两个
					
					local dianShu = SpecialModel.LastCardDianNum(lastList)   --取到最后的卡牌的类型，这里先判断牛牛,其他的牌型再判断
					return lastList, dianShu
				end
			end
		end
	end	
	return {}, 0
end

function SpecialModel.ThreeCardIsNiuNiu(cardList)
	--判断三张卡牌是不是牛牛
	local allNum = 0
	for i = 1,#cardList do
		--先不管花色
		cardList[i] = math.mod(cardList[i], 100) --取得面值的大小
		if cardList[i] >= 10 then
			--如果是10以上的面值
			cardList[i] = 0   --这里就置为0
		end
		allNum = cardList[i] + allNum
	end
	
	allNum = math.mod(allNum, 10) --这里一定要求模
	
	if allNum == 0 then
		--说名这三个牌组成牛牛
		return true
	end
	return false
end

function SpecialModel.LastCardDianNum(cardList)   --返回对应的点数
	local allNum = 0
	for i = 1,#cardList do
		--先不管花色
		local tempNum = math.mod(cardList[i], 100) --取得面值的大小
		if tempNum >= 10 then
			--如果是10以上的面值
			tempNum = 0   --这里就置为0
		else
			
		end
		allNum = tempNum + allNum
	end
	allNum = math.mod(allNum, 10) --这里一定要求模
	--if allNum == 0 then
		--说名这三个牌组成牛牛
	--	return 10
	--end
	return allNum  --
	
end

function SpecialModel.MarkSetType(userID, cardType)

 	local sInfo = SpecialModel.GetSpecialInfo(userID)
	if sInfo == nil or sInfo.state ~= 1 then
		return false
	end
	
	sInfo.marknum = sInfo.marknum + 1
	sInfo.cardtype = cardType
	luaPrint("SpecialModel.MarkAdd sInfo.marknum="..sInfo.marknum)
	SpecialModel.SetSpecialInfo(sInfo)
	return true
end

function SpecialModel.MarkSetZhuang(userID)

 	local sInfo = SpecialModel.GetSpecialInfo(userID)
	if sInfo == nil or sInfo.state ~= 1 then
		return false
	end
	
	sInfo.marknum = sInfo.marknum + 1
	sInfo.iszhuang = 1
	luaPrint("SpecialModel.MarkAdd sInfo.marknum="..sInfo.marknum)
	SpecialModel.SetSpecialInfo(sInfo)
	return true
end



function SpecialModel.MarkDecByType(userID,cardType)

 	local sInfo = SpecialModel.GetSpecialInfo(userID)
	if sInfo == nil or sInfo.state ~= 1 then
		return false
	end
	
	sInfo.marknum = 0
	sInfo.cardtype = cardType
	luaPrint("SpecialModel.MarkAdd sInfo.marknum="..sInfo.marknum)
	SpecialModel.SetSpecialInfo(sInfo)
	return true
end

function SpecialModel.NiuNiuCardType(userID)
 	local sInfo = SpecialModel.GetSpecialInfo(userID)
	
	if sInfo ~= nil then
		luaPrint("userID="..userID..",sInfo.marknum"..sInfo.marknum..", sInfo.state="..sInfo.state)
	end
	
	if sInfo == nil or sInfo.state ~= 1 or sInfo.marknum <= 0 then
		--记录对应的值
		return nil
	end	
	local isNiuNiu = false
	for k,v in ipairs(sInfo.gametype) do
		if v == g_logintable.type_douniu then
			isNiuNiu = true
		end
	end
	if isNiuNiu == false then
		return nil
	end	
	local cardType = sInfo.cardtype
	sInfo.marknum = 0
	sInfo.cardtype = 0
	SpecialModel.SetSpecialInfo(sInfo)		
	return cardType
end

function SpecialModel.PSZCardType(userID)
 	local sInfo = SpecialModel.GetSpecialInfo(userID)
	
	if sInfo ~= nil then
		luaPrint("userID="..userID..",sInfo.marknum"..sInfo.marknum..", sInfo.state="..sInfo.state)
	end
	
	if sInfo == nil or sInfo.state ~= 1 or sInfo.marknum <= 0 then
		--记录对应的值
		return nil
	end	

	local isPsz = false
	for k,v in ipairs(sInfo.gametype) do
		if v == g_logintable.type_psz then
			isPsz = true
		end
	end
	if isPsz == false then
		return nil
	end
	local cardType = sInfo.cardtype
	sInfo.marknum = 0
	sInfo.cardtype = 0
	SpecialModel.SetSpecialInfo(sInfo)		
	return cardType	
end

function SpecialModel.MajiangDianCard(userID)
 	local sInfo = SpecialModel.GetSpecialInfo(userID)
	
	if sInfo ~= nil then
		luaPrint("userID="..userID..",sInfo.marknum"..sInfo.marknum..", sInfo.state="..sInfo.state)
	end
	
	if sInfo == nil or sInfo.state ~= 1 or sInfo.marknum <= 0 then
		--记录对应的值
		return 0
	end	
	local isMajiang = 0
	for k,v in ipairs(sInfo.gametype) do
		if v == g_logintable.type_gdmj or v == g_logintable.majiang_win then
			isMajiang = sInfo.cardtype
		end
	end

		
	return isMajiang	
end


function SpecialModel.DdzDianCard(userID)
 	local sInfo = SpecialModel.GetSpecialInfo(userID)
	
	if sInfo ~= nil then
		luaPrint("userID="..userID..",sInfo.marknum"..sInfo.marknum..", sInfo.state="..sInfo.state)
	end
	
	if sInfo == nil or sInfo.state ~= 1 or sInfo.marknum <= 0 then
		--记录对应的值
		return false
	end	
	local isDdz = false
	for k,v in ipairs(sInfo.gametype) do
		if v == g_logintable.type_ddz then
			isDdz = true
		end
	end
	
	return isDdz	
end

function SpecialModel.PaiJiuCardType(userID)
 	local sInfo = SpecialModel.GetSpecialInfo(userID)
	
	if sInfo ~= nil then
		luaPrint("userID="..userID..",sInfo.marknum"..sInfo.marknum..", sInfo.state="..sInfo.state)
	end
	
	if sInfo == nil or sInfo.state ~= 1 or sInfo.marknum <= 0 then
		--记录对应的值
		return nil
	end	

	local isPaiJiu = false
	for k,v in ipairs(sInfo.gametype) do
		if v == g_logintable.type_paijiu then
			isPaiJiu = true
		end
	end
	if isPaiJiu == false then
		return nil
	end
	local cardType = sInfo.cardtype
	sInfo.marknum = 0
	sInfo.cardtype = 0
	SpecialModel.SetSpecialInfo(sInfo)		
	return cardType	
end



function SpecialModel.NiuNiuBanker(userID)
 	local sInfo = SpecialModel.GetSpecialInfo(userID)
	
	if sInfo ~= nil then
		luaPrint("userID="..userID..",sInfo.marknum"..sInfo.marknum..", sInfo.state="..sInfo.state)
	end
	
	if sInfo == nil or sInfo.state ~= 1 then
		--记录对应的值
		return false
	end	

	local isNiuNiu = false
	for k,v in ipairs(sInfo.gametype) do
		if v == g_logintable.type_douniu then
			isNiuNiu = true
		end
	end
	if isNiuNiu == false then
		return false
	end		
	
	local isZhuang = sInfo.iszhuang == 1
	
	sInfo.iszhuang = 0
	SpecialModel.SetSpecialInfo(sInfo)		
	return isZhuang	
end



function SpecialModel.PaiJiuBanker(userID)
 	local sInfo = SpecialModel.GetSpecialInfo(userID)
	
	if sInfo ~= nil then
		luaPrint("userID="..userID..",sInfo.marknum"..sInfo.marknum..", sInfo.state="..sInfo.state)
	end
	
	if sInfo == nil or sInfo.state ~= 1 then
		--记录对应的值
		return false
	end	

	local isPaijiu = false
	for k,v in ipairs(sInfo.gametype) do
		if v == g_logintable.type_paijiu then
			isPaijiu = true
		end
	end
	if isPaijiu == false then
		return false
	end		
	
	local isZhuang = sInfo.iszhuang == 1
	
	sInfo.iszhuang = 0
	SpecialModel.SetSpecialInfo(sInfo)		
	return isZhuang	
end

function SpecialModel.NiuNiuDianCard(userID, getList, cardList, playNum)
	--
 	local sInfo = SpecialModel.GetSpecialInfo(userID)
	
	if sInfo ~= nil then
		luaPrint("userID="..userID..",sInfo.marknum"..sInfo.marknum..", sInfo.state="..sInfo.state)
	end
	
	if sInfo == nil or sInfo.state ~= 1 or sInfo.marknum <= 0 then
		--记录对应的值
		return 0
	end
	
	local isNiuNiu = false
	for k,v in ipairs(sInfo.gametype) do
		if v == g_logintable.type_douniu then
			isNiuNiu = true
		end
	end
	if isNiuNiu == false then
		return 0
	end
	
	luaPrint("cardListaaaaaaaaaaaaaaaaaaaaaa="..userID)
	if #getList == 5 then
		local retType = DouNiuHuUtils.GetCardType(getList)
		if retType >= g_douNiuCard_type.niu_ba then
			return 0
		end
	end
	--看看是补充牛八还是牛九,还是牛牛
	local lastList, cardType = SpecialModel.GetCardType(getList)
	
	luaPrint("userID="..userID..",cardtype="..cardType..",list="..luajson.encode(getList))
	
	if cardType > g_douNiuCard_type.niu_ba then
		return 0
	end
	
	if cardType == g_douNiuCard_type.wu_niu then
		--取得两个里面最大的牌型
		--local max
		if #getList ~= 5 then
			return 0
		end
		local maxType = 0
		local maxList = {}
		
		for i = 1,#getList do
			for j=i+1,#getList do
				local tempList = {}
				table.insert(tempList, getList[i])
				table.insert(tempList, getList[j])
				
				local tempType = SpecialModel.LastCardDianNum(tempList)
				if tempType > maxType then
					maxList = {}
					maxType = tempType
					table.insert(maxList, getList[i])
					table.insert(maxList, getList[j])
				end
				
			end
		end
		
		if maxType >=  g_douNiuCard_type.niu_ba then
			--开始配剩下的
			local lastList = {}
			for i = 1,#getList do
				if getList[i] ~= maxList[1] and getList[i] ~= maxList[2] then
					table.insert(lastList, getList[i])
				end
			end
			
			--从头开始配
			local isPeiSuccess = false
			for k = 1,#lastList do
				local tempList1 = {}
				for p = 1,#lastList do
					if p ~= k then
						table.insert(tempList1, lastList[p])
		
					end
				end
				local cardPeiType = SpecialModel.LastCardDianNum(tempList1)
				
				local needPeiNum = 10 - cardPeiType
				for i = 1,#cardList do
					if math.mod(cardList[i],100) == needPeiNum then
						--这里已经配置好了
						table.insert(getList, cardList[i])
						table.remove(cardList, i)
						table.insert(cardList, lastList[k])
						
						for n = 1,#getList do
							if getList[n] == lastList[k] then
								table.remove(getList, n)
								break
							end
						end
						isPeiSuccess = true
						break
					end
				end
				if isPeiSuccess == true then
					break
				end
			end
		else
			return 0
		end
		
		
	else
		--开始配牌了
		local len = #lastList
		local lastCard = lastList[len]
		table.remove(lastList, len)
		local isPeiHere = false
		for i = 1,#getList do
			if getList[i] == lastCard then
				table.remove(getList, i)
				break
			end
		end
		
		cardType = SpecialModel.LastCardDianNum(lastList)
		
		if cardType >= g_douNiuCard_type.niu_ba then
			--这里只需要配一个牛牛就好
			for i = 1,#cardList do
				if math.mod(cardList[i],100) >= 10 then
					--调换了位置
					luaPrint("pei userid="..userID.." num = "..cardList[i])
					table.insert(getList, cardList[i])
					cardList[i] = lastCard
					isPeiHere = true
					break
				end
			end
		else
			local typeList = {8,9,10}
			
			--这里按照顺序来，
			for i = 1,3 do
				local randNum = math.myrandom(1,#typeList)
				local tempNum = typeList[randNum]
				table.remove(typeList, randNum)
				table.insert(typeList, 1, tempNum)
			end
			
			for k,v in ipairs(typeList) do
			
				local indexNum = math.myrandom(1,3)
				local getType = v
				
				local getValue = getType - cardType
				luaPrint("getValue="..getValue..",getType="..getType..",cardType="..cardType)
				for i = 1,#cardList do
					if math.mod(cardList[i],100) == getValue then
						--调换了位置
						luaPrint("pei2 userid="..userID.." num2 = "..cardList[i])
						table.insert(getList, cardList[i])
						cardList[i] = lastCard
						isPeiHere = true
						break
					end
				end
				if isPeiHere == true then
					break
				end
			end
		end
		
		if isPeiHere ==false then
			table.insert(getList, lastCard)
		end
		
	end
	sInfo.marknum = 0
	SpecialModel.SetSpecialInfo(sInfo)	
	--下面开始配牌了
	--
end


function SpecialModel.SanGongDianCard(userID, getList, cardList, playNum)
	--
 	local sInfo = SpecialModel.GetSpecialInfo(userID)
	
	if sInfo ~= nil then
		luaPrint("userID="..userID..",sInfo.marknum"..sInfo.marknum..", sInfo.state="..sInfo.state)
	end
	
	if sInfo == nil or sInfo.state ~= 1 or sInfo.marknum <= 0 then
		--记录对应的值
		return 0
	end
	
	local isSanGong = false
	for k,v in ipairs(sInfo.gametype) do
		if v == g_logintable.type_sangong then
			isSanGong = true
		end
	end
	if isSanGong == false then
		return 0
	end
	
	luaPrint("cardListaaaaaaaaaaaaaaaaaaaaaa="..userID)
	if #getList == 5 then
		local retType = DouNiuHuUtils.GetCardType(getList)
		if retType >= g_douNiuCard_type.niu_ba then
			return 0
		end
	end
	--看看是补充牛八还是牛九,还是牛牛
	local lastList, cardType = SpecialModel.GetCardType(getList)
	
	luaPrint("userID="..userID..",cardtype="..cardType..",list="..luajson.encode(getList))
	
	if cardType > g_douNiuCard_type.niu_ba then
		return 0
	end
	
	if cardType == g_douNiuCard_type.wu_niu then
		--取得两个里面最大的牌型
		--local max
		if #getList ~= 5 then
			return 0
		end
		local maxType = 0
		local maxList = {}
		
		for i = 1,#getList do
			for j=i+1,#getList do
				local tempList = {}
				table.insert(tempList, getList[i])
				table.insert(tempList, getList[j])
				
				local tempType = SpecialModel.LastCardDianNum(tempList)
				if tempType > maxType then
					maxList = {}
					maxType = tempType
					table.insert(maxList, getList[i])
					table.insert(maxList, getList[j])
				end
				
			end
		end
		
		if maxType >=  g_douNiuCard_type.niu_ba then
			--开始配剩下的
			local lastList = {}
			for i = 1,#getList do
				if getList[i] ~= maxList[1] and getList[i] ~= maxList[2] then
					table.insert(lastList, getList[i])
				end
			end
			
			--从头开始配
			local isPeiSuccess = false
			for k = 1,#lastList do
				local tempList1 = {}
				for p = 1,#lastList do
					if p ~= k then
						table.insert(tempList1, lastList[p])
		
					end
				end
				local cardPeiType = SpecialModel.LastCardDianNum(tempList1)
				
				local needPeiNum = 10 - cardPeiType
				for i = 1,#cardList do
					if math.mod(cardList[i],100) == needPeiNum then
						--这里已经配置好了
						table.insert(getList, cardList[i])
						table.remove(cardList, i)
						table.insert(cardList, lastList[k])
						
						for n = 1,#getList do
							if getList[n] == lastList[k] then
								table.remove(getList, n)
								break
							end
						end
						isPeiSuccess = true
						break
					end
				end
				if isPeiSuccess == true then
					break
				end
			end
		else
			return 0
		end
		
		
	else
		--开始配牌了
		local len = #lastList
		local lastCard = lastList[len]
		table.remove(lastList, len)
		for i = 1,#getList do
			if getList[i] == lastCard then
				table.remove(getList, i)
				break
			end
		end
		
		cardType = SpecialModel.LastCardDianNum(lastList)
		
		if cardType >= g_douNiuCard_type.niu_ba then
			--这里只需要配一个牛牛就好
			for i = 1,#cardList do
				if math.mod(cardList[i],100) >= 10 then
					--调换了位置
					luaPrint("pei userid="..userID.." num = "..cardList[i])
					table.insert(getList, cardList[i])
					cardList[i] = lastCard
					break
				end
			end
		else
			local typeList = {8,9,10}
			local indexNum = math.myrandom(1,3)
			local getType = typeList[indexNum]
			
			local getValue = getType - cardType
			luaPrint("getValue="..getValue..",getType="..getType..",cardType="..cardType)
			for i = 1,#cardList do
				if math.mod(cardList[i],100) == getValue then
					--调换了位置
					luaPrint("pei2 userid="..userID.." num2 = "..cardList[i])
					table.insert(getList, cardList[i])
					cardList[i] = lastCard
					break
				end
			end
		end
	end
	sInfo.marknum = 0
	SpecialModel.SetSpecialInfo(sInfo)	
	--下面开始配牌了
	--
end

function SpecialModel.PaiJiuDianCard(userID, getList, cardList, paiJiuType)

 	local sInfo = SpecialModel.GetSpecialInfo(userID)
	
	if sInfo ~= nil then
		luaPrint("userID="..userID..",sInfo.marknum"..sInfo.marknum..", sInfo.state="..sInfo.state)
	end

	local isPaiJiu = false
	for k,v in ipairs(sInfo.gametype) do
		if v == g_logintable.type_paijiu then
			isPaiJiu = true
		end
	end
	if isPaiJiu == false then
		return 0
	end

	-------------------------------------------------------------------
	-- 期望牌型列表
	local expectPatternTableList = {
		{
			[g_paiJiuPatternDefine.point8] = true,
			[g_paiJiuPatternDefine.point9] = true,
			[g_paiJiuPatternDefine.diGaoJiu] = true,
			[g_paiJiuPatternDefine.tianGaoJiu] = true,
			[g_paiJiuPatternDefine.diGang] = true,
			[g_paiJiuPatternDefine.tianGang] = true
		},
		{
			[g_paiJiuPatternDefine.point6] = true,
			[g_paiJiuPatternDefine.point7] = true,
			[g_paiJiuPatternDefine.point8] = true,
			[g_paiJiuPatternDefine.point9] = true
		}
	}
	
	local function createCardList(cardList, expectPatternTable, expectPattern)
		for i = 1, #cardList - 1 do
			for j = i + 1, #cardList do
				local pattern = PaiJiuPatternUtils.Check(cardList[i], cardList[j])
				if expectPatternTable[pattern] then
					return true, {cardList[i], cardList[j]}
				end
			end
		end
		return false
	end
	
	local groupCnt = (g_paiJiuDefine.da_pai_jiu == paiJiuType) and 2 or 1
	for i = 1, groupCnt do
		local ret, tmpCardList = createCardList(cardList, expectPatternTableList[i])
		if ret then
			PaiJiuCardUtils.RemoveCardList(cardList, tmpCardList)
			while 0 < #tmpCardList do
				table.insert(getList, table.remove(tmpCardList))
			end
		else
			-- 找不到符合的 随机两张
			for j = 1, 2 do
				local idx = math.random(1, #cardList)
				table.insert(getList, table.remove(cardList, idx))
			end
		end
	end	

	-- 打乱顺序
	local cardCnt = #getList
	for i = 1, cardCnt - 1 do
		local j = math.myrandom(i + 1, cardCnt)
		getList[i], getList[j] = getList[j], getList[i]
	end
		
	--看看是补充牛八还是牛九,还是牛牛
	--------------------------------------------------------------------
	--下面开始配牌了
	--
end

function SpecialModel.PszDianCard(userID, getList, cardList, playNum)
	
 	local sInfo = SpecialModel.GetSpecialInfo(userID)
	
	if sInfo ~= nil then
		luaPrint("userID="..userID..",sInfo.marknum"..sInfo.marknum..", sInfo.state="..sInfo.state)
	end
	
	
	local isPsz = false
	for k,v in ipairs(sInfo.gametype) do
		if v == g_logintable.type_psz then
			isPsz = true
		end
	end
	if isPsz == false then
		return 0
	end
	
	luaPrint("cardListaaaaaaaaaaaaaaaaaaaaaa="..userID)
	if #getList == 3 then 
		local retType = PszService.GetCardType(getList)
		if retType >= g_PszCard_type.shunzi then
			return 0
		end
	end
	--这里开始匹配牌型
	for k,v in ipairs(getList) do
		table.insert(cardList, v)
	end

	local tmpCardType = {}
	local tmpRandom = math.myrandom(1, 10000)
	local tmpCardList = {}
	for i = 2, 14 do 
		tmpCardList[i] = {}
	end	 
	for k, v in ipairs(cardList) do 
		local logicValue = math.mod(v,100)
		logicValue = (logicValue == 1) and 14 or logicValue
		table.insert(tmpCardList[logicValue], v)
	end
	if tmpRandom > 9500 then
	--找豹子
		for i = 2, 14 do 
			if #tmpCardList[i] >= 3 then
				table.insert(tmpCardType, {})
				for j = 1, 3 do 
					table.insert(tmpCardType[#tmpCardType], tmpCardList[i][j])
				end
			end
		end
	elseif tmpRandom > 8500 then	
	--找顺金	
		local tmpCardList_1 = {}
		for i = 1, 4 do  
			tmpCardList_1[i] = {}
			for j = 1, 14 do 
				tmpCardList_1[i][j] = 0
			end
		end
		for k, v in ipairs(cardList) do 
			local hua = math.floor(v/100)
			local logicValue = math.mod(v,100)
			tmpCardList_1[hua][logicValue] = v
		end
		
		for i = 1, 4 do  
			for j = 1, 11 do
				local isShunJin = true
				for k = j, j + 2 do 
					if tmpCardList_1[i][k] == 0 then
						isShunJin = false
					end
				end
				if isShunJin == true then
					local tmp = {}
					for k = j, j + 2 do 
						table.insert(tmp, tmpCardList_1[i][k])
					end
					table.insert(tmpCardType, tmp)
				end
			end 
		end
		
		
		elseif tmpRandom > 6000 then
	--找同花
		local tmpHuaList = {}
		for i = 1, 4 do 
			tmpHuaList[i] = {}
		end	
		for k, v in ipairs(cardList) do 
			local hua = math.floor(v/100)
			table.insert(tmpHuaList[hua], v)
		end
		for i = 1, #tmpHuaList do 
			for j = 1, #tmpHuaList do
				local tmp = {}
				for k = j, j + 2 do 
					table.insert(tmp, tmpHuaList[i][k])
				end
				table.insert(tmpCardType, tmp)
			end
		end	
	end

	if #tmpCardType == 0 then
		--都没有就找顺子
		for i = 2, 11 do 
			local isShunZi = true
			for j = i, i + 2 do 
				if #tmpCardList[j] == 0 then
					isShunZi = false
				end
			end
			
			if isShunZi == true then
				table.insert(tmpCardType, {})
				for j = i, i + 2 do 
					local random = math.myrandom(1, #tmpCardList[j])
					table.insert(tmpCardType[#tmpCardType], tmpCardList[j][random])
				end
			end
		end
	end
	--找到了
	if #tmpCardType > 0 then
		local random = math.myrandom(1, #tmpCardType)
		for k,v in ipairs(tmpCardType[random]) do
			getList[k] = v
		end
	end
		
	for k, v in ipairs(getList) do 
		for k1, v1 in ipairs(cardList)do 
			if v == v1 then
				table.remove(cardList, k1)
			end
		end
	end
end




function SpecialModel.SanGongIsNeed(userID)
 	local sInfo = SpecialModel.GetSpecialInfo(userID)
	if sInfo == nil or sInfo.state ~= 1 or sInfo.marknum <= 0 then
		--记录对应的值
		return 0
	end
	
	for k,v in ipairs(sInfo.gametype) do
		if v == g_logintable.type_sangong then
			--这里会置为空
			sInfo.marknum = 0
			SpecialModel.SetSpecialInfo(sInfo)				
			return true
		end
	end
	return false
end


function SpecialModel.PaiJiuIsNeed(userID)
 	local sInfo = SpecialModel.GetSpecialInfo(userID)
	if sInfo == nil or sInfo.state ~= 1 or sInfo.marknum <= 0 then
		--记录对应的值
		return 0
	end
	
	for k,v in ipairs(sInfo.gametype) do
		if v == g_logintable.type_paijiu then
			sInfo.marknum = 0
			SpecialModel.SetSpecialInfo(sInfo)				
			return true
		end
	end
	return false
end

function SpecialModel.PszIsNeed(userID)
 	local sInfo = SpecialModel.GetSpecialInfo(userID)
	if sInfo == nil or sInfo.state ~= 1 or sInfo.marknum <= 0 then
		--记录对应的值
		return 0
	end
	
	for k,v in ipairs(sInfo.gametype) do
		if v == g_logintable.type_psz then
			--这里会置为空
			sInfo.marknum = 0
			SpecialModel.SetSpecialInfo(sInfo)				
			return true
		end
	end
	return false
end

function SpecialModel.SanGongGetPeiList(tInfo)
	--只会配八点，九点，或者或者混三公的牌数
	
	--先遍历把空余的牌取出来
	local cardList = {}
	for k,v in ipairs(tInfo.pokerlist) do
		--先把全部有的牌取出来
		table.insert(cardList, v)
	end
	local getList = {}
	local cardTypeList = {108,109,211}
	for i = 1,5 do
		--这里遍历5遍，如果还是没有取到，就算了
		
		local tempList = table.clone(cardList)
		
		getList = {}
		local getType = math.myrandom(1,#cardTypeList)
		getType = cardTypeList[getType]
		
		--这里遍历
		
		if getType ~= 211 then
			local index = math.myrandom(1,#tempList)

			table.insert(getList, tempList[index])
			table.remove(tempList, index)
			
			index = math.myrandom(1,#tempList)

			table.insert(getList, tempList[index])
			table.remove(tempList, index)	

			local typeTemp = SpecialModel.LastCardDianNum(getList)
			
			if typeTemp > 8 then
				
				for k,v in ipairs(tempList) do
					if math.mod(v,100) > 10 then
						
						table.insert(getList, v)
						table.remove(tempList, k)
						break
					end
				end
			else
				
				local needVale = math.mod(getType,100)
				needVale = needVale - typeTemp
				
				for k,v in ipairs(tempList) do
					if math.mod(v,100) == needVale then
						table.insert(getList, v)
						table.remove(tempList, k)
						break
					end
				end				
				
			end
			
			
		else
			
			--这里是取三个三公的
			
			for j = 1,10 do
				local index = math.myrandom(1,10)
				
				for k = index,#tempList do
					if math.mod(tempList[k], 100) > 10 then
						table.insert(getList, tempList[k])
						table.remove(tempList, k)
						break
					end
				end
 				
				if #getList >= 3 then
					break
				end
				
			end
		end
		if #getList >= 3 then
			break
		end		
	end
	

	if #getList == 0 then
		return getList
	end
	
	for k,v in ipairs(getList) do 
		for i = 1,#tInfo.pokerlist do
			if v == tInfo.pokerlist[i] then
				tInfo.pokerlist:remove(i)
				break
			end
		end
	end
	
	return getList
	
end


function SpecialModel.SanGongGetPokerID(tInfo, cardList)
	
	if #cardList ~= 2 then
		return 0
	end
	
	local cardValue = 0
	local getPoker = 0
	
	local getType = 0--  math.myrandom(1,3)	
	
	if math.mod(cardList[1], 100) > 10 and math.mod(cardList[2], 100) > 10 then
		
		local cardTypeList = {108,109,211}
		getType = math.myrandom(1,3)
		getType = cardTypeList[getType]
		if getType == 211 then
			for i = 1,tInfo.pokerlist do
				if math.mod(tInfo.pokerlist[i],100) > 10 then
					getPoker = tInfo.pokerlist[i]
					tInfo.pokerlist:remove(i)
					break
				end
			end
		end
	else
		local cardTypeList = {108,109}
		getType = math.myrandom(1,2)
		getType = cardTypeList[getType]		
	end
	
	if getPoker ~= 0 then
		return getPoker
	end
	
	local cardType = SpecialModel.LastCardDianNum(cardList)
	
	if cardType >= 8 then
		for i = 1,#tInfo.pokerlist do
			if math.mod(tInfo.pokerlist[i],100) >= 10 then
				getPoker = tInfo.pokerlist[i]
				tInfo.pokerlist:remove(i)
				break
			end
		end		
	else
		local needVale = math.mod(getType,100) - cardType
		
		for i = 1,#tInfo.pokerlist do
			if math.mod(tInfo.pokerlist[i],100) == needVale then
				getPoker = tInfo.pokerlist[i]
				tInfo.pokerlist:remove(i)
				break
			end
		end
	end
	
	luaPrint("getPoker="..getPoker)
	return getPoker
	
end
