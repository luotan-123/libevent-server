GameModel = {}

GameModel.redis_index = "redis_Game"


GameModel.gamestate_list = "Gamestate_list"    --json value = {state=state,gamename=gamename,clientstate=clientstate}

GameModel.player_gametabletype_win = "player_gametabletype_win_"

GameModel.player_gameconnect = "player_gameconnect"

GameModel.gamenumber = "gamenumber"

GameModel.gamerobot = "gamerobot"

GameModel.gametablelist = "gametablelist"

GameModel.cpgamerecord_tbl_hty = "cpgamerecord_tbl_hty_"    		--牌桌的历史记录
GameModel.cpgamerecord_user_hty = "cpgamerecord_user_hty_"  		--玩家个人的历史记录

function GameModel.GetGameState(gameType)
	
	local str = redisItem:hget(GameModel.gamestate_list, gameType, GameModel.redis_index)
	str = luajson.decode(str)
	if str ~= nil and str["state"] ~= nil  then
		return str["state"] or 0
	end
	
	GameModel.loadGameStateList() 
	str = redisItem:hget(GameModel.gamestate_list, gameType, GameModel.redis_index)
    str = luajson.decode(str)
	return str["state"] or 0
end

function GameModel.GetGamePlayerState(gameType, pInfo)
	
	if pInfo.channel == g_SpecialChannel then
		return g_gamestate.normal
	end
	
	local str = redisItem:hget(GameModel.gamestate_list, gameType, GameModel.redis_index)
	if str ~= nil then
		str = luajson.decode(str)
		return str["state"] or 0
	end
	
	GameModel.loadGameStateList() 
	str = redisItem:hget(GameModel.gamestate_list, gameType, GameModel.redis_index)
    if str ~= nil then
		str = luajson.decode(str)
		return str["state"] or 0
	end
	return 0
end


function GameModel.SetGameState(gameType, state)

	redisItem:hset(GameModel.gamestate_list, gameType, state, GameModel.redis_index)
	
	local sqlCase = "update dy_gamestate set state="..state.." where gametype="..gameType
	mysqlItem:execute(sqlCase)
end

function GameModel.GetGameStateList()
	
	local GamestateList = redisItem:hgetall(GameModel.gamestate_list, GameModel.redis_index)
	
	local num = 0
	for k,v in pairs(GamestateList)do
		num = num + 1
	end
	if GamestateList ~= nil and num > 0 then
		return GamestateList
	end
	
	return GameModel.loadGameStateList()
end

function GameModel.loadGameStateList()
	redisItem:del(GameModel.gamestate_list, GameModel.redis_index)
	local sqlCase = "select gametype, state, gamename, clientstate from dy_gamestate "
	mysqlItem:executeQuery(sqlCase)
	while true do
		local ratio = mysqlItem:fetch({})
		if ratio == nil then
			break
		end
        local temp = {state=ratio[2],gamename=ratio[3],clientstate= ratio[4] }
		redisItem:hset(GameModel.gamestate_list, tonumber(ratio[1]), luajson.encode(temp), GameModel.redis_index)
	end
	
	local GamestateList = redisItem:hgetall(GameModel.gamestate_list, GameModel.redis_index)
	local num = 0
	for k,v in pairs(GamestateList)do
		num = num + 1
	end
	if GamestateList == nil or num == 0 then
		local gameList ={
			g_CpTuiTongZiDefine.game_type,
			g_cpsangongDefine.game_type,
			g_cpwrjcDefine.game_type,
			g_cplhdDefine.game_type,
			g_cphongheiDefine.game_type,
			g_cpdouniuDefine.gametype_classic,
			g_cpbrnnDefine.game_type,
			g_cpbjlDefine.game_type,
		}
        local namelist = {
            "彩票推筒子",
            "彩票三公",
            "万人竞猜",
            "彩票龙虎斗",
            "彩票红黑大战",
            "彩票牛牛",
            "彩票百人牛牛",
            "彩票百家乐",
            "彩票百人推筒子"        
        }

		for k,v in ipairs(gameList)do 
            local tem = {state=1,gamename=namelist[k],clientstate= 1}
			redisItem:hset(GameModel.gamestate_list, v, luajson.encode(temp), GameModel.redis_index)
		end

        --彩票
        for i=1,#g_caipiaoDefine.gamekey do
            local tem = {state=1,gamename=g_caipiaoDefine.init_data[i]['tablename'],clientstate= 1}
			redisItem:hset(GameModel.gamestate_list, g_caipiaoDefine.game_type + i, luajson.encode(temp), GameModel.redis_index)
        end
        
	end
	return redisItem:hgetall(GameModel.gamestate_list, GameModel.redis_index)
end

function GameModel.GetCloseGameList()
	local CloseGameList = {}
	local sqlCase = "select gametype, closegamelist from dy_gamestate "
	mysqlItem:executeQuery(sqlCase)
	while true do
		local ratio = mysqlItem:fetch({})
		if ratio == nil then
			break
		end
		local gametype_1 = tonumber(ratio[1]) == nil and 0 or tonumber(ratio[1])
		local closegamelist_1 = ratio[2]
		CloseGameList[gametype_1] = closegamelist_1
	end
	return CloseGameList
end

function GameModel.isChannelClose(channelList, pInfo)
	if channelList == nil then
		return false
	end
	
	local tmp = luajson.decode(channelList)
	if tmp ~= nil then
		for k,v in ipairs(tmp) do
			if pInfo.channel == v then
				return true
			end
		end	
	end
	return false
end


function GameModel.setGameTableTypeWin(userID, gametype, tabletype)
	
	redisItem:hset(GameModel.player_gametabletype_win..userID, gametype.."_"..tabletype, 0, GameModel.redis_index)
end

function GameModel.getGameTableTypeWin(userID, gametype, tabletype)
	
	local tmp = redisItem:hget(GameModel.player_gametabletype_win..userID, gametype.."_"..tabletype, GameModel.redis_index)
	return tmp == nil and 0 or tmp
end

function GameModel.delGameTableTypeWin_one(userID, gametype, tabletype)
	
	redisItem:hdel(GameModel.player_gametabletype_win..userID, gametype.."_"..tabletype, GameModel.redis_index)
end

function GameModel.delGameTableTypeWin_all(userID)
	
	redisItem:del(GameModel.player_gametabletype_win..userID, GameModel.redis_index)
end

function GameModel.addGameTableTypeWin(userID, gametype, tabletype, count)
	
	redisItem:hincrby(GameModel.player_gametabletype_win..userID, gametype.."_"..tabletype, count, GameModel.redis_index)
end

function GameModel.SetPlayerGameConnect(userID, jsonArr)
	redisItem:hset( GameModel.player_gameconnect, userID, luajson.encode(jsonArr), GameModel.redis_index)
end

function GameModel.GetPlayerGameConnect(userID)
	return redisItem:hget(GameModel.player_gameconnect, userID, GameModel.redis_index)
end

function GameModel.DelPlayerGameConnect(userID)
	return redisItem:hdel(GameModel.player_gameconnect, userID, GameModel.redis_index)
end


function GameModel.getGameNumber()
	local date = ""
	local tab = {}
	local t1 = TimeUtils.GetTime()
	local ts = TimeUtils.GetTimeString(t1)
	tab.year = string.sub(ts, 1, 4)
	tab.month = string.sub(ts, 6, 7)
	tab.day = string.sub(ts, 9, 10)
	date = date..tab.year..tab.month..tab.day
	
	local num = redisItem:hincrby(GameModel.gamenumber, date, 1, GameModel.redis_index)

	if num < 10 then
		date = date.."000000"..num
		
	elseif num < 100 then
		date = date.."00000"..num
	elseif num < 1000 then
		date = date.."0000"..num
	elseif num < 10000 then
		date = date.."000"..num
	elseif num < 100000 then
		date = date.."00"..num
	elseif num < 1000000 then
		date = date.."0"..num
	else
		date = date..num
	end
	
	return date
end


function GameModel.setGameRobot(gametype, tabletype, info)
	
	redisItem:hset(GameModel.gamerobot, gametype.."_"..tabletype, luajson.encode(info), GameModel.redis_index)
end

function GameModel.getGameRobot(gametype, tabletype)
	
	local info = redisItem:hget(GameModel.gamerobot, gametype.."_"..tabletype, GameModel.redis_index)
	if info ~= nil then
		info = luajson.decode(info)
		return info
	end
	
	return nil
end


function GameModel.setGameTableList(gametype, tableid, info)
	redisItem:hset(GameModel.gametablelist.."_"..gametype, tableid, info:SerializeToString(), GameModel.redis_index)
end

function GameModel.delGameTableList(gametype, tableid)
	redisItem:hdel(GameModel.gametablelist.."_"..gametype, tableid, GameModel.redis_index)
end

function GameModel.getGameTableList(gametype)
	return redisItem:hgetall(GameModel.gametablelist.."_"..gametype, GameModel.redis_index)
end


function GameModel.SetHistory(frameid, info)
	local redisKey = GameModel.cpgamerecord_tbl_hty..frameid
	redisItem:setex( redisKey, g_weekSeconds,  info, GameModel.redis_index)
end
function GameModel.GetHistroy(frameid)
	local redisKey = GameModel.cpgamerecord_tbl_hty..frameid
	return redisItem:get(redisKey, GameModel.redis_index )
end
function GameModel.HistoryExist(frameid)
	
	local redisKey = GameModel.cpgamerecord_tbl_hty..frameid
	return redisItem:exists(redisKey,GameModel.redis_index )
end

function GameModel.SetPlayerHistory(userID, gameType, frameid)
	local redisKey = GameModel.cpgamerecord_user_hty..gameType.."_"..userID
	redisItem:lpush(redisKey, frameid, GameModel.redis_index)
end
function GameModel.GetPlayerHistory(userID, gameType, pageNum)
	local redisKey = GameModel.cpgamerecord_user_hty..gameType.."_"..userID
	return redisItem:lrange(redisKey, (pageNum - 1)*10, pageNum*10 - 1, GameModel.redis_index)
end
function GameModel.DelPlayerHistory(userID, gameType, frameid)
	local redisKey = GameModel.cpgamerecord_user_hty..gameType.."_"..userID
	redisItem:lrem( redisKey, 1, frameid,  GameModel.redis_index)
end


