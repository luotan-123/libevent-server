ActivityModel = {}
ActivityModel.redis_index = "redis_activity"

--获取积分活动的接口，彩金赠"英雄"
function ActivityModel.achaward(userid, info, isToDay)    --流水积分活动
	
	if info == nil then
		local info = msg_human2_pb.gcactivityconnections()
	end

	
	return info
	
end

--获取积分活动的接口,人脉达人
function ActivityModel.inviteaward(userid, info, isToDay)     --流水积分活动


	return info
	
end
