
RosterModel = {}
RosterModel.redis_index = "redis_roster"
RosterModel.roster_info = "roster_info_"
RosterModel.roster_player_win = "roster_player_win_"
function RosterModel.LoadRoster(userID, rInfo)

	if rInfo == nil then
		rInfo = st_user_pb.rosterinfo()
	end
	
	redisItem:del(RosterModel.roster_info..userID,   RosterModel.redis_index)
	local sqlCase = "select * from dy_roster where userid="..userID
	mysqlItem:executeQuery(sqlCase)
	while true do
		local sqlData = mysqlItem:fetch({})
		if sqlData == nil then
			break
		end
		
		rInfo.gametype:append(tonumber(sqlData[10])) 
		rInfo.tabletype:append(tonumber(sqlData[11]))
		rInfo.rostertype:append(tonumber(sqlData[5]))
		rInfo.starttime:append(tonumber(sqlData[6]))
		rInfo.endtime:append(tonumber(sqlData[7]))
		rInfo.optmark:append(tonumber(sqlData[12]))
		rInfo.probability:append(tonumber(sqlData[13]))
	end
	
	if #rInfo.gametype > 0 then
		rInfo.userid = tonumber(userID)
		redisItem:set(RosterModel.roster_info..userID, rInfo:SerializeToString(), RosterModel.redis_index)
	end
end


function RosterModel.GetRoster(userID, rInfo)
	
	if rInfo == nil then
		rInfo = st_user_pb.rosterinfo()
	end
	local strGet = redisItem:get(RosterModel.roster_info..userID, RosterModel.redis_index)
	if strGet ~= nil then
		rInfo:ParseFromString(strGet)
		return rInfo
	end
	return nil
	
end

function RosterModel.CheckIsRoster(userID, gameType, tabletype)   --检查单个用户是否是白名单，

	if RobotService.IsRobot(userID) then
		return 0
	end
	
	local rInfo = RosterModel.GetRoster(userID)
	if rInfo == nil then
		--如果没有查到该玩家就不是黑白名单的
		return 0
	end
	
	local curSec = TimeUtils.GetTime()
	for i = 1, #rInfo.gametype do
		if gameType == rInfo.gametype[i] and tabletype == rInfo.tabletype[i] then
			--查看是否在有效时间里
			if curSec > rInfo.starttime[i] and curSec < rInfo.endtime[i] then
				--看看有没有超过总输赢
				local tmpcount = RosterModel.getRosterPlayer(userID, gameType, tabletype)
				if tmpcount == nil then
					local randNum = math.myrandom(1,100)
					if randNum <= rInfo.probability[i] then
						return rInfo.rostertype[i]
					end
				else
					tmpcount = tonumber(tmpcount)
					local isY = false
					if rInfo.rostertype[i] == 1 then
						--黑名单
						if 0 - rInfo.optmark[i] < tmpcount then
							isY = true
						end
					elseif rInfo.rostertype[i] == 2 then
						--白名单
						if rInfo.optmark[i] > tmpcount then
							isY = true
						end
					end
					if isY == true then
						local randNum = math.myrandom(1,100)
						if randNum <= rInfo.probability[i] then
							return rInfo.rostertype[i]
						end
					end
				end
				
			end
		end
	end
	
	return 0
end

--捕鱼难度系数
function RosterModel.fishingMonomerControl(userID, gametype, tabletype)
	
	if RobotService.IsRobot(userID) then
		return 1
	end
	
	local rInfo = RosterModel.GetRoster(userID)
	if rInfo == nil then
		--如果没有查到该玩家就不是黑白名单的
		return 1
	end
	
	local curSec = TimeUtils.GetTime()
	for i = 1, #rInfo.gametype do
		if gametype == rInfo.gametype[i] and tabletype == rInfo.tabletype[i] then
			--查看是否在有效时间里
			if curSec > rInfo.starttime[i] and curSec < rInfo.endtime[i] then
				--看看有没有超过总输赢
				local tmpcount = RosterModel.getRosterPlayer(userID, gametype, tabletype)
				if tmpcount ~= nil then
					if rInfo.optmark[i] > math.abs(tmpcount) then
						return rInfo.probability[i]
					end
				end
			end
		end
	end
	return 1
	
end


function RosterModel.GetHeiAndBai(userList, gameType, tabletype)
	
	local heiList = {}
	local baiList = {}
	
	for k,v in ipairs(userList) do
		
		if g_rosterType.type_heimingdan == RosterModel.CheckIsRoster(v, gameType, tabletype) then
			table.insert(heiList, v)
		elseif g_rosterType.type_baimingdan == RosterModel.CheckIsRoster(v, gameType, tabletype) then
			table.insert(baiList, v)
		end
		
	end
	return heiList, baiList
end

function RosterModel.addHeiAndBaiPlayerwin(userID, gameType, tabletype, count) 
	if RobotService.IsRobot(userID) or userID == 1  then
		return 
	end
	
	local rInfo = RosterModel.GetRoster(userID)
	if rInfo == nil then
		--如果没有查到该玩家就不是黑白名单的
		return
	end
	
	local curSec = TimeUtils.GetTime()
	for i = 1, #rInfo.gametype do
		if gameType == rInfo.gametype[i] and tabletype == rInfo.tabletype[i] then
			--查看是否在有效时间里
			if curSec > rInfo.starttime[i] and curSec < rInfo.endtime[i] then
				RosterModel.addRosterPlayerWin(userID, gameType, tabletype, count)
			end
		end
	end
	
end

function RosterModel.setRosterPlayer(userID, gametype, tabletype)
	
	redisItem:hset(RosterModel.roster_player_win..userID, gametype.."_"..tabletype, 0, RosterModel.redis_index)
end

function RosterModel.getRosterPlayer(userID, gametype, tabletype)
	
	local tmp = redisItem:hget(RosterModel.roster_player_win..userID, gametype.."_"..tabletype, RosterModel.redis_index)
	return tmp == nil and 0 or tmp
end

function RosterModel.deltRosterPlayer_one(userID, gametype, tabletype)
	
	redisItem:hdel(RosterModel.roster_player_win..userID, gametype.."_"..tabletype, RosterModel.redis_index)
end

function RosterModel.deltRosterPlayer_all(userID)
	
	redisItem:del(RosterModel.roster_player_win..userID, RosterModel.redis_index)
end

function RosterModel.addRosterPlayerWin(userID, gametype, tabletype, count)
	
	redisItem:hincrby(RosterModel.roster_player_win..userID, gametype.."_"..tabletype, count, RosterModel.redis_index)
end



--下面是旧版本
--[[
function RosterModel.LoadRoster(userID, rInfo)

	if rInfo == nil then
		rInfo = st_user_pb.rosterinfo()
	end
	redisItem:del( RosterModel.roster_info..userID,   RosterModel.redis_index)
	local sqlCase = "select * from dy_roster where userid="..userID.." and rostertype>0"
	LogFile("info", sqlCase)
	rInfo.userid = tonumber(userID)
	mysqlItem:executeQuery(sqlCase)
	local sqlData = mysqlItem:fetch({})
	if sqlData ~= nil then
		rInfo.rostertype = tonumber(sqlData[5])
		rInfo.starttime = tonumber(sqlData[6])
		rInfo.endtime = tonumber(sqlData[7])
		local gameList = luajson.decode(sqlData[8])
		for k,v in pairs(gameList) do
			rInfo.gamelist:append(tonumber(k))
			rInfo.probabilitylist:append(tonumber(v))
		end
		
	end
	redisItem:setex(RosterModel.roster_info..userID, g_daySeconds*3 ,rInfo:SerializeToString(), RosterModel.redis_index)
	return rInfo
end


function RosterModel.GetRoster(userID, rInfo)
	
	if rInfo == nil then
		rInfo = st_user_pb.rosterinfo()
	end
	local strGet = redisItem:get(RosterModel.roster_info..userID, RosterModel.redis_index)
	if strGet ~= nil then
		rInfo:ParseFromString(strGet)
		return rInfo
	end
	
	return RosterModel.LoadRoster(userID, rInfo)
	
end


function RosterModel.CheckIsRoster(userID, gameType)   --检查单个用户是否是白名单，

	if RobotService.IsRobot(userID) then
		return 0
	end
	
	if true then
		return 0
	end
	
	local rInfo = RosterModel.GetRoster(userID)
	
	local curSec = TimeUtils.GetTime()
	
	if curSec < rInfo.starttime  or curSec > rInfo.endtime then
		return 0
	end
	
	for k,v in ipairs(rInfo.gamelist) do
		if v == gameType then
			local randNum = math.myrandom(1,100)
			if randNum <= rInfo.probabilitylist[k] then
				return rInfo.rostertype
			end
			
			return 0
		end
	end
	
	return 0
end


function RosterModel.GetHeiAndBai(userList, gameType)
	
	local heiList = {}
	local baiList = {}
	
	for k,v in ipairs(userList) do
		
		if g_rosterType.type_heimingdan == RosterModel.CheckIsRoster(v, gameType) then
			table.insert(heiList, v)
		elseif g_rosterType.type_baimingdan == RosterModel.CheckIsRoster(v, gameType) then
			table.insert(baiList, v)
		end
		
	end
	return heiList, baiList
end
]]
