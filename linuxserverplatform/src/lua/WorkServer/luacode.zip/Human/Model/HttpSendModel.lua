
--该model用于同步发送http协议。
--在管理后台端操作httpgame服务器的时候，通过该中转文件进行对应的中转

HttpSendModel = {}
  
HttpSendModel.redis_index = "redis_httpsend"

HttpSendModel.httpsend_lock = "httpsend"


HttpSendModel.httpsend_list = "httpsend_list"   --存放需要查询的Location


HttpSendModel.send_type = {}

HttpSendModel.send_type['msg'] = 101   --发送信令信息
HttpSendModel.send_type['notice'] = 102   --发送通知
HttpSendModel.send_type['kituser'] = 103   --发送通知

function HttpSendModel.GetListLen()
	local len = redisItem:llen(HttpSendModel.httpsend_list..g_processName, HttpSendModel.redis_index)
	return len == nil and 0 or tonumber(len)
end


function HttpSendModel.PushList(itemInfo)
	--推送到所有的服务器
	local sqlCase = "select processname from dy_servicelist where state=1"
	mysqlItem:executeQuery(sqlCase)
	
	while true do
		local sqlData = mysqlItem:fetch()
		if sqlData == nil then
			return 
		end
		
		redisItem:lpush( HttpSendModel.httpsend_list..sqlData, luajson.encode( itemInfo ),  HttpSendModel.redis_index)
	end
end


function HttpSendModel.SendJetton(userid)
	
	local sendItem = {}
	sendItem['userid'] = userid
	sendItem['type'] = HttpSendModel.send_type['msg']
	sendItem['data'] = "jetton"


	local sendList = {}
	table.insert( sendList, "jetton" )
	sendItem['data'] = luajson.encode( sendList )
	
	HttpSendModel.PushList(sendItem)
end

function HttpSendModel.SendBankJetton(userid)
	
	local sendItem = {}
	sendItem['userid'] = userid
	sendItem['type'] = HttpSendModel.send_type['msg']
	sendItem['data'] = "bank_jetton"


	local sendList = {}
	table.insert( sendList, "bank_jetton" )
	sendItem['data'] = luajson.encode( sendList )
	
	HttpSendModel.PushList(sendItem)
end

function HttpSendModel.SendMoney(userid)
	
	local sendItem = {}
	sendItem['userid'] = userid
	sendItem['type'] = HttpSendModel.send_type['msg']
	
	local sendList = {}
	table.insert( sendList, "money" )
	sendItem['data'] = luajson.encode( sendList )
	
	HttpSendModel.PushList(sendItem)
end

function HttpSendModel.SendData(userid,dataStr)
	
	local sendItem = {}
	sendItem['userid'] = userid
	sendItem['type'] = HttpSendModel.send_type['msg']
	sendItem['data'] = luajson.encode(dataStr)
	
	HttpSendModel.PushList(sendItem)
end
