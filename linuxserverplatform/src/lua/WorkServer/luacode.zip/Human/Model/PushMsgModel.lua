
PushMsgModel = {}
PushMsgModel.redis_index = "redis_pushmsg"

PushMsgModel.msg_list = "push_msg_list_"
PushMsgModel.once_msg_count = 100 -- 一次最多推送100条消息

-- msg 是 序列化之后的包
function PushMsgModel.PushMsg(userlogonid, userid, packid, len, msg)
	
	local sendmsg = st_user_pb.pushmessage()
	sendmsg.userid = userid
	sendmsg.packetID = packid
	sendmsg.buffLen = len
	sendmsg.content = msg
	
	redisItem:rpush(PushMsgModel.msg_list..userlogonid, sendmsg:SerializeToString(), PushMsgModel.redis_index)
end


-- 推送消息，建议每秒执行
function PushMsgModel.SendMsgLoop()
	
	for i=1,PushMsgModel.once_msg_count do
		local msg = redisItem:lpop(PushMsgModel.msg_list..g_logonid, PushMsgModel.redis_index)
		if msg == nil then
			return
		end
		
		local sendmsg = st_user_pb.pushmessage()
		sendmsg:ParseFromString(msg)
		
		SendMessage(sendmsg.userid, sendmsg.packetID, sendmsg.buffLen, sendmsg.content)
	end
	
end