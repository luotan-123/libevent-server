
AwardModel = {}
AwardModel.redis_index = "redis_award"

AwardModel.award_ach_list = "award_ach_list"   --开业的流水活动
AwardModel.login_time = "login_award_time"   --这是一个哈希列表, 记录每个玩家领取在线奖励最后的时间 登录奖励领取的时间

AwardModel.sign_info = "sign_award"   --登录奖励的列表
AwardModel.sign_time = "sign_award_time"   --这是一个哈希列表, 记录每个玩家领取在线奖励最后的时间 登录奖励领取的时间

AwardModel.exchange_user = "exchange_user"
AwardModel.exchange_code = "exchange_code"

function AwardModel.GetLoginAwardTime(userID)
	--获取用户在线奖励领取的最后的时间
	return redisItem:hget(AwardModel.login_time, userID, AwardModel.redis_index)
end

