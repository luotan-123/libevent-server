
TransferService = {}


function TransferService.ServerLoop()
    --每个服务器只发送一次
    local len = redisItem:llen(PlayerModel.userTransfer..g_processName, PlayerModel.redis_index )     
    if len > 0 then
        processWork("TransferWorker","")
    end

end
