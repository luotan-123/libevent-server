
PlayerStatsService = {}

function PlayerStatsService.GetTodayDate()
	local tab = {}
	local t1 = TimeUtils.GetTime()
	local ts = TimeUtils.GetTimeString(t1)
	tab.year = string.sub(ts, 1, 4)
	tab.month = string.sub(ts, 6, 7)
	tab.day = string.sub(ts, 9, 10)
	tab.hour = string.sub(ts, 12, 13)
	tab.min = string.sub(ts, 15, 16)
	tab.sec = string.sub(ts, 18, 19)
	tab.isdst = false
	
	return tab
end
function PlayerStatsService.ServerLoop()
    --0点清除玩家在线时长
    local dayCurSec =  math.modf(TimeUtils.GetDayCurrSec())
    if 0 == dayCurSec or dayCurSec == 86399 then
       PlayerModel.DelAllUserOneDayOnlineTimes()
    end

    local nowstamp = TimeUtils.GetTime()
    local hongbaostamp =  PlayerModel.getHongBaoYuTime()
    --luaPrint("hongbaostamp: "..hongbaostamp.." nowstamp: "..nowstamp)
    if hongbaostamp == nowstamp then
        processWork("NoticeHongBaoYu",hongbaostamp)
    end
    

    
end

--设置新手保护期
function PlayerStatsService.setNewPlayerPeriod(pInfo)
	
	local starttime = TimeUtils.GetTime()				--开始时间
	local endtime = starttime + (86400*3)			--结束时间
	PlayerModel.setNewPlayerTime(pInfo.userid, endtime)
	PlayerModel.setNewPlayerCount(pInfo.userid)
end

function PlayerStatsService.checkNewPlayerProtect(userid, gameType, tableType)
	
	local gameList = {}
	--[[gameList[g_DdzDefine.game_type] = {1,2}				--斗地主
	gameList[g_douNiuDefine.game_type] = {1,2}			--抢庄牛牛
	gameList[g_douNiuDefine.insanegame_type] = {1,2}	--激情牛牛
	gameList[g_douNiuDefine.kinggame_type] = {1,2}		--王者牛牛
	gameList[g_PszDefine.game_type] = {1,2}				--炸金花
	gameList[g_sangongDefine.game_type]	= {1}			--三公
	gameList[g_TexasDefine.game_type] = {1,2}			--德州
	gameList[g_TuiTongZiDefine.game_type] = {1,2}			--推筒子
	]]
	local isGame = false
	for gametype, tabletypeList in pairs(gameList)do
		if gametype == gameType then
			local isR = false
			for _, tabletype in ipairs(tabletypeList) do
				if tabletype == tableType then
					isR = true 
					isGame = true
					break 
				end
			end
			if isR == true then
				break
			end
		end
	end
	
	if isGame == false then
		return 
	end
	
	
	local date = PlayerModel.getNewPlayerTime(userid)
	if date == nil or date == 0 then
		return false
	end 
	local newDate = TimeUtils.GetTime()
	if newDate > date then
		PlayerModel.delNewPlayerTime(userid)
		PlayerModel.delNewPlayerCount(userid)
		return false
	end 
	
	local count = PlayerModel.getNewPlayerCount(userid)
	if count > 5000 then
		return false
	end
	
	local rNum = math.myrandom(1, 100)
	if rNum > 70 then
		return false
	end
	
	return true
end