AgencyCommissionService = {}

function AgencyCommissionService.ServerLoop()
	
	local CommissionList = AgencyModel.GetUserCommission()
	if CommissionList == nil then
		return
	end
	for k, v in pairs(CommissionList)do
		local iV = tonumber(v)
		local iK = tonumber(k)
		
		if iV > 0 then
			local tmpV = 0 - iV
			AgencyModel.StatisticsCommission(iK, tmpV)
			
			local sqlCase = "select * from ag_player where userid="..iK
			mysqlItem:executeQuery(sqlCase)
			
			local sqlData = mysqlItem:fetch({})
			if sqlData ~= nil then
				local sqlCase = "update ag_player set moneymark=moneymark+"..iV.." where userid="..iK
				mysqlItem:executeQuery(sqlCase)
			end
		end
	end
	
	local time = TimeUtils.GetDayMinutes()
	
	if time == 90 then
		local sqlCase = "select moneymark, agent1, agent2 from ag_player where moneymark>2"
		mysqlItem:executeQuery(sqlCase)
		
		local UserList = {}
		
		while true do 
			local sqlData = mysqlItem:fetch({})
			if sqlData == nil then
				break
			end
			local takemoney = sqlData[1] == nil and 0 or tonumber(sqlData[1])
			
			if takemoney > 2 then
				local agent1 = sqlData[2] == nil and 0 or tonumber(sqlData[2])
				if agent1 > 0 then
					local agent1Count = math.floor(takemoney * 0.3) 
					if UserList[agent1] == nil then
						UserList[agent1] = {}
						UserList[agent1][1] = 0 
						UserList[agent1][2] = 0 
					end
					UserList[agent1][1] = UserList[agent1][1] + agent1Count
				end
				
				local agent2 = sqlData[3] == nil and 0 or tonumber(sqlData[3])
				if agent2 > 0 then
					local agent2Count = math.floor(takemoney * 0.05) 
					if UserList[agent2] == nil then
						UserList[agent2] = {}
						UserList[agent2][1] = 0 
						UserList[agent2][2] = 0 
					end
					UserList[agent2][2] = UserList[agent2][2] + agent2Count
				end
				
			end
		end
		
		toSQL(UserList)
		local sqlCase = "update ag_player set takemoney=0 where takemoney>0"
		mysqlItem:executeQuery(sqlCase)
	end
end


function toSQL(UserList)

	for k, v in pairs(UserList)do 
		local sqlCase = "select agent1count, agent2count from ag_player where userid="..k
		mysqlItem:executeQuery(sqlCase)
		local sqlData = mysqlItem:fetch({})
		if sqlData ~= nil then
			local agent1count = sqlData[1] == nil and 0 or tonumber(sqlData[1])
			agent1count = agent1count + v[1]
			
			local agent2count = sqlData[2] == nil and 0 or tonumber(sqlData[2])
			agent2count = agent2count + v[2]
			
			local sqlCase = "update ag_player set agent1count="..agent1count..", agent2count="..agent2count.." where userid="..k
			mysqlItem:executeQuery(sqlCase)
		end
	end
end





--改函数在Utils实例中调用，每天凌晨四点钟调用一次，
--统计今天抽水大于10元的用户，进行代理抽佣分成。
--如果抽水总额不超过10元的，那么计算到下一个循环里面去。
--在初始化的时候也需要检查一下是否已经初始化。
function AgencyCommissionService.DayCheck(tm, isInit)

	if isInit == nil or tm.hour ~= 4 or tm.min > 10 then
		--只是在凌晨四点的时候会统计
		return
	end
	
	
	local dateSec = AgencyModel.GetAgencyDaymark()
	
	local checkTm = TimeUtils.GetTableTime(dateSec)
	
	if checkTm.day == tm.day then
		--如果今天已经检查过了，就不需要了。
		return
	end
	
	
	--不能放在这里去同步。
	
	processWork("AgencyDayCheck", dateSec)  --发送到worker线程处理
	
	
end

