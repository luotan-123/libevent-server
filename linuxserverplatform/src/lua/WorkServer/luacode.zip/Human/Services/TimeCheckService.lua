
TimeCheckService = {}

function TimeCheckService.ServerLoop()
	local currMin = g_markTime.curr.min
	local lastMin = g_markTime.last.min

	if lastMin ~= currMin then  --调试，暂时设置一分钟
		--一分钟的判断
		
		
	end
	
	if 0 == math.mod(currMin, 10) and 9==math.mod(lastMin,10) then
		--这里表示是十分钟循环的一个判断
	end
	
	if 0 == math.mod(currMin,30) and 29 == math.mod(lastMin,29) then
	--if lastMin ~= currMin then  --调试，暂时设置一分钟
		--这里是半个小时一个循环的判断
	end
	
	if 0 == currMin and 59 == lastMin then
		--这里是一个小时的判断
	end
	


end

function TimeCheckService.PlayerUpdateMinutes()
	--每一分钟更新。然后把玩家的数据同步到数据库
	
	
	local userList = redisItem:hkeys(PlayerModel.player_update, PlayerModel.redis_index)
	redisItem:del(PlayerModel.player_update, PlayerModel.redis_index)  --用完后立马删掉
	
	if #userList ~= 0  then
		local getAll =  redisItem:hmget(PlayerModel.player_jetton, userList, PlayerModel.redis_index)
		for k_all, v_all in pairs(getAll) do
			local sqlCase = "update dy_player set jetton="..v_all.." where userid="..userList[k_all]  --用户ID从这里面过来
			mysqlItem:execute(sqlCase)
		end
	end

	local usergamejettonList = redisItem:hkeys(PlayerModel.gameplayer_update, PlayerModel.redis_index)
	redisItem:del(PlayerModel.gameplayer_update, PlayerModel.redis_index)  --用完后立马删掉
	
	if #usergamejettonList ~= 0  then
		local getAll =  redisItem:hmget(PlayerModel.player_gamejetton, usergamejettonList, PlayerModel.redis_index)
		for k_all, v_all in pairs(getAll) do
			local sqlCase = "update dy_player set gamejetton="..v_all.." where userid="..usergamejettonList[k_all]  --用户ID从这里面过来
			mysqlItem:execute(sqlCase)
		end
	end
    --彩票币
    local usercpjettonList = redisItem:hkeys(PlayerModel.cpplayer_update, PlayerModel.redis_index)
	redisItem:del(PlayerModel.cpplayer_update, PlayerModel.redis_index)  --用完后立马删掉
	
	if #usercpjettonList ~= 0  then
		local getAll =  redisItem:hmget(PlayerModel.player_cpjetton, usercpjettonList, PlayerModel.redis_index)
		for k_all, v_all in pairs(getAll) do
			local sqlCase = "update dy_player set cpjetton="..v_all.." where userid="..usercpjettonList[k_all]  --用户ID从这里面过来
			mysqlItem:execute(sqlCase)
		end
	end

end

--用于检测是否需要发送通知信令给客户端
function TimeCheckService.HttpSendLoop()
	if HttpSendModel.GetListLen() > 0 then
		
		processWork( "HttpSendExecute", "httpsend" )
	end		
end