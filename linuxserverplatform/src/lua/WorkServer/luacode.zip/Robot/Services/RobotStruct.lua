
RobotStruct = class("RobotStruct")

function RobotStruct:ctor()
	
	self.m_userID = 0
	self.m_state = 0
	self.m_screen = 0   --在哪个场景中
	self.m_count = 0    --机器人的统计
	self.m_timeMark = 0 --上去的时间
	self.m_jetton = 0
end

function RobotStruct:SetUserID(userID)
	self.m_userID = userID
end

function RobotStruct:SetJetton(jetton)
	self.m_jetton = tonumber(jetton)
end

return RobotStruct


