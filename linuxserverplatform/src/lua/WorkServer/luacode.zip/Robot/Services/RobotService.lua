
--该类是专门为机器人提供服务器的类
--目前来说，就欢乐赢豆和欢乐竞技场两个地方需要机器人上庄

RobotService = {}

function RobotService.Init()
	
	RobotModel.Init()

end

function RobotService.GetFreeRobot(gametype, startJetton, endJetton) --


	
	startJetton = startJetton == nil and 100000 or startJetton
	endJetton = endJetton == nil and 1000000 or endJetton
	
	
	local robotArray = RobotModel.GetArray(startJetton, endJetton)

	if #robotArray ~= 0 then
		
		local randNum = math.myrandom(1,#robotArray)
		for i = randNum,#robotArray do
			
			if nil ~= RobotModel.IsRemove( robotArray[i] ) then
				RobotModel.SetBusy(robotArray[i])
				return tonumber(robotArray[i])
			end
			
		end
		
	else
		robotArray = RobotModel.GetAllFree()
		if #robotArray ~= 0 then
			local randNum = math.myrandom(1,#robotArray)
			
			for i = randNum, #robotArray do
				if nil ~= RobotModel.IsRemove( robotArray[i] ) then
					
					--移除已经成功
					RobotModel.SetBusy(robotArray[i])
					
					local userJetton = PlayerModel.GetJettonFromRedis(robotArray[i])
					if userJetton < startJetton then
						userJetton = userJetton + startJetton
						PlayerModel.AddJettonByUserID(robotArray[i], startJetton, "robot", "没找到区间机器人")
						--LogBehavior.InfoJetton(robotArray[i], "robot", "robot add money", 0, "机器人添加:金币"..(startJetton/100)..".00个", (startJetton/100)..".00", userJetton)
					end
					return tonumber(robotArray[i])
				end				
			end
			

			
		end
	end

	return nil
end

function RobotService.RobotRelease(gametype, userID)
	if false == RobotService.IsRobot(userID) then
		return nil
	end

	local userJetton = PlayerModel.GetJettonFromRedis(userID)
	
	if userJetton < 1000 then
		--如果机器人少于100,那么就需要增加金币。
		
		local addList = {1000,2000,5000,10000,20000,30000,50000}
		
		local getRand = math.myrandom(1,#addList) 
		local jettonAdd = addList[getRand] + (userJetton > 0 and 0 or (0 - userJetton))
		PlayerModel.AddJettonByUserID(userID, jettonAdd,"robot", "add jetton")
		
		
		
		userJetton = userJetton + jettonAdd
		
		--LogBehavior.InfoJetton(userID, "robot", "robot add money", 0, "机器人添加:金币"..(jettonAdd/100)..".00个", (jettonAdd/100)..".00", userJetton)
	
	elseif userJetton >= 1000000 then
		local jettonDec = 0
		local tempJetton = userJetton
		--[[
		if userJetton > 50000000 then
			tempJetton = math.mod(userJetton, 100000)
			tempJetton = tempJetton < 100 and (tempJetton + 10000) or tempJetton   --如果整除后的金币小于100个金币，那么就需要补充金币了
		else
			local getList = RobotModel.GetArray(5000000, 10000000)
			
			if #getList >= 20 then
				--允许当庄家的人，不超过20个。
				tempJetton = math.mod(userJetton, 100000)
				tempJetton = tempJetton < 100 and (tempJetton + 10000) or tempJetton   --如果整除后的金币小于100个金币，那么就需要补充金币了
			else
				--这里是需要扣除当庄家的
				tempJetton = math.mod(userJetton, 10000000)
				tempJetton = tempJetton < 1000000 and (tempJetton + 2000000) or tempJetton   --如果庄家的金币少于100万，那么就补充200万
			
			end
		end
		]]
		
		for i = 1,10 do
			tempJetton = math.floor(tempJetton / 10)
			if tempJetton < 1000000 then
				break
			end
		end
		
		jettonDec = userJetton - tempJetton
		userJetton = tempJetton		
		PlayerModel.DecJettonByUserID(userID, jettonDec, "robot", "jetton to maney")

		--LogBehavior.InfoJetton(userID, "robot", "robot dec money", 0, "机器人减少:金币"..(jettonDec/100)..".00个", (jettonDec/100)..".00", userJetton)			
	end
	
	RobotModel.SetFree(userID, userJetton)
	return true
end

--初始化的时候，有一部分机器人已经是busy状态
function RobotService.InitBusy(userID)

	
	RobotModel.SetBusy(userID)
	
end

function RobotService.IsRobot(userID)
	if userID == nil then
		return false
	end
	return RobotModel.IsExsit(userID)
end

function RobotService.ModifyJiangChi(jetton)
	--修改机器人的奖池	
	RobotModel.ModifyJiangChi(jetton)
end


function RobotService.PrintFree()
	local List =  RobotModel.GetAllFree()
	local BuseList = RobotModel.GetAllBusy()
	local All = #List + #BuseList
	
end

function RobotService.FreeLog()
	local List =  RobotModel.GetAllFree()
	local BuseList = RobotModel.GetAllBusy()
	local All = #List + #BuseList
	LogFile("robot", "free="..#List..", busy="..#BuseList..",all="..All)
end


function RobotService.GetJulebuFreeRobot(julebuid, startJetton, endJetton) --
	
	startJetton = startJetton == nil and 100000 or startJetton
	endJetton = endJetton == nil and 1000000 or endJetton
	
	local okList = {}
	local robotList = JulebuModel.getJulebuRobotList(julebuid)
	if robotList ~= nil then
		for k,v in pairs(robotList)do 
			if startJetton <= tonumber(v) and endJetton >= tonumber(v) then
				local tmp = {}
				tmp.userid = tonumber(k)
				tmp.jetton = tonumber(v)
				table.insert(okList, tmp)
			end
		end	
	end
	for _, v in ipairs(okList) do 
		local ret = redisItem:zrem(RobotModel.robot_free, v.userid, RobotModel.redis_index)
		if ret == 1 then
			redisItem:sadd(RobotModel.robot_busy, v.userid, RobotModel.redis_index)
			local pInfo = PlayerModel.GetPlayerInfo(v.userid) 
			local diffJetton = tonumber(v.jetton) - tonumber(pInfo.jetton)
			if diffJetton > 0 then
				PlayerModel.AddJetton(pInfo, diffJetton, "robot", "robot")
			elseif diffJetton < 0 then
				diffJetton = math.abs(diffJetton)
				PlayerModel.DecJetton(pInfo, diffJetton, "robot", "robot")
			end
			PlayerModel.SetPlayerInfo(pInfo)
			return v.userid
		end
	end

	return nil
end

function RobotService.JulebudRobotRelease(julebuid, userID)
	
	if false == RobotService.IsRobot(userID) then
		return nil
	end
	
	--保存俱乐部机器人金币
	local robotList = JulebuModel.getJulebuRobotList(julebuid)
	if robotList ~= nil then
		local sqlCase = "select robotlist from dy_julebu where id="..julebuid
		local tmpRobotlist = {}
		mysqlItem:executeQuery(sqlCase)
		local sqlData = mysqlItem:fetch()
		if sqlData ~= nil then
			tmpRobotlist = luajson.decode(sqlData)
		end
		
		for userid, jetton in pairs(robotList)do  
			if userID == tonumber(userid) then
				local pInfo = PlayerModel.GetPlayerInfo(userID)
				local diffJetton = tonumber(pInfo.jetton) - tonumber(jetton)
				for i = 1, #tmpRobotlist do 
					if tonumber(tmpRobotlist[i].userid) == userID then
						tmpRobotlist[i].jetton = JulebuModel.setJulebuRobotList(julebuid, userID, diffJetton)
					end
				end
				local sqlCase = "update dy_julebu set robotlist='"..luajson.encode(tmpRobotlist).."' where id="..julebuid
				mysqlItem:execute(sqlCase)
				break
			end
		end	
	end

	local userJetton = PlayerModel.GetJettonFromRedis(userID)
	if userJetton < 1000 then
		--如果机器人少于100,那么就需要增加金币。
		
		local addList = {1000,2000,5000,10000,20000,30000,50000}
		
		local getRand = math.myrandom(1,#addList) 
		local jettonAdd = addList[getRand] + (userJetton > 0 and 0 or (0 - userJetton))
		PlayerModel.AddJettonByUserID(userID, jettonAdd,"robot", "add jetton")
		
		
		
		userJetton = userJetton + jettonAdd
	elseif userJetton >= 1000000 then
		local jettonDec = 0
		local tempJetton = userJetton
		
		for i = 1,10 do
			tempJetton = math.floor(tempJetton / 10)
			if tempJetton < 1000000 then
				break
			end
		end
		
		jettonDec = userJetton - tempJetton
		userJetton = tempJetton		
		PlayerModel.DecJettonByUserID(userID, jettonDec, "robot", "jetton to maney")			
	end
	
	RobotModel.SetFree(userID, userJetton)
	return true
end