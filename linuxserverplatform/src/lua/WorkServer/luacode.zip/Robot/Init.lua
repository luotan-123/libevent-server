
require("Robot.Model.RobotModel")
require("Robot.Services.RobotService")
require("Robot.Services.RobotStruct")
require("Robot.RobotDefine")



g_redisIndex[RobotModel.redis_index] = {index = g_redisInfo.redis_three, des = "robot", link = 0}