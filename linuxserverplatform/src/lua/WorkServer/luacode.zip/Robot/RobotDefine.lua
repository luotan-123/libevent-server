

g_robotState = {}       --机器人的状态
g_robotState.state_free = 0  --空闲状态
g_robotState.state_busy = 1  --已经被使用了