
--目前针对欢乐赢豆和欢乐竞技场中做机器人的匹配

--目前安排20个机器人上去坐庄，机器人必须是真正的ID玩家，不能够是以前的方式的机器了，我们后面固定一批号是机器人的号
--配置机器人的业务员逻辑。
--1.机器人分为两个断，1~100一个断， 

RobotModel = {}

RobotModel.robot_jiangchi = "robot_jiangchi"
RobotModel.redis_index = "redis_robot"
RobotModel.robot_list = "robot_list"   --主要用于给其他的线程判断是否是机器人用的
RobotModel.robot_free = "robot_free"   --有序集合，userID + jetton
RobotModel.robot_busy = "robot_busy"   


function RobotModel.RetSetFaceID()   --调用该函数重置机器人的头像
	--
	--
	local sqlCase = "select `userID`,`sex` from `dy_player` where `isrobot`=1 limit 2000"
	mysqlItem:executeQuery(sqlCase)
	local retList = {}
	local userList = {}
	
	while true do
		local sqlData = mysqlItem:fetch({})
		if sqlData == nil then
			break
		end
		local addItem = {}
		addItem[1] = tonumber(sqlData[1])
		addItem[2] = tonumber(sqlData[2])
		table.insert(userList,addItem)
	end	
	local boyList = {'81001_1001','81002_1001','81003_1001','81004_1001','81005_1001','81006_1001','81007_1001','81008_1001','81009_1001','81010_1001','81011_1001','81012_1001',
					'81013_1001','81014_1001','81015_1001','81016_1001','81017_1001','81018_1001','81019_1001','81020_1001'}
	local girlList = {'82001_1001','82002_1001','82003_1001','82004_1001','82005_1001','82006_1001','82007_1001','82008_1001','82009_1001','82010_1001','82011_1001','82012_1001',
					'82013_1001','82014_1001','82015_1001','82016_1001','82017_1001','82018_1001','82019_1001','82020_1001'}					
	local neutralList = {'83001_1001','83002_1001','83003_1001','83004_1001','83005_1001','83006_1001','83007_1001','83008_1001','83009_1001','83010_1001','83011_1001','83012_1001',
					'83013_1001','83014_1001','83015_1001','83016_1001','83017_1001','83018_1001'}
	for k,v in ipairs(userList) do
		local faceID
		
		if v[2] == 1 then
			local indexNum = math.myrandom(1,#boyList)
			
			faceID = boyList[indexNum]
		elseif v[2] == 2 then
			local indexNum = math.myrandom(1,#girlList)
			
			faceID = girlList[indexNum]
		else
			local indexNum = math.myrandom(1,#neutralList)
			
			faceID = neutralList[indexNum]			
		end
		
		sqlCase ="update dy_player set face_1='"..faceID.."' where userid="..v[1] 
		mysqlItem:execute(sqlCase)
	end
		
end



function RobotModel.Init()
	--加载机器人进来
	--首先，检查数据库中，存不存在机器人的奖池
	redisItem:del(RobotModel.robot_free, RobotModel.redis_index)
	--redisItem:del(RobotModel.robot_list, RobotModel.redis_index)
	local sqlCase = "select jiangjetton from dy_pond where gametype="..g_system.robot_pond_type
	mysqlItem:executeQuery(sqlCase)
	local sqlData = mysqlItem:fetch()
	if sqlData == nil then
		sqlCase = "insert dy_pond(gametype) values("..g_system.robot_pond_type..")"
		mysqlItem:execute(sqlCase)
		RobotModel.ModifyJiangChi(0)
	else
		redisItem:set(RobotModel.robot_jiangchi, sqlData, RobotModel.redis_index)
	end
	
	sqlCase = "select `userID`,`jetton` from `dy_player` where `isrobot`=1 limit 2000"
	mysqlItem:executeQuery(sqlCase)
	local retList = {}
	local userList = {}
	
	while true do
		local sqlData = mysqlItem:fetch({})
		if sqlData == nil then
			break
		end
		--table.insert(userList,tonumber(sqlData[1]))
		--redisItem:zadd(RobotModel.robot_free, sqlData[2], sqlData[1], RobotModel.redis_index)
		redisItem:hset(RobotModel.robot_list, sqlData[1], 1, RobotModel.redis_index)
		
		if false == RobotModel.IsBusy( sqlData[1] ) then
			RobotModel.SetFree( sqlData[1], sqlData[2])
		end
	end

	return retList
end

function RobotModel.IsExsit(userID)
	return redisItem:hexists(RobotModel.robot_list, userID, RobotModel.redis_index)
end

function RobotModel.CreateItem(userID)
	
	local rItem = RobotStruct.new()
	rItem:SetUserID(userID)
	return rItem
end

function RobotModel.ModifyJiangChi(jetton)


end


function RobotModel.SetBusy(userID)
	
	redisItem:zrem(RobotModel.robot_free, userID, RobotModel.redis_index)
	redisItem:sadd(RobotModel.robot_busy, userID, RobotModel.redis_index)
end

function RobotModel.SetFree(userID, jetton)
	redisItem:srem(RobotModel.robot_busy, userID, RobotModel.redis_index)
	redisItem:zadd(RobotModel.robot_free, jetton, userID, RobotModel.redis_index)
end

function RobotModel.IsBusy(userID)
	return redisItem:sismember( RobotModel.robot_busy, userID, RobotModel.redis_index)
end

function RobotModel.GetArray(startJetton, endJetton)
	return redisItem:zrangebyscore( RobotModel.robot_free, startJetton, endJetton, RobotModel.redis_index )
end

function RobotModel.GetAllFree()
	return redisItem:zrange( RobotModel.robot_free, 1, -1, RobotModel.redis_index)
end

function RobotModel.GetAllBusy()
	return redisItem:smembers( RobotModel.robot_busy, RobotModel.redis_index)
end

function RobotModel.IsRemove(userID)
	return redisItem:zrem( RobotModel.robot_free, userID,  RobotModel.redis_index)
end


