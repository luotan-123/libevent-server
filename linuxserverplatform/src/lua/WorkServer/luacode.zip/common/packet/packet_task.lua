--9000~9100 任务
PacketCode[9001] = {server = 9001, client = 9002, des = "cgtaskcenter", func = "TaskCenter"}
PacketCode[9002] = {server = 9001, client = 9002, des = "gctaskcenter", func = "TaskCenter"}
  
 --专门 绑定手机任务领取          
PacketCode[9003] = {server = 9003, client = 9004, des = "cgchecktask", func = "TaskDetail"}
PacketCode[9004] = {server = 9003, client = 9004, des = "gcchecktask", func = "TaskDetail"}


ReturnCode["task_unexist"] = 9001
ReturnCode[9001] = "任务不存在"

ReturnCode["task_awards_has_done"] = 9002
ReturnCode[9002] = "您已领取过任务奖励了"

ReturnCode["task_awards_error1"] = 9003
ReturnCode[9003] = "奖励失效"