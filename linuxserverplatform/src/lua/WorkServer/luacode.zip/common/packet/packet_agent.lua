
--1000~1100 是人物信息的ID区间
PacketCode[1301] = {server = 1301, client = 1302, des = "cggetagentinfo", func = "GetAgenctInfo"}
PacketCode[1302] = {server = 1301, client = 1302, des = "gcgetagentinfo", func = "GetAgenctInfo"}

PacketCode[1303] = {server = 1303, client = 1304, des = "cgagentopt", func = "AgenctOpt"}
PacketCode[1304] = {server = 1303, client = 1304, des = "gcagentopt", func = "AgenctOpt"}

PacketCode[1305] = {server = 1305, client = 1306, des = "cginvitebind", func = "InviteBind"}
PacketCode[1306] = {server = 1305, client = 1306, des = "gcinvitebind", func = "InviteBind"}


PacketCode[1307] = {server = 1307, client = 1308, des = "cggetagentincome", func = "GetAgentIncome"}
PacketCode[1308] = {server = 1307, client = 1308, des = "gcgetagentincome", func = "GetAgentIncome"}


PacketCode[1321] = {server = 1321, client = 1322, des = "cggetwiringinfo", func = "GetWiringInfo"}
PacketCode[1322] = {server = 1321, client = 1322, des = "gcgetwiringinfo", func = "GetWiringInfo"}

PacketCode[1323] = {server = 1323, client = 1324, des = "cggetwiringlist", func = "GetWiringList"}
PacketCode[1324] = {server = 1323, client = 1324, des = "gcgetwiringlist", func = "GetWiringList"}

PacketCode[1325] = {server = 1325, client = 1326, des = "cgwiringachievement", func = "WiringAchievement"}
PacketCode[1326] = {server = 1325, client = 1326, des = "gcwiringachievement", func = "WiringAchievement"}

PacketCode[1327] = {server = 1327, client = 1328, des = "cgwiringawardlist", func = "WiringAwardList"}
PacketCode[1328] = {server = 1327, client = 1328, des = "gcwiringawardlist", func = "WiringAwardList"}

PacketCode[1329] = {server = 1329, client = 1330, des = "cgwiringwithdraw", func = "WiringWithDraw"}
PacketCode[1330] = {server = 1329, client = 1330, des = "gcwiringwithdraw", func = "WiringWithDraw"}

PacketCode[1331] = {server = 1331, client = 1332, des = "cgwiringuserlist", func = "WiringUserList"}
PacketCode[1332] = {server = 1331, client = 1332, des = "gcwiringuserlist", func = "WiringUserList"}


PacketCode[1333] = {server = 1333, client = 1334, des = "cgcreatewiring", func = "CreateWiring"}
PacketCode[1334] = {server = 1333, client = 1334, des = "gccreatewiring", func = "CreateWiring"}

PacketCode[1335] = {server = 1335, client = 1336, des = "cgwiringdrawmoney", func = "WiringDrawMoney"}
PacketCode[1336] = {server = 1335, client = 1336, des = "gcwiringdrawmoney", func = "WiringDrawMoney"}

PacketCode[1337] = {server = 1337, client = 1338, des = "cgwiringappointmentwithdraw", func = "WiringAppointmentWithDraw"}
PacketCode[1338] = {server = 1337, client = 1338, des = "gcwiringappointmentwithdraw", func = "WiringAppointmentWithDraw"}

--下级查询
PacketCode[1339] = {server = 1339, client = 1340, des = "cgsubordinatecheck", func = "SubordinateCheck"}
PacketCode[1340] = {server = 1339, client = 1340, des = "gcsubordinatecheck", func = "SubordinateCheck"}

--设置下级保底
PacketCode[1341] = {server = 1341, client = 1342, des = "cgagentsetratenum", func = "AgentSetRateNum"}
PacketCode[1342] = {server = 1341, client = 1342, des = "gcagentsetratenum", func = "AgentSetRateNum"}

--获取分成的每日记录
PacketCode[1343] = {server = 1343, client = 1344, des = "cgfenchengdayinfo", func = "FenChengDayInfo"}
PacketCode[1344] = {server = 1343, client = 1344, des = "gcfenchengdayinfo", func = "FenChengDayInfo"}

--获取分成的每周记录
PacketCode[1345] = {server = 1345, client = 1346, des = "cgfenchengweeklist", func = "FenChengWeekList"}
PacketCode[1346] = {server = 1345, client = 1346, des = "gcfenchengweeklist", func = "FenChengWeekList"}

--获取3及代理信息
PacketCode[1347] = {server = 1347, client = 1348, des = "cggetpumpagentinfo", func = "GetPumpAgentInfo"}
PacketCode[1348] = {server = 1347, client = 1348, des = "gcgetpumpagentinfo", func = "GetPumpAgentInfo"}

--获取推广明细
PacketCode[1349] = {server = 1349, client = 1350, des = "cggetagentpromoteinfo", func = "GetAgentPromoteInfo"}
PacketCode[1350] = {server = 1349, client = 1350, des = "gcgetagentpromoteinfo", func = "GetAgentPromoteInfo"}

--获取推广排行
PacketCode[1351] = {server = 1351, client = 1352, des = "cggetagentpromoterank", func = "GetAgentPromoteRank"}
PacketCode[1352] = {server = 1351, client = 1352, des = "gcgetagentpromoterank", func = "GetAgentPromoteRank"}

--全民足球代理
--我的战绩
PacketCode[1353] = {server = 1353, client = 1354, des = "cggetnationalagentinfo", func = "GetNationalAgentInfo"}
PacketCode[1354] = {server = 1353, client = 1354, des = "gcgetnationalagentinfo", func = "GetNationalAgentInfo"}

--我的战队
PacketCode[1355] = {server = 1355, client = 1356, des = "cgnationalwiringuserlist", func = "NationalWiringUserList"}
PacketCode[1356] = {server = 1355, client = 1356, des = "gcnationalwiringuserlist", func = "NationalWiringUserList"}

--直属玩家详情
PacketCode[1357] = {server = 1357, client = 1358, des = "cggetnationaldiruserinfo", func = "GetNationalDirUserInfo"}
PacketCode[1358] = {server = 1357, client = 1358, des = "gcgetnationaldiruserinfo", func = "GetNationalDirUserInfo"}

--返佣历史
PacketCode[1359] = {server = 1359, client = 1360, des = "cgnationalincomehis", func = "NationalIncomeHis"}
PacketCode[1360] = {server = 1359, client = 1360, des = "gcnationalincomehis", func = "NationalIncomeHis"}


ReturnCode["hlyd_share_fail"] = 1201
ReturnCode["rep_error"] = 1202
ReturnCode["draw_error"] = 1203
ReturnCode["rep_error_1"] = 1204
ReturnCode["draw_error_1"] = 1205
ReturnCode["check_error_1"] = 1206
ReturnCode["check_error_2"] = 1207


ReturnCode[1201] = "分享失败"
ReturnCode[1202] = "可预提金额不住！"
ReturnCode[1203] = "可提金额不住！"
ReturnCode[1204] = "提现失败！"
ReturnCode[1205] = "预提失败！"
ReturnCode[1206] = "查找不到该玩家！"
ReturnCode[1207] = "该玩家为你自己本身！"


ReturnCode["agent_set_max"] = 1208
ReturnCode[1208] = "返点超过最大限制"

ReturnCode["agent_pre_error1"] = 1209
ReturnCode[1209] = "下级返点必须小于您的返点"

ReturnCode["agent_pre_error"] = 1210
ReturnCode[1210] = "返点不允许下降"

ReturnCode["agent_set_error"] = 1211
ReturnCode[1211] = "设置失败"

ReturnCode["bind_pre_not_agent"] = 1212
ReturnCode[1212] = "请绑定代理的邀请码"

ReturnCode["agent_pre_error2"] = 1213
ReturnCode[1213] = "返点极差为2"

ReturnCode["agent_pre_error3"] = 1214
ReturnCode[1214] = "返点小于下限"