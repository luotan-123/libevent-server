--7800~7899 是彩票龙虎斗的玩法
--进入游戏
PacketCode[7801] = {server = 7801, client = 7802, des = "cgcplhdenter", func = "CpLhdEnter"}
PacketCode[7802] = {server = 7801, client = 7802, des = "gccplhdenter", func = "CpLhdEnter"}

--离开游戏
PacketCode[7803] = {server = 7803, client = 7804, des = "cgcplhdleave", func = "CpLhdLeave"}
PacketCode[7804] = {server = 7803, client = 7804, des = "gccplhdleave", func = "CpLhdLeave"}

--开始游戏
PacketCode[7806] = {server = 7805, client = 7806, des = "gccplhdstart", func = "CpLhdStart"}

--下注
PacketCode[7807] = {server = 7807, client = 7808, des = "cgcplhdpourjetton", func = "CpLhdPourJetton"}
PacketCode[7808] = {server = 7807, client = 7808, des = "gccplhdpourjetton", func = "CpLhdPourJetton"}

--更新各个区域的下注情况
PacketCode[7810] = {server = 7809, client = 7810, des = "gccplhdgroupjetton", func = "CpLhdGroupJetton"}

--获取开奖结果
PacketCode[7812] = {server = 7811, client = 7812, des = "gccplhdgetawardresult", func = "CpLhdGetAwardResul"}

--结算
PacketCode[7814] = {server = 7813, client = 7814, des = "gccplhdcount", func = "CpLhdCount"}

--上庄
PacketCode[7815] = {server = 7815, client = 7816, des = "cgcplhdbeingbanker", func = "CpLhdBeingBanker"}
PacketCode[7816] = {server = 7815, client = 7816, des = "gccplhdbeingbanker", func = "CpLhdBeingBanker"}

--下庄
PacketCode[7817] = {server = 7817, client = 7818, des = "cgcplhddropbanker", func = "CpLhdDropBanker"}
PacketCode[7818] = {server = 7817, client = 7818, des = "gccplhddropbanker", func = "CpLhdDropBanker"}

--游戏记录
PacketCode[7819] = {server = 7819, client = 7820, des = "cgcplhdhistory", func = "CpLhdHistory"}
PacketCode[7820] = {server = 7819, client = 7820, des = "gccplhdhistory", func = "CpLhdHistory"}

--聊天
PacketCode[7821] = {server = 7821, client = 7822, des = "cgcplhdchat", func = "CpLhdChat"}
PacketCode[7822] = {server = 7821, client = 7822, des = "gccplhdchat", func = "CpLhdChat"}

--上庄列表
PacketCode[7823] = {server = 7823, client = 7824, des = "cgcplhdbankerlist", func = "CpLhdBankerList"}
PacketCode[7824] = {server = 7823, client = 7824, des = "gccplhdbankerlist", func = "CpLhdBankerList"}

--投注记录
PacketCode[7825] = {server = 7825, client = 7826, des = "cgcplhdbetrecord", func = "CpLhdBetRecord"}
PacketCode[7826] = {server = 7825, client = 7826, des = "gccplhdbetrecord", func = "CpLhdBetRecord"}

--开奖记录
PacketCode[7827] = {server = 7827, client = 7828, des = "cgcplhdawardrecord", func = "CpLhdAwardRecord"}
PacketCode[7828] = {server = 7827, client = 7828, des = "gccplhdawardrecord", func = "CpLhdAwardRecord"}

--获取站立的列表信息
PacketCode[7829] = {server = 7829, client = 7830, des = "cgcplhdstandlist", func = "CpLhdStandList"}
PacketCode[7830] = {server = 7829, client = 7830, des = "gccplhdstandlist", func = "CpLhdStandList"}



--游戏错误码
ReturnCode["cplhd_not_exist"] = 7801
ReturnCode[7801] = "该牌桌不存在"

ReturnCode["cplhd_state_notpour"] = 7802
ReturnCode[7802] = "请稍后再下注"

ReturnCode["cplhd_jetton_notenough"] = 7803
ReturnCode[7803] = "您的余额不足"

ReturnCode["cplhd_pourtype_error"] = 7804
ReturnCode[7804] = "下注失败，请选择正确的下注区域"

ReturnCode["cplhd_behanker_list"] = 7805
ReturnCode[7805] = "已加入上庄列表"

ReturnCode["cplhd_pour_banker"] = 7806
ReturnCode[7806] = "庄家不能下注"

ReturnCode["cplhd_banker_notenough"] = 7807
ReturnCode[7807] = "金币不足，最低上庄需要1000金币"

ReturnCode["cplhd_pour_lose"] = 7808
ReturnCode[7808] = "已达下注上限，下注失败"

ReturnCode["cplhd_is_full"] = 7809
ReturnCode[7809] = "该牌桌人数已满，请选择其他牌桌"

ReturnCode["cplhd_is_bankerlist"] = 7810
ReturnCode[7810] = "您已经加入上庄列表中，请耐心等着"

ReturnCode["cplhd_jetton_error_1"] = 7811
ReturnCode[7811] = "金币不足，无法进入房间"

ReturnCode["cplhd_jetton_error_2"] = 7812  --金币太多，无法进人房间
ReturnCode[7812] = "金币太多，无法进入房间"

ReturnCode["cplhd_not_banker"] = 7813 
ReturnCode[7813] = "您还不是庄家呢"  

ReturnCode["cplhd_is_drop"] = 7814
ReturnCode[7814] = "您已经申请下庄了"  

ReturnCode["cplhd_drop_success"] = 7815
ReturnCode[7815] = "申请下庄成功"  

ReturnCode["cplhd_bebankeer_success"] = 7816
ReturnCode[7816] = "申请上庄成功"  

ReturnCode["cplhd_pour_max"] = 7817
ReturnCode[7817] = "已经超过下注限额，请选择更小的面值"  

ReturnCode["cplhd_banker_leave"] = 7818
ReturnCode[7818] = "请先下庄，再离开游戏"  

ReturnCode["cplhd_bankerlist_dorp"] = 7819
ReturnCode[7819] = "已经离开的申请上庄列表"  

ReturnCode["cplhd_is_pour"] = 7820
ReturnCode[7820] = "您已下注，请结算后离开"  

ReturnCode["cplhd_limitred"] = 7821
ReturnCode[7821] = "该区域已超过限红，请下别的区域！"  

ReturnCode["cplhd_banker_jetton"] = 7822
ReturnCode[7822] = "该区域已超过庄家可赔额度，请下别的区域！"  

ReturnCode["cplhd_nobanker_pourerr"] = 7823
ReturnCode[7823] = "无庄的时候不能下和！"  
