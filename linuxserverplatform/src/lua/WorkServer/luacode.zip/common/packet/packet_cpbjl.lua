--7900~7999 是彩票百家乐的玩法
--进入游戏
PacketCode[7901] = {server = 7901, client = 7902, des = "cgcpbjlenter", func = "CpBjlEnter"}
PacketCode[7902] = {server = 7901, client = 7902, des = "gccpbjlenter", func = "CpBjlEnter"}

--离开游戏
PacketCode[7903] = {server = 7903, client = 7904, des = "cgcpbjlleave", func = "CpBjlLeave"}
PacketCode[7904] = {server = 7903, client = 7904, des = "gccpbjlleave", func = "CpBjlLeave"}

--开始游戏
PacketCode[7906] = {server = 7905, client = 7906, des = "gccpbjlstart", func = "CpBjlStart"}

--下注
PacketCode[7907] = {server = 7907, client = 7908, des = "cgcpbjlpourjetton", func = "CpBjlPourJetton"}
PacketCode[7908] = {server = 7907, client = 7908, des = "gccpbjlpourjetton", func = "CpBjlPourJetton"}

--更新各个区域的下注情况
PacketCode[7910] = {server = 7909, client = 7910, des = "gccpbjlgroupjetton", func = "CpBjlGroupJetton"}

--获取开奖结果
PacketCode[7912] = {server = 7911, client = 7912, des = "gccpbjlgetawardresult", func = "CpBjlGetAwardResul"}

--结算
PacketCode[7914] = {server = 7913, client = 7914, des = "gccpbjlcount", func = "CpBjlCount"}

--上庄
PacketCode[7915] = {server = 7915, client = 7916, des = "cgcpbjlbeingbanker", func = "CpBjlBeingBanker"}
PacketCode[7916] = {server = 7915, client = 7916, des = "gccpbjlbeingbanker", func = "CpBjlBeingBanker"}

--下庄
PacketCode[7917] = {server = 7917, client = 7918, des = "cgcpbjldropbanker", func = "CpBjlDropBanker"}
PacketCode[7918] = {server = 7917, client = 7918, des = "gccpbjldropbanker", func = "CpBjlDropBanker"}

--游戏记录
PacketCode[7919] = {server = 7919, client = 7920, des = "cgcpbjlhistory", func = "CpBjlHistory"}
PacketCode[7920] = {server = 7919, client = 7920, des = "gccpbjlhistory", func = "CpBjlHistory"}

--聊天
PacketCode[7921] = {server = 7921, client = 7922, des = "cgcpbjlchat", func = "CpBjlChat"}
PacketCode[7922] = {server = 7921, client = 7922, des = "gccpbjlchat", func = "CpBjlChat"}

--上庄列表
PacketCode[7923] = {server = 7923, client = 7924, des = "cgcpbjlbankerlist", func = "CpBjlBankerList"}
PacketCode[7924] = {server = 7923, client = 7924, des = "gccpbjlbankerlist", func = "CpBjlBankerList"}

--投注记录
PacketCode[7925] = {server = 7925, client = 7926, des = "cgcpbjlbetrecord", func = "CpBjlBetRecord"}
PacketCode[7926] = {server = 7925, client = 7926, des = "gccpbjlbetrecord", func = "CpBjlBetRecord"}

--开奖记录
PacketCode[7927] = {server = 7927, client = 7928, des = "cgcpbjlawardrecord", func = "CpBjlAwardRecord"}
PacketCode[7928] = {server = 7927, client = 7928, des = "gccpbjlawardrecord", func = "CpBjlAwardRecord"}

--获取站立的列表信息
PacketCode[7929] = {server = 7929, client = 7930, des = "cgcpbjlstandlist", func = "CpBjlStandList"}
PacketCode[7930] = {server = 7929, client = 7930, des = "gccpbjlstandlist", func = "CpBjlStandList"}




--游戏错误码
ReturnCode["cpbjl_not_exist"] = 7901
ReturnCode[7901] = "该牌桌不存在"

ReturnCode["cpbjl_state_notpour"] = 7902
ReturnCode[7902] = "请稍后再下注"

ReturnCode["cpbjl_jetton_notenough"] = 7903
ReturnCode[7903] = "您的余额不足"

ReturnCode["cpbjl_pourtype_error"] = 7904
ReturnCode[7904] = "下注失败，请选择正确的下注区域"

ReturnCode["cpbjl_behanker_list"] = 7905
ReturnCode[7905] = "已加入上庄列表"

ReturnCode["cpbjl_pour_banker"] = 7906
ReturnCode[7906] = "庄家不能下注"

ReturnCode["cpbjl_banker_notenough"] = 7907
ReturnCode[7907] = "金币不足，最低上庄需要3000金币"

ReturnCode["cpbjl_pour_lose"] = 7908
ReturnCode[7908] = "已达下注上限，下注失败"

ReturnCode["cpbjl_is_full"] = 7909
ReturnCode[7909] = "该牌桌人数已满，请选择其他牌桌"

ReturnCode["cpbjl_is_bankerlist"] = 7910
ReturnCode[7910] = "您已经加入上庄列表中，请耐心等着"

ReturnCode["cpbjl_jetton_error_1"] = 7911
ReturnCode[7911] = "金币不足，无法进入房间"

ReturnCode["cpbjl_jetton_error_2"] = 7912  --金币太多，无法进人房间
ReturnCode[7912] = "金币太多，无法进入房间"

ReturnCode["cpbjl_not_banker"] = 7913 
ReturnCode[7913] = "您还不是庄家呢"  

ReturnCode["cpbjl_is_drop"] = 7914
ReturnCode[7914] = "您已经申请下庄了"  

ReturnCode["cpbjl_drop_success"] = 7915
ReturnCode[7915] = "申请下庄成功"  

ReturnCode["cpbjl_bebankeer_success"] = 7916
ReturnCode[7916] = "申请上庄成功"  

ReturnCode["cpbjl_pour_max"] = 7917
ReturnCode[7917] = "已经超过下注限额，请选择更小的面值"  

ReturnCode["cpbjl_banker_leave"] = 7918
ReturnCode[7918] = "请先下庄，再离开游戏"  

ReturnCode["cpbjl_limitred"] = 7919
ReturnCode[7919] = "该区域已超过限红，请下别的区域！"  

ReturnCode["cpbjl_banker_jetton"] = 7920
ReturnCode[7920] = "该区域已超过庄家可赔额度，请下别的区域！"  

ReturnCode["cpbjl_nobanker_pourerr"] = 7921
ReturnCode[7921] = "无庄的时候不能下和、庄对和闲对！"  

ReturnCode["cpbjl_bankerlist_dorp"] = 7922
ReturnCode[7922] = "已经离开的申请上庄列表"  

ReturnCode["cpbjl_is_pour"] = 7923
ReturnCode[7923] = "您已下注，请结算后离开"  