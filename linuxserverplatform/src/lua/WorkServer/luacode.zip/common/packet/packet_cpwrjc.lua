--8400~8499 是万人竞猜的玩法


--下注
PacketCode[8401] = {server = 8401, client = 8402, des = "cgcpwrjcpourjetton", func = "CpWrjcPourJetton"}
PacketCode[8402] = {server = 8401, client = 8402, des = "gccpwrjcpourjetton", func = "CpWrjcPourJetton"}


--请求万人竞猜页面信息
PacketCode[8403] = {server = 8403, client = 8404, des = "cgcpwrjcdatainfo", func = "CpWrjcDataInfo"}
PacketCode[8404] = {server = 8403, client = 8404, des = "gccpwrjcdatainfo", func = "CpWrjcDataInfo"}


--推送结算
PacketCode[8406] = {server = 8405, client = 8406, des = "gccpwrjccount", func = "CpWrjcCount"}


--自己的游戏记录
PacketCode[8407] = {server = 8407, client = 8408, des = "cgcpwrjchistory", func = "CpWrjcHistory"}
PacketCode[8408] = {server = 8407, client = 8408, des = "gccpwrjchistory", func = "CpWrjcHistory"}


--请求下注信息
PacketCode[8409] = {server = 8409, client = 8410, des = "cgcpwrjcareainfo", func = "CpWrjcAreaInfo"}
PacketCode[8410] = {server = 8409, client = 8410, des = "gccpwrjcareainfo", func = "CpWrjcAreaInfo"}


--关闭界面
PacketCode[8411] = {server = 8411, client = 8412, des = "cgcpwrjccloase", func = "CpWrjcClose"}
PacketCode[8412] = {server = 8411, client = 8412, des = "gccpwrjccloase", func = "CpWrjcClose"}


--游戏错误码
ReturnCode["cpwrjc_state_notpour"] = 8401
ReturnCode[8401] = "请稍后再下注"


ReturnCode["cpwrjc_count_notpour"] = 8402
ReturnCode[8402] = "开奖结算中，请稍后下注"

ReturnCode["cpwrjc_game_notpour"] = 8403
ReturnCode[8403] = "您的余额仅够完成当前对局，无法参与万人竞猜！"
