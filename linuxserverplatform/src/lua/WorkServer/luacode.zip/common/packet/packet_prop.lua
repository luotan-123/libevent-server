--8901~9000 道具
PacketCode[8901] = {server = 8901, client = 8902, des = "cgpropgetproplist", func = "PropGetPropList"}
PacketCode[8902] = {server = 8901, client = 8902, des = "gcpropgetproplist", func = "PropGetPropList"}

PacketCode[8903] = {server = 8903, client = 8904, des = "cgpropuseprop", func = "PropUseProp"}
PacketCode[8904] = {server = 8903, client = 8904, des = "gcpropuseprop", func = "PropUseProp"}

PacketCode[8905] = {server = 8905, client = 8906, des = "cgpropturntableprizelist", func = "PropTurntablePrizeList"}
PacketCode[8906] = {server = 8905, client = 8906, des = "gcpropturntableprizelist", func = "PropTurntablePrizeList"}

PacketCode[8907] = {server = 8907, client = 8908, des = "cgpropturntablerecord", func = "PropTurntableRecord"}
PacketCode[8908] = {server = 8907, client = 8908, des = "gcpropturntablerecord", func = "PropTurntableRecord"}



ReturnCode["prop_not_exist"] = 8901
ReturnCode[8901] = "道具不存在"

ReturnCode["prop_not_you"] = 8902
ReturnCode[8902] = "道具不属于你"

ReturnCode["prop_use"] = 8903
ReturnCode[8903] = "道具已使用"

ReturnCode["prop_not_use"] = 8904
ReturnCode[8904] = "道具不能在这里使用"

ReturnCode["prop_timeout_error"] = 8905
ReturnCode[8905] = "道具已过期！"

ReturnCode["prop_binphone_error"] = 8906
ReturnCode[8906] = "请绑定手机！"

ReturnCode["prop_tyjetton_error"] = 8907
ReturnCode[8907] = "还有体验金没有使用完"

ReturnCode["prop_tyorder_error"] = 8908
ReturnCode[8908] = "还有体验订单未结算完成！"