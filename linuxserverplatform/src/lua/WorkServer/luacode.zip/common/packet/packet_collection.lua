--8800~8899 是彩票采集服务器

PacketCode[8801] = {server = 8801, client = 8802, des = "cggetcphistroy", func = "GetCpHistroy"}
PacketCode[8802] = {server = 8801, client = 8802, des = "gcgetcphistroy", func = "GetCpHistroy"}
	