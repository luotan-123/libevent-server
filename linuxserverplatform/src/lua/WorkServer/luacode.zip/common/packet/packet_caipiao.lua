--9200~9300 是彩票协议
--进卓
PacketCode[9201] = {server = 9201, client = 9202, des = "cgcaipiaoenter", func = "CaiPiaoEnter"}
PacketCode[9202] = {server = 9201, client = 9202, des = "gccaipiaoenter", func = "CaiPiaoEnter"}
--离开
PacketCode[9203] = {server = 9203, client = 9204, des = "cgcaipiaoleave", func = "CaiPiaoLeave"}
PacketCode[9204] = {server = 9203, client = 9204, des = "gccaipiaoleave", func = "CaiPiaoLeave"}

--下注
PacketCode[9205] = {server = 9205, client = 9206, des = "cgcaipiaopourjetton", func = "CaiPiaoPour"}
PacketCode[9206] = {server = 9205, client = 9206, des = "gccaipiaopourjetton", func = "CaiPiaoPour"}

--通知下注 封盘 维护 状态更新
PacketCode[9210] = {server = 9209, client = 9210, des = "gccaipiaoupdate", func = "CaiPiaoUpdate"}

--历史单个结果
PacketCode[9212] = {server = 9211, client = 9212, des = "gccaipiaohistory", func = "CaiPiaoHistory"}


--押注记录
PacketCode[9213] = {server = 9213, client = 9214, des = "cgcaipiaopourrecord", func = "CaiPiaoPourRecord"}
PacketCode[9214] = {server = 9213, client = 9214, des = "gccaipiaopourrecord", func = "CaiPiaoPourRecord"}

--撤单
PacketCode[9215] = {server = 9215, client = 9216, des = "cgcaipiaorevocation", func = "CaiPiaoRevocation"}
PacketCode[9216] = {server = 9215, client = 9216, des = "gccaipiaorevocation", func = "CaiPiaoRevocation"}

--彩票list
PacketCode[9217] = {server = 9217, client = 9218, des = "cgcaipiaolist", func = "GetCaiPiaoInitInfo"}
PacketCode[9218] = {server = 9217, client = 9218, des = "gccaipiaolist", func = "GetCaiPiaoInitInfo"}

--彩票开奖结果
PacketCode[9219] = {server = 9219, client = 9220, des = "cgcaipiaohistory", func = "CaiPiaoOpenResult"}
PacketCode[9220] = {server = 9219, client = 9220, des = "gccaipiaohistory", func = "CaiPiaoOpenResult"}

ReturnCode["caipiao_not_exist"] = 9201	
ReturnCode[9201] = "彩票桌子不存在"

ReturnCode["pour_max_limit"] = 9202
ReturnCode[9202] = "超出本期下注总额的最大限制"

ReturnCode["caipiao_jetton_notenough"] = 9203
ReturnCode[9203] = "您的筹码不足，下注失败"

ReturnCode["caipiao_state_notpour"] = 9204
ReturnCode[9204] = "当前不是下注状态，下注失败"

ReturnCode["caipiao_pourtype_error"] = 9205
ReturnCode[9205] = "下注失败，请选择正确的下注区域"

ReturnCode["orderid_not_exist"] = 9206
ReturnCode[9206] = "订单不存在"

ReturnCode["orderid_revocation_fail"] = 9207
ReturnCode[9207] = "订单已封盘，撤单失败"

ReturnCode["orderid_xutou_fail_0"] = 9208
ReturnCode[9208] = "该期已封盘，续投失败"

ReturnCode["orderid_xutou_fail_1"] = 9209
ReturnCode[9209] = "上期未下注，续投失败"

ReturnCode["caipiao_jetton_error"] = 9210
ReturnCode[9210] = "下注金额错误"

ReturnCode["orderid_xutou_fail_2"] = 9211
ReturnCode[9211] = "您的筹码不足，续投失败"

ReturnCode["pour_max_limit"] = 9212
ReturnCode[9212] = "超出本期下注总额的最大限制"
