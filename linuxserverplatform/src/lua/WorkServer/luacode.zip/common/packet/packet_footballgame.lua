--7600~7699 是全民足球协议字段

--赛事
PacketCode[7601] = {server = 7601, client = 7602, des = "cgfootballeventlist", func = "FootballEventList"}
PacketCode[7602] = {server = 7601, client = 7602, des = "gcfootballeventlist", func = "FootballEventList"}

--赛事详情
PacketCode[7603] = {server = 7603, client = 7604, des = "cgfootballeventdetail", func = "FootballEventDetail"}
PacketCode[7604] = {server = 7603, client = 7604, des = "gcfootballeventldetail", func = "FootballEventDetail"}


--订单
PacketCode[7605] = {server = 7605, client = 7606, des = "cgfootballorderlist", func = "FootballOrderList"}
PacketCode[7606] = {server = 7605, client = 7606, des = "gcfootballorderlist", func = "FootballOrderList"}

--订单详情
PacketCode[7607] = {server = 7607, client = 7608, des = "cgfootballorderdetail", func = "FootballOrderDetail"}
PacketCode[7608] = {server = 7607, client = 7608, des = "gcfootballorderdetail", func = "FootballOrderDetail"}

--下单
PacketCode[7609] = {server = 7609, client = 7610, des = "cgfootballpourinfo", func = "FootballPour"}
PacketCode[7610] = {server = 7609, client = 7610, des = "gcfootballpourinfo", func = "FootballPour"}

--撤单
PacketCode[7611] = {server = 7611, client = 7612, des = "cgfootballordercancel", func = "FootballOrderCancel"}
PacketCode[7612] = {server = 7611, client = 7612, des = "gcfootballordercancel", func = "FootballOrderCancel"}

--消息
PacketCode[7613] = {server = 7613, client = 7614, des = "cgfootballnews", func = "FootballNews"}
PacketCode[7614] = {server = 7613, client = 7614, des = "gcfootballnews", func = "FootballNews"}


--交易记录
PacketCode[7615] = {server = 7615, client = 7616, des = "cgfootballrecords", func = "FootballRecords"}
PacketCode[7616] = {server = 7615, client = 7616, des = "gcfootballrecords", func = "FootballRecords"}

--登入请求查看是否有可撤单信息
PacketCode[7617] = {server = 7617, client = 7618, des = "cgfootballnoticecancelorder", func = "NoticeCancelOrder"}
PacketCode[7618] = {server = 7617, client = 7618, des = "gcfootballnoticecancelorder", func = "NoticeCancelOrder"}

--赛事关注
PacketCode[7619] = {server = 7619, client = 7620, des = "cgfootballpayattentionevent", func = "FootballAttention"}
PacketCode[7620] = {server = 7619, client = 7620, des = "gcfootballpayattentionevent", func = "FootballAttention"}


--翻翻乐  收益报告
PacketCode[7621] = {server = 7621, client = 7622, des = "cgflipprofitreport", func = "FlipProfitReport"}
PacketCode[7622] = {server = 7621, client = 7622, des = "gcflipprofitreport", func = "FlipProfitReport"}

--翻翻乐  查看收益明细
PacketCode[7623] = {server = 7623, client = 7624, des = "cgflipprofitreportdetail", func = "FlipProfitReportDetail"}
PacketCode[7624] = {server = 7623, client = 7624, des = "gcflipprofitreportdetail", func = "FlipProfitReportDetail"}


--翻翻乐  翻翻乐的中奖情况记录
PacketCode[7625] = {server = 7625, client = 7626, des = "cgflipprofitrecords", func = "FlipProfitRecords"}
PacketCode[7626] = {server = 7625, client = 7626, des = "gcflipprofitrecords", func = "FlipProfitRecords"}

--翻翻乐  翻翻乐抽奖
PacketCode[7627] = {server = 7627, client = 7628, des = "cgflipprofitdrawlottery", func = "FlipProfitDrawLottery"}
PacketCode[7628] = {server = 7627, client = 7628, des = "gcflipprofitdrawlottery", func = "FlipProfitDrawLottery"}

--即使比分
PacketCode[7629] = {server = 7629, client = 7630, des = "cgcurrentracescore", func = "RaceCurrentScore"}
PacketCode[7630] = {server = 7629, client = 7630, des = "gccurrentracescore", func = "RaceCurrentScore"}

--数据分析
PacketCode[7631] = {server = 7631, client = 7632, des = "cgracedataanalysis", func = "RaceDataAnalysis"}
PacketCode[7632] = {server = 7631, client = 7632, des = "gcracedataanalysis", func = "RaceDataAnalysis"}

--文字直播
PacketCode[7633] = {server = 7633, client = 7634, des = "cgracetextinfo", func = "RaceTextInfo"}
PacketCode[7634] = {server = 7633, client = 7634, des = "gcracetextinfo", func = "RaceTextInfo"}


ReturnCode["param_error"] = 7601  --参数错误
ReturnCode[7601] = "参数错误"

ReturnCode["order_no_exit"] = 7602  --订单不存在
ReturnCode[7602] = "订单不存在"

ReturnCode["order_cancel_time_limit"] = 7603  --超过撤单时间限制,撤单失败
ReturnCode[7603] = "超过撤单时间限制,撤单失败"

ReturnCode["order_cancel_start_limit"] = 7604  --比赛以开始,撤单失败
ReturnCode[7604] = "比赛以开始,撤单失败"

ReturnCode["order_cancel_state_error"] = 7605  --撤单失败
ReturnCode[7605] = "撤单失败"

ReturnCode["event_has_start"] = 7606  --比赛已经开始
ReturnCode[7606] = "比赛已经开始"

ReturnCode["event_not_exit"] = 7607 --赛事不存在
ReturnCode[7607] = "赛事不存在"

ReturnCode["pour_limit"] = 7608 --超过下注限制,下注失败
ReturnCode[7608] = "超过下注限制,下注失败"

ReturnCode["pourtype_not_exit"] = 7609 --下注区域不存在
ReturnCode[7609] = "下注区域不存在"

ReturnCode["pour_error"] = 7610 --下单失败
ReturnCode[7610] = "下单失败"

ReturnCode["typourtype_error"] = 7611 --体验金只能在带“验”字标识的比分下注"
ReturnCode[7611] = "体验金只能在带“验”字标识的比分下注"

ReturnCode["typourtype_time_error"] = 7612 --体验金有效时间已过
ReturnCode[7612] = "体验金已过期失效，请充值下注"

ReturnCode["can_not_pour"] = 7613 --赛事不可投注
ReturnCode[7613] = "赛事不可投注"

ReturnCode["can_not_draw"] = 7614 --当前无法抽奖
ReturnCode[7614] = "当前无法抽奖"

ReturnCode["payjetton_error"] = 7615 --付费金额错误
ReturnCode[7615] = "付费金额错误"

ReturnCode["jetton_not_enought"] = 7616 --付费金额错误
ReturnCode[7616] = "余额不足"

ReturnCode["free_count_error"] = 7617 --您当前没有免费次数
ReturnCode[7617] = "您当前没有免费次数"

ReturnCode["cards_not_use_error1"] = 7618 --卡片只能全场下注使用
ReturnCode[7618] = "卡片只能全场下注使用"

ReturnCode["cards_not_exist"] = 7619 --卡片不存在
ReturnCode[7619] = "卡片不存在"

ReturnCode["cards_not_use_error2"] = 7620 --下注区域的收益不能使用卡片
ReturnCode[7620] = "下注区域的收益不能使用卡片"

ReturnCode["cards_not_use_error3"] = 7621 --无效卡片
ReturnCode[7621] = "无效卡片"

ReturnCode["cards_is_used"] = 7622 --卡片已使用过
ReturnCode[7622] = "卡片已使用过"

ReturnCode["score_close"] = 7623
ReturnCode[7623] = "比分已经关盘"

ReturnCode["viplevel_not_allow"] = 7624
ReturnCode[7624] = "单笔下注额度超过当前vip等级限制"

ReturnCode["viplevel_not_card"] = 7625
ReturnCode[7625] = "当前vip等级不允许使用该卡券"

ReturnCode["viplevel_cardnum_over"] = 7626
ReturnCode[7626] = "该卡券今天的使用次数已用完"

ReturnCode["tyorder_not_cancle"] = 7627
ReturnCode[7627] = "体验金下注不能撤单"