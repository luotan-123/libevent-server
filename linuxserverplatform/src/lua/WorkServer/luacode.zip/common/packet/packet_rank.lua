


--1400~1500 是排行榜的ID区间
PacketCode[1401] = {server = 1401, client = 1402, des = "cggetranklist", func = "GetRankList"}
PacketCode[1402] = {server = 1401, client = 1402, des = "gcgetranklist", func = "GetRankList"}




