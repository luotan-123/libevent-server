--8600~8699 是专家模块协议

--热门专家
PacketCode[8601] = {server = 8601, client = 8602, des = "cgexperthotlist", func = "ExpertHotList"}
PacketCode[8602] = {server = 8601, client = 8602, des = "gcexperthotlist", func = "ExpertHotList"}


--热门方案
PacketCode[8603] = {server = 8603, client = 8604, des = "cgexperthotplanlist", func = "ExpertHotPlanList"}
PacketCode[8604] = {server = 8603, client = 8604, des = "gcexperthotplanlist", func = "ExpertHotPlanList"}


--盈利排行榜
PacketCode[8605] = {server = 8605, client = 8606, des = "cgexpertwinranklist", func = "ExpertWinRankList"}
PacketCode[8606] = {server = 8605, client = 8606, des = "gcexpertwinranklist", func = "ExpertWinRankList"}


--关注的专家
PacketCode[8607] = {server = 8607, client = 8608, des = "cgexpertconcernuserlist", func = "ExpertConcernUserList"}
PacketCode[8608] = {server = 8607, client = 8608, des = "gcexpertconcernuserlist", func = "ExpertConcernUserList"}


--关注的方案
PacketCode[8609] = {server = 8609, client = 8610, des = "cgexpertconcernplanlist", func = "ExpertConcernPlanList"}
PacketCode[8610] = {server = 8609, client = 8610, des = "gcexpertconcernplanlist", func = "ExpertConcernPlanList"}

--专家---周榜
PacketCode[8611] = {server = 8611, client = 8612, des = "cgexpertweekranklist", func = "ExpertWeekRankList"}
PacketCode[8612] = {server = 8611, client = 8612, des = "gcexpertweekranklist", func = "ExpertWeekRankList"}

--专家---全部
PacketCode[8613] = {server = 8613, client = 8614, des = "cgexpertalluserlist", func = "ExpertAllUserList"}
PacketCode[8614] = {server = 8613, client = 8614, des = "gcexpertalluserlist", func = "ExpertAllUserList"}


---------------专家详情分4个协议获取
--获取专家简单信息
PacketCode[8615] = {server = 8615, client = 8616, des = "cgexpertgetuserinfo", func = "ExpertGetUserInfo"}
PacketCode[8616] = {server = 8615, client = 8616, des = "gcexpertgetuserinfo", func = "ExpertGetUserInfo"}

--获取专家命中率和赔率
PacketCode[8617] = {server = 8617, client = 8618, des = "cgexpertgetuserhitrate", func = "ExpertGetUserHitRate"}
PacketCode[8618] = {server = 8617, client = 8618, des = "gcexpertgetuserhitrate", func = "ExpertGetUserHitRate"}

--获取专家方案战绩
PacketCode[8619] = {server = 8619, client = 8620, des = "cgexpertgetuserrecords", func = "ExpertGetUserRecords"}
PacketCode[8620] = {server = 8619, client = 8620, des = "gcexpertgetuserrecords", func = "ExpertGetUserRecords"}

--获取专家历史方案
PacketCode[8621] = {server = 8621, client = 8622, des = "cgexperthisplanlist", func = "ExpertGetHisPlanList"}
PacketCode[8622] = {server = 8621, client = 8622, des = "gcexperthisplanlist", func = "ExpertGetHisPlanList"}


---------------
--查看别人的方案详情
PacketCode[8623] = {server = 8623, client = 8624, des = "cgexpertgetotherplaninfo", func = "ExpertGetOtherPlanInfo"}
PacketCode[8624] = {server = 8623, client = 8624, des = "gcexpertgetotherplaninfo", func = "ExpertGetOtherPlanInfo"}

--购买方案
PacketCode[8625] = {server = 8625, client = 8626, des = "cgexpertbuyplan", func = "ExpertBuyPlan"}
PacketCode[8626] = {server = 8625, client = 8626, des = "gcexpertbuyplan", func = "ExpertBuyPlan"}

--自动跟投，跟投会把一个方案的所有赛事的比分，都投注
--跟投走下注订单协议，页面信息在 expertplanraceinfo 有

---------------------
--添加专家发布方案提醒
PacketCode[8627] = {server = 8627, client = 8628, des = "cgexpertaddnotice", func = "ExpertAddNotice"}
PacketCode[8628] = {server = 8627, client = 8628, des = "gcexpertaddnotice", func = "ExpertAddNotice"}

--关注专家
PacketCode[8629] = {server = 8629, client = 8630, des = "cgexpertaddconcerned", func = "ExpertAddConcerned"}
PacketCode[8630] = {server = 8629, client = 8630, des = "gcexpertaddconcerned", func = "ExpertAddConcerned"}

--关注方案
PacketCode[8631] = {server = 8631, client = 8632, des = "cgexpertaddplanconcerned", func = "ExpertAddPlanConcerned"}
PacketCode[8632] = {server = 8631, client = 8632, des = "gcexpertaddplanconcerned", func = "ExpertAddPlanConcerned"}


--查询庄家模块自己的状态
PacketCode[8633] = {server = 8633, client = 8634, des = "cgexpertquerystatus", func = "ExpertQueryStatus"}
PacketCode[8634] = {server = 8633, client = 8634, des = "gcexpertquerystatus", func = "ExpertQueryStatus"}

--申请成为专家
PacketCode[8635] = {server = 8635, client = 8636, des = "cgexpertapplytoexpert", func = "ExpertApplyToExpert"}
PacketCode[8636] = {server = 8635, client = 8636, des = "gcexpertapplytoexpert", func = "ExpertApplyToExpert"}

--查询名字
PacketCode[8637] = {server = 8637, client = 8638, des = "cgexpertqueryname", func = "ExpertQueryName"}
PacketCode[8638] = {server = 8637, client = 8638, des = "gcexpertqueryname", func = "ExpertQueryName"}

--推送审核状态，不需要生成文件
PacketCode[8640] = {server = 8639, client = 8640, des = "gcexpertnotifystatus", func = "no"}

---------------------------------------------------  以下协议都在 msg_expert2_pb 中
--我的相关协议  
--查看自己的简单信息
PacketCode[8641] = {server = 8641, client = 8642, des = "cgexpertlookmyinfo", func = "ExpertLookMyInfo"}
PacketCode[8642] = {server = 8641, client = 8642, des = "gcexpertlookmyinfo", func = "ExpertLookMyInfo"}

--编辑个人介绍
PacketCode[8643] = {server = 8643, client = 8644, des = "cgexpertchangecontent", func = "ExpertChangeContent"}
PacketCode[8644] = {server = 8643, client = 8644, des = "gcexpertchangecontent", func = "ExpertChangeContent"}

--正在进行中的方案
PacketCode[8645] = {server = 8645, client = 8646, des = "cgexpertmyplaninglist", func = "ExpertMyplaningList"}
PacketCode[8646] = {server = 8645, client = 8646, des = "gcexpertmyplaninglist", func = "ExpertMyplaningList"}

--历史方案，投注截止的方案
PacketCode[8647] = {server = 8647, client = 8648, des = "cgexpertmyplanedlist", func = "ExpertMyplanedList"}
PacketCode[8648] = {server = 8647, client = 8648, des = "gcexpertmyplanedlist", func = "ExpertMyplanedList"}

--获取自己方案的售卖详情
PacketCode[8649] = {server = 8649, client = 8650, des = "cgexpertgetmyplaninfo", func = "ExpertGetMyPlanInfo"}
PacketCode[8650] = {server = 8649, client = 8650, des = "gcexpertgetmyplaninfo", func = "ExpertGetMyPlanInfo"}


---------------------------
--发布方案
--获取自己方案的售卖详情
PacketCode[8651] = {server = 8651, client = 8652, des = "cgexpertcreateplan", func = "ExpertCreatePlan"}
PacketCode[8652] = {server = 8651, client = 8652, des = "gcexpertcreateplan", func = "ExpertCreatePlan"}


----------------------
--赛事系统，里面还有个，关于本场比赛的专家赛事方案
--获取赛事相关的方案
PacketCode[8653] = {server = 8653, client = 8654, des = "cggetraceplan", func = "GetRacePlan"}
PacketCode[8654] = {server = 8653, client = 8654, des = "gcgetraceplan", func = "GetRacePlan"}

-----------------------

--获取赛事状态
PacketCode[8655] = {server = 8655, client = 8656, des = "cgexpertgetracestatus", func = "ExpertGetRaceStatus"}
PacketCode[8656] = {server = 8655, client = 8656, des = "gcexpertgetracestatus", func = "ExpertGetRaceStatus"}

--跟投方案
PacketCode[8657] = {server = 8657, client = 8658, des = "cgexpertpourplan", func = "ExpertPourPlan"}
PacketCode[8658] = {server = 8657, client = 8658, des = "gcexpertpourplan", func = "ExpertPourPlan"}

--有关系的方案
PacketCode[8659] = {server = 8659, client = 8660, des = "cgexpertrelationplanlist", func = "ExpertRelationPlanList"}
PacketCode[8660] = {server = 8659, client = 8660, des = "gcexpertrelationplanlist", func = "ExpertRelationPlanList"}

ReturnCode["param_error"] = 8601  --参数错误
ReturnCode[8601] = "参数错误"

ReturnCode["expert_no_exit"] = 8602  --专家不存在
ReturnCode[8602] = "专家不存在"

ReturnCode["already_expert"] = 8603  --已经是专家
ReturnCode[8603] = "已经是专家"

ReturnCode["not_become_expert"] = 8604  --不满足成为专家条件
ReturnCode[8604] = "不满足成为专家条件"

ReturnCode["applying"] = 8605  --正在审核中
ReturnCode[8605] = "正在审核中"

ReturnCode["illegal_name"] = 8606  --名字非法
ReturnCode[8606] = "名字非法"

ReturnCode["no_concern_myself"] = 8607  --自己不能关注自己
ReturnCode[8607] = "自己不能关注自己"

ReturnCode["no_notice_myself"] = 8608  --自己不能添加提醒自己
ReturnCode[8608] = "自己不能添加提醒自己"

ReturnCode["no_concern_myself_plan"] = 8609  --自己不能关注自己的方案
ReturnCode[8609] = "自己不能关注自己的方案"

ReturnCode["plan_no_exists"] = 8610  --方案不存在
ReturnCode[8610] = "专家不存在"

ReturnCode["score_too_much"] = 8611  --选择的赛事数量超过限制
ReturnCode[8611] = "选择的赛事数量超过限制"

ReturnCode["race_started"] = 8612  --选择的赛事已经开赛
ReturnCode[8612] = "选择的赛事已经开赛"

ReturnCode["race_not_exists"] = 8613  --选择的赛事不存在
ReturnCode[8613] = "选择的赛事不存在"

ReturnCode["error_character"] = 8614
ReturnCode[8614] = "选择的比分不符合自己性格"

ReturnCode["price_too_much"] = 8615
ReturnCode[8615] = "价格超出范围"

ReturnCode["expert_forbid"] = 8616
ReturnCode[8616] = "专家功能被禁用了"

ReturnCode["plan_forbid"] = 8617
ReturnCode[8617] = "方案被下架"

ReturnCode["two_time_once"] = 8618
ReturnCode[8618] = "赛事之间间隔两个小时"

ReturnCode["rece_one_day"] = 8619
ReturnCode[8619] = "只能选择一天的赛事"

ReturnCode["pour_time_end"] = 8620
ReturnCode[8620] = "跟投时间截止"

ReturnCode["already_pour_plan"] = 8621
ReturnCode[8621] = "已经更投过该方案"
