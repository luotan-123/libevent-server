--8300~8399 是彩票推筒子

--进入						
PacketCode[8301] = {server = 8301, client = 8302, des = "cgcptuitongzienter", func = "CpTuiTongZiEnter"}
PacketCode[8302] = {server = 8301, client = 8302, des = "gccptuitongzienter", func = "CpTuiTongZiEnter"}

--离开
PacketCode[8303] = {server = 8303, client = 8304, des = "cgcptuitongzileave", func = "CpTuiTongZiLeave"}
PacketCode[8304] = {server = 8303, client = 8304, des = "gccptuitongzileave", func = "CpTuiTongZiLeave"}

--坐下
PacketCode[8305] = {server = 8305, client = 8306, des = "cgcptuitongzisitdown", func = "CpTuiTongZiSitdown"}
PacketCode[8306] = {server = 8305, client = 8306, des = "gccptuitongzisitdown", func = "CpTuiTongZiSitdown"}

--站起
PacketCode[8308] = {server = 8307, client = 8308, des = "gccptuitongzistandup", func = "CpTuiTongZiStandup"}

--开始
PacketCode[8310] = {server = 8309, client = 8310, des = "gccptuitongzistart", func = "CpTuiTongZiStart"}

--抢庄
PacketCode[8311] = {server = 8311, client = 8312, des = "cgcptuitongzibank", func = "CpTuiTongZiBanker"}
PacketCode[8312] = {server = 8311, client = 8312, des = "gccptuitongzibank", func = "CpTuiTongZiBanker"}

--确定庄家 
PacketCode[8314] = {server = 8313, client = 8314, des = "gccptuitongzibanketopt", func = "CpTuiTongZiBankOpt"}

--选位置
PacketCode[8315] = {server = 8315, client = 8316, des = "cgcptuitongziselect", func = "CpTuiTongZiSelect"}
PacketCode[8316] = {server = 8315, client = 8316, des = "gccptuitongziselect", func = "CpTuiTongZiSelect"}

--确定选的位置 
PacketCode[8318] = {server = 8317, client = 8318, des = "gccptuitongziselectend", func = "CpTuiTongZiSelectEnd"}

--下注
PacketCode[8319] = {server = 8319, client = 8320, des = "cgcptuitongzipour", func = "CpTuiTongZiPour"}
PacketCode[8320] = {server = 8319, client = 8320, des = "gccptuitongzipour", func = "CpTuiTongZiPour"}

--确定下注 
PacketCode[8322] = {server = 8321, client = 8322, des = "gcptuitongzipouropt", func = "CpTuiTongZiPourOpt"}

--结算
PacketCode[8324] = {server = 8323, client = 8324, des = "gccptuitongzicount", func = "CpTuiTongZiCount"}

--休息时间
PacketCode[8326] = {server = 8325, client = 8326, des = "gccptuitongzinextout", func = "CpTuiTongZiNextOut"}

--准备
PacketCode[8327] = {server = 8327, client = 8328, des = "cgcptuitongzinext", func = "CpTuiTongZiNext"}
PacketCode[8328] = {server = 8327, client = 8328, des = "gccptuitongzinext", func = "CpTuiTongZiNext"}

--采集把的数据
PacketCode[8330] = {server = 8329, client = 8330, des = "gccptuitongziready", func = "CpTuiTongZiReady"}

--设置自动操作
PacketCode[8331] = {server = 8331, client = 8332, des = "cgcptuitongzisetauto", func = "CpTuiTongZiSetAuto"}
PacketCode[8332] = {server = 8331, client = 8332, des = "gccptuitongzisetauto", func = "CpTuiTongZiSetAuto"}

--聊天
PacketCode[8333] = {server = 8333, client = 8334, des = "cgcptuitongzichat", func = "CpTuiTongZiChat"}
PacketCode[8334] = {server = 8333, client = 8334, des = "gccptuitongzichat", func = "CpTuiTongZiChat"}

--历史记录
PacketCode[8335] = {server = 8335, client = 8336, des = "cgcptuitongzihistory", func = "CpTuiTongZiHistory"}
PacketCode[8336] = {server = 8335, client = 8336, des = "gccptuitongzihistory", func = "CpTuiTongZiHistory"}

--开始前倒计时
PacketCode[8338] = {server = 8337, client = 8338, des = "gccptuitongzicountdown", func = "CpTuiTongZiCountdown"}

---------------------------------------------------------------------------------------------------------

ReturnCode["cptuitongzi_not_exist"] = 8301
ReturnCode[8301] = "该牌桌不存在！"

ReturnCode["cptuitongzi_enter_error"] = 8302
ReturnCode[8302] = "进入房间失败！"

ReturnCode["cptuitongzi_time_err"] = 8303
ReturnCode[8303] = "请稍后再操作！"

ReturnCode["cptuitongzi_operat_err"] = 8304
ReturnCode[8304] = "操作失败"	

ReturnCode["cptuitongzi_leave_error"] = 8306
ReturnCode[8306] = "请稍后再离开！"

ReturnCode["cptuitongzi_full"] = 8307
ReturnCode[8307] = "该牌桌人数已满，请选择其他牌桌"

ReturnCode["cptuitongzi_bankerjetton_error"] = 8308
ReturnCode[8308] = "您余额小于最低抢庄" 

ReturnCode["cptuitongzi_bankermul_error"] = 8309
ReturnCode[8309] = "抢庄倍数太高了" 

ReturnCode["cptuitongzi_pos_ex"] = 8310
ReturnCode[8310] = "该位置已经被选择了" 

ReturnCode["cptuitongzi_baker_pour"] = 8311
ReturnCode[8311] = "庄家不用下注" 

ReturnCode["cptuitongzi_select_err"] = 8312
ReturnCode[8312] = "已选择完成"	


