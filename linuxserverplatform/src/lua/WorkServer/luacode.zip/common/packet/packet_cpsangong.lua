--8200~8299 是彩票三公

--加入房间
PacketCode[8201] = {server = 8201, client = 8202, des = "cgcpsangongenter", func = "CpSanGongEnter"}
PacketCode[8202] = {server = 8201, client = 8202, des = "gccpsangongenter", func = "CpSanGongEnter"}

--离开房间
PacketCode[8203] = {server = 8203, client = 8204, des = "cgcpsangongleave", func = "CpSanGongLeave"}
PacketCode[8204] = {server = 8203, client = 8204, des = "gccpsangongleave", func = "CpSanGongLeave"}

--坐下
PacketCode[8205] = {server = 8205, client = 8206, des = "cgcpsangongsitdown", func = "CpSanGongSitDown"}
PacketCode[8206] = {server = 8205, client = 8206, des = "gccpsangongsitdown", func = "CpSanGongSitDown"}

--站起
PacketCode[8208] = {server = 8207, client = 8208, des = "gccpsangongstandup", func = "CpSanGongStandUp"}

--开始
PacketCode[8210] = {server = 8209, client = 8210, des = "gccpsangongstart", func = "CpSanGongStart"}

--选位置
PacketCode[8211] = {server = 8211, client = 8212, des = "cgcpsangongselect", func = "CpSanGongSelect"}
PacketCode[8212] = {server = 8211, client = 8212, des = "gccpsangongselect", func = "CpSanGongSelect"}

--确定选的位置
PacketCode[8214] = {server = 8213, client = 8214, des = "gccpsangongselectend", func = "CpSanGongSelectEnd"}

--下注
PacketCode[8215] = {server = 8215, client = 8216, des = "cgcpsangongpour", func = "CpSanGongPour"}
PacketCode[8216] = {server = 8215, client = 8216, des = "gccpsangongpour", func = "CpSanGongPour"}

--确定下注
PacketCode[8218] = {server = 8217, client = 8218, des = "gccpsangongpouropt", func = "CpSanGongpourOpt"}

--结算
PacketCode[8220] = {server = 8219, client = 8220, des = "gccpsangongcount", func = "CpSanGongCount"}

--休息时间
PacketCode[8222] = {server = 8221, client = 8222, des = "gccpsangongend", func = "CpSanGongEnd"}

--准备
PacketCode[8223] = {server = 8223, client = 8224, des = "cgcpsangongready", func = "CpSanGongReady"}
PacketCode[8224] = {server = 8223, client = 8224, des = "gccpsangongready", func = "CpSanGongReady"}

--采集把的数据
PacketCode[8226] = {server = 8225, client = 8226, des = "gccpsangonggoready", func = "CpSanGongGoReady"}

--设置自动操作
PacketCode[8227] = {server = 8227, client = 8228, des = "cgcpsangongsetauto", func = "CpSanGongSetAuto"}
PacketCode[8228] = {server = 8227, client = 8228, des = "gccpsangongsetauto", func = "CpSanGongSetAuto"}

--聊天
PacketCode[8229] = {server = 8229, client = 8230, des = "cgcpsangongchat", func = "CpSanGongChat"}
PacketCode[8230] = {server = 8229, client = 8230, des = "gccpsangongchat", func = "CpSanGongChat"}

--历史记录
PacketCode[8231] = {server = 8231, client = 8232, des = "cgcpsangonghistory", func = "CpSanGongHistory"}
PacketCode[8232] = {server = 8231, client = 8232, des = "gccpsangonghistory", func = "CpSanGongHistory"}

--开始前倒计时
PacketCode[8234] = {server = 8232, client = 8234, des = "gccpsangongcountdown", func = "CpSanGongCountdown"}

ReturnCode["cpsangong_not_exist"] = 8201   
ReturnCode[8201] = "该牌桌已经解散" 

ReturnCode["cpsangong_is_full"] = 8202   
ReturnCode[8202] = "该牌桌已经满座" 

ReturnCode["cpsangong_leave_state"] = 8203  
ReturnCode[8203] = "请等待牌局结束再离开" 

ReturnCode["cpsangong_play_error"] = 8204
ReturnCode[8204] = "操作错误" 

ReturnCode["cpsangong_ready_error"] = 8205
ReturnCode[8205] = "准备失败"

ReturnCode["cpsangong_ready_fail"] = 8206
ReturnCode[8206] = "请稍后再操作"

ReturnCode["cpsangong_jetton_not_enough"] = 8207
ReturnCode[8207] = "金币不足"

ReturnCode["cpsangong_jetton_error_1"] = 8208
ReturnCode[8208] = "金币太多了, 请到更高的场次去玩吧"	

ReturnCode["cpsangong_time_err"] = 8209
ReturnCode[8209] = "请稍后再操作"	

ReturnCode["cpsangong_operat_err"] = 8210
ReturnCode[8210] = "操作失败"	

ReturnCode["cpsangong_jetton_error_2"] = 8211
ReturnCode[8211] = "金币不足，进入房间失败"	

ReturnCode["cpsangong_jetton_error_3"] = 8212
ReturnCode[8212] = "下注超过最大限制"

ReturnCode["cpsangong_jetton_err"] = 8213 
ReturnCode[8213] = "金币不足！"

ReturnCode["cpsangong_pos_ex"] = 8214
ReturnCode[8214] = "该位置已经被选择了" 

ReturnCode["cpsangong_select_err"] = 8215
ReturnCode[8215] = "已选择完成"
















