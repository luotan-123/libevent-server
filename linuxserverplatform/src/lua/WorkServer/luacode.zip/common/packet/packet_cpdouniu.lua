--8101~8199 是彩票牛牛的玩法	

--进入房间
PacketCode[8101] = {server = 8101, client = 8102, des = "cgcpdouniujoinroom", func = "CpDouNiuJoinRoom"}
PacketCode[8102] = {server = 8101, client = 8102, des = "gccpdouniujoinroom", func = "CpDouNiuJoinRoom"}

--离开房间
PacketCode[8103] = {server = 8103, client = 8104, des = "cgcpdouniuleave", func = "CpDouNiuLeave"}
PacketCode[8104] = {server = 8103, client = 8104, des = "gccpdouniuleave", func = "CpDouNiuLeave"}

--坐下
PacketCode[8105] = {server = 8105, client = 8106, des = "cgcpdouniusitdown", func = "CpDouNiuSitdown"}
PacketCode[8106] = {server = 8105, client = 8106, des = "gccpdouniusitdown", func = "CpDouNiuSitdown"}

--站起
PacketCode[8108] = {server = 8107, client = 8108, des = "gccpdouniustandup", func = "CpDouNiuStandup"}

--开始
PacketCode[8110] = {server = 8109, client = 8110, des = "gccpdouniustart", func = "CpDouNiuStart"}

--选位置
PacketCode[8111] = {server = 8111, client = 8112, des = "cgcpdouniuselect", func = "CpDouNiuSelect"}
PacketCode[8112] = {server = 8111, client = 8112, des = "gccpdouniuselect", func = "CpDouNiuSelect"}

--确定选的位置
PacketCode[8114] = {server = 8113, client = 8114, des = "gccpdouniuselectend", func = "CpDouNiuSelectend"}

--抢庄
PacketCode[8115] = {server = 8115, client = 8116, des = "cgcpdouniubanker", func = "CpDouNiuBanker"}
PacketCode[8116] = {server = 8115, client = 8116, des = "gccpdouniubanker", func = "CpDouNiuBanker"}

--确定庄家
PacketCode[8118] = {server = 8117, client = 8118, des = "gccpdouniubanketopt", func = "CpDouNiuBanketOpt"}

--下注
PacketCode[8119] = {server = 8119, client = 8120, des = "cgcpdouniupour", func = "CpDouNiuPour"}
PacketCode[8120] = {server = 8119, client = 8120, des = "gccpdouniupour", func = "CpDouNiuPour"}

--确定下注
PacketCode[8122] = {server = 8121, client = 8122, des = "gccpdouniupouropt", func = "CpDouNiuPourOpt"}

--发牌
PacketCode[8124] = {server = 8123, client = 8124, des = "gccpdouniudeal", func = "CpDouNiuDeal"}

--亮牌
PacketCode[8125] = {server = 8125, client = 8126, des = "cgcpdouniushowpoker", func = "CpDouNiuShowPoker"}
PacketCode[8126] = {server = 8125, client = 8126, des = "gccpdouniushowpoker", func = "CpDouNiuShowPoker"}

--结算
PacketCode[8128] = {server = 8127, client = 8128, des = "gccpdouniucount", func = "CpDouNiuCount"}

--休息时间
PacketCode[8130] = {server = 8129, client = 8130, des = "gccpdouniunextout", func = "CpDouNiuNextout"}

--准备
PacketCode[8131] = {server = 8131, client = 8132, des = "cgcpdouniunext", func = "CpDouNiuNext"}
PacketCode[8132] = {server = 8131, client = 8132, des = "gccpdouniunext", func = "CpDouNiuNext"}

--聊天
PacketCode[8133] = {server = 8133, client = 8134, des = "cgcpdouniuchat", func = "CpDouNiuChat"}
PacketCode[8134] = {server = 8133, client = 8134, des = "gccpdouniuchat", func = "CpDouNiuChat"}

--游戏托管
PacketCode[8135] = {server = 8135, client = 8136, des = "cgcpdouniutrusteeship", func = "CpDouNiuTrusteeship"}
PacketCode[8136] = {server = 8135, client = 8136, des = "gccpdouniutrusteeship", func = "CpDouNiuTrusteeship"}

--自动亮牌
PacketCode[8137] = {server = 8137, client = 8138, des = "cgcpdouniuvolun", func = "CpDouNiuvolun"}
PacketCode[8138] = {server = 8137, client = 8138, des = "gccpdouniuvolun", func = "CpDouNiuvolun"}

--采集把的数据
PacketCode[8140] = {server = 8139, client = 8140, des = "gccpdouniuready", func = "CpDouNiuReady"}

--自动亮牌
PacketCode[8141] = {server = 8141, client = 8142, des = "cgcpdouniusetauto", func = "CpDouNiuSetAuto"}
PacketCode[8142] = {server = 8141, client = 8142, des = "gccpdouniusetauto", func = "CpDouNiuSetAuto"}

--历史记录
PacketCode[8143] = {server = 8143, client = 8144, des = "cgcpdouniuhistory", func = "CpDouNiuHistory"}
PacketCode[8144] = {server = 8143, client = 8144, des = "gccpdouniuhistory", func = "CpDouNiuHistory"}

--开始前倒计时
PacketCode[8146] = {server = 8145, client = 8146, des = "gccpdouniucountdown", func = "CpDouNiuCountdown"}

--创建游戏
PacketCode[8147] = {server = 8147, client = 8148, des = "cgcpdouniucreate", func = "CpDouNiuCreate"}
PacketCode[8148] = {server = 8147, client = 8148, des = "gccpdouniucreate", func = "CpDouNiuCreate"}

--发起解散房间
PacketCode[8149] = {server = 8149, client = 8150, des = "cgcpdouniudissolve", func = "CpDouNiuDissolve"}
PacketCode[8150] = {server = 8149, client = 8150, des = "gccpdouniudissolve", func = "CpDouNiuDissolve"}

--回应解散房间请求  
PacketCode[8151] = {server = 8151, client = 8152, des = "cgcpdouniudissolveopt", func = "CpDouNiuDissolveOpt"}
PacketCode[8152] = {server = 8151, client = 8152, des = "gccpdouniudissolveopt", func = "CpDouNiuDissolveOpt"}


ReturnCode["cpdouniu_not_exist"] = 8101
ReturnCode[8101] = "该牌桌不存在"

ReturnCode["cpdouniu_full"] = 8102  			
ReturnCode[8102] = "该牌桌人数已满，请选择其他牌桌"

ReturnCode["cpdouniu_leave_state"] = 8103 		
ReturnCode[8103] = "请等待游戏结束再离开"

ReturnCode["cpdouniu_room_close"] = 8104 			
ReturnCode[8104] = "房间已经关闭，不能进入"

ReturnCode["cpdouniu_Jetton_overbrim"] = 8106		
ReturnCode[8106] = "您的金币太多了， 请到更高级的场去玩！！！！"
  
ReturnCode["cpdouniu_enter_error"] = 8107   
ReturnCode[8107] = "进入失败， 金币不足！"

ReturnCode["cpdouniu_banker_err"] = 8108   
ReturnCode[8108] = "抢庄失败，金币低于房间抢庄要求！"

ReturnCode["cpdouniu_sit_err"] = 8109   
ReturnCode[8109] = "该位置上已经有人！"

ReturnCode["cpdouniu_time_err"] = 8110  
ReturnCode[8110] = "请稍后再操作" 

ReturnCode["cpdouniu_operat_err"] = 8111 
ReturnCode[8111] = "操作失败" 

ReturnCode["cpdouniu_pos_ex"] = 8112
ReturnCode[8112] = "该位置已经被选择了" 

ReturnCode["cpdouniu_bankerjetton_error"] = 8113
ReturnCode[8113] = "您余额小于最低抢庄" 

ReturnCode["cpdouniu_baker_pour"] = 8114
ReturnCode[8114] = "庄家不用下注" 

ReturnCode["cpdouniu_bankermul_error"] = 8115
ReturnCode[8115] = "抢庄倍数太高了" 

ReturnCode["cpdouniu_select_err"] = 8116 
ReturnCode[8116] = "已选择完成" 

ReturnCode["cpdouniu_dissolve_fail"] = 8117 
ReturnCode[8117] = "该玩法不能解散" 

ReturnCode["cpdouniu_dissolve_fail2"] = 8118 
ReturnCode[8118] = "游戏开始后才能申请解散" 

ReturnCode["cpdouniu_dissolve_fail3"] = 8119
ReturnCode[8119] = "申请解散失败" 

ReturnCode["cpdouniu_create_error"] = 8120
ReturnCode[8120] = "创建房间失败，参数错误" 

ReturnCode["cpdouniu_enter_error1"] = 8121
ReturnCode[8121] = "进入房间失败，参数错误" 