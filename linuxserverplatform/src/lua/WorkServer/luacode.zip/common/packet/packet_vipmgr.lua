--9100~9200 vip
PacketCode[9101] = {server = 9101, client = 9102, des = "cgvipprivilege", func = "VipPrivilege"}
PacketCode[9102] = {server = 9101, client = 9102, des = "gcvipprivilege", func = "VipPrivilege"}

PacketCode[9103] = {server = 9103, client = 9104, des = "cgpointsrecords", func = "VipPointsRecords"}
PacketCode[9104] = {server = 9103, client = 9104, des = "gcpointsrecords", func = "VipPointsRecords"}
  