--7700~7799 是彩票百人牛牛的玩法
--进入游戏
PacketCode[7701] = {server = 7701, client = 7702, des = "cgcpbrnnenter", func = "CpBrnnEnter"}
PacketCode[7702] = {server = 7701, client = 7702, des = "gccpbrnnenter", func = "CpBrnnEnter"}

--离开游戏
PacketCode[7703] = {server = 7703, client = 7704, des = "cgcpbrnnleave", func = "CpBrnnLeave"}
PacketCode[7704] = {server = 7703, client = 7704, des = "gccpbrnnleave", func = "CpBrnnLeave"}

--开始游戏
PacketCode[7706] = {server = 7705, client = 7706, des = "gccpbrnnstart", func = "CpBrnnStart"}

--下注
PacketCode[7707] = {server = 7707, client = 7708, des = "cgcpbrnnpourjetton", func = "CpBrnnPourJetton"}
PacketCode[7708] = {server = 7707, client = 7708, des = "gccpbrnnpourjetton", func = "CpBrnnPourJetton"}

--更新各个区域的下注情况
PacketCode[7710] = {server = 7709, client = 7710, des = "gccpbrnngroupjetton", func = "CpBrnnGroupJetton"}

--获取开奖结果
PacketCode[7712] = {server = 7711, client = 7712, des = "gccpbrnngetawardresult", func = "CpBrnnGetAwardResul"}

--结算
PacketCode[7714] = {server = 7713, client = 7714, des = "gccpbrnncount", func = "CpBrnnCount"}

--上庄
PacketCode[7715] = {server = 7715, client = 7716, des = "cgcpbrnnbeingbanker", func = "CpBrnnBeingBanker"}
PacketCode[7716] = {server = 7715, client = 7716, des = "gccpbrnnbeingbanker", func = "CpBrnnBeingBanker"}

--下庄
PacketCode[7717] = {server = 7717, client = 7718, des = "cgcpbrnndropbanker", func = "CpBrnnDropBanker"}
PacketCode[7718] = {server = 7717, client = 7718, des = "gccpbrnndropbanker", func = "CpBrnnDropBanker"}

--游戏记录
PacketCode[7719] = {server = 7719, client = 7720, des = "cgcpbrnnhistory", func = "CpBrnnHistory"}
PacketCode[7720] = {server = 7719, client = 7720, des = "gccpbrnnhistory", func = "CpBrnnHistory"}

--聊天
PacketCode[7721] = {server = 7721, client = 7722, des = "cgcpbrnnchat", func = "CpBrnnChat"}
PacketCode[7722] = {server = 7721, client = 7722, des = "gccpbrnnchat", func = "CpBrnnChat"}

--上庄列表
PacketCode[7723] = {server = 7723, client = 7724, des = "cgcpbrnnbankerlist", func = "CpBrnnBankerList"}
PacketCode[7724] = {server = 7723, client = 7724, des = "gccpbrnnbankerlist", func = "CpBrnnBankerList"}

--投注记录
PacketCode[7725] = {server = 7725, client = 7726, des = "cgcpbrnnbetrecord", func = "CpBrnnBetRecord"}
PacketCode[7726] = {server = 7725, client = 7726, des = "gccpbrnnbetrecord", func = "CpBrnnBetRecord"}

--开奖记录
PacketCode[7727] = {server = 7727, client = 7728, des = "cgcpbrnnawardrecord", func = "CpBrnnAwardRecord"}
PacketCode[7728] = {server = 7727, client = 7728, des = "gccpbrnnawardrecord", func = "CpBrnnAwardRecord"}

--奖池变化
PacketCode[7729] = {server = 7729, client = 7730, des = "cgcpbrnnpoolmoneychange", func = "CpBrnnPoolChange"}
PacketCode[7730] = {server = 7729, client = 7730, des = "gccpbrnnpoolmoneychange", func = "CpBrnnPoolChange"}

--开大奖
PacketCode[7732] = {server = 7731, client = 7732, des = "gccpbrnnsendreward", func = "CpBrnnSendReward"}

--开奖分布
PacketCode[7733] = {server = 7733, client = 7734, des = "cgcpbrnnrewardgraph", func = "CpBrnnRewardGraph"}
PacketCode[7734] = {server = 7733, client = 7734, des = "gccpbrnnrewardgraph", func = "CpBrnnRewardGraph"}

--我的中奖记录
PacketCode[7735] = {server = 7735, client = 7736, des = "cgcpbrnnrewardrecords", func = "CpBrnnRewardRecords"}
PacketCode[7736] = {server = 7735, client = 7736, des = "gccpbrnnrewardrecords", func = "CpBrnnRewardRecords"}

--获取站立的列表信息
PacketCode[7737] = {server = 7737, client = 7738, des = "cgcpbrnnstandlist", func = "CpBrnnStandList"}
PacketCode[7738] = {server = 7737, client = 7738, des = "gccpbrnnstandlist", func = "CpBrnnStandList"}


--游戏错误码
ReturnCode["cpbrnn_not_exist"] = 7701
ReturnCode[7701] = "该牌桌不存在"

ReturnCode["cpbrnn_state_notpour"] = 7702
ReturnCode[7702] = "请稍后再下注"

ReturnCode["cpbrnn_jetton_notenough"] = 7703
ReturnCode[7703] = "您的余额不足"

ReturnCode["cpbrnn_pourtype_error"] = 7704
ReturnCode[7704] = "下注失败，请选择正确的下注区域"

ReturnCode["cpbrnn_behanker_list"] = 7705
ReturnCode[7705] = "已加入上庄列表"

ReturnCode["cpbrnn_pour_banker"] = 7706
ReturnCode[7706] = "庄家不能下注"

ReturnCode["cpbrnn_banker_notenough1"] = 7707
ReturnCode[7707] = "金币不足，最低上庄需要5000金币"

ReturnCode["cpbrnn_pour_lose"] = 7708
ReturnCode[7708] = "已达下注上限，下注失败"

ReturnCode["cpbrnn_is_full"] = 7709
ReturnCode[7709] = "该牌桌人数已满，请选择其他牌桌"

ReturnCode["cpbrnn_is_bankerlist"] = 7710
ReturnCode[7710] = "您已经加入上庄列表中，请耐心等着"

ReturnCode["cpbrnn_jetton_error_1"] = 7711
ReturnCode[7711] = "金币不足，无法进入房间"

ReturnCode["cpbrnn_jetton_error_2"] = 7712  --金币太多，无法进人房间
ReturnCode[7712] = "金币太多，无法进入房间"

ReturnCode["cpbrnn_not_banker"] = 7713 
ReturnCode[7713] = "您还不是庄家呢"  

ReturnCode["cpbrnn_is_drop"] = 7714
ReturnCode[7714] = "您已经申请下庄了"  

ReturnCode["cpbrnn_drop_success"] = 7715
ReturnCode[7715] = "申请下庄成功"  

ReturnCode["cpbrnn_bebankeer_success"] = 7716
ReturnCode[7716] = "申请上庄成功"  

ReturnCode["cpbrnn_pour_max"] = 7717
ReturnCode[7717] = "已经超过下注限额，请选择更小的面值"  

ReturnCode["cpbrnn_banker_leave"] = 7718
ReturnCode[7718] = "请先下庄，再离开游戏"  

ReturnCode["cpbrnn_bankerlist_dorp"] = 7719
ReturnCode[7719] = "已经离开的申请上庄列表"  

ReturnCode["cpbrnn_is_pour"] = 7720
ReturnCode[7720] = "您已下注，请结算后离开" 

ReturnCode["cpbrnn_banker_notenough"] = 7721
ReturnCode[7721] = "庄家余额不足"
 
