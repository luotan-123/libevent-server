--8000~8100 是彩票红黑大战的玩法
--进入游戏
PacketCode[8001] = {server = 8001, client = 8002, des = "cgcphongheienter", func = "CpHongheiEnter"}
PacketCode[8002] = {server = 8001, client = 8002, des = "gccphongheienter", func = "CpHongheiEnter"}

--离开游戏
PacketCode[8003] = {server = 8003, client = 8004, des = "cgcphongheileave", func = "CpHongheiLeave"}
PacketCode[8004] = {server = 8003, client = 8004, des = "gccphongheileave", func = "CpHongheiLeave"}

--开始游戏
PacketCode[8006] = {server = 8005, client = 8006, des = "gccphongheistart", func = "CpHongheiStart"}

--下注
PacketCode[8007] = {server = 8007, client = 8008, des = "cgcphongheipourjetton", func = "CpHongheiPourJetton"}
PacketCode[8008] = {server = 8007, client = 8008, des = "gccphongheipourjetton", func = "CpHongheiPourJetton"}

--更新各个区域的下注情况
PacketCode[8010] = {server = 8009, client = 8010, des = "gccphongheigroupjetton", func = "CpHongheiGroupJetton"}

--获取开奖结果
PacketCode[8012] = {server = 8011, client = 8012, des = "gccphongheigetawardresult", func = "CpHongheiGetAwardResul"}

--结算
PacketCode[8014] = {server = 8013, client = 8014, des = "gccphongheicount", func = "CpHongheiCount"}

--上庄
PacketCode[8015] = {server = 8015, client = 8016, des = "cgcphongheibeingbanker", func = "CpHongheiBeingBanker"}
PacketCode[8016] = {server = 8015, client = 8016, des = "gccphongheibeingbanker", func = "CpHongheiBeingBanker"}

--下庄
PacketCode[8017] = {server = 8017, client = 8018, des = "cgcphongheidropbanker", func = "CpHongheiDropBanker"}
PacketCode[8018] = {server = 8017, client = 8018, des = "gccphongheidropbanker", func = "CpHongheiDropBanker"}

--游戏记录
PacketCode[8019] = {server = 8019, client = 8020, des = "cgcphongheihistory", func = "CpHongheiHistory"}
PacketCode[8020] = {server = 8019, client = 8020, des = "gccphongheihistory", func = "CpHongheiHistory"}

--聊天
PacketCode[8021] = {server = 8021, client = 8022, des = "cgcphongheichat", func = "CpHongheiChat"}
PacketCode[8022] = {server = 8021, client = 8022, des = "gccphongheichat", func = "CpHongheiChat"}

--上庄列表
PacketCode[8023] = {server = 8023, client = 8024, des = "cgcphongheibankerlist", func = "CpHongheiBankerList"}
PacketCode[8024] = {server = 8023, client = 8024, des = "gccphongheibankerlist", func = "CpHongheiBankerList"}

--投注记录
PacketCode[8025] = {server = 8025, client = 8026, des = "cgcphongheibetrecord", func = "CpHongheiBetRecord"}
PacketCode[8026] = {server = 8025, client = 8026, des = "gccphongheibetrecord", func = "CpHongheiBetRecord"}

--开奖记录
PacketCode[8027] = {server = 8027, client = 8028, des = "cgcphongheiawardrecord", func = "CpHongheiAwardRecord"}
PacketCode[8028] = {server = 8027, client = 8028, des = "gccphongheiawardrecord", func = "CpHongheiAwardRecord"}

--获取站立的列表信息
PacketCode[8029] = {server = 8029, client = 8030, des = "cgcphongheistandlist", func = "CpHongheiStandList"}
PacketCode[8030] = {server = 8029, client = 8030, des = "gccphongheistandlist", func = "CpHongheiStandList"}


--游戏错误码
ReturnCode["cphonghei_not_exist"] = 8001
ReturnCode[8001] = "该牌桌不存在"

ReturnCode["cphonghei_state_notpour"] = 8002
ReturnCode[8002] = "请稍后再下注"

ReturnCode["cphonghei_jetton_notenough"] = 8003
ReturnCode[8003] = "您的余额不足"

ReturnCode["cphonghei_pourtype_error"] = 8004
ReturnCode[8004] = "下注失败，请选择正确的下注区域"

ReturnCode["cphonghei_behanker_list"] = 8005
ReturnCode[8005] = "已加入上庄列表"

ReturnCode["cphonghei_pour_banker"] = 8006
ReturnCode[8006] = "庄家不能下注"

ReturnCode["cphonghei_banker_notenough"] = 8007
ReturnCode[8007] = "金币不足，最低上庄需要3000金币"

ReturnCode["cphonghei_pour_lose"] = 8008
ReturnCode[8008] = "已达下注上限，下注失败"

ReturnCode["cphonghei_is_full"] = 8009
ReturnCode[8009] = "该牌桌人数已满，请选择其他牌桌"

ReturnCode["cphonghei_is_bankerlist"] = 8010
ReturnCode[8010] = "您已经加入上庄列表中，请耐心等着"

ReturnCode["cphonghei_jetton_error_1"] = 8011
ReturnCode[8011] = "金币不足，无法进入房间"

ReturnCode["cphonghei_jetton_error_2"] = 8012  --金币太多，无法进人房间
ReturnCode[8012] = "金币太多，无法进入房间"

ReturnCode["cphonghei_not_banker"] = 8013 
ReturnCode[8013] = "您还不是庄家呢"  

ReturnCode["cphonghei_is_drop"] = 8014
ReturnCode[8014] = "您已经申请下庄了"  

ReturnCode["cphonghei_drop_success"] = 8015
ReturnCode[8015] = "申请下庄成功"  

ReturnCode["cphonghei_bebankeer_success"] = 8016
ReturnCode[8016] = "申请上庄成功"  

ReturnCode["cphonghei_pour_max"] = 8017
ReturnCode[8017] = "已经超过下注限额，请选择更小的面值"  

ReturnCode["cphonghei_banker_leave"] = 8018
ReturnCode[8018] = "请先下庄，再离开游戏"  

ReturnCode["cphonghei_limitred"] = 8019
ReturnCode[8019] = "该区域已超过限红，请下别的区域！"  

ReturnCode["cphonghei_banker_jetton"] = 8020
ReturnCode[8020] = "该区域已超过庄家可赔额度，请下别的区域！"  

ReturnCode["cphonghei_bankerlist_dorp"] = 8021
ReturnCode[8021] = "已经离开的申请上庄列表"  

ReturnCode["cphonghei_is_pour"] = 8022
ReturnCode[8022] = "您已下注，请结算后离开"  

ReturnCode["cphonghei_nobanker_pourerr"] = 8023
ReturnCode[8023] = "无庄的时候不能下幸运一击！"  