--彩票百人牛牛

g_cpbrnnDefine = {}

g_cpbrnnDefine.game_type = 7700   						--协议号
g_cpbrnnDefine.gamekey = 5								--彩种
g_cpbrnnDefine.pour_type = {1,2,3,4}					--下注区域列表

--现在，我们初始化的牌桌数量有我们自己指定创建，没有必要动态创建，后期看需要加入到数据库中动态创建
g_cpbrnnDefine.init_data = {}                 			--初始化的数据，一开始初始化三个类型的牌桌，先初始化一个
g_cpbrnnDefine.init_data[1] = {}

g_cpbrnnDefine.init_data[1]['tableid'] = 2051001     	--房间ID
g_cpbrnnDefine.init_data[1]['maxuser'] = 99				--最大人数
g_cpbrnnDefine.init_data[1]['banklimit'] = 500000		--最低上庄
g_cpbrnnDefine.init_data[1]['enterlimit'] = 0			--牌桌准入
g_cpbrnnDefine.init_data[1]['entermax'] = 999999999		--最大准入
g_cpbrnnDefine.init_data[1]['tabletype'] = 1			--牌桌类型
g_cpbrnnDefine.init_data[1]['limitred'] = 999999999		--限红

g_cpbrnnDefine.state_ready = 1    						--准备状态
g_cpbrnnDefine.state_start = 2							--开始状态
g_cpbrnnDefine.state_pour = 3      						--下注状态	
g_cpbrnnDefine.state_wait = 4      						--取结果状态
g_cpbrnnDefine.state_count = 5      					--结算状态

g_cpbrnnDefine.time_ready = 1 							--准备时间
g_cpbrnnDefine.time_start = 2 							--开始时间
g_cpbrnnDefine.time_count = 10 							--结算时间

g_cpbrnnDefine.robot_range = { {20000, 800000} }		--机器人的进入范围

g_cpbrnnDefine.chat_txt = 1
g_cpbrnnDefine.chat_img = 2
g_cpbrnnDefine.chat_voice = 3

g_cpbrnnDefine.quit_count  = 15    						--最大连续不投轮数
g_cpbrnnDefine.dropbanker_count  = 5     				--最大上庄轮数
g_cpbrnnDefine.timeout_count  = 10    					--最大超时不结算时间
g_cpbrnnDefine.max_rate  = 11   						--最大倍数
g_cpbrnnDefine.start_cardnum  = 3    					--开始发多少张票

g_cpbrnncard_type = {}
g_cpbrnncard_type.wu_niu = 0     				--无牛
g_cpbrnncard_type.niu_yi = 1     				--牛一
g_cpbrnncard_type.niu_er = 2     				--牛二
g_cpbrnncard_type.niu_san = 3    				--牛三
g_cpbrnncard_type.niu_si = 4     				--牛四
g_cpbrnncard_type.niu_wu = 5     				--牛五
g_cpbrnncard_type.niu_liu = 6   			 	--牛六
g_cpbrnncard_type.niu_qi = 7     				--牛七
g_cpbrnncard_type.niu_ba = 8     				--牛八
g_cpbrnncard_type.niu_jiu = 9    				--牛九
g_cpbrnncard_type.niu_niu = 10   				--牛牛
g_cpbrnncard_type.shun_zi = 11   				--顺子牛
g_cpbrnncard_type.wu_hua = 12   				--五花牛
g_cpbrnncard_type.tong_hua = 13   				--同花牛
g_cpbrnncard_type.hu_lu = 14   					--葫芦牛
g_cpbrnncard_type.zha_dan = 15   				--炸弹牛
g_cpbrnncard_type.wu_xiao = 16    				--五小牛
g_cpbrnncard_type.tonghua_shun = 17    			--同花顺牛

g_cpbrnncard_type.win_rate = {}  --这个是低倍场赔率
g_cpbrnncard_type.win_rate[0] = 2
g_cpbrnncard_type.win_rate[1] = 2
g_cpbrnncard_type.win_rate[2] = 2
g_cpbrnncard_type.win_rate[3] = 2
g_cpbrnncard_type.win_rate[4] = 2
g_cpbrnncard_type.win_rate[5] = 2
g_cpbrnncard_type.win_rate[6] = 2
g_cpbrnncard_type.win_rate[7] = 3
g_cpbrnncard_type.win_rate[8] = 3
g_cpbrnncard_type.win_rate[9] = 4
g_cpbrnncard_type.win_rate[10] = 5
g_cpbrnncard_type.win_rate[11] = 6
g_cpbrnncard_type.win_rate[12] = 7
g_cpbrnncard_type.win_rate[13] = 8
g_cpbrnncard_type.win_rate[14] = 9
g_cpbrnncard_type.win_rate[15] = 10
g_cpbrnncard_type.win_rate[16] = 11
g_cpbrnncard_type.win_rate[17] = 12

--标志是否有正在执行的任务
g_cpbrnnDefine.game_lockstate = {}
g_cpbrnnDefine.game_lockstate.lock_no = 1
g_cpbrnnDefine.game_lockstate.lock_yes = 2