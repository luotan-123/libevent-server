--彩票龙虎斗

g_cplhdDefine = {}

g_cplhdDefine.game_type = 7800   						--协议号
g_cplhdDefine.gamekey = 5								--彩种
g_cplhdDefine.pour_type = {1,2,3} 						-- 龙、虎、和

--现在，我们初始化的牌桌数量有我们自己指定创建，没有必要动态创建，后期看需要加入到数据库中动态创建
g_cplhdDefine.init_data = {}                 			--初始化的数据，一开始初始化三个类型的牌桌，先初始化一个
g_cplhdDefine.init_data[1] = {}

g_cplhdDefine.init_data[1]['tableid'] = 2061001     	--房间ID
g_cplhdDefine.init_data[1]['maxuser'] = 99				--最大人数
g_cplhdDefine.init_data[1]['banklimit'] = 100000		--最低上庄
g_cplhdDefine.init_data[1]['enterlimit'] = 0			--牌桌准入
g_cplhdDefine.init_data[1]['entermax'] = 999999999		--最大准入
g_cplhdDefine.init_data[1]['tabletype'] = 1				--牌桌类型
g_cplhdDefine.init_data[1]['limitred'] = 999999999		--限红

g_cplhdDefine.state_ready = 1    						--准备状态
g_cplhdDefine.state_start = 2							--开始状态
g_cplhdDefine.state_pour = 3      						--下注状态	
g_cplhdDefine.state_wait = 4      						--取结果状态
g_cplhdDefine.state_count = 5      						--结算状态

g_cplhdDefine.time_ready = 1 							--准备时间
g_cplhdDefine.time_start = 2 							--开始时间
g_cplhdDefine.time_count = 10 							--结算时间

g_cplhdDefine.robot_range = { {20000, 800000} }			--机器人的进入范围

g_cplhdDefine.chat_txt = 1
g_cplhdDefine.chat_img = 2
g_cplhdDefine.chat_voice = 3

g_cplhdDefine.quit_count  = 15     						--最大连续不投轮数
g_cplhdDefine.dropbanker_count  = 5     				--最大上庄轮数
g_cplhdDefine.timeout_count  = 10    					--最大超时不结算时间

g_cplhdDefine.lines = {}
g_cplhdDefine.lines[1] = 2    							--龙
g_cplhdDefine.lines[2] = 2    							--虎
g_cplhdDefine.lines[3] = 9    							--和

--标志是否有正在执行的任务
g_cplhdDefine.game_lockstate = {}
g_cplhdDefine.game_lockstate.lock_no = 1
g_cplhdDefine.game_lockstate.lock_yes = 2
