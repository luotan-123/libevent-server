--彩票采集
g_collectionDefine = {}

g_collectionDefine.game_lockstate = {}
g_collectionDefine.game_lockstate.lock_no = 1
g_collectionDefine.game_lockstate.lock_yes = 2

g_collectionDefine.httpUrl = "http://47.244.218.158/api/"
g_collectionDefine.next = "cp/code/next?name="
g_collectionDefine.open = "cp/code/open?name="

g_collectionDefine.gametype = {}
g_collectionDefine.gametype[4] = "msft"
g_collectionDefine.gametype[5] = "jsft"