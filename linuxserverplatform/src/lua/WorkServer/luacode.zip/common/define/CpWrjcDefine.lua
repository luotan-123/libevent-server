--万人竞猜

g_cpwrjcDefine = {}

g_cpwrjcDefine.game_type = 8400   						--协议号
g_cpwrjcDefine.gamekey = 5								--彩种
g_cpwrjcDefine.pour_type = {1,2,3,4,5,6,7,8,9,10}					--下注区域列表



g_cpwrjcDefine.state_ready = 0    						--准备状态
g_cpwrjcDefine.state_pour = 1     						--下注状态	
g_cpwrjcDefine.state_count = 2      					--开奖结算状态

g_cpwrjcDefine.time_ready = 1 							--准备时间
g_cpwrjcDefine.time_start = 2 							--开始时间
g_cpwrjcDefine.time_count = 10 							--结算时间

g_cpwrjcDefine.robot_range = {1000, 800000}		--机器人的进入范围

g_cpwrjcDefine.chat_txt = 1
g_cpwrjcDefine.chat_img = 2
g_cpwrjcDefine.chat_voice = 3

g_cpwrjcDefine.quit_count  = 15    						--最大连续不投轮数
g_cpwrjcDefine.dropbanker_count  = 5     				--最大上庄轮数
g_cpwrjcDefine.timeout_count  = 30    					--最大超时不结算时间
g_cpwrjcDefine.max_rate  = 6    						--最大倍数
g_cpwrjcDefine.start_cardnum  = 3    					--开始发多少张票


--标志是否有正在执行的任务
g_cpwrjcDefine.game_lockstate = {}
g_cpwrjcDefine.game_lockstate.lock_no = 1
g_cpwrjcDefine.game_lockstate.lock_yes = 2