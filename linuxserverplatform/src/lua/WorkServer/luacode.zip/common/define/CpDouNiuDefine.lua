--彩票牛牛玩法
g_cpdouniuDefine = {}

g_cpdouniuDefine.gametype_classic = 8100	   				--经典牛牛
g_cpdouniuDefine.gametype_insane = 8101	   					--激情牛牛
g_cpdouniuDefine.gametype_king = 8102	   					--王者牛牛
g_cpdouniuDefine.gametype_friend = 8103	   					--王者牛牛

g_cpdouniuDefine.gamekey = 5								--彩种
			
g_cpdouniuDefine.type_nnsz = 101    						--牛牛上庄
g_cpdouniuDefine.type_gdzj = 102    						--固定庄家
g_cpdouniuDefine.type_zyqz = 103    						--自由抢庄
g_cpdouniuDefine.type_mpqz = 104    						--看牌抢庄
g_cpdouniuDefine.type_tbnn = 105    						--通比牛牛

g_cpdouniuDefine.state_ready = 1							--准备状态
g_cpdouniuDefine.state_start  = 2     						--开始状态
g_cpdouniuDefine.state_banker = 3    						--抢庄状态
g_cpdouniuDefine.state_select = 4							--选位置状态
g_cpdouniuDefine.state_pour = 5    							--下注状态
g_cpdouniuDefine.state_collection = 6    					--采集状态
g_cpdouniuDefine.state_play  = 7							--看牌状态
g_cpdouniuDefine.state_count  = 8							--结算状态  
g_cpdouniuDefine.state_next = 9								--休息状态
g_cpdouniuDefine.state_delete  = 10    						--删除状态
g_cpdouniuDefine.state_dissolve  = 11    					--解散状态

g_cpdouniuDefine.time_start = 1      						--开始时间
g_cpdouniuDefine.time_select = 25     						--选位置时间
g_cpdouniuDefine.time_banker = 5							--抢庄时间
g_cpdouniuDefine.time_pour = 5    							--下注时间
g_cpdouniuDefine.time_play = 8								--看牌时间
g_cpdouniuDefine.time_count = 2								--结算时间
g_cpdouniuDefine.time_next = 7								--休息时间
g_cpdouniuDefine.time_dissolve = 120						--解散时间

g_cpdouniuDefine.player_enter = 101   						--刚进入状态
g_cpdouniuDefine.player_ready = 102   						--准备完状态
g_cpdouniuDefine.player_banker = 103						--抢庄完状态
g_cpdouniuDefine.player_select = 104   						--位置选完状态
g_cpdouniuDefine.player_pour = 105   						--下注完状态
g_cpdouniuDefine.player_play = 106							--亮牌完状态


g_cpdouniuDefine.max_user = 8								--最大人数
g_cpdouniuDefine.posnum = 1									--选位置数量
g_cpdouniuDefine.poscount = 20								--公共牌数量
g_cpdouniuDefine.timeout_count  = 10    					--最大超时不结算时间

g_cpdouniuDefine.cardtype_zero = 0     						--无牛
g_cpdouniuDefine.cardtype_one = 1     						--牛一
g_cpdouniuDefine.cardtype_two = 2     						--牛二
g_cpdouniuDefine.cardtype_three = 3    						--牛三
g_cpdouniuDefine.cardtype_four = 4     						--牛四
g_cpdouniuDefine.cardtype_five = 5     						--牛五
g_cpdouniuDefine.cardtype_six = 6    						--牛六
g_cpdouniuDefine.cardtype_seven = 7     					--牛七
g_cpdouniuDefine.cardtype_eight = 8     					--牛八
g_cpdouniuDefine.cardtype_nine = 9   						--牛九
g_cpdouniuDefine.cardtype_ten = 10  						--牛牛
g_cpdouniuDefine.cardtype_shunzi = 11  						--顺子牛
g_cpdouniuDefine.cardtype_wuhua = 12  						--五花牛
g_cpdouniuDefine.cardtype_tonghua = 13  					--同花牛
g_cpdouniuDefine.cardtype_hulu = 14  						--葫芦牛
g_cpdouniuDefine.cardtype_zhadan = 15  						--炸弹牛
g_cpdouniuDefine.cardtype_wuxiao = 16  						--五小牛
g_cpdouniuDefine.cardtype_tonghuashun = 17  				--同花顺牛

g_cpdouniuDefine.chat_txt = 1								--聊天文字				
g_cpdouniuDefine.chat_img = 2								--聊天图片
g_cpdouniuDefine.chat_voice = 3								--聊天语音

g_cpdouniuDefine.startEnter_yes = 1							--开始禁入
g_cpdouniuDefine.startEnter_no = 0							--开始可入

g_cpdouniuDefine.autoReady_yes = 1							--自动准备
g_cpdouniuDefine.autoReady_no = 0							--手动准备

g_cpdouniuDefine.watchEnter_yes = 1							--观战
g_cpdouniuDefine.watchEnter_no = 0							--参战


g_cpdouniuDefine.autoShow_yes = 1 							--自动亮牌
g_cpdouniuDefine.autoShow_no = 0 							--手动亮牌

g_cpdouniuDefine.forbidShow_yes = 1 						--禁止亮牌
g_cpdouniuDefine.forbidShow_no = 0 							--可以亮牌

g_cpdouniuDefine.trusteeship_yes = 1						--托管
g_cpdouniuDefine.trusteeship_no = 0							--自管

g_cpdouniuDefine.tableType_primary = 1						--初级场
g_cpdouniuDefine.tableType_intermediate = 2					--中级场
g_cpdouniuDefine.tableType_advanced = 3						--高级场
g_cpdouniuDefine.tableType_Extreme = 4						--至尊场
g_cpdouniuDefine.tableType_super = 5						--超级场

g_cpdouniuDefine.pourList = {}
g_cpdouniuDefine.pourList[1] = "1/2/3/4"					--初级场下注列表
g_cpdouniuDefine.pourList[2] = "1/2/3/4"					--中级场下注列表
g_cpdouniuDefine.pourList[3] = "1/2/3/4"					--高级场下注列表
g_cpdouniuDefine.pourList[4] = "1/2/3/4"					--至尊场下注列表
g_cpdouniuDefine.pourList[5] = "1/2/3/4"					--超级场下注列表

g_cpdouniuDefine.difen = {}
g_cpdouniuDefine.difen[1] = 100								--初级场默认底分
g_cpdouniuDefine.difen[2] = 200								--中级场默认底分
g_cpdouniuDefine.difen[3] = 500								--高级场默认底分
g_cpdouniuDefine.difen[4] = 1000							--至尊场默认底分
g_cpdouniuDefine.difen[5] = 2000							--超级场默认底分


g_cpdouniuDefine.minEnterJetton = {}
g_cpdouniuDefine.minEnterJetton[1] = 2500					--初级场最低准入
g_cpdouniuDefine.minEnterJetton[2] = 5000					--中级场最低准入
g_cpdouniuDefine.minEnterJetton[3] = 25000					--高级场最低准入
g_cpdouniuDefine.minEnterJetton[4] = 50000					--至尊场最低准入
g_cpdouniuDefine.minEnterJetton[5] = 100000					--超级场最低准入


g_cpdouniuDefine.MaxEnterJetton = {}
g_cpdouniuDefine.MaxEnterJetton[1] = -1						--初级场最高准入
g_cpdouniuDefine.MaxEnterJetton[2] = -1						--中级场最高准入
g_cpdouniuDefine.MaxEnterJetton[3] = -1						--高级场最高准入
g_cpdouniuDefine.MaxEnterJetton[4] = -1						--至尊场最高准入
g_cpdouniuDefine.MaxEnterJetton[5] = -1						--超级场最高准入

g_cpdouniuDefine.robotEnterJetton = {}
g_cpdouniuDefine.robotEnterJetton[1] = {2500, 10000}		--初级场机器人进入范围
g_cpdouniuDefine.robotEnterJetton[2] = {5000, 40000}		--中级场机器人进入范围
g_cpdouniuDefine.robotEnterJetton[3] = {25000, 100000}		--高级场机器人进入范围
g_cpdouniuDefine.robotEnterJetton[4] = {50000, 200000}		--至尊场机器人进入范围
g_cpdouniuDefine.robotEnterJetton[5] = {100000, 500000}		--超级场机器人进入范围


g_cpdouniuDefine.game_lockstate = {}
g_cpdouniuDefine.game_lockstate.lock_no = 1
g_cpdouniuDefine.game_lockstate.lock_yes = 2 
