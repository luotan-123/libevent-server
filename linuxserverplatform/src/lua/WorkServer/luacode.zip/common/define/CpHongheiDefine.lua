--彩票红黑大战

g_cphongheiDefine = {}

g_cphongheiDefine.game_type = 8000   						--协议号
g_cphongheiDefine.gamekey = 5								--彩种
g_cphongheiDefine.pour_type = {1,2,3}					    --红、黑、幸运一击

--现在，我们初始化的牌桌数量有我们自己指定创建，没有必要动态创建，后期看需要加入到数据库中动态创建
g_cphongheiDefine.init_data = {}                 			--初始化的数据，一开始初始化三个类型的牌桌，先初始化一个
g_cphongheiDefine.init_data[1] = {}

g_cphongheiDefine.init_data[1]['tableid'] = 2081001     	--房间ID
g_cphongheiDefine.init_data[1]['maxuser'] = 99				--最大人数
g_cphongheiDefine.init_data[1]['banklimit'] = 300000		--最低上庄
g_cphongheiDefine.init_data[1]['enterlimit'] = 0			--牌桌准入
g_cphongheiDefine.init_data[1]['entermax'] = 999999999		--最大准入
g_cphongheiDefine.init_data[1]['tabletype'] = 1				--牌桌类型
g_cphongheiDefine.init_data[1]['limitred'] = 999999999		--限红

g_cphongheiDefine.state_ready = 1    						--准备状态
g_cphongheiDefine.state_start = 2							--开始状态
g_cphongheiDefine.state_pour = 3      						--下注状态	
g_cphongheiDefine.state_wait = 4      						--取结果状态
g_cphongheiDefine.state_count = 5      					    --结算状态

g_cphongheiDefine.time_ready = 1 							--准备时间
g_cphongheiDefine.time_start = 2 							--开始时间
g_cphongheiDefine.time_count = 10 							--结算时间

g_cphongheiDefine.robot_range = { {20000, 800000} }			--机器人的进入范围

g_cphongheiDefine.chat_txt = 1
g_cphongheiDefine.chat_img = 2
g_cphongheiDefine.chat_voice = 3

g_cphongheiDefine.quit_count  = 15     						--最大连续不投轮数
g_cphongheiDefine.dropbanker_count  = 5     				--最大上庄轮数
g_cphongheiDefine.timeout_count  = 10    					--最大超时不结算时间
g_cphongheiDefine.max_rate  = 10    						--最大倍数


g_cphongheicard_type = {}

g_cphongheicard_type.teshu = 1    							--特殊牌
g_cphongheicard_type.danzhang = 2     						--单张
g_cphongheicard_type.duizi = 3     							--对子
g_cphongheicard_type.shunzi = 4    							--顺子
g_cphongheicard_type.tonghua = 5    						--同花
g_cphongheicard_type.tonghuashun = 6   						--同花顺
g_cphongheicard_type.baozi = 7     							--豹子


g_cphongheicard_type.win_rate = {}    						
g_cphongheicard_type.win_rate[1] = 2  						--特殊牌
g_cphongheicard_type.win_rate[2] = 2  						--单张
g_cphongheicard_type.win_rate[3] = 2  						--对子
g_cphongheicard_type.win_rate[4] = 3  						--顺子
g_cphongheicard_type.win_rate[5] = 4  						--同花(金花)    
g_cphongheicard_type.win_rate[6] = 6  						--同花顺(顺金)
g_cphongheicard_type.win_rate[7] = 11 						--豹子


--标志是否有正在执行的任务
g_cphongheiDefine.game_lockstate = {}
g_cphongheiDefine.game_lockstate.lock_no = 1
g_cphongheiDefine.game_lockstate.lock_yes = 2