--彩票百人牛牛

g_cpbjlDefine = {}

g_cpbjlDefine.game_type = 7900   						--协议号
g_cpbjlDefine.gamekey = 5								--彩种
g_cpbjlDefine.pour_type = {1,2,3,4,5}					--下注区域列表 庄, 闲, 和, 庄对，闲对

--现在，我们初始化的牌桌数量有我们自己指定创建，没有必要动态创建，后期看需要加入到数据库中动态创建
g_cpbjlDefine.init_data = {}                 			--初始化的数据，一开始初始化三个类型的牌桌，先初始化一个
g_cpbjlDefine.init_data[1] = {}

g_cpbjlDefine.init_data[1]['tableid'] = 2071001     	--房间ID
g_cpbjlDefine.init_data[1]['maxuser'] = 99				--最大人数
g_cpbjlDefine.init_data[1]['banklimit'] = 300000		--最低上庄
g_cpbjlDefine.init_data[1]['enterlimit'] = 0			--牌桌准入
g_cpbjlDefine.init_data[1]['entermax'] = 999999999		--最大准入
g_cpbjlDefine.init_data[1]['tabletype'] = 1				--牌桌类型
g_cpbjlDefine.init_data[1]['limitred'] = 999999999		--限红

g_cpbjlDefine.state_ready = 1    						--准备状态
g_cpbjlDefine.state_start = 2							--开始状态
g_cpbjlDefine.state_pour = 3      						--下注状态	
g_cpbjlDefine.state_wait = 4      						--取结果状态
g_cpbjlDefine.state_count = 5      						--结算状态

g_cpbjlDefine.time_ready = 1 							--准备时间
g_cpbjlDefine.time_start = 2 							--开始时间
g_cpbjlDefine.time_count = 10 							--结算时间

g_cpbjlDefine.robot_range = { {20000, 800000} }		--机器人的进入范围

g_cpbjlDefine.chat_txt = 1
g_cpbjlDefine.chat_img = 2
g_cpbjlDefine.chat_voice = 3

g_cpbjlDefine.quit_count  = 15     					--最大连续不投轮数
g_cpbjlDefine.dropbanker_count  = 5     				--最大上庄轮数
g_cpbjlDefine.timeout_count  = 10    					--最大超时不结算时间

g_cpbjlDefine.lines = {}
g_cpbjlDefine.lines[1] = 2    		--庄
g_cpbjlDefine.lines[2] = 2    		--闲
g_cpbjlDefine.lines[3] = 9    		--和
g_cpbjlDefine.lines[4] = 12   		--庄对
g_cpbjlDefine.lines[5] = 12    		--闲对

--标志是否有正在执行的任务
g_cpbjlDefine.game_lockstate = {}
g_cpbjlDefine.game_lockstate.lock_no = 1
g_cpbjlDefine.game_lockstate.lock_yes = 2