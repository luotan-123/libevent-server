g_expertDefine = {}
g_expertDefine.game_type = 8600   