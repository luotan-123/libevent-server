--彩票

g_caipiaoDefine = {}
--牌桌状态
g_caipiaoDefine.state_maintenance   = 1   --维护中状态
g_caipiaoDefine.state_pour          = 2   --下注状态
g_caipiaoDefine.state_fengpan       = 3   --封盘状态


g_caipiaoDefine.game_type           = 9200   			--彩票类型
g_caipiaoDefine.award_existtime     = 24 * 60 * 60      --彩票开奖结果生存周期（s）
g_caipiaoDefine.history_count       = 20                --彩票开奖历史数据条数

g_caipiaoDefine.liushui_mode        = 1                 --流水模式 0 全部下注额 1 下注的四分之一
g_caipiaoDefine.choushui_mode       = 0                 --是否抽水反佣 0 不抽水 1 抽水

g_caipiaoDefine.httpUrl             = "http://47.244.218.158/api/"
g_caipiaoDefine.nextinfo            = "cp/code/next?name="
g_caipiaoDefine.openinfo            = "cp/code/open?name="



g_caipiaoDefine.gamekey = {}							--彩种
--PK10 4个
g_caipiaoDefine.gamekey[1] = 1 				            --幸运飞艇
g_caipiaoDefine.gamekey[2] = 2 				            --六合彩
g_caipiaoDefine.gamekey[3] = 3 				            --北京赛车(北京Pk10)
g_caipiaoDefine.gamekey[4] = 4 				            --秒速飞艇
g_caipiaoDefine.gamekey[5] = 5 				            --极速飞艇
--时时彩 8个 SSC	 
g_caipiaoDefine.gamekey[6] = 6 				            --幸运分分彩
g_caipiaoDefine.gamekey[7] = 7 				            --腾讯分分彩
g_caipiaoDefine.gamekey[8] = 8 				            --幸运5分钟
g_caipiaoDefine.gamekey[9] = 9 				            --河内五分钟
g_caipiaoDefine.gamekey[10] = 10 				        --重庆欢乐生肖
g_caipiaoDefine.gamekey[11] = 11 				        --天津时时彩
g_caipiaoDefine.gamekey[12] = 12 				        --新疆时时彩
g_caipiaoDefine.gamekey[13] = 13 				        --黑龙江时时彩
--六合彩  LHC
g_caipiaoDefine.gamekey[14] = 14 				        --六合5分彩
--11选5 6个 11X5
g_caipiaoDefine.gamekey[15] = 15 				        --极速11选5
g_caipiaoDefine.gamekey[16] = 16 				        --幸运11选5
g_caipiaoDefine.gamekey[17] = 17 				        --广东11选5
g_caipiaoDefine.gamekey[18] = 18 				        --山东11选5
g_caipiaoDefine.gamekey[19] = 19 				        --江西11选5
g_caipiaoDefine.gamekey[20] = 20 				        --广西11选5
--快三 6个 K3
g_caipiaoDefine.gamekey[21] = 21 				        --秒速快三
g_caipiaoDefine.gamekey[22] = 22 				        --幸运快三
g_caipiaoDefine.gamekey[23] = 23 				        --江苏快三
g_caipiaoDefine.gamekey[24] = 24 				        --安徽快三
g_caipiaoDefine.gamekey[25] = 25 				        --广西快三
g_caipiaoDefine.gamekey[26] = 26 				        --吉林快三
--3D 4个     3D
g_caipiaoDefine.gamekey[27] = 27 				        --极速3D
g_caipiaoDefine.gamekey[28] = 28 				        --幸运3D
g_caipiaoDefine.gamekey[29] = 29 				        --福彩3D
g_caipiaoDefine.gamekey[30] = 30 				        --排列3/5
--快乐8 2个 KL8
g_caipiaoDefine.gamekey[31] = 31 				        --极速快乐8
g_caipiaoDefine.gamekey[32] = 32 				        --北京快乐8

--桌子基本信息
g_caipiaoDefine.init_data = {}

g_caipiaoDefine.init_data[1]                        = {}
g_caipiaoDefine.init_data[1]['tableid']             = 2300001       --桌子id 
g_caipiaoDefine.init_data[1]['maxuser']             = 999           --最大人数
g_caipiaoDefine.init_data[1]['tabletype']           = 1             --桌子类型
g_caipiaoDefine.init_data[1]['tablename']           = "幸运飞艇"    --桌子名称
g_caipiaoDefine.init_data[1]['fengpantime']         = 30            --封盘时间间隔开奖时间(s)
g_caipiaoDefine.init_data[1]['openawardtime']       = 30            --开奖时间(s)(本地延迟开奖)
g_caipiaoDefine.init_data[1]['gamekey']             = 1             --彩种
g_caipiaoDefine.init_data[1]['unsettle_checktime']  = 10            --检测未结算订单时间间隔(s)
g_caipiaoDefine.init_data[1]['group']               = "PK10"        --类别
g_caipiaoDefine.init_data[1]['pourlimit']           = 5000 * 100    --下注总额限制
g_caipiaoDefine.init_data[1]['spe_pourlimit']       = 5000 * 100    --特殊玩家下注总额限制
g_caipiaoDefine.init_data[1]['name']                = "xyft"        --采集name
g_caipiaoDefine.init_data[1]['desc']                = "5分钟1期"    --描述

g_caipiaoDefine.init_data[2]                        = {}
g_caipiaoDefine.init_data[2]['tableid']             = 2300002       --桌子id 
g_caipiaoDefine.init_data[2]['maxuser']             = 999           --最大人数
g_caipiaoDefine.init_data[2]['tabletype']           = 1             --桌子类型
g_caipiaoDefine.init_data[2]['tablename']           = "六合彩"      --桌子名称
g_caipiaoDefine.init_data[2]['fengpantime']         = 60 * 60       --封盘时间间隔开奖时间(s)
g_caipiaoDefine.init_data[2]['openawardtime']       = 10 * 60       --开奖时间(s)(本地延迟开奖)
g_caipiaoDefine.init_data[2]['gamekey']             = 2             --彩种
g_caipiaoDefine.init_data[2]['unsettle_checktime']  = 10            --检测未结算订单时间间隔(s)
g_caipiaoDefine.init_data[2]['group']               = "LHC"         --类别
g_caipiaoDefine.init_data[2]['pourlimit']           = 5000 * 100    --下注总额限制
g_caipiaoDefine.init_data[2]['spe_pourlimit']       = 5000 * 100    --特殊玩家下注总额限制
g_caipiaoDefine.init_data[2]['name']                = "lhc"        --采集name
g_caipiaoDefine.init_data[2]['desc']                = "每周2-3期"     --描述

g_caipiaoDefine.init_data[3]                        = {}
g_caipiaoDefine.init_data[3]['tableid']             = 2300003       --桌子id 
g_caipiaoDefine.init_data[3]['maxuser']             = 999           --最大人数
g_caipiaoDefine.init_data[3]['tabletype']           = 1             --桌子类型
g_caipiaoDefine.init_data[3]['tablename']           = "北京赛车"    --桌子名称
g_caipiaoDefine.init_data[3]['fengpantime']         = 60            --封盘时间间隔开奖时间(s)
g_caipiaoDefine.init_data[3]['openawardtime']       = 60            --开奖时间(s)(本地延迟开奖)
g_caipiaoDefine.init_data[3]['gamekey']             = 3             --彩种
g_caipiaoDefine.init_data[3]['unsettle_checktime']  = 10            --检测未结算订单时间间隔(s)
g_caipiaoDefine.init_data[3]['group']               = "PK10"        --类别
g_caipiaoDefine.init_data[3]['pourlimit']           = 5000 * 100    --下注总额限制
g_caipiaoDefine.init_data[3]['spe_pourlimit']       = 5000 * 100    --特殊玩家下注总额限制
g_caipiaoDefine.init_data[3]['name']                = "bjpk10"        --采集name
g_caipiaoDefine.init_data[3]['desc']                = "20分钟1期"     --描述

g_caipiaoDefine.init_data[4]                        = {}
g_caipiaoDefine.init_data[4]['tableid']             = 2300004       --桌子id 
g_caipiaoDefine.init_data[4]['maxuser']             = 999           --最大人数
g_caipiaoDefine.init_data[4]['tabletype']           = 4             --桌子类型
g_caipiaoDefine.init_data[4]['tablename']           = "秒速飞艇"    --桌子名称
g_caipiaoDefine.init_data[4]['fengpantime']         = 15            --封盘时间间隔开奖时间(s)
g_caipiaoDefine.init_data[4]['openawardtime']       = 15            --开奖时间(s)(本地延迟开奖)
g_caipiaoDefine.init_data[4]['gamekey']             = 4             --彩种
g_caipiaoDefine.init_data[4]['unsettle_checktime']  = 10            --检测未结算订单时间间隔(s)
g_caipiaoDefine.init_data[4]['group']               = "PK10"        --类别
g_caipiaoDefine.init_data[4]['pourlimit']           = 5000 * 100    --下注总额限制
g_caipiaoDefine.init_data[4]['spe_pourlimit']       = 5000 * 100    --特殊玩家下注总额限制
g_caipiaoDefine.init_data[4]['name']                = "msft"        --采集name
g_caipiaoDefine.init_data[4]['desc']                = "1分钟1期"     --描述

g_caipiaoDefine.init_data[5]                        = {}
g_caipiaoDefine.init_data[5]['tableid']             = 2300005       --桌子id 
g_caipiaoDefine.init_data[5]['maxuser']             = 999           --最大人数
g_caipiaoDefine.init_data[5]['tabletype']           = 1             --桌子类型
g_caipiaoDefine.init_data[5]['tablename']           = "极速飞艇"    --桌子名称
g_caipiaoDefine.init_data[5]['fengpantime']         = 15            --封盘时间间隔开奖时间(s)
g_caipiaoDefine.init_data[5]['openawardtime']       = 15            --开奖时间(s)(本地延迟开奖)
g_caipiaoDefine.init_data[5]['gamekey']             = 5             --彩种
g_caipiaoDefine.init_data[5]['unsettle_checktime']  = 10            --检测未结算订单时间间隔(s)
g_caipiaoDefine.init_data[5]['group']               = "PK10"        --类别
g_caipiaoDefine.init_data[5]['pourlimit']           = 5000 * 100    --下注总额限制
g_caipiaoDefine.init_data[5]['spe_pourlimit']       = 5000 * 100    --特殊玩家下注总额限制
g_caipiaoDefine.init_data[5]['name']                = "jsft"        --采集name
g_caipiaoDefine.init_data[5]['desc']                = "1分钟1期"    --描述

--时时彩
g_caipiaoDefine.init_data[6]                        = {}
g_caipiaoDefine.init_data[6]['tableid']             = 2300006       --桌子id 
g_caipiaoDefine.init_data[6]['maxuser']             = 999           --最大人数
g_caipiaoDefine.init_data[6]['tabletype']           = 1             --桌子类型
g_caipiaoDefine.init_data[6]['tablename']           = "幸运分分彩"  --桌子名称
g_caipiaoDefine.init_data[6]['fengpantime']         = 15            --封盘时间间隔开奖时间(s)
g_caipiaoDefine.init_data[6]['openawardtime']       = 15            --开奖时间(s)(本地延迟开奖)
g_caipiaoDefine.init_data[6]['gamekey']             = 6             --彩种
g_caipiaoDefine.init_data[6]['unsettle_checktime']  = 10            --检测未结算订单时间间隔(s)
g_caipiaoDefine.init_data[6]['group']               = "SSC"         --类别
g_caipiaoDefine.init_data[6]['pourlimit']           = 5000 * 100    --下注总额限制
g_caipiaoDefine.init_data[6]['spe_pourlimit']       = 5000 * 100    --特殊玩家下注总额限制
g_caipiaoDefine.init_data[6]['name']                = "xyffc"       --采集name
g_caipiaoDefine.init_data[6]['desc']                = "1分钟1期"    --描述


g_caipiaoDefine.init_data[7]                        = {}
g_caipiaoDefine.init_data[7]['tableid']             = 2300007       --桌子id 
g_caipiaoDefine.init_data[7]['maxuser']             = 999           --最大人数
g_caipiaoDefine.init_data[7]['tabletype']           = 1             --桌子类型
g_caipiaoDefine.init_data[7]['tablename']           = "腾讯分分彩"  --桌子名称
g_caipiaoDefine.init_data[7]['fengpantime']         = 15            --封盘时间间隔开奖时间(s)
g_caipiaoDefine.init_data[7]['openawardtime']       = 15            --开奖时间(s)(本地延迟开奖)
g_caipiaoDefine.init_data[7]['gamekey']             = 7             --彩种
g_caipiaoDefine.init_data[7]['unsettle_checktime']  = 10            --检测未结算订单时间间隔(s)
g_caipiaoDefine.init_data[7]['group']               = "SSC"         --类别
g_caipiaoDefine.init_data[7]['pourlimit']           = 5000 * 100    --下注总额限制
g_caipiaoDefine.init_data[7]['spe_pourlimit']       = 5000 * 100    --特殊玩家下注总额限制
g_caipiaoDefine.init_data[7]['name']                = "txffc"       --采集name
g_caipiaoDefine.init_data[7]['desc']                = "1分钟1期"    --描述

g_caipiaoDefine.init_data[8]                        = {}
g_caipiaoDefine.init_data[8]['tableid']             = 2300008       --桌子id 
g_caipiaoDefine.init_data[8]['maxuser']             = 999           --最大人数
g_caipiaoDefine.init_data[8]['tabletype']           = 1             --桌子类型
g_caipiaoDefine.init_data[8]['tablename']           = "幸运五分钟"  --桌子名称
g_caipiaoDefine.init_data[8]['fengpantime']         = 30            --封盘时间间隔开奖时间(s)
g_caipiaoDefine.init_data[8]['openawardtime']       = 30            --开奖时间(s)(本地延迟开奖)
g_caipiaoDefine.init_data[8]['gamekey']             = 8             --彩种
g_caipiaoDefine.init_data[8]['unsettle_checktime']  = 10            --检测未结算订单时间间隔(s)
g_caipiaoDefine.init_data[8]['group']               = "SSC"         --类别
g_caipiaoDefine.init_data[8]['pourlimit']           = 5000 * 100    --下注总额限制
g_caipiaoDefine.init_data[8]['spe_pourlimit']       = 5000 * 100    --特殊玩家下注总额限制
g_caipiaoDefine.init_data[8]['name']                = "xywfz"       --采集name
g_caipiaoDefine.init_data[8]['desc']                = "5分钟1期"    --描述

g_caipiaoDefine.init_data[9]                        = {}
g_caipiaoDefine.init_data[9]['tableid']             = 2300009       --桌子id 
g_caipiaoDefine.init_data[9]['maxuser']             = 999           --最大人数
g_caipiaoDefine.init_data[9]['tabletype']           = 1             --桌子类型
g_caipiaoDefine.init_data[9]['tablename']           = "河内五分钟"  --桌子名称
g_caipiaoDefine.init_data[9]['fengpantime']         = 30            --封盘时间间隔开奖时间(s)
g_caipiaoDefine.init_data[9]['openawardtime']       = 30            --开奖时间(s)(本地延迟开奖)
g_caipiaoDefine.init_data[9]['gamekey']             = 9             --彩种
g_caipiaoDefine.init_data[9]['unsettle_checktime']  = 10            --检测未结算订单时间间隔(s)
g_caipiaoDefine.init_data[9]['group']               = "SSC"         --类别
g_caipiaoDefine.init_data[9]['pourlimit']           = 5000 * 100    --下注总额限制
g_caipiaoDefine.init_data[9]['spe_pourlimit']       = 5000 * 100    --特殊玩家下注总额限制
g_caipiaoDefine.init_data[9]['name']                = "hnwfz"       --采集name
g_caipiaoDefine.init_data[9]['desc']                = "5分钟1期"    --描述


g_caipiaoDefine.init_data[10]                        = {}
g_caipiaoDefine.init_data[10]['tableid']             = 2300010       --桌子id 
g_caipiaoDefine.init_data[10]['maxuser']             = 999           --最大人数
g_caipiaoDefine.init_data[10]['tabletype']           = 1             --桌子类型
g_caipiaoDefine.init_data[10]['tablename']           = "重庆欢乐生肖" --桌子名称
g_caipiaoDefine.init_data[10]['fengpantime']         = 30            --封盘时间间隔开奖时间(s)
g_caipiaoDefine.init_data[10]['openawardtime']       = 30            --开奖时间(s)(本地延迟开奖)
g_caipiaoDefine.init_data[10]['gamekey']             = 10             --彩种
g_caipiaoDefine.init_data[10]['unsettle_checktime']  = 10            --检测未结算订单时间间隔(s)
g_caipiaoDefine.init_data[10]['group']               = "SSC"         --类别
g_caipiaoDefine.init_data[10]['pourlimit']           = 5000 * 100    --下注总额限制
g_caipiaoDefine.init_data[10]['spe_pourlimit']       = 5000 * 100    --特殊玩家下注总额限制
g_caipiaoDefine.init_data[10]['name']                = "cqhlsx"      --采集name
g_caipiaoDefine.init_data[10]['desc']                = "20分钟1期"    --描述


g_caipiaoDefine.init_data[11]                        = {}
g_caipiaoDefine.init_data[11]['tableid']             = 2300011       --桌子id 
g_caipiaoDefine.init_data[11]['maxuser']             = 999           --最大人数
g_caipiaoDefine.init_data[11]['tabletype']           = 1             --桌子类型
g_caipiaoDefine.init_data[11]['tablename']           = "天津时时彩"  --桌子名称
g_caipiaoDefine.init_data[11]['fengpantime']         = 30            --封盘时间间隔开奖时间(s)
g_caipiaoDefine.init_data[11]['openawardtime']       = 30            --开奖时间(s)(本地延迟开奖)
g_caipiaoDefine.init_data[11]['gamekey']             = 11            --彩种
g_caipiaoDefine.init_data[11]['unsettle_checktime']  = 10            --检测未结算订单时间间隔(s)
g_caipiaoDefine.init_data[11]['group']               = "SSC"         --类别
g_caipiaoDefine.init_data[11]['pourlimit']           = 5000 * 100    --下注总额限制
g_caipiaoDefine.init_data[11]['spe_pourlimit']       = 5000 * 100    --特殊玩家下注总额限制
g_caipiaoDefine.init_data[11]['name']                = "tjssc"       --采集name
g_caipiaoDefine.init_data[11]['desc']                = "20分钟1期"    --描述

g_caipiaoDefine.init_data[12]                        = {}
g_caipiaoDefine.init_data[12]['tableid']             = 2300012       --桌子id 
g_caipiaoDefine.init_data[12]['maxuser']             = 999           --最大人数
g_caipiaoDefine.init_data[12]['tabletype']           = 1             --桌子类型
g_caipiaoDefine.init_data[12]['tablename']           = "新疆时时彩"  --桌子名称
g_caipiaoDefine.init_data[12]['fengpantime']         = 30            --封盘时间间隔开奖时间(s)
g_caipiaoDefine.init_data[12]['openawardtime']       = 30            --开奖时间(s)(本地延迟开奖)
g_caipiaoDefine.init_data[12]['gamekey']             = 12            --彩种
g_caipiaoDefine.init_data[12]['unsettle_checktime']  = 10            --检测未结算订单时间间隔(s)
g_caipiaoDefine.init_data[12]['group']               = "SSC"         --类别
g_caipiaoDefine.init_data[12]['pourlimit']           = 5000 * 100    --下注总额限制
g_caipiaoDefine.init_data[12]['spe_pourlimit']       = 5000 * 100    --特殊玩家下注总额限制
g_caipiaoDefine.init_data[12]['name']                = "xjssc"       --采集name
g_caipiaoDefine.init_data[12]['desc']                = "20分钟1期"    --描述

g_caipiaoDefine.init_data[13]                        = {}
g_caipiaoDefine.init_data[13]['tableid']             = 2300013       --桌子id 
g_caipiaoDefine.init_data[13]['maxuser']             = 999           --最大人数
g_caipiaoDefine.init_data[13]['tabletype']           = 1             --桌子类型
g_caipiaoDefine.init_data[13]['tablename']           = "黑龙江时时彩"--桌子名称
g_caipiaoDefine.init_data[13]['fengpantime']         = 30            --封盘时间间隔开奖时间(s)
g_caipiaoDefine.init_data[13]['openawardtime']       = 30            --开奖时间(s)(本地延迟开奖)
g_caipiaoDefine.init_data[13]['gamekey']             = 13            --彩种
g_caipiaoDefine.init_data[13]['unsettle_checktime']  = 10            --检测未结算订单时间间隔(s)
g_caipiaoDefine.init_data[13]['group']               = "SSC"         --类别
g_caipiaoDefine.init_data[13]['pourlimit']           = 5000 * 100    --下注总额限制
g_caipiaoDefine.init_data[13]['spe_pourlimit']       = 5000 * 100    --特殊玩家下注总额限制
g_caipiaoDefine.init_data[13]['name']                = "hljssc"       --采集name
g_caipiaoDefine.init_data[13]['desc']                = "20分钟1期"    --描述

--六合彩  LHC
g_caipiaoDefine.init_data[14]                        = {}
g_caipiaoDefine.init_data[14]['tableid']             = 2300014       --桌子id 
g_caipiaoDefine.init_data[14]['maxuser']             = 999           --最大人数
g_caipiaoDefine.init_data[14]['tabletype']           = 1             --桌子类型
g_caipiaoDefine.init_data[14]['tablename']           = "六合5分彩"   --桌子名称
g_caipiaoDefine.init_data[14]['fengpantime']         = 30            --封盘时间间隔开奖时间(s)
g_caipiaoDefine.init_data[14]['openawardtime']       = 30            --开奖时间(s)(本地延迟开奖)
g_caipiaoDefine.init_data[14]['gamekey']             = 14            --彩种
g_caipiaoDefine.init_data[14]['unsettle_checktime']  = 10            --检测未结算订单时间间隔(s)
g_caipiaoDefine.init_data[14]['group']               = "LHC"         --类别
g_caipiaoDefine.init_data[14]['pourlimit']           = 5000 * 100    --下注总额限制
g_caipiaoDefine.init_data[14]['spe_pourlimit']       = 5000 * 100    --特殊玩家下注总额限制
g_caipiaoDefine.init_data[14]['name']                = "lhwfc"       --采集name
g_caipiaoDefine.init_data[14]['desc']                = "5分钟1期"    --描述

--11选5
g_caipiaoDefine.init_data[15]                        = {}
g_caipiaoDefine.init_data[15]['tableid']             = 2300015       --桌子id 
g_caipiaoDefine.init_data[15]['maxuser']             = 999           --最大人数
g_caipiaoDefine.init_data[15]['tabletype']           = 1             --桌子类型
g_caipiaoDefine.init_data[15]['tablename']           = "极速11选5"   --桌子名称
g_caipiaoDefine.init_data[15]['fengpantime']         = 30            --封盘时间间隔开奖时间(s)
g_caipiaoDefine.init_data[15]['openawardtime']       = 30            --开奖时间(s)(本地延迟开奖)
g_caipiaoDefine.init_data[15]['gamekey']             = 15            --彩种
g_caipiaoDefine.init_data[15]['unsettle_checktime']  = 10            --检测未结算订单时间间隔(s)
g_caipiaoDefine.init_data[15]['group']               = "11X5"        --类别
g_caipiaoDefine.init_data[15]['pourlimit']           = 5000 * 100    --下注总额限制
g_caipiaoDefine.init_data[15]['spe_pourlimit']       = 5000 * 100    --特殊玩家下注总额限制
g_caipiaoDefine.init_data[15]['name']                = "js11x5"       --采集name
g_caipiaoDefine.init_data[15]['desc']                = "1分钟1期"    --描述

g_caipiaoDefine.init_data[16]                        = {}
g_caipiaoDefine.init_data[16]['tableid']             = 2300016       --桌子id 
g_caipiaoDefine.init_data[16]['maxuser']             = 999           --最大人数
g_caipiaoDefine.init_data[16]['tabletype']           = 1             --桌子类型
g_caipiaoDefine.init_data[16]['tablename']           = "幸运11选5"   --桌子名称
g_caipiaoDefine.init_data[16]['fengpantime']         = 30            --封盘时间间隔开奖时间(s)
g_caipiaoDefine.init_data[16]['openawardtime']       = 30            --开奖时间(s)(本地延迟开奖)
g_caipiaoDefine.init_data[16]['gamekey']             = 16            --彩种
g_caipiaoDefine.init_data[16]['unsettle_checktime']  = 10            --检测未结算订单时间间隔(s)
g_caipiaoDefine.init_data[16]['group']               = "11X5"        --类别
g_caipiaoDefine.init_data[16]['pourlimit']           = 5000 * 100    --下注总额限制
g_caipiaoDefine.init_data[16]['spe_pourlimit']       = 5000 * 100    --特殊玩家下注总额限制
g_caipiaoDefine.init_data[16]['name']                = "xy11x5"      --采集name
g_caipiaoDefine.init_data[16]['desc']                = "5分钟1期"    --描述

g_caipiaoDefine.init_data[17]                        = {}
g_caipiaoDefine.init_data[17]['tableid']             = 2300017       --桌子id 
g_caipiaoDefine.init_data[17]['maxuser']             = 999           --最大人数
g_caipiaoDefine.init_data[17]['tabletype']           = 1             --桌子类型
g_caipiaoDefine.init_data[17]['tablename']           = "广东11选5"   --桌子名称
g_caipiaoDefine.init_data[17]['fengpantime']         = 30            --封盘时间间隔开奖时间(s)
g_caipiaoDefine.init_data[17]['openawardtime']       = 30            --开奖时间(s)(本地延迟开奖)
g_caipiaoDefine.init_data[17]['gamekey']             = 17            --彩种
g_caipiaoDefine.init_data[17]['unsettle_checktime']  = 10            --检测未结算订单时间间隔(s)
g_caipiaoDefine.init_data[17]['group']               = "11X5"        --类别
g_caipiaoDefine.init_data[17]['pourlimit']           = 5000 * 100    --下注总额限制
g_caipiaoDefine.init_data[17]['spe_pourlimit']       = 5000 * 100    --特殊玩家下注总额限制
g_caipiaoDefine.init_data[17]['name']                = "gd11x5"      --采集name
g_caipiaoDefine.init_data[17]['desc']                = "20分钟1期"    --描述

g_caipiaoDefine.init_data[18]                        = {}
g_caipiaoDefine.init_data[18]['tableid']             = 2300018       --桌子id 
g_caipiaoDefine.init_data[18]['maxuser']             = 999           --最大人数
g_caipiaoDefine.init_data[18]['tabletype']           = 1             --桌子类型
g_caipiaoDefine.init_data[18]['tablename']           = "山东11选5"   --桌子名称
g_caipiaoDefine.init_data[18]['fengpantime']         = 30            --封盘时间间隔开奖时间(s)
g_caipiaoDefine.init_data[18]['openawardtime']       = 30            --开奖时间(s)(本地延迟开奖)
g_caipiaoDefine.init_data[18]['gamekey']             = 18            --彩种
g_caipiaoDefine.init_data[18]['unsettle_checktime']  = 10            --检测未结算订单时间间隔(s)
g_caipiaoDefine.init_data[18]['group']               = "11X5"        --类别
g_caipiaoDefine.init_data[18]['pourlimit']           = 5000 * 100    --下注总额限制
g_caipiaoDefine.init_data[18]['spe_pourlimit']       = 5000 * 100    --特殊玩家下注总额限制
g_caipiaoDefine.init_data[18]['name']                = "sd11x5"      --采集name
g_caipiaoDefine.init_data[18]['desc']                = "20分钟1期"    --描述

g_caipiaoDefine.init_data[19]                        = {}
g_caipiaoDefine.init_data[19]['tableid']             = 2300019       --桌子id 
g_caipiaoDefine.init_data[19]['maxuser']             = 999           --最大人数
g_caipiaoDefine.init_data[19]['tabletype']           = 1             --桌子类型
g_caipiaoDefine.init_data[19]['tablename']           = "江西11选5"   --桌子名称
g_caipiaoDefine.init_data[19]['fengpantime']         = 30            --封盘时间间隔开奖时间(s)
g_caipiaoDefine.init_data[19]['openawardtime']       = 30            --开奖时间(s)(本地延迟开奖)
g_caipiaoDefine.init_data[19]['gamekey']             = 19            --彩种
g_caipiaoDefine.init_data[19]['unsettle_checktime']  = 10            --检测未结算订单时间间隔(s)
g_caipiaoDefine.init_data[19]['group']               = "11X5"        --类别
g_caipiaoDefine.init_data[19]['pourlimit']           = 5000 * 100    --下注总额限制
g_caipiaoDefine.init_data[19]['spe_pourlimit']       = 5000 * 100    --特殊玩家下注总额限制
g_caipiaoDefine.init_data[19]['name']                = "jx11x5"      --采集name
g_caipiaoDefine.init_data[19]['desc']                = "20分钟1期"    --描述

g_caipiaoDefine.init_data[20]                        = {}
g_caipiaoDefine.init_data[20]['tableid']             = 2300020       --桌子id 
g_caipiaoDefine.init_data[20]['maxuser']             = 999           --最大人数
g_caipiaoDefine.init_data[20]['tabletype']           = 1             --桌子类型
g_caipiaoDefine.init_data[20]['tablename']           = "广西11选5"   --桌子名称
g_caipiaoDefine.init_data[20]['fengpantime']         = 30            --封盘时间间隔开奖时间(s)
g_caipiaoDefine.init_data[20]['openawardtime']       = 30            --开奖时间(s)(本地延迟开奖)
g_caipiaoDefine.init_data[20]['gamekey']             = 20            --彩种
g_caipiaoDefine.init_data[20]['unsettle_checktime']  = 10            --检测未结算订单时间间隔(s)
g_caipiaoDefine.init_data[20]['group']               = "11X5"        --类别
g_caipiaoDefine.init_data[20]['pourlimit']           = 5000 * 100    --下注总额限制
g_caipiaoDefine.init_data[20]['spe_pourlimit']       = 5000 * 100    --特殊玩家下注总额限制
g_caipiaoDefine.init_data[20]['name']                = "gx11x5"      --采集name
g_caipiaoDefine.init_data[20]['desc']                = "20分钟1期"    --描述

--K3
g_caipiaoDefine.init_data[21]                        = {}
g_caipiaoDefine.init_data[21]['tableid']             = 2300021       --桌子id 
g_caipiaoDefine.init_data[21]['maxuser']             = 999           --最大人数
g_caipiaoDefine.init_data[21]['tabletype']           = 1             --桌子类型
g_caipiaoDefine.init_data[21]['tablename']           = "秒速快三"    --桌子名称
g_caipiaoDefine.init_data[21]['fengpantime']         = 15            --封盘时间间隔开奖时间(s)
g_caipiaoDefine.init_data[21]['openawardtime']       = 15            --开奖时间(s)(本地延迟开奖)
g_caipiaoDefine.init_data[21]['gamekey']             = 21            --彩种
g_caipiaoDefine.init_data[21]['unsettle_checktime']  = 10            --检测未结算订单时间间隔(s)
g_caipiaoDefine.init_data[21]['group']               = "K3"          --类别
g_caipiaoDefine.init_data[21]['pourlimit']           = 5000 * 100    --下注总额限制
g_caipiaoDefine.init_data[21]['spe_pourlimit']       = 5000 * 100    --特殊玩家下注总额限制
g_caipiaoDefine.init_data[21]['name']                = "msk3"        --采集name
g_caipiaoDefine.init_data[21]['desc']                = "1分钟1期"    --描述

g_caipiaoDefine.init_data[22]                        = {}
g_caipiaoDefine.init_data[22]['tableid']             = 2300022       --桌子id 
g_caipiaoDefine.init_data[22]['maxuser']             = 999           --最大人数
g_caipiaoDefine.init_data[22]['tabletype']           = 1             --桌子类型
g_caipiaoDefine.init_data[22]['tablename']           = "幸运快三"   --桌子名称
g_caipiaoDefine.init_data[22]['fengpantime']         = 30            --封盘时间间隔开奖时间(s)
g_caipiaoDefine.init_data[22]['openawardtime']       = 30            --开奖时间(s)(本地延迟开奖)
g_caipiaoDefine.init_data[22]['gamekey']             = 22            --彩种
g_caipiaoDefine.init_data[22]['unsettle_checktime']  = 10            --检测未结算订单时间间隔(s)
g_caipiaoDefine.init_data[22]['group']               = "K3"          --类别
g_caipiaoDefine.init_data[22]['pourlimit']           = 5000 * 100    --下注总额限制
g_caipiaoDefine.init_data[22]['spe_pourlimit']       = 5000 * 100    --特殊玩家下注总额限制
g_caipiaoDefine.init_data[22]['name']                = "xyk3"      --采集name
g_caipiaoDefine.init_data[22]['desc']                = "5分钟1期"    --描述

g_caipiaoDefine.init_data[23]                        = {}
g_caipiaoDefine.init_data[23]['tableid']             = 2300023       --桌子id 
g_caipiaoDefine.init_data[23]['maxuser']             = 999           --最大人数
g_caipiaoDefine.init_data[23]['tabletype']           = 1             --桌子类型
g_caipiaoDefine.init_data[23]['tablename']           = "江苏快三"   --桌子名称
g_caipiaoDefine.init_data[23]['fengpantime']         = 30            --封盘时间间隔开奖时间(s)
g_caipiaoDefine.init_data[23]['openawardtime']       = 30            --开奖时间(s)(本地延迟开奖)
g_caipiaoDefine.init_data[23]['gamekey']             = 23            --彩种
g_caipiaoDefine.init_data[23]['unsettle_checktime']  = 10            --检测未结算订单时间间隔(s)
g_caipiaoDefine.init_data[23]['group']               = "K3"          --类别
g_caipiaoDefine.init_data[23]['pourlimit']           = 5000 * 100    --下注总额限制
g_caipiaoDefine.init_data[23]['spe_pourlimit']       = 5000 * 100    --特殊玩家下注总额限制
g_caipiaoDefine.init_data[23]['name']                = "jsk3"        --采集name
g_caipiaoDefine.init_data[23]['desc']                = "20分钟1期"   --描述


g_caipiaoDefine.init_data[24]                        = {}
g_caipiaoDefine.init_data[24]['tableid']             = 2300024       --桌子id 
g_caipiaoDefine.init_data[24]['maxuser']             = 999           --最大人数
g_caipiaoDefine.init_data[24]['tabletype']           = 1             --桌子类型
g_caipiaoDefine.init_data[24]['tablename']           = "安徽快三"    --桌子名称
g_caipiaoDefine.init_data[24]['fengpantime']         = 30            --封盘时间间隔开奖时间(s)
g_caipiaoDefine.init_data[24]['openawardtime']       = 30            --开奖时间(s)(本地延迟开奖)
g_caipiaoDefine.init_data[24]['gamekey']             = 24            --彩种
g_caipiaoDefine.init_data[24]['unsettle_checktime']  = 10            --检测未结算订单时间间隔(s)
g_caipiaoDefine.init_data[24]['group']               = "K3"          --类别
g_caipiaoDefine.init_data[24]['pourlimit']           = 5000 * 100    --下注总额限制
g_caipiaoDefine.init_data[24]['spe_pourlimit']       = 5000 * 100    --特殊玩家下注总额限制
g_caipiaoDefine.init_data[24]['name']                = "ahk3"      --采集name
g_caipiaoDefine.init_data[24]['desc']                = "20分钟1期"    --描述

g_caipiaoDefine.init_data[25]                        = {}
g_caipiaoDefine.init_data[25]['tableid']             = 2300025       --桌子id 
g_caipiaoDefine.init_data[25]['maxuser']             = 999           --最大人数
g_caipiaoDefine.init_data[25]['tabletype']           = 1             --桌子类型
g_caipiaoDefine.init_data[25]['tablename']           = "广西快三"    --桌子名称
g_caipiaoDefine.init_data[25]['fengpantime']         = 30            --封盘时间间隔开奖时间(s)
g_caipiaoDefine.init_data[25]['openawardtime']       = 30            --开奖时间(s)(本地延迟开奖)
g_caipiaoDefine.init_data[25]['gamekey']             = 25            --彩种
g_caipiaoDefine.init_data[25]['unsettle_checktime']  = 10            --检测未结算订单时间间隔(s)
g_caipiaoDefine.init_data[25]['group']               = "K3"          --类别
g_caipiaoDefine.init_data[25]['pourlimit']           = 5000 * 100    --下注总额限制
g_caipiaoDefine.init_data[25]['spe_pourlimit']       = 5000 * 100    --特殊玩家下注总额限制
g_caipiaoDefine.init_data[25]['name']                = "gxk3"        --采集name
g_caipiaoDefine.init_data[25]['desc']                = "20分钟1期"   --描述

g_caipiaoDefine.init_data[26]                        = {}
g_caipiaoDefine.init_data[26]['tableid']             = 2300026       --桌子id 
g_caipiaoDefine.init_data[26]['maxuser']             = 999           --最大人数
g_caipiaoDefine.init_data[26]['tabletype']           = 1             --桌子类型
g_caipiaoDefine.init_data[26]['tablename']           = "吉林快三"   --桌子名称
g_caipiaoDefine.init_data[26]['fengpantime']         = 30            --封盘时间间隔开奖时间(s)
g_caipiaoDefine.init_data[26]['openawardtime']       = 30            --开奖时间(s)(本地延迟开奖)
g_caipiaoDefine.init_data[26]['gamekey']             = 26            --彩种
g_caipiaoDefine.init_data[26]['unsettle_checktime']  = 10            --检测未结算订单时间间隔(s)
g_caipiaoDefine.init_data[26]['group']               = "K3"          --类别
g_caipiaoDefine.init_data[26]['pourlimit']           = 5000 * 100    --下注总额限制
g_caipiaoDefine.init_data[26]['spe_pourlimit']       = 5000 * 100    --特殊玩家下注总额限制
g_caipiaoDefine.init_data[26]['name']                = "jlk3"        --采集name
g_caipiaoDefine.init_data[26]['desc']                = "20分钟1期"    --描述

--3D
g_caipiaoDefine.init_data[27]                        = {}
g_caipiaoDefine.init_data[27]['tableid']             = 2300027       --桌子id 
g_caipiaoDefine.init_data[27]['maxuser']             = 999           --最大人数
g_caipiaoDefine.init_data[27]['tabletype']           = 1             --桌子类型
g_caipiaoDefine.init_data[27]['tablename']           = "极速3D"      --桌子名称
g_caipiaoDefine.init_data[27]['fengpantime']         = 15            --封盘时间间隔开奖时间(s)
g_caipiaoDefine.init_data[27]['openawardtime']       = 15            --开奖时间(s)(本地延迟开奖)
g_caipiaoDefine.init_data[27]['gamekey']             = 27            --彩种
g_caipiaoDefine.init_data[27]['unsettle_checktime']  = 10            --检测未结算订单时间间隔(s)
g_caipiaoDefine.init_data[27]['group']               = "3D"          --类别
g_caipiaoDefine.init_data[27]['pourlimit']           = 5000 * 100    --下注总额限制
g_caipiaoDefine.init_data[27]['spe_pourlimit']       = 5000 * 100    --特殊玩家下注总额限制
g_caipiaoDefine.init_data[27]['name']                = "js3d"        --采集name
g_caipiaoDefine.init_data[27]['desc']                = "1分钟1期"    --描述

g_caipiaoDefine.init_data[28]                        = {}
g_caipiaoDefine.init_data[28]['tableid']             = 2300028       --桌子id 
g_caipiaoDefine.init_data[28]['maxuser']             = 999           --最大人数
g_caipiaoDefine.init_data[28]['tabletype']           = 1             --桌子类型
g_caipiaoDefine.init_data[28]['tablename']           = "幸运3D"      --桌子名称
g_caipiaoDefine.init_data[28]['fengpantime']         = 30            --封盘时间间隔开奖时间(s)
g_caipiaoDefine.init_data[28]['openawardtime']       = 30            --开奖时间(s)(本地延迟开奖)
g_caipiaoDefine.init_data[28]['gamekey']             = 28            --彩种
g_caipiaoDefine.init_data[28]['unsettle_checktime']  = 10            --检测未结算订单时间间隔(s)
g_caipiaoDefine.init_data[28]['group']               = "3D"          --类别
g_caipiaoDefine.init_data[28]['pourlimit']           = 5000 * 100    --下注总额限制
g_caipiaoDefine.init_data[28]['spe_pourlimit']       = 5000 * 100    --特殊玩家下注总额限制
g_caipiaoDefine.init_data[28]['name']                = "xy3d"      --采集name
g_caipiaoDefine.init_data[28]['desc']                = "5分钟1期"    --描述

g_caipiaoDefine.init_data[29]                        = {}
g_caipiaoDefine.init_data[29]['tableid']             = 2300029       --桌子id 
g_caipiaoDefine.init_data[29]['maxuser']             = 999           --最大人数
g_caipiaoDefine.init_data[29]['tabletype']           = 1             --桌子类型
g_caipiaoDefine.init_data[29]['tablename']           = "福彩3D"      --桌子名称
g_caipiaoDefine.init_data[29]['fengpantime']         = 60*30         --封盘时间间隔开奖时间(s)
g_caipiaoDefine.init_data[29]['openawardtime']       = 60*30         --开奖时间(s)(本地延迟开奖)
g_caipiaoDefine.init_data[29]['gamekey']             = 29            --彩种
g_caipiaoDefine.init_data[29]['unsettle_checktime']  = 10            --检测未结算订单时间间隔(s)
g_caipiaoDefine.init_data[29]['group']               = "3D"          --类别
g_caipiaoDefine.init_data[29]['pourlimit']           = 5000 * 100    --下注总额限制
g_caipiaoDefine.init_data[29]['spe_pourlimit']       = 5000 * 100    --特殊玩家下注总额限制
g_caipiaoDefine.init_data[29]['name']                = "fc3d"        --采集name
g_caipiaoDefine.init_data[29]['desc']                = "1天1期"      --描述

g_caipiaoDefine.init_data[30]                        = {}
g_caipiaoDefine.init_data[30]['tableid']             = 2300030       --桌子id 
g_caipiaoDefine.init_data[30]['maxuser']             = 999           --最大人数
g_caipiaoDefine.init_data[30]['tabletype']           = 1             --桌子类型
g_caipiaoDefine.init_data[30]['tablename']           = "排列3/5"     --桌子名称
g_caipiaoDefine.init_data[30]['fengpantime']         = 60*30         --封盘时间间隔开奖时间(s)
g_caipiaoDefine.init_data[30]['openawardtime']       = 60*30         --开奖时间(s)(本地延迟开奖)
g_caipiaoDefine.init_data[30]['gamekey']             = 30            --彩种
g_caipiaoDefine.init_data[30]['unsettle_checktime']  = 10            --检测未结算订单时间间隔(s)
g_caipiaoDefine.init_data[30]['group']               = "3D"          --类别
g_caipiaoDefine.init_data[30]['pourlimit']           = 5000 * 100    --下注总额限制
g_caipiaoDefine.init_data[30]['spe_pourlimit']       = 5000 * 100    --特殊玩家下注总额限制
g_caipiaoDefine.init_data[30]['name']                = "pl3/5"       --采集name
g_caipiaoDefine.init_data[30]['desc']                = "1天1期"      --描述

--快乐8
g_caipiaoDefine.init_data[31]                        = {}
g_caipiaoDefine.init_data[31]['tableid']             = 2300031       --桌子id 
g_caipiaoDefine.init_data[31]['maxuser']             = 999           --最大人数
g_caipiaoDefine.init_data[31]['tabletype']           = 1             --桌子类型
g_caipiaoDefine.init_data[31]['tablename']           = "极速快乐8"   --桌子名称
g_caipiaoDefine.init_data[31]['fengpantime']         = 15            --封盘时间间隔开奖时间(s)
g_caipiaoDefine.init_data[31]['openawardtime']       = 15            --开奖时间(s)(本地延迟开奖)
g_caipiaoDefine.init_data[31]['gamekey']             = 31            --彩种
g_caipiaoDefine.init_data[31]['unsettle_checktime']  = 10            --检测未结算订单时间间隔(s)
g_caipiaoDefine.init_data[31]['group']               = "KL8"         --类别
g_caipiaoDefine.init_data[31]['pourlimit']           = 5000 * 100    --下注总额限制
g_caipiaoDefine.init_data[31]['spe_pourlimit']       = 5000 * 100    --特殊玩家下注总额限制
g_caipiaoDefine.init_data[31]['name']                = "jskl8"       --采集name
g_caipiaoDefine.init_data[31]['desc']                = "1分钟1期"    --描述

g_caipiaoDefine.init_data[32]                        = {}
g_caipiaoDefine.init_data[32]['tableid']             = 2300032       --桌子id 
g_caipiaoDefine.init_data[32]['maxuser']             = 999           --最大人数
g_caipiaoDefine.init_data[32]['tabletype']           = 1             --桌子类型
g_caipiaoDefine.init_data[32]['tablename']           = "北京快乐8"   --桌子名称
g_caipiaoDefine.init_data[32]['fengpantime']         = 30            --封盘时间间隔开奖时间(s)
g_caipiaoDefine.init_data[32]['openawardtime']       = 30            --开奖时间(s)(本地延迟开奖)
g_caipiaoDefine.init_data[32]['gamekey']             = 32            --彩种
g_caipiaoDefine.init_data[32]['unsettle_checktime']  = 10            --检测未结算订单时间间隔(s)
g_caipiaoDefine.init_data[32]['group']               = "KL8"         --类别
g_caipiaoDefine.init_data[32]['pourlimit']           = 5000 * 100    --下注总额限制
g_caipiaoDefine.init_data[32]['spe_pourlimit']       = 5000 * 100    --特殊玩家下注总额限制
g_caipiaoDefine.init_data[32]['name']                = "bjkl8"      --采集name
g_caipiaoDefine.init_data[32]['desc']                = "5分钟1期"    --描述
