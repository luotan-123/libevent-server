
--改文件是用于存放排行旁的类型的


RankDefine = {}

RankDefine.rank_jetton = 1001   --欢乐赢豆中金币的排行
RankDefine.rank_money = 1002   --钻石榜单
RankDefine.rank_level = 1003   --等级榜单

RankDefine.rank_dailyjetton = 1004 --每日赚金榜


