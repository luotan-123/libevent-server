g_footballgameDefine = {}
g_footballgameDefine.game_type = 7600   

g_footballgameDefine.order_cancel_time = 3*60


g_footballgameDefine.homeTeamFace = "http://fxlogo.oss-cn-hongkong.aliyuncs.com/teams/266593.png"
g_footballgameDefine.visitTeamFace = "http://fxlogo.oss-cn-hongkong.aliyuncs.com/teams/318725.png"