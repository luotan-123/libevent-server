--彩票三公玩法
g_cpsangongDefine = {}   										

g_cpsangongDefine.game_type = 8200								--经典三公	

g_cpsangongDefine.gamekey = 5									--彩种

g_cpsangongDefine.state_ready = 1   							--准备状态
g_cpsangongDefine.state_start = 2   							--开始状态
g_cpsangongDefine.state_select = 3   							--选位置状态
g_cpsangongDefine.state_pour = 4	    						--下注状态
g_cpsangongDefine.state_collection = 5	    					--采集状态
g_cpsangongDefine.state_count = 6  								--结算状态
g_cpsangongDefine.state_end = 7     							--休息状态
g_cpsangongDefine.state_delete = 8								--删除状态

g_cpsangongDefine.time_start = 1  								--开始时间
g_cpsangongDefine.time_select = 25								--选位置时间
g_cpsangongDefine.time_pour = 10								--下注时间
g_cpsangongDefine.time_count = 20        						--结算时间
g_cpsangongDefine.time_end = 6  								--休息时间

g_cpsangongDefine.player_enter = 101  	 						--刚进入状态
g_cpsangongDefine.player_ready = 102    						--准备完状态
g_cpsangongDefine.player_select = 103    						--位置选完状态
g_cpsangongDefine.player_pour = 104    							--下注完状态


g_cpsangongDefine.max_user = 8									--最大人数
g_cpsangongDefine.posnum = 3									--选位置数量
g_cpsangongDefine.poscount = 50									--公共牌数量
g_cpsangongDefine.timeout_count  = 10   					 --最大超时不结算时间

g_cpsangongDefine.cardtype_lingdian = 100      					--零点
g_cpsangongDefine.cardtype_onelingdian = 101	   				--单公零
g_cpsangongDefine.cardtype_twolingdian = 102   					--双公零
g_cpsangongDefine.cardtype_yidian = 103       					--一点
g_cpsangongDefine.cardtype_oneyidian = 104    					--单公一
g_cpsangongDefine.cardtype_twoyidian = 105     					--双公一
g_cpsangongDefine.cardtype_liangdian = 106     					--两点
g_cpsangongDefine.cardtype_oneliangdian = 107  					--单公两
g_cpsangongDefine.cardtype_woliangdian = 108  					--双公两
g_cpsangongDefine.cardtype_sandian = 109       					--三点
g_cpsangongDefine.cardtype_onesandian = 110    					--单公三
g_cpsangongDefine.cardtype_twosandian = 111    					--双公三
g_cpsangongDefine.cardtype_sidian = 112        					--四点
g_cpsangongDefine.cardtype_onesidian = 113     					--单公四
g_cpsangongDefine.cardtype_twosidian = 114     					--双公四
g_cpsangongDefine.cardtype_wudian = 115        					--五点
g_cpsangongDefine.cardtype_onewudian = 116     					--单公五
g_cpsangongDefine.cardtype_twowudian = 117     					--双公五
g_cpsangongDefine.cardtype_liudian = 118       					--六点
g_cpsangongDefine.cardtype_oneliudian = 119    					--单公六
g_cpsangongDefine.cardtype_twoliudian = 120    					--双公六
g_cpsangongDefine.cardtype_qidian = 121        					--七点
g_cpsangongDefine.cardtype_oneqidian = 122     					--单公七
g_cpsangongDefine.cardtype_twoqidian = 123     					--双公七
g_cpsangongDefine.cardtype_badian = 124        					--八点
g_cpsangongDefine.cardtype_onebadian = 125     					--单公八
g_cpsangongDefine.cardtype_twobadian = 126     					--双公八
g_cpsangongDefine.cardtype_jiudian = 127      		 			--九点
g_cpsangongDefine.cardtype_onejiudian = 128    					--单公九
g_cpsangongDefine.cardtype_wojiudian = 129    					--双公九
g_cpsangongDefine.cardtype_huncpsangong = 130   	  			--混三公
g_cpsangongDefine.cardtype_xiaocpsangong = 131  	  			--小三公
g_cpsangongDefine.cardtype_dacpsangong = 132    	 			--大三公
g_cpsangongDefine.cardtype_baojiu = 133        					--爆九

g_cpsangongDefine.CardType = {}
g_cpsangongDefine.CardType[0] = g_cpsangongDefine.cardtype_lingdian
g_cpsangongDefine.CardType[1] = g_cpsangongDefine.cardtype_yidian
g_cpsangongDefine.CardType[2] = g_cpsangongDefine.cardtype_liangdian
g_cpsangongDefine.CardType[3] = g_cpsangongDefine.cardtype_sandian
g_cpsangongDefine.CardType[4] = g_cpsangongDefine.cardtype_sidian
g_cpsangongDefine.CardType[5] = g_cpsangongDefine.cardtype_wudian
g_cpsangongDefine.CardType[6] = g_cpsangongDefine.cardtype_liudian
g_cpsangongDefine.CardType[7] = g_cpsangongDefine.cardtype_qidian
g_cpsangongDefine.CardType[8] = g_cpsangongDefine.cardtype_badian
g_cpsangongDefine.CardType[9] = g_cpsangongDefine.cardtype_jiudian


g_cpsangongDefine.chat_txt = 1									--聊天文字				
g_cpsangongDefine.chat_img = 2									--聊天图片
g_cpsangongDefine.chat_voice = 3								--聊天语音

g_cpsangongDefine.autoReady_yes = 1								--自动准备
g_cpsangongDefine.autoReady_no = 0								--手动准备

g_cpsangongDefine.autoSelect_yes = 1							--自动选位置
g_cpsangongDefine.autoSelect_no = 0								--手动选位置

g_cpsangongDefine.tableType_primary = 1							--初级场
g_cpsangongDefine.tableType_intermediate = 2					--中级场
g_cpsangongDefine.tableType_advanced = 3						--高级场
g_cpsangongDefine.tableType_Extreme = 4							--至尊场
g_cpsangongDefine.tableType_super = 5							--超级场

g_cpsangongDefine.pourList = {}
g_cpsangongDefine.pourList[1] = "500/1000/1500/2000"					--初级场下注列表
g_cpsangongDefine.pourList[2] = "1000/2000/3000/4000"					--中级场下注列表
g_cpsangongDefine.pourList[3] = "2000/4000/6000/8000"					--高级场下注列表
g_cpsangongDefine.pourList[4] = "5000/10000/15000/20000"				--至尊场下注列表
g_cpsangongDefine.pourList[5] = "10000/20000/30000/40000"				--超级场下注列表

g_cpsangongDefine.minEnter = {}
g_cpsangongDefine.minEnter[1] = 2000							--初级场最低准入
g_cpsangongDefine.minEnter[2] = 5000							--中级场最低准入
g_cpsangongDefine.minEnter[3] = 10000							--高级场最低准入
g_cpsangongDefine.minEnter[4] = 20000							--至尊场最低准入
g_cpsangongDefine.minEnter[5] = 50000							--超级场最低准入			

g_cpsangongDefine.MaxEnterJetton = {}
g_cpsangongDefine.MaxEnterJetton[1] = -1						--初级场最高准入
g_cpsangongDefine.MaxEnterJetton[2] = -1						--中级场最高准入
g_cpsangongDefine.MaxEnterJetton[3] = -1						--高级场最高准入
g_cpsangongDefine.MaxEnterJetton[4] = -1						--至尊场最高准入
g_cpsangongDefine.MaxEnterJetton[5] = -1						--超级场最高准入

g_cpsangongDefine.minPour = {}
g_cpsangongDefine.minPour[1] = 500								--初级场最低下注
g_cpsangongDefine.minPour[2] = 1000								--中级场最低下注
g_cpsangongDefine.minPour[3] = 2000								--高级场最低下注
g_cpsangongDefine.minPour[4] = 5000								--至尊场最低下注
g_cpsangongDefine.minPour[5] = 10000							--超级场最低下注

g_cpsangongDefine.maxPour = {}
g_cpsangongDefine.maxPour[1] = 999999999						--初级场最高下注
g_cpsangongDefine.maxPour[2] = 999999999						--中级场最高下注
g_cpsangongDefine.maxPour[3] = 999999999						--高级场最高下注
g_cpsangongDefine.maxPour[4] = 999999999						--至尊场最高下注
g_cpsangongDefine.maxPour[5] = 999999999						--超级场最高下注

g_cpsangongDefine.robotEnterJetton = {}
g_cpsangongDefine.robotEnterJetton[1] = {2000, 20000}			--初级场机器人进入范围
g_cpsangongDefine.robotEnterJetton[2] = {5000, 50000}			--中级场机器人进入范围
g_cpsangongDefine.robotEnterJetton[3] = {10000, 100000}			--高级场机器人进入范围
g_cpsangongDefine.robotEnterJetton[4] = {20000, 200000}			--至尊场机器人进入范围
g_cpsangongDefine.robotEnterJetton[5] = {50000, 500000}			--超级场机器人进入范围


g_cpsangongDefine.game_lockstate = {}
g_cpsangongDefine.game_lockstate.lock_no = 1
g_cpsangongDefine.game_lockstate.lock_yes = 2
