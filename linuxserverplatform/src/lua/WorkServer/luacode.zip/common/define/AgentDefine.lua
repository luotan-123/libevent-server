


-- 以前的渠道号，不用管了
------------------------------------------------
g_agentDeine = {}
g_agentDeine.channel_thyl = "thyl"    --天河娱乐
g_agentDeine.channel_xyyl = "xyyl"    --轩辕娱乐
g_agentDeine.channel_cfyl = "cfyl"    --超凡娱乐
g_agentDeine.channel_hyyl = "hyyl"    --红运娱乐
-------------------------------------------------





-- 配置所有渠道号
-- 目前使用的渠道号，配置这里就行
------------------------------------------------
g_agentAllChannel = {}
g_agentAllChannel[1] 	= "qmty_bct"  	--全名体育
g_agentAllChannel[2] 	= "tty_bct"    	--天天赢
g_agentAllChannel[3] 	= "gjlm_bct"    --冠军联盟
-------------------------------------------------