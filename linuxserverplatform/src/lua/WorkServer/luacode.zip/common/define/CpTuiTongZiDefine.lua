--彩票推筒子
g_CpTuiTongZiDefine = {}

g_CpTuiTongZiDefine.game_type = 8300

g_CpTuiTongZiDefine.gamekey = 5								--彩种	   									

g_CpTuiTongZiDefine.state_ready = 1							--准备状态
g_CpTuiTongZiDefine.state_start  = 2     					--开始状态
g_CpTuiTongZiDefine.state_banker = 3     					--抢庄状态
g_CpTuiTongZiDefine.state_select = 4						--选位置状态
g_CpTuiTongZiDefine.state_pour = 5    						--下注状态
g_CpTuiTongZiDefine.state_collection = 6    				--采集状态
g_CpTuiTongZiDefine.state_count  = 7						--结算状态
g_CpTuiTongZiDefine.state_next = 8							--休息状态
g_CpTuiTongZiDefine.state_delete = 9						--删除状态

g_CpTuiTongZiDefine.time_start = 1							--开始时间
g_CpTuiTongZiDefine.time_banker = 5 						--抢庄时间
g_CpTuiTongZiDefine.time_select = 26      					--选位置时间
g_CpTuiTongZiDefine.time_pour =  5      					--下注时间
g_CpTuiTongZiDefine.time_count = 15							--结算时间
g_CpTuiTongZiDefine.time_next =  6							--休息时间

g_CpTuiTongZiDefine.player_enter = 101   					--刚进入状态
g_CpTuiTongZiDefine.player_ready = 102  					--准备完状态
g_CpTuiTongZiDefine.player_banker = 103						--抢庄完状态
g_CpTuiTongZiDefine.player_select = 105   					--位置选完状态
g_CpTuiTongZiDefine.player_pour = 106   					--下注状态

g_CpTuiTongZiDefine.max_user = 8							--最大人数
g_CpTuiTongZiDefine.posnum = 2								--选位置数量
g_CpTuiTongZiDefine.poscount = 20							--公共牌数量
g_CpTuiTongZiDefine.halfPoint = 1							--是否显示半点
g_CpTuiTongZiDefine.timeout_count  = 10    					--最大超时不结算时间

g_CpTuiTongZiDefine.cardType_zero = 1    					--鳖十
g_CpTuiTongZiDefine.cardType_one = 2     					--一点
g_CpTuiTongZiDefine.cardType_onehalf = 3     				--一点半
g_CpTuiTongZiDefine.cardType_two = 4     					--二点
g_CpTuiTongZiDefine.cardType_twohalf = 5     				--二点半
g_CpTuiTongZiDefine.cardType_three = 6   					--三点
g_CpTuiTongZiDefine.cardType_threehalf = 7   				--三点半
g_CpTuiTongZiDefine.cardType_four = 8     					--四点
g_CpTuiTongZiDefine.cardType_fourhalf = 9     				--四点半
g_CpTuiTongZiDefine.cardType_five = 10     					--五点
g_CpTuiTongZiDefine.cardType_fivehalf = 11     				--五点半
g_CpTuiTongZiDefine.cardType_six = 12    					--六点
g_CpTuiTongZiDefine.cardType_sixhalf = 13    				--六点半
g_CpTuiTongZiDefine.cardType_seven = 14    					--七点
g_CpTuiTongZiDefine.cardType_sevenhalf = 15    				--七点半
g_CpTuiTongZiDefine.cardType_eight = 16    					--八点
g_CpTuiTongZiDefine.cardType_eighthalf = 17    				--八点半
g_CpTuiTongZiDefine.cardType_nine = 18   					--九点
g_CpTuiTongZiDefine.cardType_ninehalf = 19   				--九点半
g_CpTuiTongZiDefine.cardType_twoEight = 20					--二八杠
g_CpTuiTongZiDefine.cardType_onebao = 21  					--一宝
g_CpTuiTongZiDefine.cardType_twobao = 22  					--二宝
g_CpTuiTongZiDefine.cardType_threebao = 23  				--三宝
g_CpTuiTongZiDefine.cardType_fourbao = 24  					--四宝
g_CpTuiTongZiDefine.cardType_fivebao = 25  					--五宝
g_CpTuiTongZiDefine.cardType_sixbao = 26  					--六宝
g_CpTuiTongZiDefine.cardType_sevenbao = 27  				--七宝
g_CpTuiTongZiDefine.cardType_egihtbao = 28  				--八宝
g_CpTuiTongZiDefine.cardType_ninebao = 29  					--九宝
g_CpTuiTongZiDefine.cardType_King = 30  					--天王

g_CpTuiTongZiDefine.chat_txt = 1							--聊天文字	
g_CpTuiTongZiDefine.chat_img = 2							--聊天图片
g_CpTuiTongZiDefine.chat_voice = 3							--聊天语音

g_CpTuiTongZiDefine.autoReady_yes = 1						--自动准备
g_CpTuiTongZiDefine.autoReady_no = 0						--手动准备

g_CpTuiTongZiDefine.autoOpt_yes = 1							--自动准备
g_CpTuiTongZiDefine.autoOpt_no = 0							--手动准备

g_CpTuiTongZiDefine.grade_free = 1 							--初级场
g_CpTuiTongZiDefine.grade_junior = 2						--中级场
g_CpTuiTongZiDefine.grade_medium = 3						--高级场
g_CpTuiTongZiDefine.grade_senior = 4						--至尊场
g_CpTuiTongZiDefine.grade_senior = 5						--超级场


g_CpTuiTongZiDefine.pourList = {}
g_CpTuiTongZiDefine.pourList[1] = "1/2/3/4"				--初级场下注列表
g_CpTuiTongZiDefine.pourList[2] = "1/2/3/4"				--中级场下注列表
g_CpTuiTongZiDefine.pourList[3] = "1/2/3/4"				--高级场下注列表
g_CpTuiTongZiDefine.pourList[4] = "1/2/3/4"				--至尊场下注列表
g_CpTuiTongZiDefine.pourList[5] = "1/2/3/4"				--超级场下注列表

g_CpTuiTongZiDefine.difen = {}
g_CpTuiTongZiDefine.difen[1] = 100							--初级场默认底分
g_CpTuiTongZiDefine.difen[2] = 200							--中级场默认底分
g_CpTuiTongZiDefine.difen[3] = 500							--高级场默认底分
g_CpTuiTongZiDefine.difen[4] = 1000							--至尊场默认底分
g_CpTuiTongZiDefine.difen[5] = 2000							--超级场默认底分


g_CpTuiTongZiDefine.minEnterJetton = {}
g_CpTuiTongZiDefine.minEnterJetton[1] = 2500					--初级场最低准入
g_CpTuiTongZiDefine.minEnterJetton[2] = 5000					--中级场最低准入
g_CpTuiTongZiDefine.minEnterJetton[3] = 25000					--高级场最低准入
g_CpTuiTongZiDefine.minEnterJetton[4] = 50000					--至尊场最低准入
g_CpTuiTongZiDefine.minEnterJetton[5] = 100000					--超级场最低准入

g_CpTuiTongZiDefine.MaxEnterJetton = {}
g_CpTuiTongZiDefine.MaxEnterJetton[1] = -1						--初级场最高准入
g_CpTuiTongZiDefine.MaxEnterJetton[2] = -1						--中级场最高准入
g_CpTuiTongZiDefine.MaxEnterJetton[3] = -1						--高级场最高准入
g_CpTuiTongZiDefine.MaxEnterJetton[4] = -1						--至尊场最高准入
g_CpTuiTongZiDefine.MaxEnterJetton[5] = -1						--超级场最高准入


g_CpTuiTongZiDefine.robotEnterJetton = {}
g_CpTuiTongZiDefine.robotEnterJetton[1] = {2500, 10000}		--初级场机器人进入范围
g_CpTuiTongZiDefine.robotEnterJetton[2] = {5000, 40000}		--中级场机器人进入范围
g_CpTuiTongZiDefine.robotEnterJetton[3] = {25000, 100000}		--高级场机器人进入范围
g_CpTuiTongZiDefine.robotEnterJetton[4] = {50000, 200000}		--至尊场机器人进入范围
g_CpTuiTongZiDefine.robotEnterJetton[5] = {100000, 500000}		--超级场机器人进入范围


g_CpTuiTongZiDefine.game_lockstate = {}
g_CpTuiTongZiDefine.game_lockstate.lock_no = 1
g_CpTuiTongZiDefine.game_lockstate.lock_yes = 2 
