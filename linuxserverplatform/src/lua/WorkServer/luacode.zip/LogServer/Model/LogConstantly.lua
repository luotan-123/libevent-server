LogConstantly = {}
LogConstantly.redis_index = "redis_log"

LogConstantly.con_game_win = "con_game_win_"

LogConstantly.con_game_num = "con_game_num_"

LogConstantly.con_game_pour = "con_game_pour_"

--gameType : 游戏类型
--gameMark  :  游戏的表示，如果是百人场，那么，这个就是tableid，如果非百人场，那么这个就是tabletype

function LogConstantly.IncrGameWinJetton(gameType, gameMark, userID, winCount)    --每次游戏结束的时候，必须调用此方法，同步刷新对应的数据。
	
	redisItem:hincrby( LogConstantly.con_game_win..gameType..gameMark, userID, winCount, LogConstantly.redis_index )
	
end

function LogConstantly.GetGameWinJetton(gameType, gameMark, userID)
	local winJetton = redisItem:hget( LogConstantly.con_game_win..gameType..gameMark, userID, LogConstantly.redis_index )
	return winJetton == nil and 0 or winJetton
end

function LogConstantly.IncrGamePourJetton(gameType, gameMark, userID, pourJetton)
	redisItem:hincrby(LogConstantly.con_game_pour..gameType..gameMark, userID, pourJetton, LogConstantly.redis_index)
end

function LogConstantly.GetGamePourJetton(gameType, gameMark, userID)
	local pourJetton = redisItem:hget( LogConstantly.con_game_pour..gameType..gameMark, userID, LogConstantly.redis_index )
	return pourJetton == nil and 0 or pourJetton	
end


function LogConstantly.GetPlayerList(gameType, gameMark)
	
	return redisItem:hgetall(LogConstantly.con_game_win..gameType..gameMark, LogConstantly.redis_index)
	
end

--百人类游戏的玩法，在每次游戏启动的时候，调用该方法，同步玩家的数据信息
function LogConstantly.HundredGameUpdate(gameType, gameMark, userList)
	
	local allList = redisItem:hkeys(LogConstantly.con_game_win..gameType..gameMark, LogConstantly.redis_index)
	
	for k,v in ipairs(userList) do
		table.remove(allList, tostring(v))
	end	
	for k,v in pairs(allList) do
		redisItem:hdel( LogConstantly.con_game_win..gameType..gameMark, k , LogConstantly.redis_index )
	end
end



function LogConstantly.IncrPlayerGameNum(gameType, gameMark, userID)
	
	redisItem:hincrby(LogConstantly.con_game_num..gameType..gameMark, userID, 1, LogConstantly.redis_index)
	
end

function LogConstantly.GetPlayerGameNum(gameType, gameMark, userID)
	
	local num = redisItem:hget(LogConstantly.con_game_num..gameType..gameMark, userID, LogConstantly.redis_index)
	return num == nil and 0 or num
	
end

