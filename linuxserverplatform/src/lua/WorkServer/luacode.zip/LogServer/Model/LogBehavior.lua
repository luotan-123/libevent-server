
LogBehavior = {}
--该类用于记录玩家所有行为的log


function LogBehavior.Info(pInfo, category, tag, retcode, msg)
	local sqlCase = ""
	if type(pInfo) == "number" then
		sqlCase = "insert into log_behavior(userid,createdate,category,tag,retcode,msg) values("..pInfo..",'"..
			TimeUtils.GetTimeString().."','"..category.."','"..tag.."',"..retcode..",'"..msg.."')"
	elseif type(pInfo) == "string" then
		sqlCase = "insert into log_behavior(nickname,createdate,category,tag,retcode,msg) values('"..pInfo.."','"..
			TimeUtils.GetTimeString().."','"..category.."','"..tag.."',"..retcode..",'"..msg.."')"

	else
		local prechannel = GameUtils.GetChannel_login(pInfo.channel)
		sqlCase = "insert into log_behavior(userid,nickname,createdate,category,tag,retcode,msg,channel,prechannel) values("..pInfo.userid..",'"..pInfo.nickname.."','"..
			TimeUtils.GetTimeString().."','"..category.."','"..tag.."',"..retcode..",'"..msg.."','"..pInfo.channel.."','"..prechannel.."')"
	end
	
	LogModel.LogBehaviorPush(sqlCase)
end

function LogBehavior.InfoJetton(pInfo, category, tag, retcode, msg, modNum, allNum)
	local sqlCase = ""
	if type(pInfo) == "number" then
		sqlCase = "insert into log_behavior(userid,createdate,category,tag,costamount,getamount,retcode,msg) values("..pInfo..",'"..
			TimeUtils.GetTimeString().."','"..category.."','"..tag.."',"..modNum..","..allNum..","..retcode..",'"..msg.."')"
	elseif type(pInfo) == "string" then
		sqlCase = "insert into log_behavior(nickname,createdate,category,tag,costamount,getamount,retcode,msg) values('"..pInfo.."','"..
			TimeUtils.GetTimeString().."','"..category.."','"..tag.."',"..modNum..","..allNum..","..retcode..",'"..msg.."')"
	else
		sqlCase = "insert into log_behavior(userid,nickname,createdate,category,tag,costamount,getamount,retcode,msg) values("..pInfo.userid..",'"..pInfo.nickname.."','"..
			TimeUtils.GetTimeString().."','"..category.."','"..tag.."',"..modNum..","..allNum..","..retcode..",'"..msg.."')"
	end
	
	LogModel.LogBehaviorPush(sqlCase)
end

function LogBehavior.Warning(pInfo, category, tag, retcode, msg)
	local sqlCase = ""
	if type(pInfo) == "number" then
		sqlCase = "insert into log_behavior(userid,level,createdate,category,tag,retcode,msg) values("..pInfo..",'warning','"..
			TimeUtils.GetTimeString().."','"..category.."','"..tag.."',"..retcode..",'"..msg.."')"
	elseif type(pInfo) == "string" then
		sqlCase = "insert into log_behavior(nickname,level,createdate,category,tag,retcode,msg) values('"..pInfo.."','warning','"..
			TimeUtils.GetTimeString().."','"..category.."','"..tag.."',"..retcode..",'"..msg.."')"
	else
		sqlCase = "insert into log_behavior(userid,nickname,level,createdate,category,tag,retcode,msg) values("..pInfo.userid..",'"..pInfo.nickname.."','warning','"..
			TimeUtils.GetTimeString().."','"..category.."','"..tag.."',"..retcode..",'"..msg.."')"
	end
	LogModel.LogBehaviorPush(sqlCase)
end

function LogBehavior.Error(pInfo, category, tag, retcode, msg)
	local sqlCase = ""
	if type(pInfo) == "number" then
		sqlCase = "insert into log_behavior(userid,level,createdate,category,tag,retcode,msg) values("..pInfo..",'error','"..
			TimeUtils.GetTimeString().."','"..category.."','"..tag.."',"..retcode..",'"..msg.."')"
	
	elseif type(pInfo) == "string" then
		sqlCase = "insert into log_behavior(nickname,level,createdate,category,tag,retcode,msg) values('"..pInfo.."','error','"..
			TimeUtils.GetTimeString().."','"..category.."','"..tag.."',"..retcode..",'"..msg.."')"
	else
		sqlCase = "insert into log_behavior(userid,nickname,level,createdate,category,tag,retcode,msg) values("..pInfo.userid..",'"..pInfo.nickname.."','error','"..
			TimeUtils.GetTimeString().."','"..category.."','"..tag.."',"..retcode..",'"..msg.."')"
	end
	LogModel.LogBehaviorPush(sqlCase)
end

--[[
opttype 操作类型，1=登录，2=登出，3=修改密码，4=信息修改
]]
function LogBehavior.UserAction(pInfo, opttype, remark)
    local sqlCase = ""
    local prechannel = GameUtils.GetChannel_login(pInfo.channel)
    
    sqlCase = "insert into log_useraction(userid,plat,ip,lastaddr,create_at,remark,channel,prechannel,opttype) values("..pInfo.userid..",'"..pInfo.oprsys.."','"..pInfo.ip.. "','"..pInfo.ipaddr.. "','"..
    TimeUtils.GetTimeString().."','"..remark.."','"..pInfo.channel.."','"..prechannel.."',"..opttype..")"  
    --print(sqlCase)
    LogModel.LogBehaviorPush(sqlCase)
end