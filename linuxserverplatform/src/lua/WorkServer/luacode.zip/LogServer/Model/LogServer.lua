LogServer = {}



function LogServer.Init()
	
	
end

function LogServer.NewPlayer(pInfo)
	if RobotService.IsRobot(pInfo.userid) then
		return
	end
	--有新玩家进来的时候
	--在log_player表中插入一条记录
	--更新log_sysdaily中玩家总数以及最近玩家人数
	
	LogModel.SetRedisMaxConday(pInfo.userid, 1)
	LogModel.SetRedisConday(pInfo.userid, 1)

	LogDispatch.NewPlayer(pInfo)
end

function LogServer.ReportInfo()

	reportTime = TimeUtils.GetTableTime()
	
	local minutes = TimeUtils.GetDayMinutes(reportTime)

	local onlineNum = OnlineModel.GetOnlineNum()

	onlineNum = onlineNum == nil and 0 or onlineNum
	onlineNum = string.format("%#x",onlineNum)
	onlineNum = string.sub(onlineNum,3,string.len(onlineNum))
	
	minutes = string.format("%#x",minutes)
	minutes = string.sub(minutes,3,string.len(minutes))	
	
	local sqlCase = "update log_onlinedaily set onlinelist=concat(onlinelist,'"..onlineNum.."|'),minulist=concat(minulist,'"..minutes.."|') where dateid='"..TimeUtils.GetDayString().."'"

	LogModel.LogSysdailyPush(sqlCase)
	
	OnlineModel.UpdateMaxOnline()
end


function LogServer.PlayerRetain(pInfo)
	if RobotService.IsRobot(userID) then
		return
	end	
	--每次登入的时候，对留存进行分析
	local timeSec = TimeUtils.GetTime()

	if pInfo.lasttime == 0 then
		pInfo.lasttime = timeSec
	end

	local regDay = TimeUtils.DifferentDay(pInfo.regdate, timeSec) + 1
	
	if regDay < 1 then
		return
	end
	
	local sqlCase = "update log_retain set loginday=loginday+1"
	
	local dayid
	if regDay <= 30 and regDay > 0 then
		dayid = "day"..regDay
	elseif regDay <= 60 then
		dayid = "day30"
	elseif regDay <= 90 then
		dayid = "day90"
	elseif regDay <= 120 then
		dayid = "day120"
	elseif regDay <= 150 then
		dayid = "day150"
	elseif regDay <= 180 then
		dayid = "day180"
	elseif regDay <= 210 then
		dayid = "day210"
	elseif regDay <= 240 then
		dayid = "day240"
	elseif regDay <= 270 then
		dayid = "day270"
	elseif regDay <= 300 then
		dayid = "day300"
	elseif regDay <= 330 then
		dayid = "day330"
	else
		dayid = "day360"
	end
	sqlCase = sqlCase..","..dayid.."="..dayid.."+1"
	sqlCase = sqlCase..",updatetime="..TimeUtils.GetTime().." where userid="..pInfo.userid

	LogModel.LogRetain(sqlCase)

end


--检查玩牌的最高筹码
function LogServer.CheckMaxJetton(userID, jetton)

	if RobotService.IsRobot(userID) then
		return
	end
	
	local maxjetton = LogModel.GetMaxJetton(userID)

	if jetton < maxjetton then
		return
	end
	maxjetton = jetton
	local sqlCase = "update log_player set maxjetton="..maxjetton.." where userid="..userID
	
	LogModel.SetRedisMaxJetton(userID, maxjetton)
	LogModel.LogPlayerPush(sqlCase)
end


function LogServer.PlayerFee(userID, amount)
	if RobotService.IsRobot(userID) then
		return
	end	
	--[[
	local sqlCase = "update log_player set feeamount=feeamount+"..amount.." where userid="..userID
	LogModel.LogPlayerPush(sqlCase)
	
	sqlCase = "update log_playerdaily set feeamount=feeamount+"..amount.." where id >0 and userid="..userID.." and dateid='"..TimeUtils.GetDayString().."'"
	LogModel.LogPlayerPush(sqlCase)

	sqlCase = "update log_playerweek set feeamount=feeamount+"..amount.." where id >0 and userid="..userID.." and dateid='"..TimeUtils.GetWeekString().."'"
	LogModel.LogPlayerPush(sqlCase)

	sqlCase = "update log_playermonth set feeamount=feeamount+"..amount.." where id >0 and userid="..userID.." and dateid='"..TimeUtils.GetMonthString().."'"
	LogModel.LogPlayerPush(sqlCase)
	]]
	
	
	
end



--入参说明：gameType:游戏类型
--tableType:牌桌类型
--result：开奖结果 tablelist 例如：{庄家：红桃1，方块2，梅花8},{}
--zhuanginfo：庄家的信息
--winList:赢钱的列表 {区域A:  {玩家A：{下注额：100}{盈利：200}}, 玩家B：{下注额：100}{盈利：200}}
--loseList:数钱列表 {区域B：{玩家A：100,}{玩家B：200}}
--whiteList :白名单
--blackList ：黑名单
--pondInfo : 奖池信息,直接把结构体传入
--sysWin，系统输赢，
--feeNum，抽水
--addPondNum:奖池的变化，
--pondRateNum : 奖池的抽水
function LogServer.GameEndCommit(gameType,tableType,result,zhuangInfo, winList,loseList,whiteList,blackList,pondInfo, sysWin, feeNum, addPondNum, pondRateNum, gameNumber)

	local zuInfo = {}
	zuInfo['userid'] = zhuangInfo.userid
	zuInfo['nickname'] = zhuangInfo.nickname
	zuInfo['winnum'] = 0 - sysWin
	zuInfo['jetton'] = zhuangInfo.jetton
	
	if gameNumber == nil then
		gameNumber = ""
	end
	
	local pondList = {}
	pondList["奖池"] = pondInfo.jiangjetton
	pondList["等级1"] = pondInfo.level_1
	pondList["概率1"] = pondInfo.rate_1
	pondList["等级2"] = pondInfo.level_2
	pondList["概率2"] = pondInfo.rate_2
	pondList["等级3"] = pondInfo.level_3
	pondList["概率3"] = pondInfo.rate_3
	pondList["等级4"] = pondInfo.level_4
	pondList["概率4"] = pondInfo.rate_4	
   
   	local sqlCase = "insert into log_gamedetail(createdate,gameType,gamename,tableType,tablename,result,zhuanginfo,winlist,loselist,whitelist,blacklist,pondinfo,syswin,feenum,gamenumber) values('"..TimeUtils.GetTimeString().."',"..
		gameType..",'"..GameUtils.GetGameName(gameType).."',"..tableType..",'"..GameUtils.GetTableName(gameType, tableType).."','"..luajson.encode(result).."','"..luajson.encode(zuInfo).."','"..luajson.encode(winList).."','"..
		luajson.encode(loseList).."','"..luajson.encode(whiteList).."','"..luajson.encode(blackList).."','"..luajson.encode(pondList).."',"..sysWin..","..feeNum..",'"..gameNumber.."')"
	--LogFile("sqlDebug",sqlCase)
	
	
	
	LogModel.LogUserGameDetail(sqlCase)


	
end



--pInfo：玩家的用户信息
--winCount:输赢金额,输了就是负数
--gameType:
--tableType:
--tableID：牌桌ID
--resultList: 如果是拼三张，斗地主，牛牛，把拿到的牌的牌型传入，其他百人场，就把玩家赢牌列表传入
--pourJetton:下注总额
--winList：下注后赢牌的区域的列表  {"龙"：100,}
--lostList:下注后输钱的区域列表   {"虎"：200，"和"：100}
--feeNum : 抽水总额,
function LogServer.GameUserCount(pInfo, winCount, gameType, tableType, tableID, resultList, pourJetton,winList,loseList, feeNum, msg, achamount, gameNumber,season)
	
	local Count = achamount 
	if g_CommissionFwSwitch == 1 then
		--抽水不算流水
		local tmp = feeNum == nil and 0 or feeNum
		Count = Count - tmp
	end
	
	--新手保护期间的赢输
	PlayerModel.addNewPlayerCount(pInfo.userid, winCount+feeNum)
	
	if gameNumber == nil then
		gameNumber = ""
	end
	
	local sqlCase = "insert into log_usergamelist(userid,nickname,gametype,gamename,createdate,tabletype,tablename,tableid,result,pourjetton,winjetton,feenum,winlist,loselist) values("..
		pInfo.userid..",'"..pInfo.nickname.."',"..gameType..",'"..GameUtils.GetGameName(gameType).." ','"..TimeUtils.GetTimeString().."',"..tableType..",'"..GameUtils.GetTableName(gameType,tableType).."',"..
		tableID..",'"..luajson.encode(resultList).."',"..pourJetton..","..winCount..","..feeNum..",'"..luajson.encode(winList).."','"..luajson.encode(loseList).."')"

	LogModel.LogUserGameList(sqlCase)

	LogServer.GameUserMoney(pInfo, gameType, tableType, winCount,msg, Count, gameNumber,season)
	
	--实时监控系统
	RTMModel.addPlayerRecord(pInfo.userid, pInfo.nickname, TimeUtils.GetTime(), gameType,tableType, winCount, pInfo.jetton, msg)
	
	
	GameModel.addGameTableTypeWin(pInfo.userid, gameType, tableType, winCount)
	--连赢活动暂时不开
    --LogServer.BrcGameUserQuinella(pInfo.userid,gameType,tableType,winCount)
	--对局排名活动
	--LogServer.statisticsMatchScore(pInfo.userid,gameType)
	
	--统计玩家
	local winAll = 0
    local channel = pInfo.channel

    winAll = 0 - (winCount + feeNum)
      
	sqlCase = "update log_syschannel set feeamount=feeamount+"..feeNum..",syswinamount=syswinamount+"..winAll.." where id > 0 and channel='all' or channel='"..channel.."'"
	LogModel.LogSysdailyPush(sqlCase)
	
	sqlCase = "update log_sysdaily set feeamount=feeamount+"..feeNum..",syswinamount=syswinamount+"..winAll.." where id>0 and dateid='"..TimeUtils.GetDayString().."' and (channel='all' or channel='"..channel.."')"
	LogModel.LogSysdailyPush(sqlCase)	


	sqlCase = "update log_sysweek set feeamount=feeamount+"..feeNum..",syswinamount=syswinamount+"..winAll.." where id>0 and dateid='"..TimeUtils.GetWeekString().."' and (channel='all' or channel='"..channel.."')"
	LogModel.LogSysdailyPush(sqlCase)	

	sqlCase = "update log_sysmonth set feeamount=feeamount+"..feeNum..",syswinamount=syswinamount+"..winAll.." where id>0 and dateid='"..TimeUtils.GetMonthString().."' and (channel='all' or channel='"..channel.."')"
	LogModel.LogSysdailyPush(sqlCase)

	
end


--捕鱼的奖励记录
function LogServer.BuYuUserCount(pInfo, winCount, gameType, tableType, tableID, pourJetton, feeNum,logstr,achamount)
	
	
	local redisStr = GameUtils.GetTableName(gameType, tableType)
	
	redisStr = redisStr..",发炮"..string.format("%.2f", pourJetton/100)..",赢得"..string.format("%.2f", winCount/100).."元,"..tostring(logstr)
	local t_redisStr = {redisStr=redisStr,achamount=achamount}
    local str = luajson.encode(t_redisStr)
	local allWin = winCount - pourJetton
	LogModel.LogBuYu( pInfo.userid, str, pInfo.jetton ,allWin )
	
end


--转账统计
function LogServer.TransferCount(toPinfo, fromPinfo, amount,optmsg)
	if optmsg == nil then
	   optmsg = "银行转入"
	end
	local tchannel = toPinfo.channel --GameUtils.GetChannel(toPinfo.channel)
    local tprechannel = GameUtils.GetChannel_login(tchannel)
	local msg = "收到["..fromPinfo.userid.."]"..fromPinfo.nickname.."转入"..string.format("%.2f", amount/100).."元"
	
	local sqlCase = "insert into log_moneydetail(userid,nickname,createdate,opttype,optmsg,amount,usermoney,remark,channel,prechannel,season,tyjetton,gamejetton,cpjetton ) values("..
            toPinfo.userid..",'"..toPinfo.nickname.."','"..TimeUtils.GetTimeString().."',"..g_moneyOptType.opt_transfer_in..",'"..optmsg.."',"..amount..","..toPinfo.jetton..",'"..msg.."','"..tchannel.."','"..
            tprechannel.."',"..g_moneyOptType.opt_transfer_in..","..toPinfo.tyjetton..","..toPinfo.gamejetton..","..toPinfo.cpjetton..")"
	LogModel.LogUserMoneyList(sqlCase)	

    if optmsg == nil then
	   optmsg = "银行转出"
	end

	msg = "向["..toPinfo.userid.."]"..toPinfo.nickname.."转出"..string.format("%.2f", amount/100).."元"
	amount = 0-amount
    local fchannel = fromPinfo.channel --GameUtils.GetChannel(fromPinfo.channel)
    local fprechannel = GameUtils.GetChannel_login(fchannel)
	sqlCase = "insert into log_moneydetail(userid,nickname,createdate,opttype,optmsg,amount,usermoney,remark,channel,prechannel,season,tyjetton,gamejetton,cpjetton ) values("..fromPinfo.userid..",'"..fromPinfo.nickname.."','"..TimeUtils.GetTimeString().."',"..g_moneyOptType.opt_transfer_out..",'银行转出',"..
		amount..","..fromPinfo.jetton..",'"..msg.."','"..fchannel.."','".. tprechannel.."',"..g_moneyOptType.opt_transfer_in..","..fromPinfo.tyjetton..","..fromPinfo.gamejetton..","..fromPinfo.cpjetton..")"
	--mysqlItem:execute(sqlCase)
	LogModel.LogUserMoneyList(sqlCase)
	
end
--

--存入银行中
function LogServer.BankDeposit(pInfo, amount)
	
	local msg = "往银行存入"..string.format("%.2f", amount/100).."元"
    local channel = pInfo.channel --GameUtils.GetChannel(pInfo.channel)
	local sqlCase = "insert into log_moneydetail(userid,nickname,createdate,opttype,optmsg,amount,usermoney,remark,channel) values("..pInfo.userid..",'"..pInfo.nickname.."','"..TimeUtils.GetTimeString().."',"..g_moneyOptType.opt_bank_in..",'银行存入',"..
		amount..","..pInfo.jetton..",'"..msg.."','"..channel.."')"
	--mysqlItem:execute(sqlCase)
	LogModel.LogUserMoneyList(sqlCase)
end

--从银行中取出
function LogServer.BankWithdraw(pInfo, amount)
	
	local msg = "从银行中取出"..string.format("%.2f", amount/100).."元"
	local channel = pInfo.channel --GameUtils.GetChannel(pInfo.channel)
	local sqlCase = "insert into log_moneydetail(userid,nickname,createdate,opttype,optmsg,amount,usermoney,remark,channel) values("..pInfo.userid..",'"..pInfo.nickname.."','"..TimeUtils.GetTimeString().."',"..g_moneyOptType.opt_bank_out..",'银行取出',"..
		amount..","..pInfo.jetton..",'"..msg.."','"..channel.."')"
	--mysqlItem:execute(sqlCase)
	LogModel.LogUserMoneyList(sqlCase)
end

--存入视讯账号中
function LogServer.SxBankDeposit(pInfo, amount)
	
	local msg = "往视讯账号存入"..string.format("%.2f", amount/100).."元"
	print("llllll"..msg)
    local channel = pInfo.channel --GameUtils.GetChannel(pInfo.channel)
	local sqlCase = "insert into log_moneydetail(userid,nickname,createdate,opttype,optmsg,amount,usermoney,remark,channel) values("..pInfo.userid..",'"..pInfo.nickname.."','"..TimeUtils.GetTimeString().."',"..g_moneyOptType.opt_sx_in..",'视讯账号存入',"..
		amount..","..pInfo.jetton..",'"..msg.."','"..channel.."')"
	--mysqlItem:execute(sqlCase)
	LogModel.LogUserMoneyList(sqlCase)
end

--从视讯账号中取出
function LogServer.SxBankWithdraw(pInfo, amount)
	
	local msg = "从视讯账号中取出"..string.format("%.2f", amount/100).."元"
	local channel = pInfo.channel --GameUtils.GetChannel(pInfo.channel)
	local sqlCase = "insert into log_moneydetail(userid,nickname,createdate,opttype,optmsg,amount,usermoney,remark,channel) values("..pInfo.userid..",'"..pInfo.nickname.."','"..TimeUtils.GetTimeString().."',"..g_moneyOptType.opt_sx_out..",'视讯账号取出',"..
		amount..","..pInfo.jetton..",'"..msg.."','"..channel.."')"
	--mysqlItem:execute(sqlCase)
	LogModel.LogUserMoneyList(sqlCase)
end

--存入游戏钱包中
function LogServer.ganmejetonDeposit(pInfo, amount)
	local prechannel = GameUtils.GetChannel_login(pInfo.channel)
	local msg = "往游戏钱包存入"..string.format("%.2f", 0 - amount/100).."元"
    local channel = pInfo.channel 
	local sqlCase = "insert into log_moneydetail(userid,nickname,createdate,opttype,optmsg,amount,usermoney,remark,channel,prechannel,season,tyjetton,gamejetton)"
					.."values("..pInfo.userid..",'"..pInfo.nickname.."','"..TimeUtils.GetTimeString().."',"..g_moneyOptType.opt_gamejetton_in
					..",'游戏钱包存入',"..(0 - amount)..","..pInfo.jetton..",'"..msg.."','"..channel.."','"..prechannel.."',"..g_moneyOptType.opt_gamejetton_out
					..","..pInfo.tyjetton..","..pInfo.gamejetton..")"
	LogModel.LogUserMoneyList(sqlCase)
	
	
	local msg = "往游戏钱包存入"..string.format("%.2f", amount/100).."元"
    local channel = pInfo.channel 
    
	local sqlCase = "insert into log_gamejettondetail(userid,nickname,createdate,opttype,optmsg,amount,usermoney,remark,channel,prechannel) values("..pInfo.userid..",'"..pInfo.nickname.."','"..TimeUtils.GetTimeString().."',"..g_moneyOptType.opt_gamejetton_in..",'游戏钱包存入',"..
		amount..","..pInfo.gamejetton..",'"..msg.."','"..channel.."','"..prechannel.."')"
	LogModel.LogUserMoneyList(sqlCase)
	
end

--从游戏钱包中取出
function LogServer.ganmejetonWithdraw(pInfo, amount)
	 local prechannel = GameUtils.GetChannel_login(pInfo.channel)
	local msg = "从游戏钱包取出"..string.format("%.2f", amount/100).."元"
	local channel = pInfo.channel 
	local sqlCase = "insert into log_moneydetail(userid,nickname,createdate,opttype,optmsg,amount,usermoney,remark,channel,prechannel,season,tyjetton,gamejetton)"
				.." values("..pInfo.userid..",'"..pInfo.nickname.."','"..TimeUtils.GetTimeString().."',"..g_moneyOptType.opt_gamejetton_out
				..",'游戏钱包取出',"..amount..","..pInfo.jetton..",'"..msg.."','"..channel.."','"..prechannel.."',"..g_moneyOptType.opt_gamejetton_out
				..","..pInfo.tyjetton..","..pInfo.gamejetton..")"
	LogModel.LogUserMoneyList(sqlCase)
	
	
	local msg = "从游戏钱包取出"..string.format("%.2f", 0 - amount/100).."元"
	local channel = pInfo.channel 
	local sqlCase = "insert into log_gamejettondetail(userid,nickname,createdate,opttype,optmsg,amount,usermoney,remark,channel,prechannel) values("..pInfo.userid..",'"..pInfo.nickname.."','"..TimeUtils.GetTimeString().."',"..g_moneyOptType.opt_gamejetton_out..",'游戏钱包取出',"..
		0 - amount..","..pInfo.gamejetton..",'"..msg.."','"..channel.."','"..prechannel.."')"
	LogModel.LogUserMoneyList(sqlCase)
	
end

--存入彩票钱包中
function LogServer.cpjetonDeposit(pInfo, amount)
	local prechannel = GameUtils.GetChannel_login(pInfo.channel)
	local msg = "往彩票钱包存入"..string.format("%.2f", 0 - amount/100).."元"
    local channel = pInfo.channel 
	local sqlCase = "insert into log_moneydetail(userid,nickname,createdate,opttype,optmsg,amount,usermoney,remark,channel,prechannel,season,tyjetton,gamejetton,cpjetton)"
					.."values("..pInfo.userid..",'"..pInfo.nickname.."','"..TimeUtils.GetTimeString().."',"..g_moneyOptType.opt_cpjetton_in
					..",'彩票钱包存入',"..(0 - amount)..","..pInfo.jetton..",'"..msg.."','"..channel.."','"..prechannel.."',"..g_moneyOptType.opt_cpjetton_out
					..","..pInfo.tyjetton..","..pInfo.gamejetton..","..pInfo.cpjetton..")"
	LogModel.LogUserMoneyList(sqlCase)
		
end

--从彩票钱包中取出
function LogServer.cpjetonWithdraw(pInfo, amount)
	 local prechannel = GameUtils.GetChannel_login(pInfo.channel)
	local msg = "从彩票钱包取出"..string.format("%.2f", amount/100).."元"
	local channel = pInfo.channel 
	local sqlCase = "insert into log_moneydetail(userid,nickname,createdate,opttype,optmsg,amount,usermoney,remark,channel,prechannel,season,tyjetton,gamejetton,cpjetton)"
				.." values("..pInfo.userid..",'"..pInfo.nickname.."','"..TimeUtils.GetTimeString().."',"..g_moneyOptType.opt_cpjetton_out
				..",'彩票钱包取出',"..amount..","..pInfo.jetton..",'"..msg.."','"..channel.."','"..prechannel.."',"..g_moneyOptType.opt_cpjetton_out
				..","..pInfo.tyjetton..","..pInfo.gamejetton..","..pInfo.cpjetton..")"
	LogModel.LogUserMoneyList(sqlCase)

end



--[[
insert_log_Win 1: 不插入log_moneydetail 2:不写入log_player  
]]
function LogServer.GameUserMoney(pInfo, gameType, tableType, amount, msg, achamount, gameNumber,season,orderid,istymoney,insert_log_Win)
	
--	if amount == 0 then
--		return
--	end

	local gameNmae = GameUtils.GetGameName(gameType)
	local tableName = GameUtils.GetTableName(gameType, tableType)
	--[[local msg = "" 
	
	if amount > 0 then
		msg = "在"..gameNmae..tableName.."中盈利"..string.format("%.2f",amount/100).."元"
	else
		msg = "在"..gameNmae..tableName.."中输掉"..string.format("%.2f", amount/100).."元"
	end]]
	if msg == nil then
		msg = ""

--        if amount > 0 then
--		    msg = "在"..gameNmae..tableName.."中盈利"..string.format("%.2f",amount/100).."元"
--	    else
--		    msg = "在"..gameNmae..tableName.."中输掉"..string.format("%.2f", amount/100).."元"
--	    end
	end

    if season == nil then
       season = gameType
    end
    if orderid == nil then
       orderid =""
    end
    local channel = pInfo.channel
    local prechannel = GameUtils.GetChannel_login(pInfo.channel)
	local sqlCase = "insert into log_moneydetail(userid,nickname,createdate,opttype,optmsg,amount,usermoney,remark, achamount, gamenumber,channel,season,prechannel,orderid,tyjetton,gamejetton) values("..pInfo.userid..",'"..pInfo.nickname.."','"..TimeUtils.GetTimeString().."',"..gameType..",'"..gameNmae..tableName.."',"..
		amount..","..pInfo.jetton..",'"..msg.."',"..achamount..",'"..gameNumber.."','"..channel.. "',"..season..",'"..prechannel.."','"..orderid.."',"..pInfo.tyjetton..","..pInfo.gamejetton..")"
	
    insert_log_Win = insert_log_Win or 0

	--print(sqlCase)
	--mysqlItem:execute(sqlCase)
    if insert_log_Win ~= 2 then
        if not istymoney  then      
			if amount > 0 then
				PlayerModel.IncrPlayerWin(pInfo.userid, amount - achamount) 
			else
				PlayerModel.IncrPlayerWin(pInfo.userid, amount) 
			end
        end
    end

    if insert_log_Win ~= 1 then
        LogModel.LogUserMoneyList(sqlCase)
    end
	
end

function LogServer.specialCardTypeActivity(userid, gametype, tabletype, cardtype,cardlist)
	
	if true then
		return 
	end
	
	if RobotService.IsRobot(userid) == true then
		return
	end 
	
	local rewardjetton = 0
	local remarks = ""
	if gametype == g_douNiuDefine.game_type or gametype == g_douNiuDefine.insanegame_type or gametype == g_douNiuDefine.kinggame_type then
		--带癞子的牌型不算奖励
		local haveKing = false
		for k, v in ipairs(cardlist) do
			if v == 525 or v == 515 then
				haveKing  = true
				break
			end
		end
		
		if haveKing == false then
			if cardtype == g_douNiuCard_type.tonghuashun_niu then
				rewardjetton = 188
				remarks = "同花顺牛"
			elseif cardtype == g_douNiuCard_type.wuxiao_niu then
				rewardjetton = 58
				remarks = "五小牛"
			elseif cardtype == g_douNiuCard_type.zhadan_niu then
				rewardjetton = 58 
				remarks = "炸弹牛"
			elseif cardtype == g_douNiuCard_type.wuhua_niu then
				rewardjetton = 38
				remarks = "五花牛"
			elseif cardtype == g_douNiuCard_type.tonghua_niu then
				rewardjetton = 8
				remarks = "同花牛" 
			elseif cardtype == g_douNiuCard_type.hulu_niu then
				rewardjetton = 18
				remarks = "葫芦牛"
			elseif cardtype == g_douNiuCard_type.shunzi_niu then
				rewardjetton = 8
				remarks = "顺子牛"
			end
		end
		
	elseif gametype == g_PszDefine.game_type then
		if #cardlist == 3 then 
			if 1 == math.mod(cardlist[1], 100) and 1 == math.mod(cardlist[2], 100) and 1 == math.mod(cardlist[3], 100) then
				rewardjetton = 188
				remarks = "AAA"
			elseif cardtype == g_PszCard_type.baozi then
				rewardjetton = 38
				remarks = "豹子"
			elseif cardtype == g_PszCard_type.tonghuashun then
				rewardjetton = 28 
				remarks = "同花顺"
			end
		end
	end
	
	if rewardjetton > 0 then
		rewardjetton = rewardjetton * 100
		LogServer.rewardDistribution(userid, gametype, tabletype, rewardjetton, remarks, 1)
	end
	
end


function LogServer.rewardDistribution(userid, gametype, tabletype, rewardjetton, remarks, activitytype)

	local gameList = {}
	gameList[g_barccatatDefine.game_type] = "百家乐"
	gameList[g_bcbmDefine.game_type] = "奔驰宝马"
	gameList[g_brnnDefine.game_type] = "百人牛牛"
	gameList[g_caipiaoDefine.bjsc_game_type] = "北京赛车"
	gameList[g_caipiaoDefine.lhc_game_type] = "香港六合彩"
	gameList[g_caipiaoDefine.xyft_game_type] = "幸运飞艇"
    gameList[g_caipiaoDefine.msft_game_type] = "秒速飞艇"
	gameList[g_cjmpDefine.game_type] = "五星宏辉"
	gameList[g_DdzDefine.game_type] = "斗地主"
	gameList[g_douNiuDefine.game_type] = "抢庄牛牛"
	gameList[g_douNiuDefine.insanegame_type] = "激情牛牛"
	gameList[g_douNiuDefine.kinggame_type] = "王者牛牛"
	gameList[g_fenfencaiDefine.game_type] = "分分彩"
	gameList[g_fqzsDefine.game_type] = "狮子王国"
	gameList[g_hongheiDefine.game_type] = "红黑大战"
	gameList[g_lhdDefine.game_type] = "龙虎斗"
	gameList[g_PszDefine.game_type] = "炸金花"
	gameList[g_sangongDefine.game_type] = "三公"
	gameList[g_sicboDefine.game_type] = "骰宝"
	gameList[g_slhbDefine.game_type] = "扫雷红包"
	gameList[g_TexasDefine.game_type] = "德州扑克"
	gameList[g_yqsDefine.game_type] = "捕鱼"
	
	--先发邮件
	msg = ""
	if activitytype == 1 then
		msg = "恭喜老板！您在活动期间参与了特殊牌型奖励活动，并在"..gameList[gametype].."游戏中获得了"
		..remarks.."牌型，系统奖励"..(rewardjetton/100).."金币！请在邮件中领取。祝老板游戏愉快！"
		
	elseif activitytype == 2 then
		msg = "恭喜老板！您在活动期间参与了连赢奖励活动，并在"..gameList[gametype].."游戏中"
		..remarks.."，系统奖励"..(rewardjetton/100).."金币！请在邮件中领取。祝老板游戏愉快！"
	end
	
	local pInfo = PlayerModel.GetPlayerInfo(userid)
	if pInfo == nil then
		return 
	end
	--通过邮件的形式直接发送
    local addItem = st_human_pb.mailinfo() 
	addItem.title = '系统活动邮件'
	addItem.content = msg
	addItem.senderid = 1
	addItem.sender = "系统"
	addItem.receiverid = pInfo.userid
	addItem.receiver = pInfo.nickname
	addItem.senddate = TimeUtils.GetTimeString()
	addItem.validity = 7
	addItem.externdata = "[[1002,"..(rewardjetton).."]]"
	addItem.mailtype = 2
	addItem.mailstate = g_mailState.state_unreadadd
	local tTime = TimeUtils.GetTableTime()
	tTime.hour = 0
	tTime.min = 0
	tTime.sec = 0
	local currSec = TimeUtils.GetTime(tTime)
	currSec = currSec + g_daySeconds*2
	addItem.markdate = TimeUtils.GetDayString(currSec)
	MailModel.AddMail(addItem)
    --红点通知
    NoticeModel.SendNotice(pInfo.userid, g_noticeType.mail_unread)	
	
	
	--写数据库保存领奖记录
	local sqlCase = "insert into log_activity_record(userid,nickname,activitytype,gametype,tabletype,rewardjetton,remarks) values("
	..pInfo.userid..",'"..pInfo.nickname.."',"..activitytype..","..gametype..","..tabletype..","..rewardjetton..",'"..remarks.."')" 
	mysqlItem:execute(sqlCase)
	
	--这里这优化一下特殊牌型也查数据了
	if activitytype == 1 then
		LogModel.addPrizesList(pInfo, rewardjetton)
	end 
end

--玩家连赢百人场统计
--彩金明牌 龙虎斗 红黑大战 百家乐 百人牛牛 奔驰宝马 狮子王国 骰宝 扫雷红包 分分彩
function LogServer.BrcGameUserQuinella(userId,gameType,tableType,winCount)
    
    --活动是否开启
    if g_ActivitySwitch ~= 1 then
       return
    end
    --luaPrint("LogServer.BrcGameUserQuinellaL winCount: "..winCount.." type: "..type(winCount).." gameType:")
    if  gameType ~= g_cjmpDefine.game_type      and
        gameType ~= g_lhdDefine.game_type       and
        gameType ~= g_hongheiDefine.game_type   and
        gameType ~= g_barccatatDefine.game_type and
        gameType ~= g_brnnDefine.game_type      and
        gameType ~= g_bcbmDefine.game_type      and
        gameType ~= g_fqzsDefine.game_type      and
        gameType ~= g_sicboDefine.game_type     and
        gameType ~= g_slhbDefine.game_type      and
        gameType ~= g_fenfencaiDefine.game_type     
    then 	   
        return
	end
    
    if RobotService.IsRobot(userId) then
       return
    end
    --大于等于9元
    if tonumber(winCount) >= 900 then
        LogModel.AddUserQuinella(userId,gameType,tableType,1)
        local count = LogModel.GetUserQuinella(userId,gameType,tableType)
        local remarks = 0
        local rewardjetton = 0
        --print("count: "..count)
        if count == 20 then
        --满足连赢20局
            remarks = 20
            rewardjetton = 888800
            LogModel.DelUserQuinella(userId,gameType,tableType)
        elseif count == 12 then
            remarks = 12
            rewardjetton = 88800
        elseif count == 8 then
            remarks = 8
            rewardjetton = 8800
        elseif count ==  5 then
            remarks = 5
            rewardjetton = 1800
        end
        
        if remarks > 0 then
            local remarks_str = "连赢"..remarks.."局"
--            local sqlCase  = "select * from log_activity_record where userid = "..userId.." and gametype = "..gameType.." and tabletype = "..tableType.." and remarks = '"..remarks_str.."'"
--            mysqlLog:executeQuery(sqlCase)
--		    local sqlData = mysqlLog:fetch({})
--            --print(sqlCase)
--		    if sqlData == nil then
--		        --没有领奖记录 可以领奖
--                --print(userId, gameType, tableType, rewardjetton, remarks, 2)

--                LogServer.rewardDistribution(userId, gameType, tableType, rewardjetton, remarks_str, 2)
--            else
--               --已经领过，不能重复领取

--		    end
            LogServer.rewardDistribution(userId, gameType, tableType, rewardjetton, remarks_str, 2)                    
        end

    else
        LogModel.DelUserQuinella(userId,gameType,tableType)
    end

end

--对局排名活动
--只有牛牛，三公， 金花参与游戏
function LogServer.statisticsMatchScore(userid,gameType)
	
	if	RobotService.IsRobot(userid) == true or userid == 1 then
		return 
	end
	
	if gameType ~= g_douNiuDefine.game_type   		--抢庄牛牛
	and gameType ~= g_douNiuDefine.insanegame_type 	--激情牛牛
	and gameType ~= g_douNiuDefine.kinggame_type 	--王者牛牛
	and gameType ~= g_douNiuDefine.kinggame_type 	--王者牛牛
	and gameType ~= g_PszDefine.game_type 			--炸金花
	and gameType ~= g_sangongDefine.game_type 		--三公
	then
		return
	end
	
	--local tab = LogServer.GetTodayDate()
	--local date = tab.year..tab.month..tab.day
	--LogModel.addPlayerMatchScore(userid, date)
end


--获得对局排名
function LogServer.GetMatchScoreRanking(date)
	
	local palayerScoreList = LogModel.getAllPlayerMatchScore(date)
	local sortList = {}
	for k,v in pairs(palayerScoreList)do 
		table.insert(sortList, {k, v})
	end
	--排序
	table.sort(sortList, function(a,b)
		return tonumber(a[2]) > tonumber(b[2])
	end)
	
	return sortList
end


function LogServer.GetTodayDate()
	local tab = {}
	local t1 = TimeUtils.GetTime()
	local ts = TimeUtils.GetTimeString(t1)
	tab.year = string.sub(ts, 1, 4)
	tab.month = string.sub(ts, 6, 7)
	tab.day = string.sub(ts, 9, 10)
	tab.hour = string.sub(ts, 12, 13)
	tab.min = string.sub(ts, 15, 16)
	tab.sec = string.sub(ts, 18, 19)
	tab.isdst = false
	
	return tab
end


function LogServer.GetYestedayDate()
	local tab = {}
	local t1 = TimeUtils.GetTime()
	t1 = t1 - 86400
	local ts = TimeUtils.GetTimeString(t1)
	tab.year = string.sub(ts, 1, 4)
	tab.month = string.sub(ts, 6, 7)
	tab.day = string.sub(ts, 9, 10)
	tab.hour = string.sub(ts, 12, 13)
	tab.min = string.sub(ts, 15, 16)
	tab.sec = string.sub(ts, 18, 19)
	tab.isdst = false
	
	return tab
end


function LogServer.GetPlayerPayAmonut(userID)
	
	local payAmount = redisItem:hget( LogModel.redis_payamount, userID, LogModel.redis_index )
	return payAmount == nil and 0 or tonumber(payAmount)
end

-- opttype 收入 1 支出 2
-- remark(备注) 下注 结算 提现 充值 ..
-- pourjetton 金额 收入 >= 0 支出 < 0
--orderid 有订单id填，没有就nil
function LogServer.addRecords(userid,opttype,remark,pourjetton,orderid,msg)
    if orderid == nil then
       orderid =  ""
    end
    if msg == nil then
       msg = ""
    end

    local recordinfo = msg_footballgame_pb.gcfootballrecords()
    recordinfo.result = 0
    recordinfo.opttype= opttype
    local addrecords = recordinfo.records:add()
    addrecords.amount = tostring(pourjetton)
    addrecords.opttime = TimeUtils.GetTime()
    addrecords.remark = remark
    addrecords.orderid = tostring(orderid)
    FootballModel.SetUserRecords(userid,recordinfo)
    
    local sqlCase = "insert into log_records(userid,opttype,amount,opttime,remark,orderid,msg) values ( "..userid..","..opttype..","..tonumber(pourjetton)..",'"..TimeUtils.GetTimeString(addrecords.opttime).. "','"..remark.."','"..orderid.."','"..msg.."')"
    --print(sqlCase)
    LogModel.LogUserMoneyList(sqlCase)	
end

--[[赛事的每天下注统计
bet    投注额
tybet  投注额
ordertime 下单时间

]]
function LogServer.dailFBBetCount(bet,tybet,ordertime,pInfo)
    bet = bet == nil and 0 or tonumber(bet)
    btybetet = tybet == nil and 0 or tonumber(tybet)
    local dateid = TimeUtils.GetDayString(ordertime)
    local channel = pInfo.channel
    local prechannel = GameUtils.GetChannel_login(pInfo.channel)
    local sqlCase = " insert into log_betdaily(dateid,bet,tybet,channel,prechannel) values ( '" ..dateid.."',"..bet..","..tybet..",'"..channel.."','"..prechannel.."')  ON DUPLICATE KEY update bet=bet+".. bet..",tybet=tybet+"..tybet
    --print(sqlCase)
    LogModel.LogUserMoneyList(sqlCase)	
end


--联赛统计事统计
--[[
    racename   联赛类型 德甲 西甲
    bet        投注额度
    betcount   注单数（正常结算时不需要（下注时已+1），如果是赛事取消的 betcount = -1） 
    tybet      体验投注额度
    tybetcount 体验注单数（正常结算不需要（下注时已+1），如果是赛事取消的 tybetcount = -1）
    channel    小渠道 
    prechannel 大渠道
    income     盈亏 win 赢>0 输小于 0 (如果是体验金结算 income = 0, 这个是定时任务或者后台操作) 如果已结算过要扣掉
    ordertime  下单时间
]]
function LogServer.raceFBRaceCount(racename,bet,betcount,tybet,tybetcount,channel,prechannel,income,ordertime)
    
    bet = bet == nil and 0 or tonumber(bet)
    btybetet = tybet == nil and 0 or tonumber(tybet)
    betcount = betcount  == nil and 0 or tonumber(betcount)
    tybetcount = tybetcount == nil and 0 or tonumber(tybetcount)
    income = income == nil and 0 or tonumber(income)

    local dateid = TimeUtils.GetDayString(ordertime)

    local sqlCase = " insert into log_racedaily(racename,bet,betcount,tybet,tybetcount,channel,prechannel,income,dateid) values ( '" ..
    racename.."',"..bet..","..betcount..","..tybet..","..tybetcount..",'"..channel.."','" ..prechannel.."',"..income ..",'"..dateid..               
     "')  ON DUPLICATE KEY update bet=bet+".. bet ..",betcount=betcount+"..betcount ..",tybet=tybet+"..tybet ..",tybetcount=tybetcount+"..tybetcount..
    ",income=income+"..income
    --print(sqlCase)
    LogModel.LogUserMoneyList(sqlCase)	
end

--[[
    翻翻乐收益报告
    pInfo    玩家
    orderid  结算订单
    income   盈亏
]]
function LogServer.flipProfitReport(pInfo,orderid,win)
    local channel = pInfo.channel
    local prechannel = GameUtils.GetChannel_login(pInfo.channel)
    local sqlCase = "insert into  log_flipprofitreport(profitid, userid ,profitsum, freeflipcount, orderidlist, status, channel, prechannel)values("..
    0 .."'"..pInfo.userid.." "

end

--[[
vip积分统计
    userid   玩家id
    pointsType =   积分类型 0=充值  1=流水奖励（个人） 2=拉新奖励  3=团队充值奖励  4=团队流水  5= 降级扣除积分
    params = 
    {
        userRecharge = 0, --个人充值
        userAchi     = 0, --个人流水
        inviteUserid = 0, --拉新玩家id 
        teamRecharge = 0, --团队充值
        teamAchi     = 0, --团队流水
        downPoints   = 0  --降级扣除积分 
    }

    params 不用的字段 默认设置0

]]
function LogServer.vipPointsCount(userid,pointsType,params)
    
    local pInfo = PlayerModel.GetPlayerInfo(userid)
    if pInfo == nil then
        return 
    end
    local datemonth     = TimeUtils.GetMonthString()
    local createtime    = TimeUtils.GetTimeString()
    local prechannel = GameUtils.GetChannel_login(pInfo.channel)
    
    local userRecharge = tonumber(params["userRecharge"]) or 0
    local userAchi     = tonumber(params["userAchi"]) or 0
    local inviteUserid = tonumber(params["inviteUserid"]) or 0
    local teamRecharge = tonumber(params["teamRecharge"]) or 0
    local teamAchi     = tonumber(params["teamAchi"]) or 0
    local downPoints   = tonumber(params["downPoints"]) or 0
    local points = 0 

    if pointsType == 0 then
        --充值 充值，100元*10%=10积分，例 5000元=500积分 十分之一
        points = userRecharge * 0.01 * 0.1

    elseif pointsType == 1  then
        --流水奖励（个人） 1000流⽔*1% =10积分 ，50000流⽔=500积分 百分之一
        points = userAchi * 0.01 * 0.01 

    elseif pointsType == 2  then
        --拉新奖励 ⼀个新活跃⽤户（新⽤户且有充值与投注）=100积分
        points = 100

    elseif pointsType == 3  then
        --团队充值奖励 例直系下属 充值 1000元，1000/10=100*10%=10积分  百分之一
        points = teamRecharge * 0.01 * 0.1 * 0.1
      
    elseif pointsType == 4  then
        --团队流水 流⽔10000元，10000/10=1000*10 ‰=10积分 千分之一
        points = teamAchi  * 0.01 * 0.1 * 0.01

    elseif pointsType == 5  then
        --降级扣除积分
        points = downPoints
    end
    --保留2位小数
    points = math.floor(points * 100) * 0.01
    if points >= 0.01 or (points < 0 and  pointsType == 5)then
        local sqlCase = "insert into log_vippointrecords (userid,points,pointstype,inviteuserid,createtime,channel,prechannel,datemonth) values ("..
        pInfo.userid..","..points..","..pointsType..","..inviteUserid..",'"..createtime.."','"..pInfo.channel.."','"..prechannel.."','"..datemonth.."')"
        print(sqlCase)
        if  pointsType ~= 3 and pointsType ~= 4 then
            --个人
            VipMgrModel.SetVipUserTotalPoints(pInfo.userid,points)
            VipMgrModel.SetVipUserMonthTotalPoints(pInfo.userid,points)
        else
            --团队
            VipMgrModel.SetVipUserTeamTotalPoints(pInfo.userid,points)
            VipMgrModel.SetVipUserMonthTeamTotalPoints(pInfo.userid,points)
        end

        mysqlLog:execute(sqlCase)

    end

end


function LogServer.GetNewLogOrderid()
    local nowtime = TimeUtils.GetMescTime()
    nowtime = nowtime*10000
    local rdnum = redisItem:incrby("NewLogOrderid",1,LogModel.redis_index)
    return "orderid"..nowtime..rdnum
end


--统计首次下注或者玩游戏
--playtype 1 赛事 2 游戏
function LogServer.firstPlayer(userid,playtype)
    
	local play = 0
	local game = 0
	local matc = 0
	
	if nil == LogModel.isPlayEnd(userid) then
		play = 1
		LogModel.addPlayEnd(userid)
	end
	
	if playtype == 1 then
		if nil == LogModel.isMatchEnd(userid) then
			matc = 1
			LogModel.addMatchEnd(userid)
		end
	else
		if nil == LogModel.isGameEnd(userid) then
			game = 1
			LogModel.addGameEnd(userid)
		end
	end
	if play > 0 or game > 0 or matc > 0 then
		LogDispatch.lognewplayerbehavior(userid, play, 0, 0, matc, game, 0)
	end
	
end