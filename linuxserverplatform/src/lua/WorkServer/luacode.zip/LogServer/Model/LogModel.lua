LogModel = {}
LogModel.redis_index = "redis_log"
LogModel.log_sysdaily = "log_sysdaily"
LogModel.log_behavior = "log_behavior"
LogModel.log_player = "log_player"

LogModel.game_player = "log_dy_game"  --这一个不是写到log的数据库的。是写到游戏数据库的。

LogModel.log_retain = "log_retain"



LogModel.log_conday = "log_rds_conday"   --连续登陆天数
LogModel.log_maxconday = "log_rds_maxconday"   --连续登陆天数
LogModel.log_maxjetton = "log_rds_maxjetton"


LogModel.log_file = "log_file"

LogModel.log_game_detail = "log_game_detail"
LogModel.log_user_game_detail = "log_user_game_detail"
LogModel.log_user_money = "log_user_money"

LogModel.log_user_game = "log_user_gamelist"

LogModel.Log_unlimited = "log_unlimited"


LogModel.log_buyu_list = "log_buyu_"     --该变量是保存捕鱼这每次存档记录和胜利记录
LogModel.log_buyu_user_jetton = "log_buyu_user_jetton"   --保存捕鱼的log的玩家的jetton
LogModel.log_buyu_win_jetton = "log_buyu_all_win"        --保存捕鱼中log的玩家盈利的总额

LogModel.log_user_quinella = "log_user_quinella"    --玩家连赢次数(盈利大于等于9元)

LogModel.match_score_hash = "match_score_hash"					--对局积分列表
LogModel.liushui_ranking_today = "liushui_ranking_today"			--流水排行今天
LogModel.liushui_ranking_yesterday = "liushui_ranking_yesterday"--流水排行昨天
LogModel.cardtype_prizes_list = "cardtype_prizes_list"		--特殊牌型领奖列表


LogModel.redis_payamount = "log_payamount"

LogModel.player_playend = "player_playend"					--已经下过赛事或者玩过游戏的玩家列表
LogModel.player_gameend = "player_gameend"					--已经玩过游戏的玩家列表
LogModel.player_matchend = "player_matchend"					--已经下过赛事的玩家列表


function LogModel.LogSysdailyPush(sqlCase)
	
	if sqlCase == nil then
		return
	end

	redisItem:rpush(LogModel.log_sysdaily, sqlCase, LogModel.redis_index)

end

function LogModel.LogBehaviorPush(sqlCase)
	
	if sqlCase == nil then
		return
	end
	redisItem:rpush( LogModel.log_behavior, sqlCase, LogModel.redis_index )
end

function LogModel.LogPlayerPush(sqlCase)
	if sqlCase == nil then
		return
	end
	redisItem:rpush( LogModel.log_player, sqlCase, LogModel.redis_index )
end


function LogModel.GameSqlServer(sqlCase)
	if sqlCase == nil then
		return
	end
	redisItem:rpush(LogModel.game_player, sqlCase, LogModel.redis_index )
end

function LogModel.LogRetain(sqlCase)
	if sqlCase == nil then
		return
	end
	redisItem:rpush(LogModel.log_retain, sqlCase, LogModel.redis_index)
end


function LogModel.SetRedisConday(userID, conDay)
	redisItem:hset( LogModel.log_conday, userID, conDay, LogModel.redis_index )
end

function LogModel.SetRedisMaxConday(userID, maxConDay)
	redisItem:hset( LogModel.log_maxconday, userID, maxConDay, LogModel.redis_index)
end

function LogModel.SetRedisMaxJetton(userID, maxJetton)
	redisItem:hset( LogModel.log_maxjetton, userID, maxJetton, LogModel.redis_index)
end

function LogModel.GetMaxJetton(userID)
	local maxJetton = redisItem:hget(LogModel.log_maxjetton, userID, LogModel.redis_index)
	if conDay == nil then
		local sqlCase = "select maxjetton from log_player where userID="..userID
		mysqlLog:executeQuery(sqlCase)
		local sqlData = mysqlLog:fetch()
		
		if sqlData ~= nil then
			maxJetton = tonumber(sqlData)
		else
			maxJetton = 0
		end
		
		redisItem:hset( LogModel.log_maxjetton, userID, maxJetton, LogModel.redis_index )
	else
		maxJetton = tonumber(maxJetton)
	end
	return maxJetton
end

function LogModel.LogFile(logLevel, content)
	
	content = "["..os.date("%H:%M:%S", os.time()).."]"..content
	if g_platfrom ~= 'luaself' then
		local fileName = os.date("%Y-%m-%d", os.time())
		fileName = "./log/"..fileName.."-"..logLevel..".log"
		--c_clog(fileName, content)
		redisItem:rpush(LogModel.log_file, fileName..content, LogModel.redis_index)
	end	
end


function LogModel.LogGameDetail(sqlCase)
	
	if sqlCase == nil then
		return
	end
	redisItem:rpush( LogModel.log_game_detail, sqlCase, LogModel.redis_index )	
end


function LogModel.LogUserGameDetail(sqlCase)
	if sqlCase == nil then
		return
	end
	redisItem:rpush(LogModel.log_user_game_detail, sqlCase, LogModel.redis_index)
end

function LogModel.LogUserMoneyList( sqlCase )
	if sqlCase == nil then
		return
	end
	redisItem:rpush( LogModel.log_user_money, sqlCase,  LogModel.redis_index)
end

function LogModel.LogUserGameList( sqlCase )
	if sqlCase == nil then
		return
	end
	--print(sqlCase)
	redisItem:rpush(LogModel.log_user_game, sqlCase, LogModel.redis_index)
end

function LogModel.LogBuYu(userID, redisStr, jetton, allWin)

	redisItem:lpush( LogModel.log_buyu_list..userID, redisStr,  LogModel.redis_index)
	
--LogModel.log_buyu_list = "log_buyu_"     --该变量是保存捕鱼这每次存档记录和胜利记录
--LogModel.log_buyu_user_jetton = "log_buyu_user_jetton"   --保存捕鱼的log的玩家的jetton
	redisItem:hset( LogModel.log_buyu_user_jetton, userID, jetton, LogModel.redis_index )
	redisItem:hincrby( LogModel.log_buyu_win_jetton, userID, allWin,  LogModel.redis_index )
end


function LogModel.AddUserQuinella(userid,gametype,tabletype,count)
    if RobotService.IsRobot(userid) then
        return 
    end
    return redisItem:hincrby(LogModel.log_user_quinella..gametype..tabletype, userid, count, LogModel.redis_index )
end

function LogModel.GetUserQuinella(userid,gametype,tabletype)
    local count =  redisItem:hget(LogModel.log_user_quinella..gametype..tabletype, userid, LogModel.redis_index )
    count = count == nil and 0 or tonumber(count)
    return count
end

function LogModel.DelUserQuinella(userid,gametype,tabletype)
    if RobotService.IsRobot(userid) then
        return 
    end
    if true == redisItem:hexists(LogModel.log_user_quinella..gametype..tabletype, userid, LogModel.redis_index) then
        redisItem:hdel(LogModel.log_user_quinella..gametype..tabletype, userid, LogModel.redis_index )
    end
    
end

function LogModel.addPlayerMatchScore(userid, date)
	redisItem:hincrby(LogModel.match_score_hash..date, userid, 100, LogModel.redis_index )
end

function LogModel.getAllPlayerMatchScore(date)
	return redisItem:hgetall(LogModel.match_score_hash..date, LogModel.redis_index )
end


function LogModel.SetLiushuiRanking_today(Info)
	redisItem:set(LogModel.liushui_ranking_today,Info:SerializeToString(), LogModel.redis_index)  --接着设置信息
end
function LogModel.GelLiushuiRanking_today()
	return redisItem:get(LogModel.liushui_ranking_today, LogModel.redis_index)  --接着设置信息
end

function LogModel.DelLiushuiRanking_today()
	redisItem:del(LogModel.liushui_ranking_today, LogModel.redis_index)  --接着设置信息
end

function LogModel.SetLiushuiRanking_yesterday(Info)
	redisItem:set(LogModel.liushui_ranking_yesterday,Info:SerializeToString(), LogModel.redis_index)  --接着设置信息
end

function LogModel.GetLiushuiRanking_yesterday()
	return redisItem:get(LogModel.liushui_ranking_yesterday, LogModel.redis_index)  --接着设置信息
end

function LogModel.DelLiushuiRanking_yesterday()
	redisItem:del(LogModel.liushui_ranking_yesterday, LogModel.redis_index)  --接着设置信息
end


function LogModel.addPrizesList(pInfo, jetton)

	local addUH = st_human_pb.cardtypeprizesinfo()
	addUH.userid = pInfo.userid
	addUH.nickname = pInfo.nickname
	addUH.jetton = tostring(jetton)

	redisItem:rpush(LogModel.cardtype_prizes_list, addUH:SerializeToString(), LogModel.redis_index)
	
	--大于20就不要最久一条
	if redisItem:llen(LogModel.cardtype_prizes_list, LogModel.redis_index) > 20 then
		redisItem:lpop(LogModel.cardtype_prizes_list, LogModel.redis_index)
	end
end

function LogModel.getPrizesList()
	
	local list = redisItem:lrange(LogModel.cardtype_prizes_list, 0, 20, LogModel.redis_index)
	
	if #list > 0  then
		return list
	else
		local myList = {}
		local sqlCase = "select * from log_activity_record where activitytype = 1 order by id desc limit 20"   --每一次只会取20个
		mysqlItem:executeQuery(sqlCase)
		local addUH = st_human_pb.cardtypeprizesinfo()
		for i = 1,100 do
			local sqlData = mysqlItem:fetch({})
			if sqlData == nil then
				break
			end
			local tmp = {}
			tmp["userid"] = tonumber(sqlData[2])
			tmp["nickname"] = sqlData[3]
			tmp["jetton"] = sqlData[8]
			
			table.insert(myList, tmp)
		end	
		for i = #myList, 1, -1 do 
			addUH.userid = myList[i]["userid"]
			addUH.nickname = myList[i]["nickname"]
			addUH.jetton = myList[i]["jetton"]
			redisItem:rpush(LogModel.cardtype_prizes_list, addUH:SerializeToString(), LogModel.redis_index)
		end
		return redisItem:lrange(LogModel.cardtype_prizes_list, 0, 20, LogModel.redis_index)
		
	end
end

function LogModel.isPlayEnd(userid)
	return redisItem:zscore(LogModel.player_playend, userid, LogModel.redis_index)
end

function LogModel.addPlayEnd(userid)
	return redisItem:zadd(LogModel.player_playend, 1, userid, LogModel.redis_index)
end

function LogModel.isGameEnd(userid)
	return redisItem:zscore(LogModel.player_gameend, userid, LogModel.redis_index)	
end

function LogModel.addGameEnd(userid)
	return redisItem:zadd(LogModel.player_gameend, 1, userid, LogModel.redis_index)
end

function LogModel.isMatchEnd(userid)
	return redisItem:zscore(LogModel.player_matchend, userid, LogModel.redis_index)	
end

function LogModel.addMatchEnd(userid)
	return redisItem:zadd(LogModel.player_matchend, 1, userid, LogModel.redis_index)
end





