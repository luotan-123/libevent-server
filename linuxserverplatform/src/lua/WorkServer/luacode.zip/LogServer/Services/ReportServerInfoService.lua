ReportServerInfoService = {}

function ReportServerInfoService.ServerLoop()
	
	local t = TimeUtils.GetTableTime()

	--每分钟统计一次数据
	if  tonumber(t.sec)  == 1 then
		processWork("ReportServerInfo", "0")
	end

end
