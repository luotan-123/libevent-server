
LogDispatch = {}

LogDispatch.log_dispatch = {} --"log_dispath"


LogDispatch.log_dispatch['lognewplayer'] = "log_dis_newplayer"
LogDispatch.log_dispatch['logplayerlogin'] = "log_dis_playerlogin"
LogDispatch.log_dispatch['logplayerlogout'] = "log_dis_playerlogout"
LogDispatch.log_dispatch['logcheckmaxjetton'] = "log_dis_checkmaxjetton"
LogDispatch.log_dispatch['logpaysuccess'] = "log_dis_paysuccess"
LogDispatch.log_dispatch['logcallpay'] = "log_dis_callpay"
LogDispatch.log_dispatch['logvippay'] = "log_dis_vippay"
LogDispatch.log_dispatch['logdailyaward'] = "log_dis_dailyaward"
LogDispatch.log_dispatch['logwithdraw'] = "log_dis_withdraw"
LogDispatch.log_dispatch['logwithdrawcom'] = "logwithdrawcom"    ---佣金账户提现，走的佣金账户的通道
LogDispatch.log_dispatch['logwithdrefuse'] = "log_dis_withdrawrefuse"
LogDispatch.log_dispatch['logregisteraward'] = "log_dis_registeraward"
LogDispatch.log_dispatch['logmailaward'] = "log_dis_mailaward"
LogDispatch.log_dispatch['loguserbindagent'] = "log_user_bind_agent"
LogDispatch.log_dispatch['logcommissionchange'] = "logcommissionchange"
LogDispatch.log_dispatch['loguserachcount'] = "loguserachcount"

LogDispatch.log_dispatch['logcommpreissue'] = "logcommpreissue"      --佣金提前发放

LogDispatch.log_dispatch['logcommdistribution'] = "logcommdistribution"      --多级分销模式
LogDispatch.log_dispatch['logsysgive'] = "logsysgive"                    --赠金
LogDispatch.log_dispatch['logbetcount'] = "logbetcount"                 --投注值统计
LogDispatch.log_dispatch['loggameplayerandsyswin'] = "loggameplayerandsyswin"      --统计玩家和系统在游戏中的盈亏
LogDispatch.log_dispatch['lognewplayerbehavior'] = "lognewplayerbehavior"      	--统计新玩家的一些行为

function LogDispatch.Push(strindex,jsonStr)
	redisItem:lpush( LogDispatch.log_dispatch[strindex], jsonStr, LogDispatch.redis_index )
end

--统计新增玩家，新增玩家会有新增玩家的操作
function LogDispatch.NewPlayer(pInfo)
	
	local data = {}

	data['userid'] = pInfo.userid
	data['channel'] = pInfo.channel
	data['nickname'] = pInfo.nickname
	
	LogDispatch.Push( "lognewplayer", luajson.encode( data ) )
end

--统计用户登入的信息
function LogDispatch.PlayerLogin(pInfo)

	if RobotService.IsRobot(pInfo.userid) then
		return
	end	
	local timeSec = TimeUtils.GetTime()
	if pInfo.lasttime == 0 then
		pInfo.lasttime = timeSec
	end	
	
	local data = {}
	data['userid'] = pInfo.userid
	data['nickname'] = pInfo.nickname
	data['channel'] = pInfo.channel
	data['lasttime'] = pInfo.lasttime
	data['currtime'] = timeSec
	
	LogDispatch.Push( "logplayerlogin", luajson.encode( data ) )
end

--统计用户登入的信息
function LogDispatch.PlayerLogout(pInfo)

	if RobotService.IsRobot(pInfo.userid) then
		return
	end	
	local timeSec = TimeUtils.GetTime()
	if pInfo.lasttime == 0 then
		pInfo.lasttime = timeSec
	end	
	
	local data = {}
	data['userid'] = pInfo.userid
	data['nickname'] = pInfo.nickname
	data['channel'] = pInfo.channel
	data['lasttime'] = pInfo.lasttime
	data['currtime'] = timeSec
	
	LogDispatch.Push( "logplayerlogout", luajson.encode( data ) )
end

--入参：用户ID，渠道ID，支付的数额，单位：分, 支付后玩家身上金币
function LogDispatch.PaySuccess(pInfo, amount, orderid)
	
	local data = {}
	data['userid'] = pInfo.userid
	data['nickname'] = pInfo.nickname
	data['jetton'] = pInfo.jetton
	data['channel'] = pInfo.channel
	data['amount'] = amount
	data['orderid'] = orderid
	data['date'] = TimeUtils.GetTimeString
	LogDispatch.Push("logpaysuccess", luajson.encode(data))
	
end

--掉起支付的信息
--入参：用户ID，渠道号，掉起支付的数额：单位：分
function LogDispatch.CallPay(pInfo, amount, orderid )
	local data = {}
	data['userid'] = pInfo.userid
	data['nickname'] = pInfo.nickname
	data['channel'] = pInfo.channel	
	data['date'] = TimeUtils.GetTimeString()
	data['amount'] = amount
	data['jetton'] = pInfo.jetton
	data['orderid'] = orderid
	LogDispatch.Push("logcallpay", luajson.encode(data))
end

--VIP VIP支付
--入参，用户ID， 渠道类型，入款金额，入款后玩家身上金额
function LogDispatch.VIPPay(pInfo, amount, orderid)
	local data = {}
	data['userid'] = pInfo.userid
	data['nickname'] = pInfo.nickname
	data['channel'] = pInfo.channel	
	data['date'] = TimeUtils.GetTimeString()
	data['amount'] = amount
	data['jetton'] = pInfo.jetton
	data['orderid'] = orderid
	LogDispatch.Push("logvippay", luajson.encode(data))		
end

--提现
function LogDispatch.WithDrawCount(pInfo,amount, orderid)
	
	local data = {}
	data['userid'] = pInfo.userid
	data['nickname'] = pInfo.nickname
	data['channel'] = pInfo.channel	
	data['date'] = TimeUtils.GetTimeString()
	data['amount'] = amount
	data['jetton'] = pInfo.jetton
	data['orderid'] = orderid
    data['tyjetton'] = pInfo.tyjetton
    data['gamejetton'] = pInfo.gamejetton
	LogDispatch.Push("logwithdraw", luajson.encode(data))	
	
end

--佣金提现
function LogDispatch.WithDrawCountCom(pInfo,amount, orderid)
	
	local data = {}
	data['userid'] = pInfo.userid
	data['nickname'] = pInfo.nickname
	data['channel'] = pInfo.channel	
	data['date'] = TimeUtils.GetTimeString()
	data['amount'] = amount
	data['jetton'] = pInfo.jetton
	data['orderid'] = orderid == nil and TimeUtils.GetTime() or orderid
	LogDispatch.Push("logwithdrawcom", luajson.encode(data))	
	
end

--提现驳回
function LogDispatch.WithDrawRefuse(pInfo, amount, remark, orderid )
	local data = {}
	data['userid'] = pInfo.userid
	data['nickname'] = pInfo.nickname
	data['channel'] = pInfo.channel	
	data['date'] = TimeUtils.GetTimeString()
	data['amount'] = amount
	data['jetton'] = pInfo.jetton
	data['orderid'] = orderid
	data['remark'] = remark
	LogDispatch.Push("logwithdrefuse", luajson.encode(data))	
end

function LogDispatch.TransferCount(toPinfo, fromPinfo, amount)
	
end

--每日领取
function LogDispatch.DailyAward(pInfo, amount)
	local data = {}

	data['userid'] = pInfo.userid
	data['channel'] = pInfo.channel
	data['nickname'] = pInfo.nickname
	data['date'] = TimeUtils.GetTimeString()
	data['amount'] = amount
	data['jetton'] = pInfo.jetton

	
	--print(luajson.encode(data))
	LogDispatch.Push("logdailyaward", luajson.encode(data))	
end
--每日领取
function LogDispatch.MailAward(pInfo, amount)
	local data = {}

	data['userid'] = pInfo.userid
	data['channel'] = pInfo.channel
	data['nickname'] = pInfo.nickname
	data['date'] = TimeUtils.GetTimeString()
	data['amount'] = amount
	data['jetton'] = pInfo.jetton

	
	--print(luajson.encode(data))
	LogDispatch.Push("logmailaward", luajson.encode(data))	
end

--注册赠送
function LogDispatch.RegisterAward(pInfo, amount)

	local data = {}

	data['userid'] = pInfo.userid
	data['channel'] = pInfo.channel
	data['nickname'] = pInfo.nickname
	data['date'] = TimeUtils.GetTimeString()
	data['amount'] = amount
	data['jetton'] = pInfo.jetton

	LogDispatch.Push("logregisteraward", luajson.encode(data))	
	
end

--存入银行中
function LogDispatch.BankDeposit(pInfo, amount)
	
end

--从银行中取出
function LogDispatch.BankWithdraw(pInfo, amount)
	
end

function LogDispatch.UserBindAgent(pInfo, touserid)
	local data = {}
	data['userid'] = pInfo.userid
	data['touserid'] = touserid
	data['channel'] = pInfo.channel
	LogDispatch.Push("loguserbindagent", luajson.encode(data))
end


--代理佣金转入账户
function LogDispatch.CommissionChange(pInfo, amount, orderid)
	local data = {}
	data['userid'] = pInfo.userid
	data['nickname'] = pInfo.nickname
	data['channel'] = pInfo.channel	
	data['date'] = TimeUtils.GetTimeString()
	data['amount'] = amount
	data['jetton'] = pInfo.jetton
	data['orderid'] = orderid == nil and TimeUtils.GetTime() or orderid
    data['tyjetton'] = pInfo.tyjetton
    data['gamejetton'] = pInfo.gamejetton
	LogDispatch.Push("logcommissionchange", luajson.encode(data))
end

function LogDispatch.UserAchCount(userid)
	--这里只需要一个userid
	local data = {}
	data['userid'] = userid
	
	LogDispatch.Push("loguserachcount", luajson.encode(data))
end

function LogDispatch.CommPreIssue(userid, amount)
	local data = {}
	data['userid'] = userid
	data['amount'] = amount
	LogDispatch.Push("logcommpreissue", luajson.encode(data))	
end

function LogDispatch.CommDistribution(userid, amount)   --多级分销模式的实时发放佣金
	local data = {}
	data['userid'] = userid
	data['amount'] = amount
	LogDispatch.Push("logcommdistribution", luajson.encode(data))	
end


--赠金统计
function LogDispatch.logSysGive(pInfo, amount, orderid)

	local data = {}

	data['userid'] = pInfo.userid
	data['channel'] = pInfo.channel
    data['nickname'] = pInfo.nickname
	data['date'] = TimeUtils.GetTimeString()
	data['amount'] = amount
	data['orderid'] = orderid
	LogDispatch.Push("logsysgive", luajson.encode(data))	
	
end

--[[
    optType 0 赛事 1 游戏
    subType 0 下注 1 结算(撤单)
    bet   正常账号(大于0 加 小于0 减)
    tybet 体验账号(大于0 加 小于0 减)
]]
function LogDispatch.logBetCount(pInfo,bet,tybet,optType,subType)
    
    bet = bet == nil and 0 or tonumber(bet)
    tybet = tybet == nil and 0 or tonumber(tybet)

	local data = {}
	data['userid'] = pInfo.userid
	data['channel'] = pInfo.channel
    data['nickname'] = pInfo.nickname
	data['date'] = TimeUtils.GetTimeString()
    data['bet'] = bet
    data['tybet'] = tybet
	data['optType'] = optType
    data['subType'] = subType
	LogDispatch.Push("logbetcount", luajson.encode(data))	
	
end

function LogDispatch.GamePlayerAndSysSin(userid, amount, win, channel,feeCount, gamejettonin, gamejettonout)   --统计玩家和系统在游戏中的盈亏
	local data = {}
	data['userid'] = userid				
	data['amount'] = amount					--流水
	data['win'] = win						--盈亏
	data['channel'] = channel				--渠道
	data['feeCount'] = feeCount				--总抽水
	data['gamejettonin'] = gamejettonin		--游戏金币转入
	data['gamejettonout'] = gamejettonout		--游戏金币转出
	LogDispatch.Push("loggameplayerandsyswin", luajson.encode(data))	
end

function LogDispatch.lognewplayerbehavior(userid, newplay, newbindphone, newrealname,newplayermatch, newplayergame, newexpert)   --统计新玩家的一些行为
	local data = {}
	data['userid'] = userid				
	data['newplay'] = newplay					--游玩玩家+1
	data['newbindphone'] = newbindphone			--绑定手机玩家+1
	data['newrealname'] = newrealname			--实名玩家+1
	data['newplayermatch'] = newplayermatch		--下注赛事玩家+1
	data['newplayergame'] = newplayergame		--玩游戏玩家+1
	data['newexpert'] = newexpert				--成为专家玩家+1
	LogDispatch.Push("lognewplayerbehavior", luajson.encode(data))	
end