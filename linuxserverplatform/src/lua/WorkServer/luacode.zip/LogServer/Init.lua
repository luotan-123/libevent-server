
require("LogServer.Model.LogServer")
require("LogServer.Model.LogBehavior")
require("LogServer.Services.LogDispatch")
require("LogServer.Model.LogConstantly")
require("LogServer.Model.LogModel")
require("LogServer.Services.ActivityService")
require("LogServer.Services.ActivityStatisticsToday")
require("LogServer.Services.ActivityStatisticsYesterday")
require("LogServer.Services.ReportServerInfoService")
require("LogServer.Worker.ReportServerInfo")


--g_redisIndex[LogDBCheck.redis_index] = {index = g_redisInfo.redis_three, des = "LogDBCheck", link = 0}

g_redisIndex[LogConstantly.redis_index] = {index = g_redisInfo.redis_three, des = "LogConstantly", link = 0}

g_redisIndex[LogModel.redis_index] = {index = g_redisInfo.redis_three, des = "LogModel", link = 0}
