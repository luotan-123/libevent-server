
LoadHelper = {}

require("trdlib.Init")  --先加载第三方库
require("conf.serverConf")
require("conf.redisConf")
require("Public.Init")
require("LogServer.Init")
require("Human.Init")
require("Agent.Init")
require("FootballGame.Init")
require("Robot.Init")     --加载机器
require("Expert.Init")
require("RedisClear.Init")
function LoadHelper.Reload()
	--[[--print('aaaaaaaaaaa')
	if g_isDebug ~= 1 then
		return nil
	end	
	package.loaded["Fruit.Services.FruitService"] = nil
	require("Fruit.Services.FruitService")	
	FruitService.Init()



	package.loaded["Forest.Services.ForestService"] = nil
	require("Forest.Services.ForestService")	
	ForestService.Init()
	
	package.loaded["DouNiu.Services.DouNiuJinBiChang"] = nil
	require("DouNiu.Services.DouNiuJinBiChang")
	--FruitService.Init()
	
	package.loaded["Sscai.Services.SscaiService"] = nil
	require("Sscai.Services.SscaiService")
	SscaiService.Init()--]]
	
	--[[package.loaded["Ersh.Services.SscaiService"] = nil
	require("Ersh.Services.SscaiService")
	ErshService.Init()
	
	package.loaded["Bcbm.Services.SscaiService"] = nil
	require("Bcbm.Services.SscaiService")
	BcbmService.Init()
	
	package.loaded["Fqzs.Services.SscaiService"] = nil
	require("Fqzs.Services.SscaiService")
	FqzsService.Init()--]]
	
end


function LoadHelper.HlydReload()
	if g_isDebug ~= 1 then
		return nil
	end



end

function LoadHelper.HttpReload()
	
end