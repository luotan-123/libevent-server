module('timerManager', package.seeall)


function timerManager.Init(currTime, timerType)
		
	g_markTime.curr = TimeUtils.GetTableTime()
	if timerType == "logtimer" then
		--BroadCastModel.Init()
	elseif timerType == "pokertimer" then
		--RaceManager.Init()
		--luaPrint("RaceManager init end")
		--RankService.Init()
		--把这个线程空余出来，作为事件的触发器。
	elseif timerType == "gametimer" then
		
		JettonModel.Init()
		PopularModel.Init()
		OnlineModel.Init()    --把非在线的全部清空
		LogServer.Init()
		ExpertService.Init()

	elseif timerType == "utilstimer" then
		
	end
	g_markTime.last = g_markTime.curr
	print(timerType.." init end")
end


function timerManager:execute(currTime, timerType)
	
	if g_markTime.last == nil then
		g_markTime.last = TimeUtils.GetTableTime()
		return
	end
	
	--上报信息功能
	ReportServerInfoService.ServerLoop()	

	--每分钟更新一次服务器的数据	
	g_markTime.curr = TimeUtils.GetTableTime()
	if timerType == "logtimer" then
		
	elseif timerType == "gametimer" then
		
		PushMsgModel.SendMsgLoop()
		NoticeModel.SeverLoop()
        PlayerStatsService.ServerLoop()
		TimeCheckService.HttpSendLoop()
        FootballService.LoginServerLoop()
		ExpertService.UtilsLoop()
	end
	
	g_markTime.last = g_markTime.curr
	
	---------------------测试数据------------------
	
	
	
	
	
	
end

function timerManager:createOnceTimer(strIndex)
	return _G[strIndex]
end


