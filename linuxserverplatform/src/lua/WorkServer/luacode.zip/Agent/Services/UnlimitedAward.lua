
UnlimitedAward = {}

function UnlimitedAward.Init(cgmsg, gcmsg)

--这里不需要初始化

end


function UnlimitedAward.CountUserAward(userID, userTeamAch, dayStr)
	
	local myRate = UnlimitedAward.GetAwardLevel(userTeamAch, userID)
	
	local retTeam = 0
	local retDir = 0
	local userIDList = AgentModel.GetUserDirUserIDList(userID, 0, -1)

	for k,v_userid in ipairs(userIDList) do
		local toTeamWeekAch = UnlimitedModel.GetUserTeamDayAch(v_userid, dayStr)
		retTeam = retTeam + UnlimitedAward.CountAward(myRate, toTeamWeekAch, v_userid)
	end
	
	return retTeam 
end

function UnlimitedAward.CountAward(myRate,toAch, toUserID)
	
	local toRate = UnlimitedAward.GetAwardLevel(toAch, toUserID)
	
	if myRate < toRate then
		return 0
	end
	
	return (myRate - toRate)*toAch/10000
	
end

function UnlimitedAward.CountAgentDirAward(myUserID, myAllAch, myDirAch)

	if myAllAch == 0 then
		return 0
	end
	
	local myRate = UnlimitedAward.GetAwardLevel(myAllAch, myUserID)
	return myRate*myDirAch/10000
end


function UnlimitedAward.CountDirAward(myRate, toAch)
	return myRate*toAch/10000
end

--在每日结算的时候，计算当前玩家上级的直属收益
function UnlimitedAward.CountPreAgentDirAward(preUserID, preAllAch,  achNum)
	if achNum == 0 then
		return 0
	end
	local preRate = UnlimitedAward.GetAwardLevel(achNum, preUserID)
	return preRate*achNum/10000
end


function UnlimitedAward.CountTeamAward(preUserID, preAllAch, userID, userAllAch, userSelfAch)

	local preRate = UnlimitedAward.GetAwardLevel(preAllAch, preUserID)
	local userRate = UnlimitedAward.GetAwardLevel(userAllAch, userID)

	if preRate < userRate then
		return 0
	end

	local retNum = (preRate - userRate)*(userAllAch - userSelfAch)/10000
	
	if retNum < 0 then
		return 0
	end
	
	return math.floor(retNum)
end


function UnlimitedAward.GetAwardLevel(achNum,userID)

	achNum = tonumber(achNum)
	local getNum = UnlimitedModel.GetUserRateNum(userID)
	
	if getNum > 0 then
		return getNum
	else
		return 0
	end
	
	--[[
	local tempNum = 0
	
	if g_gamename == "dejia" then
		achNum = achNum/100
		if achNum < 5000 then
			tempNum = 30
		elseif achNum < 10000 then
			tempNum =  50
		elseif achNum < 50000 then
			tempNum = 60
		elseif achNum < 100000 then
			tempNum = 70
		elseif achNum < 200000 then
			tempNum = 80
		elseif achNum < 500000 then
			tempNum = 90 
		elseif achNum < 1000000 then
			tempNum = 100
		elseif achNum < 2000000 then
			tempNum = 120
		elseif achNum < 4000000 then
			tempNum = 140
		elseif achNum < 6000000 then
			tempNum = 160
		elseif achNum < 8000000 then
			tempNum = 180
		elseif achNum < 10000000 then
			tempNum = 200
		elseif achNum < 20000000 then
			tempNum = 210
		elseif achNum < 30000000 then
			tempNum = 220
		else
			tempNum = 225
		end
	else
		achNum = achNum/100
		if achNum < 1000 then
			tempNum =  60
		elseif achNum < 7000 then
			tempNum = 70
		elseif achNum < 12000 then
			tempNum = 80
		elseif achNum < 40000 then
			tempNum = 100
		elseif achNum < 80000 then
			tempNum = 120 
		elseif achNum < 120000 then
			tempNum = 140
		elseif achNum < 250000 then
			tempNum = 160
		elseif achNum < 500000 then
			tempNum = 180
		elseif achNum < 800000 then
			tempNum = 200
		elseif achNum < 1000000 then
			tempNum = 220
		elseif achNum < 1200000 then
			tempNum = 240
		elseif achNum < 3600000 then
			tempNum = 260
		elseif achNum < 5000000 then
			tempNum = 270
		elseif achNum < 10000000 then
			tempNum =  280
		elseif achNum < 15000000 then
			tempNum = 290
		else
			tempNum = 300
		end
	
	end
	if tempNum > getNum then
		return tempNum
	else
		return getNum
	end
	]]
end

--这是一个活动接口。获取上周玩家的直属流水收益
function UnlimitedAward.GetDirAch(userID)
	
	local sqlCase = "select achdirect from log_unlimitedweekaward_0503 where userid="..userID
	mysqlItem:executeQuery(sqlCase)
	local sqlData = mysqlItem:fetch()
	if sqlData == nil then
		return 0
	end
	return tonumber(sqlData)
	
end

function UnlimitedAward.GetSixLevelAward(level)
	local indexList = {2,2,2,2,2,0}
	if level > 5 or level < 1 then
		return 0
	end
	return indexList[level]
end

