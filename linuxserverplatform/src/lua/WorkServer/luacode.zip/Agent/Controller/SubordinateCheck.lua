module("SubordinateCheck", package.seeall)


function execute(packetID, operateID, buffer)

	local cgmsg = msg_agent_pb.cgsubordinatecheck()
	local gcmsg = msg_agent_pb.gcsubordinatecheck()
	
	cgmsg:ParseFromString(buffer)
	local checkMsg = RedisHelper.CheckRedis(cgmsg.userid,operateID)
	if checkMsg ~= nil then
		
		LogBehavior.Warning(cgmsg.userid, "agent", "GetWiringList", 0,"缓存已存在")
		return cgmsg.userid,0,string.len(checkMsg),checkMsg
	end	

	if cgmsg.userid == cgmsg.checkid then
		gcmsg.result = ReturnCode["check_error_2"]
		return cgmsg.userid, 0, gcmsg:ByteSize(), gcmsg:SerializeToString()		
	end
	
	local pInfo = PlayerModel.GetPlayerInfo(cgmsg.userid)
		if pInfo == nil then
		LogBehavior.Error(cgmsg.userid,"wiring","SubordinateCheck", ReturnCode["player_not_exist"], "该玩家不存在")
		gcmsg.result = ReturnCode["player_not_exist"]
		return cgmsg.userid, 0, gcmsg:ByteSize(), gcmsg:SerializeToString()		
	end
	
	local cInfo = PlayerModel.GetPlayerInfo(cgmsg.checkid)
		if cInfo == nil then
		gcmsg.result = ReturnCode["check_error_1"]
		gcmsg.userid = cgmsg.userid
		gcmsg.checkid = cgmsg.checkid
		gcmsg.issubordinate = 2
		return cgmsg.userid, 0, gcmsg:ByteSize(), gcmsg:SerializeToString()		
	end
	
	if AgentModel.IsSubordinate(cgmsg.userid, cgmsg.checkid) == false then
		gcmsg.result = ReturnCode["check_error_1"]
		gcmsg.userid = cgmsg.userid
		gcmsg.checkid = cgmsg.checkid
		gcmsg.issubordinate = 2
		return cgmsg.userid, 0, gcmsg:ByteSize(), gcmsg:SerializeToString()	
	end
	
	gcmsg.userid = cgmsg.userid
	gcmsg.checkid = cgmsg.checkid
	gcmsg.issubordinate = 1
	gcmsg.checkNickname = cInfo.nickname
	gcmsg.teamcount = UnlimitedModel.GetUserTeamUserNum(cgmsg.checkid)
	gcmsg.directlycount = AgentModel.GetUserDirUserLen(cgmsg.checkid	)
	
	local agyinfo = AgentModel.GetAgentInfo(cgmsg.checkid)
	gcmsg.superiorid = agyinfo.agent1
	gcmsg.weekallach = "0"
	gcmsg.weekselfach = "0"
	gcmsg.weekteamach = "0"
	gcmsg.lastlogtime = TimeUtils.GetTimeString(cInfo.lasttime)
	gcmsg.result = 0
	return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
end