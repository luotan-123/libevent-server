module("WiringAwardList", package.seeall)


function execute(packetID, operateID, buffer)

	local cgmsg = msg_agent_pb.cgwiringawardlist()
	local gcmsg = msg_agent_pb.gcwiringawardlist()
	
	cgmsg:ParseFromString(buffer)
	local checkMsg = RedisHelper.CheckRedis(cgmsg.userid,operateID)
	if checkMsg ~= nil then
		LogBehavior.Warning(cgmsg.userid, "ddz", "DdzAction", 0,"aaaaaaaaa")
		return cgmsg.userid,0,string.len(checkMsg),checkMsg
	end
	

	gcmsg.result = 0
	return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
end