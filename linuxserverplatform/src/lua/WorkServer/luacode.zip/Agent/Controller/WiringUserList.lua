module("WiringUserList", package.seeall)

function execute(packetID, operateID, buffer)

	local cgmsg = msg_agent_pb.cgwiringuserlist()
	local gcmsg = msg_agent_pb.gcwiringuserlist()
	
	cgmsg:ParseFromString(buffer)
	

	local checkMsg = RedisHelper.CheckRedis(cgmsg.userid,operateID)
	if checkMsg ~= nil then
		
		LogBehavior.Warning(cgmsg.userid, "agent", "WiringUserList", 0,"缓存已存在")
		return cgmsg.userid,0,string.len(checkMsg),checkMsg
	end		
	
	

	if cgmsg.wiringid ~= 0 then
		--这里查询的是对应排线的ID
		local startPos = (cgmsg.pagenum - 1)*8
		startPos = startPos < 0 and 0 or startPos

		local sqlCase = "select userid from ag_player where wiringid="..cgmsg.wiringid.." order by userid desc limit "..startPos..", 8"
		mysqlItem:executeQuery(sqlCase)
		local userList = {}
		while true do
			local sqlData = mysqlItem:fetch({})
			if sqlData == nil then
				break
			end
			
			local addItem = {}
			addItem[1] = sqlData[1]
			addItem[2] = sqlData[2]
			table.insert(userList, addItem)
		end
		
		for k,item in ipairs(userList) do
			
			local pInfo = PlayerModel.GetPlayerInfo(item[1])
			if pInfo ~= nil then
				gcmsg.useridlist:append(tonumber(item[1]))
				gcmsg.nicknamelist:append(pInfo.nickname)
				
				local daystr = TimeUtils.GetDayString();
				gcmsg.teamoffer:append( tostring(UnlimitedModel.GetUserTeamDayAch(item[1], daystr) ))
				gcmsg.useroffer:append( tostring(UnlimitedModel.GetUserDayDirAch(item[1], daystr)))
				gcmsg.teamusernum:append( UnlimitedModel.GetUserTeamUserNum(item[1]) )
				gcmsg.directusernum:append( AgentModel.GetUserDirUserLen(item[1]))
				
				gcmsg.createdate:append( pInfo.regdate )
				
				gcmsg.baodinum:append( UnlimitedModel.GetUserRateNum( item[1] , AgentModel.GetChannel(pInfo.channel)) )
			end
		end

		sqlCase = "select count(*) from ag_player where wiringid="..cgmsg.wiringid
		
		mysqlItem:executeQuery(sqlCase)
		local sqlData = mysqlItem:fetch()
		if sqlData ~= nil then
			gcmsg.allnum = tonumber(sqlData)
		else
			gcmsg.allnum = #userList
		end
				
		gcmsg.pagenum = cgmsg.pagenum

		gcmsg.result = 0
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()		
		
	end
		
	
	gcmsg.result = 0
	local myAgent = AgentModel.GetAgentInfo(cgmsg.userid)

	if myAgent == nil then
		return cgmsg.userid, 0, gcmsg:ByteSize(), gcmsg:SerializeToString()
	end
	
	if cgmsg.checkuserid == 0 then
		
		local startPos = (cgmsg.pagenum - 1)*8
		startPos = startPos < 0 and 0 or startPos
		
		local userList = AgentModel.GetUserDirUserIDList(cgmsg.userid, startPos, startPos + 8)

		
		for k,v_userid in ipairs(userList) do
			
			local pInfo = PlayerModel.GetPlayerInfo(v_userid)
			if pInfo ~= nil then

				gcmsg.useridlist:append(tonumber(v_userid))
				gcmsg.nicknamelist:append(pInfo.nickname)
				-- 无限代理
				--gcmsg.teamoffer:append( tostring(UnlimitedModel.GetUserTeamDayAch(v_userid, TimeUtils.GetDayString() )))
				--gcmsg.useroffer:append( tostring(UnlimitedModel.GetUserDayDirAch(v_userid, TimeUtils.GetDayString() )))
				
				-- 三级代理
				gcmsg.teamoffer:append( tostring(UnlimitedModel.GetUserTeamWeekPump(v_userid, TimeUtils.GetWeekString() )))
				gcmsg.useroffer:append( tostring(UnlimitedModel.GetUserDirWeekPump(v_userid, TimeUtils.GetWeekString() )))
				
				gcmsg.teamusernum:append( UnlimitedModel.GetUserTeamUserNum(v_userid) )
				gcmsg.directusernum:append( AgentModel.GetUserDirUserLen(v_userid))
				
				gcmsg.createdate:append( pInfo.regdate )
				gcmsg.baodinum:append( UnlimitedModel.GetUserRateNum( v_userid , AgentModel.GetChannel(pInfo.channel)) )
			end
		end
		
		gcmsg.pagenum = cgmsg.pagenum
		gcmsg.checkuserid = cgmsg.checkuserid
		gcmsg.allnum = AgentModel.GetUserDirUserLen(cgmsg.userid)
	else
		local pInfo = PlayerModel.GetPlayerInfo(cgmsg.checkuserid)
		if pInfo ~= nil then
			
			local dirUserList = AgentModel.GetUserDirUserIDList(cgmsg.userid, 0, -1 )
			
			for k,v_userid in ipairs(dirUserList) do
				if cgmsg.checkuserid == tonumber(v_userid) then
					gcmsg.useridlist:append(cgmsg.checkuserid)
					gcmsg.nicknamelist:append(pInfo.nickname)
					gcmsg.teamoffer:append( tostring(UnlimitedModel.GetUserTeamDayAch(cgmsg.checkuserid, TimeUtils.GetDayString())))
					gcmsg.useroffer:append( tostring(UnlimitedModel.GetUserDayDirAch(cgmsg.checkuserid, TimeUtils.GetDayString())))
					gcmsg.teamusernum:append( UnlimitedModel.GetUserTeamUserNum(cgmsg.checkuserid))
					gcmsg.directusernum:append( AgentModel.GetUserDirUserLen(cgmsg.checkuserid))
					gcmsg.createdate:append( pInfo.regdate )
					gcmsg.baodinum:append( UnlimitedModel.GetUserRateNum(cgmsg.checkuserid), AgentModel.GetChannel(pInfo.channel) )
					gcmsg.pagenum = cgmsg.pagenum
					gcmsg.checkuserid = cgmsg.checkuserid
					gcmsg.allnum = 1
					break
				end
			end

		end
	end
	
	gcmsg.result = 0
	return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
end