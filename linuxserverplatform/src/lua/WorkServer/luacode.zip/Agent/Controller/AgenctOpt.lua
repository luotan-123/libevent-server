module("AgencyOpt", package.seeall)


function execute(packetID, operateID, buffer)

	local cgmsg = msg_human_pb.cgagencyopt()
	local gcmsg = msg_human_pb.gcagencyopt()
	
	cgmsg:ParseFromString(buffer)
	


	
	return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
end