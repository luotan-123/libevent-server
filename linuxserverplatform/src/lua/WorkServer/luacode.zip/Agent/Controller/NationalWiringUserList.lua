
module("NationalWiringUserList", package.seeall)


function execute(packetID, operateID, buffer)

	local cgmsg = msg_agent2_pb.cgnationalwiringuserlist()
	local gcmsg = msg_agent2_pb.gcnationalwiringuserlist()
	
	cgmsg:ParseFromString(buffer)
	

	local checkMsg = RedisHelper.CheckRedis(cgmsg.userid,operateID)
	if checkMsg ~= nil then
		
		LogBehavior.Warning(cgmsg.userid, "agent", "NationalWiringUserList", 0,"�����Ѵ���")
		return cgmsg.userid,0,string.len(checkMsg),checkMsg
	end		
	
	
	local myAgent = AgentModel.GetAgentInfo(cgmsg.userid)

	if myAgent == nil then
		gcmsg.result = 0
		return cgmsg.userid, 0, gcmsg:ByteSize(), gcmsg:SerializeToString()
	end
	
	local startPos = (cgmsg.pagenum - 1)*15
	startPos = startPos < 0 and 0 or startPos
	
	local userList = AgentModel.GetUserDirUserIDList(cgmsg.userid, startPos, startPos + 15)

	
	for k,v_userid in ipairs(userList) do
		
		local pInfo = PlayerModel.GetPlayerInfo(v_userid)
		if pInfo ~= nil then
			
			local user = gcmsg.user:add()
			
			user.memuserid = tonumber(v_userid)
			user.name = pInfo.nickname
			
			
			-- ��ѯ log_player���������
			local sqlCase = "select dirpumpamount,teampumpamount from log_player where userid="..v_userid
			mysqlLog:executeQuery(sqlCase)
			local sqlData = mysqlLog:fetch({})
			if sqlData ~= nil then
				user.useroffer = sqlData[1]
				user.teamoffer = sqlData[2]
			end
			
			
			user.teamnum = UnlimitedModel.GetUserTeamUserNum(v_userid)
			user.dirnum = AgentModel.GetUserDirUserLen(v_userid)
			user.rate = UnlimitedModel.GetUserRateNum(v_userid)

		end
	end
	
	gcmsg.pagenum = cgmsg.pagenum
	gcmsg.allnum = AgentModel.GetUserDirUserLen(cgmsg.userid)
	
	
	gcmsg.result = 0
	return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
end
