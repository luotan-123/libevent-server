module("GetAgentPromoteRank", package.seeall)


function execute(packetID, operateID, buffer)

	local cgmsg = msg_agent2_pb.cggetagentpromoterank()
	local gcmsg = msg_agent2_pb.gcgetagentpromoterank()
	
	cgmsg:ParseFromString(buffer)

	local checkMsg = RedisHelper.CheckRedis(cgmsg.userid,operateID)
	if checkMsg ~= nil then
		
		LogBehavior.Warning(cgmsg.userid, "agent", "GetWiringList", 0,"缓存已存在")
		return cgmsg.userid,0,string.len(checkMsg),checkMsg 
	end	
	
	local weekStr = TimeUtils.GetWeekString()	
	local sqlCase = "select userid,commisionamount from log_playerweek where dateid='"..weekStr.."' ORDER BY commisionamount DESC LIMIT 10"
	mysqlLog:executeQuery(sqlCase)
	
	local userList = {}
	while true do
		local sqlData = mysqlLog:fetch({})
		if sqlData == nil then
			break
		end
		
		local addItem = {}
		addItem[1] = sqlData[1]
		addItem[2] = sqlData[2]
		table.insert(userList, addItem)
	end
	
	for k,item in ipairs(userList) do
		
		local pInfo = PlayerModel.GetPlayerInfo(item[1])
		if pInfo ~= nil then
			gcmsg.ranking:append(k)
			gcmsg.useridlist:append(tonumber(item[1]))
			gcmsg.nicknamelist:append(pInfo.nickname)
			gcmsg.facelist:append(pInfo.face_1)
			gcmsg.incomelist:append(tonumber(item[2]))
		end
	end
	
	gcmsg.result = 0
	return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
end