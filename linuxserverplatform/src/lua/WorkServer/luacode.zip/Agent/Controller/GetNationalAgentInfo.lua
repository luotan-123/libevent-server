
module("GetNationalAgentInfo", package.seeall)


function execute(packetID, operateID, buffer)

	local cgmsg = msg_agent2_pb.cggetnationalagentinfo()
	local gcmsg = msg_agent2_pb.gcgetnationalagentinfo()
	
	cgmsg:ParseFromString(buffer)

	local checkMsg = RedisHelper.CheckRedis(cgmsg.userid,operateID)
	if checkMsg ~= nil then
		LogBehavior.Warning(cgmsg.userid, "agent", "GetNationalAgentInfo", 0,"�����Ѵ���")
		return cgmsg.userid,0,string.len(checkMsg),checkMsg 
	end	
	
	
	local pInfo = PlayerModel.GetPlayerInfo(cgmsg.userid)
	if pInfo == nil then
		gcmsg.result = ReturnCode["player_not_exist"]
		return cgmsg.userid, gcmsg.result, gcmsg:ByteSize(), gcmsg:SerializeToString()		
	end
	
	local sqlCase = "select allmoney,takemoney from ag_player where userid="..cgmsg.userid
	mysqlItem:executeQuery(sqlCase)
	local sqlData = mysqlItem:fetch({})
	if sqlData ~= nil then
		gcmsg.allmoney = tostring(math.floor(tonumber(sqlData[1])));
		local cantakemoney = math.floor(tonumber(sqlData[2]));
		if cantakemoney < 0 then
			cantakemoney = 0
		end
		gcmsg.takemoney =tostring(cantakemoney);
	end
	
	
	gcmsg.directnum = AgentModel.GetUserDirUserLen(cgmsg.userid)
	gcmsg.othernum = UnlimitedModel.GetUserTeamUserNum(cgmsg.userid) - gcmsg.directnum;
	if gcmsg.othernum < 0 then
		gcmsg.othernum = 0
	end
	
	gcmsg.userrate = UnlimitedModel.GetUserRateNum(cgmsg.userid, AgentModel.GetChannel(pInfo.channel))
	
	
	sqlCase = "select commisiondiramount,commisionamount from log_player where userid="..cgmsg.userid
	mysqlLog:executeQuery(sqlCase)
	local sqlData = mysqlLog:fetch({})
	if sqlData ~= nil then
		gcmsg.dirmoney = sqlData[1]
		gcmsg.othermoney = tostring(tonumber(sqlData[2]) - tonumber(sqlData[1]))
	end
	

	gcmsg.result = 0
	return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
end
