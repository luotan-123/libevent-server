module("WiringAchievement", package.seeall)

function execute(packetID, operateID, buffer)

	local cgmsg = msg_agent_pb.cgwiringachievement()
	local gcmsg = msg_agent_pb.gcwiringachievement()
	
	cgmsg:ParseFromString(buffer)
	local checkMsg = RedisHelper.CheckRedis(cgmsg.userid,operateID)
	if checkMsg ~= nil then
		LogBehavior.Warning(cgmsg.userid, "wiring", "WiringAchievement", 0,"缓存已存在")
		return cgmsg.userid,0,string.len(checkMsg),checkMsg
	end	
	
	local pInfo = PlayerModel.GetPlayerInfo(cgmsg.userid)
	if pInfo == nil then
		LogBehavior.Error(cgmsg.userid,"wiring","WiringAchievement", ReturnCode["player_not_exist"], "该玩家不存在")
		gcmsg.result = ReturnCode["player_not_exist"]
		return cgmsg.userid, gcmsg.result, gcmsg:ByteSize(), gcmsg:SerializeToString()		
	end

	UnlimitedModel.IsMarkDayAch(cgmsg.userid,pInfo.nickname)  --首先检查今天的存不存在
	local dayStr = TimeUtils.GetDayString()
	local sqlCase = "select userid,achall,achself,awardnum,gotmoney,datestr from log_unlimiteddayaward where userid="..cgmsg.userid.." order by id desc limit 8"   --每一次只会取7个
	
	--print(sqlCase)
	mysqlLog:executeQuery(sqlCase)

	local dataList = {}
	for i = 1,10 do
		local sqlData = mysqlLog:fetch({})
		if sqlData == nil then
			break
		end		
		table.insert(dataList, sqlData)
	end
	
	
	--luaDump(dataList)
	
	for k,sqlData in ipairs( dataList ) do
				
		if sqlData[6] == dayStr then
			
			gcmsg.weekallach = sqlData[2]
			gcmsg.weekselfach = sqlData[3]
			local myRate = UnlimitedAward.GetAwardLevel( tonumber(gcmsg.weekallach), cgmsg.userid )
			local getAward  = myRate * tonumber(gcmsg.weekselfach)/10000
			getAward = getAward + UnlimitedAward.CountUserAward(cgmsg.userid, tonumber(gcmsg.weekallach), TimeUtils.GetDayString())
			gcmsg.getmoneynum = tostring(getAward)
			gcmsg.precandrawnum = sqlData[5]
			gcmsg.weekteamach = tostring(tonumber(sqlData[2]) - tonumber(sqlData[3]))
		else
			local addItem = gcmsg.wlist:add()
			addItem.datestr = sqlData[6]
			addItem.allach_1 = sqlData[2]
			addItem.selfach_1 = sqlData[3]
			addItem.teamach_1 = tostring( tonumber(sqlData[2]) -  tonumber(sqlData[3]))
			addItem.getmoney = tonumber(sqlData[4])
		end
	end
	
	
	gcmsg.alldaynum = #dataList - 1
	gcmsg.pagenum = cgmsg.daypagenum
	gcmsg.result = 0
	return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
end