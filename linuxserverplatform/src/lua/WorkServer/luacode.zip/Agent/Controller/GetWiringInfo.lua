module("GetWiringInfo", package.seeall)


function execute(packetID, operateID, buffer)

	local cgmsg = msg_agent_pb.cggetwiringinfo()
	local gcmsg = msg_agent_pb.gcgetwiringinfo()
	
	cgmsg:ParseFromString(buffer)

	local checkMsg = RedisHelper.CheckRedis(cgmsg.userid,operateID)
	if checkMsg ~= nil then
		
		LogBehavior.Warning(cgmsg.userid, "agent", "GetWiringList", 0,"缓存已存在")
		return cgmsg.userid,0,string.len(checkMsg),checkMsg 
	end	


	--团队人数 = 我创建的排线的总人数+我所在的排线一下的人数。


	AgentModel.GetAgentInfo(cgmsg.userid, gcmsg.agyinfo)


	local dayStr = TimeUtils.GetDayString()
	
	gcmsg.newusernum = UnlimitedModel.GetUserNewTeamUserNum(cgmsg.userid, dayStr)
	gcmsg.activeusernum = UnlimitedModel.GetUserActiveTeamUserNum(cgmsg.userid, dayStr)
	gcmsg.awardratenum = UnlimitedAward.GetAwardLevel(  UnlimitedModel.GetUserTeamDayAch(cgmsg.userid, dayStr),  cgmsg.userid)
	--一下计算我所在排线的位置的人数。
	gcmsg.directusernum = AgentModel.GetUserDirUserLen(cgmsg.userid)
	gcmsg.teamusernum = UnlimitedModel.GetUserTeamUserNum(cgmsg.userid)
	gcmsg.fcrate = UnlimitedModel.GetUserRateNum(cgmsg.userid)
	gcmsg.result = 0
	return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
end