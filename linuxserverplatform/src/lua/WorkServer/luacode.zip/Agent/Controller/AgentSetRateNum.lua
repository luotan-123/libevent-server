
--设置保底金额

module("AgentSetRateNum", package.seeall)


function execute(packetID, operateID, buffer)

	local cgmsg = msg_agent_pb.cgagentsetratenum()
	local gcmsg = msg_agent_pb.gcagentsetratenum()
	
	cgmsg:ParseFromString(buffer)
	local pInfo = PlayerModel.GetPlayerInfo(cgmsg.selfuserid)
	if pInfo == nil then
		gcmsg.result = ReturnCode["player_not_exist"]
		return cgmsg.selfuserid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
	end
	

	-- 获取自己的返佣率
	local sqlCase = "select getrate from ag_player where userid="..cgmsg.selfuserid
	mysqlItem:executeQuery(sqlCase)
	local retNum = mysqlItem:fetch()
	retNum = retNum == nil and 0 or tonumber(retNum)	


	if AgentAward.IsHaveFiveAgent( AgentModel.GetChannel(pInfo.channel) ) then
		
		if cgmsg.ratenum > retNum - 2 then
			gcmsg.result = ReturnCode["agent_pre_error2"]
			return cgmsg.selfuserid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()		
		end
		
		if cgmsg.ratenum < 30 then
			gcmsg.result = ReturnCode["agent_pre_error3"]
			return cgmsg.selfuserid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()		
		end
	
	else
		
		if cgmsg.ratenum < 1 then
			gcmsg.result = ReturnCode["agent_set_error"]
			return cgmsg.selfuserid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()		
		end
		
		
		if cgmsg.ratenum > retNum then
			gcmsg.result = ReturnCode["agent_pre_error1"]
			return cgmsg.selfuserid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()		
		end
		
	end

	
	sqlCase = "select getrate from ag_player where userid="..cgmsg.touserid
	mysqlItem:executeQuery(sqlCase)
	local toRateNUm = mysqlItem:fetch()
	if toRateNUm == nil then
		gcmsg.result = ReturnCode["agent_set_error"]
		return cgmsg.selfuserid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()			
	end
	
	local tmpToRateNUm = tonumber(toRateNUm)
	if cgmsg.ratenum <= tonumber(toRateNUm) then
		gcmsg.result = ReturnCode["agent_pre_error"]
		return cgmsg.selfuserid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()		
	end

	sqlCase = "update ag_player set getrate="..cgmsg.ratenum.." where userid="..cgmsg.touserid
	mysqlItem:execute(sqlCase)
	
	redisItem:hset( UnlimitedModel.Wiring_user_ratenum, cgmsg.touserid, cgmsg.ratenum,  UnlimitedModel.redis_index)
	
	local pInfo = PlayerModel.GetPlayerInfo(cgmsg.selfuserid)
	local msg = ""..cgmsg.selfuserid.."把"..cgmsg.touserid.."的返点从"..tmpToRateNUm.."修改为"..cgmsg.ratenum
	LogBehavior.Info(pInfo, "ratenum", "RateNumModify", cgmsg.touserid, msg)
	
	gcmsg.selfuserid = cgmsg.selfuserid
	gcmsg.touserid = cgmsg.touserid
	gcmsg.ratenum = cgmsg.ratenum
	
	gcmsg.result = 0
	return cgmsg.selfuserid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
end
