module("GetWiringList", package.seeall)


function execute(packetID, operateID, buffer)

	local cgmsg = msg_agent_pb.cggetwiringlist()
	local gcmsg = msg_agent_pb.gcgetwiringlist()
	
	cgmsg:ParseFromString(buffer)
	

	
	local checkMsg = RedisHelper.CheckRedis(cgmsg.userid,operateID)
	if checkMsg ~= nil then
		
		LogBehavior.Warning(cgmsg.userid, "agent", "GetWiringList", 0,"缓存已存在")
		return cgmsg.userid,0,string.len(checkMsg),checkMsg
	end		
	if cgmsg.checkwiringname ~= '' then
		local starPos = (cgmsg.pagenum-1)*10 + 1
		local endPos = starPos + 9
		local sqlCase = "select * from dy_unlimitedwiring where ownerid="..cgmsg.userid.." and isexist = 1 and name=".."'"..cgmsg.checkwiringname.."' limit "..(starPos - 1)..", "..(endPos - 1)
		mysqlItem:executeQuery(sqlCase)
		while true do
			local sqlData = mysqlItem:fetch({})
			if sqlData == nil then
				break
			end
			local addItem = gcmsg.wirelist:add()
			UnlimitedModel.GetWiringInfoByID(tonumber(sqlData[1]), addItem)
			addItem.qrcodeurl = AgentModel.CreateWiringQrcode(cgmsg.userid, tonumber(sqlData[1]))   --这里必须临时生成。因为每个人的都一样
		
			addItem.currnum = 0
			addItem.usernum = 0 
			addItem.newaddnum = 0
			addItem.createdate = ""
		end
		
		local sqlCase = "select count(*) from dy_unlimitedwiring where ownerid="..cgmsg.userid.." and isexist = 1 and name=".."'"..cgmsg.checkwiringname.."'"
		mysqlItem:executeQuery(sqlCase)
		local sqlData = mysqlItem:fetch()
		if sqlData ~= nil then
			gcmsg.allnum = tonumber(sqlData)
		end
		gcmsg.result = 0
		gcmsg.checkwiringname = cgmsg.checkwiringname
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
	end
	
	local IDList = UnlimitedModel.GetWiringIDList(cgmsg.userid)


	local starPos = (cgmsg.pagenum-1)*10 + 1
	
	local endPos = starPos + 9
	endPos = endPos > #IDList and #IDList or endPos

	for i = starPos,endPos do
		
		local addItem = gcmsg.wirelist:add()
		UnlimitedModel.GetWiringInfoByID(IDList[i], addItem)
		addItem.qrcodeurl = AgentModel.CreateWiringQrcode(cgmsg.userid, IDList[i])   --这里必须临时生成。因为每个人的都一样
		
		addItem.currnum = 0 
		addItem.usernum = 0 
		addItem.newaddnum = 0 
		addItem.createdate = ""
		
		
	end
	
	gcmsg.allnum = #IDList
	gcmsg.result = 0
	
	return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
end