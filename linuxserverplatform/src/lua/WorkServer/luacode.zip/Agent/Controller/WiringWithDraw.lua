module("WiringWithDraw", package.seeall)

function execute(packetID, operateID, buffer)

	local cgmsg = msg_agent_pb.cgwiringwithdraw()
	local gcmsg = msg_agent_pb.gcwiringwithdraw()
	
	cgmsg:ParseFromString(buffer)
	
	local checkMsg = RedisHelper.CheckRedis(cgmsg.userid,operateID)
	if checkMsg ~= nil then
		LogBehavior.Warning(cgmsg.userid, "wiring", "WiringWithDraw", 0,"»º´æÒÑ´æÔÚ")
		return cgmsg.userid,0,string.len(checkMsg),checkMsg
	end	
	
	local pInfo = PlayerModel.GetPlayerInfo(cgmsg.userid)
	if pInfo == nil then
		LogBehavior.Error(cgmsg.userid,"wiring","WiringWithDraw", ReturnCode["player_not_exist"], "¸ÃÍæ¼Ò²»´æÔÚ")
		gcmsg.result = ReturnCode["player_not_exist"]
		return cgmsg.userid, gcmsg.result, gcmsg:ByteSize(), gcmsg:SerializeToString()		
	end
	
	local sqlCase = "select * from ag_player where userid="..cgmsg.userid
	mysqlItem:executeQuery(sqlCase)
	local sqlData = mysqlItem:fetch({})
	if sqlData ~= nil then
		gcmsg.allawardnum = tostring(sqlData[15]) == nil and  "0" or tostring(sqlData[15])
		gcmsg.drawawawdnum = tostring(sqlData[40]) == nil and  "0" or tostring(sqlData[40])
		gcmsg.candrawnum = tostring(sqlData[16]) == nil and "0"  or tostring(sqlData[16])
		gcmsg.precandrawnum = ""
		
		
	end
	
	
	local sqlCase = "select * from ag_drawmoney where userid=".. cgmsg.userid.." and taketype!=0".." order by id desc"
	mysqlItem:executeQuery(sqlCase)
	
	local counter = 1
	local startPos = 5*(cgmsg.pagenum - 1) + 1
	local endPos = 5*cgmsg.pagenum
	while true do
		
		local sqlData = mysqlItem:fetch({})
		if sqlData == nil then
			break
		end 
		if counter >= startPos then
			local addw = gcmsg.wlist:add()
			addw.drawid = tostring(sqlData[17]) == nil and "" or tostring(sqlData[17])
			addw.userid = tonumber(sqlData[2]) == nil and 0 or tonumber(sqlData[2])
			addw.datestr = tostring(sqlData[8]) == nil and "" or tostring(sqlData[8])
			addw.amount = tostring(sqlData[9]) == nil and "0" or tostring(sqlData[9])
			if tonumber(sqlData[21]) == 1 then
				if tonumber(sqlData[18]) == 1 then
					addw.drawtypw = 2
				elseif tonumber(sqlData[18]) == 2 then
					addw.drawtypw = 1
				elseif tonumber(sqlData[18]) == 3 then
					addw.drawtypw = 3
				end
			elseif tonumber(sqlData[21]) == 2 then
				if tonumber(sqlData[18]) == 3 then
					addw.drawtypw = 4
				end
			end
			if tonumber(sqlData[18])  == 1 then
				addw.account = tostring(sqlData[13]) == nil and "" or tostring(sqlData[13])
			elseif tonumber(sqlData[18])  == 2 then
				addw.account = tostring(sqlData[14]) == nil and "" or tostring(sqlData[14])
			elseif tonumber(sqlData[18])  == 3 then
				addw.account = tostring(sqlData[2]) == nil and "" or tostring(sqlData[2])
			end
			addw.state = tonumber(sqlData[7]) == nil and 0 or tonumber(sqlData[7])
		end
		if counter >= endPos then
			break
		end
		counter = counter + 1
	end

	gcmsg.userid = cgmsg.userid
	local sqlCase = "select count(*) from ag_drawmoney where userid=".. cgmsg.userid.." and taketype!=0"
	mysqlItem:executeQuery(sqlCase)
	local sqlData = mysqlItem:fetch()
	local count = 0
	if sqlData ~= nil then
		count = sqlData
	end
	gcmsg.alllistcount = tonumber(count) == nil and 0 or tonumber(count)
	gcmsg.pagenum = cgmsg.pagenum
	gcmsg.result = 0
	return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
end

