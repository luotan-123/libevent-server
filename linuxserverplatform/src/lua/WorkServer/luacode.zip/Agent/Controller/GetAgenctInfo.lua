
module("GetAgenctInfo", package.seeall)


function execute(packetID, operateID, buffer)

	local cgmsg = msg_agent_pb.cggetagentinfo()
	local gcmsg = msg_agent_pb.gcgetagentinfo()
	
	cgmsg:ParseFromString(buffer)
	local pInfo = PlayerModel.GetPlayerInfo(cgmsg.userid)
	if pInfo == nil then
		gcmsg.result = ReturnCode["player_not_exist"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
	end
	
	AgentModel.GetAgentInfo(cgmsg.userid, gcmsg.agyinfo)
	gcmsg.result = 0
	return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
end
