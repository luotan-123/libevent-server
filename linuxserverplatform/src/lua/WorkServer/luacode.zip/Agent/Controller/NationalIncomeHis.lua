
module("NationalIncomeHis", package.seeall)


function execute(packetID, operateID, buffer)

	local cgmsg = msg_agent2_pb.cgnationalincomehis()
	local gcmsg = msg_agent2_pb.gcnationalincomehis()
	
	cgmsg:ParseFromString(buffer)
	
	local checkMsg = RedisHelper.CheckRedis(cgmsg.userid,operateID)
	if checkMsg ~= nil then
		
		LogBehavior.Warning(cgmsg.userid, "agent", "NationalIncomeHis", 0,"�����Ѵ���")
		return cgmsg.userid,0,string.len(checkMsg),checkMsg
	end		
	
	local currtime = TimeUtils.GetTime() 
	
	-- ��ѯһ��
	--local sqlCase = "select regdate,wucommisionamount,commisionamount from log_playerweek where userid="..cgmsg.userid.." order by id desc limit 60"
	local sqlCase = "select regdate,wucommisionamount,commisionamount from log_playerdaily where userid="..cgmsg.userid.." order by id desc limit 90"
	mysqlLog:executeQuery(sqlCase)
	while true do
		local sqlData = mysqlLog:fetch({})
		if sqlData == nil then
			break
		end
		
		local record = gcmsg.datas:add()
		
		record.time = sqlData[1] or "0"
		--record.activemem = tonumber(sqlData[2])
		--record.incomerate = sqlData[3]
		record.userincome = sqlData[2]
		record.income = sqlData[3] 
		record.teamincome = tostring( tonumber(record.income) - tonumber(record.userincome))
		
		if tonumber(record.time) == 0 then
			record.time = tostring(currtime)
		end
	end
	

	gcmsg.result = 0
	return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
end
