module("WiringAchievement", package.seeall)

function execute(packetID, operateID, buffer)

	local cgmsg = msg_agent_pb.cgwiringachievement()
	local gcmsg = msg_agent_pb.gcwiringachievement()
	
	cgmsg:ParseFromString(buffer)
	local checkMsg = RedisHelper.CheckRedis(cgmsg.userid,operateID)
	if checkMsg ~= nil then
		LogBehavior.Warning(cgmsg.userid, "wiring", "WiringAchievement", 0,"缓存已存在")
		return cgmsg.userid,0,string.len(checkMsg),checkMsg
	end	
	
	gcmsg.result = 0
	return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
end