
module("InviteBind", package.seeall)


function execute(packetID, operateID, buffer)

	local cgmsg = msg_agent_pb.cginvitebind()
	local gcmsg = msg_agent_pb.gcinvitebind()
	cgmsg:ParseFromString(buffer)

	if cgmsg.userid == tonumber(cgmsg.invitestr) then
		--不能过绑定自己
		gcmsg.result = ReturnCode["bind_not_self"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
	end

	local pInfo = PlayerModel.GetPlayerInfo(cgmsg.userid)
	if pInfo == nil then
		gcmsg.result = ReturnCode["player_not_exist"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
	end

	if cgmsg.invitestr == nil or 0 == string.len(cgmsg.invitestr) then
		gcmsg.result = ReturnCode["agency_bind_error"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
	end
	
--[[	if nil == PlayerModel.GetPlayerInfo(tonumber(cgmsg.invitestr)) then
		gcmsg.result = ReturnCode["agency_not_exist"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
	end--]]
	
	--检查有没有绑定别人
	
	local myAgent = AgentModel.GetAgentInfo( cgmsg.userid, gcmsg.agyinfo )
	
	
	local toAgent = AgentModel.GetAgentInfo(cgmsg.invitestr)
	
	
	if myAgent == nil then
		gcmsg.result = ReturnCode["player_not_exist"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()		
	end
	
	if toAgent == nil then
		gcmsg.result = ReturnCode["agency_not_exist"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()		
	end


	
	if gcmsg.agyinfo.agent1 ~= 0 then
		gcmsg.result = ReturnCode["agency_is_band"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
	end
	
	if toAgent.agent1 == 0 and toAgent.level < 99 then
		--如果绑定的上次还不是总代或者绑定其他的代理。那么，也不能绑定该代理
		gcmsg.result = ReturnCode["bind_pre_not_agent"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
	end
	
    local topInfo = PlayerModel.GetPlayerInfo(cgmsg.invitestr)
    
    --代理必须同一个渠道
    if GameUtils.GetChannel_login(topInfo.channel) ~= GameUtils.GetChannel_login(pInfo.channel) or (pInfo.usertype == 1 and topInfo.usertype ~= pInfo.usertype)  then
        --print(topInfo.channel,pInfo.channel)
        gcmsg.result = ReturnCode["agency_not_exist"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()	
    end


	--绑定我的两级代理
	local sqlCase = "update ag_player set agent1="..cgmsg.invitestr..", agent2="..toAgent.agent1..",agent3="..toAgent.agent2..",soleagent="..toAgent.soleagent.." where userid="..cgmsg.userid
	mysqlItem:execute(sqlCase)
	
	gcmsg.agyinfo.agent1 = tonumber(cgmsg.invitestr)
	gcmsg.agyinfo.agent2 = toAgent.agent1
	gcmsg.agyinfo.agent3 = toAgent.agent2
	gcmsg.agyinfo.soleagent = toAgent.soleagent
	
	AgentModel.SetAgent(cgmsg.userid, gcmsg.agyinfo)
	
	UnlimitedModel.SetUserPreAgentID( cgmsg.userid, cgmsg.invitestr )
	gcmsg.result = 0
	


	local sendData = {}
	sendData['userid'] = cgmsg.userid
	sendData['wiringid'] = toAgent.wiringid
	sendData['paixian'] = 0
    --print(cgmsg.invitestr,toAgent.userid,pInfo.userid)
	VipMgrModel.SetVipUserInvalidFriends(toAgent.userid,pInfo.userid)
	LogDispatch.UserBindAgent(pInfo, toAgent.userid)
	
	return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
end