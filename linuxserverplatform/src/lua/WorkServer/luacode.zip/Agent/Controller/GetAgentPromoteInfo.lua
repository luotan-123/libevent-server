module("GetAgentPromoteInfo", package.seeall)


function execute(packetID, operateID, buffer)

	local cgmsg = msg_agent2_pb.cggetagentpromoteinfo()
	local gcmsg = msg_agent2_pb.gcgetagentpromoteinfo()
	
	cgmsg:ParseFromString(buffer)

	gcmsg.result = 0
	return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
end