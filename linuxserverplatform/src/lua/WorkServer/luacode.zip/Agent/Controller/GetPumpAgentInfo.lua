module("GetPumpAgentInfo", package.seeall)


function execute(packetID, operateID, buffer)

	local cgmsg = msg_agent2_pb.cggetpumpagentinfo()
	local gcmsg = msg_agent2_pb.gcgetpumpagentinfo()
	
	cgmsg:ParseFromString(buffer)

	local checkMsg = RedisHelper.CheckRedis(cgmsg.userid,operateID)
	if checkMsg ~= nil then
		LogBehavior.Warning(cgmsg.userid, "agent", "GetPumpAgentInfo", 0,"缓存已存在")
		return cgmsg.userid,0,string.len(checkMsg),checkMsg 
	end	

	local sqlCase = "select allmoney,takemoney from ag_player where userid="..cgmsg.userid
	mysqlItem:executeQuery(sqlCase)
	local sqlData = mysqlItem:fetch({})
	if sqlData ~= nil then
		gcmsg.allincome = tostring(math.floor(tonumber(sqlData[1])));
		local cantakemoney = math.floor(tonumber(sqlData[2]));
		if cantakemoney < 0 then
			cantakemoney = 0
		end
		gcmsg.canincome =tostring(cantakemoney);
	end
	
	gcmsg.directnum = AgentModel.GetUserDirUserLen(cgmsg.userid)
	gcmsg.othernum = UnlimitedModel.GetUserTeamUserNum(cgmsg.userid) - gcmsg.directnum;
	if gcmsg.othernum < 0 then
		gcmsg.othernum = 0
	end
	
	-- 三个昨日信息  查询 log_daylevelaward
	local currTime = TimeUtils.GetTime();
	local yesterday = TimeUtils.GetDayString(currTime - 24 * 60 * 60);
	--local sqlCase = "update log_daylevelaward set awardall=awardall+"..addAward..",ach"..level.."=ach"..level.."+"..addNum..",award"..level.."=award"..level.."+"..addAward.." where userid="..preAgentID.." and datestr='"..dayStr.."'"
	local sqlCase = "select awardall,award1 from log_daylevelaward where userid="..cgmsg.userid.." and datestr='"..yesterday.."'"
	mysqlLog:executeQuery(sqlCase)
	local sqlData = mysqlLog:fetch({})
	if sqlData ~= nil then
		gcmsg.allyestincome = tostring( math.floor(tonumber(sqlData[1])) )
		gcmsg.directyestincome = tostring( math.floor(tonumber(sqlData[2])) )
		gcmsg.otheryestincome = tostring(tonumber(gcmsg.allyestincome) - tonumber(gcmsg.directyestincome))  or "0"
	end
	
	gcmsg.result = 0
	
	return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
end