module("WiringAwardList", package.seeall)


function execute(packetID, operateID, buffer)

	local cgmsg = msg_agent_pb.cgwiringawardlist()
	local gcmsg = msg_agent_pb.gcwiringawardlist()
	
	cgmsg:ParseFromString(buffer)
	local checkMsg = RedisHelper.CheckRedis(cgmsg.userid,operateID)
	if checkMsg ~= nil then
		LogBehavior.Warning(cgmsg.userid, "ddz", "DdzAction", 0,"aaaaaaaaa")
		return cgmsg.userid,0,string.len(checkMsg),checkMsg
	end
	
	local pInfo = PlayerModel.GetPlayerInfo(cgmsg.userid)
	if pInfo == nil then
		LogBehavior.Error(cgmsg.userid,"wiring","DdzAction", ReturnCode["player_not_exist"], "aaaaaaaaaaaa")
		gcmsg.result = ReturnCode["player_not_exist"]
		return cgmsg.userid, gcmsg.result, gcmsg:ByteSize(), gcmsg:SerializeToString()		
	end


	UnlimitedModel.IsMarkDaySix(cgmsg.userid)
	
	local sqlCase = "select * from log_daylevelaward where id > 0 and userid="..cgmsg.userid.." order by id desc limit 7"
	
	mysqlLog:executeQuery(sqlCase)
	
	for i = 1, 10 do
		
		local sqlData = mysqlLog:fetch({})
		if sqlData == nil then
			break
		end
		
		local addItem = gcmsg.walist:add()
		addItem.datestr = sqlData[3]
		addItem.award1 = tonumber(sqlData[6])
		addItem.award2 = tonumber(sqlData[8])
		addItem.award3 = tonumber(sqlData[10])
		addItem.award4 = tonumber(sqlData[12])
		addItem.award5 = tonumber(sqlData[14])
		addItem.award6 = tonumber(sqlData[16])
		addItem.awardnum = tostring( addItem.award1 + addItem.award2 + addItem.award3 + addItem.award4 + addItem.award5 + addItem.award6 )
	end
	
	gcmsg.allnum = #gcmsg.walist
	gcmsg.pagenum = cgmsg.pagenum
	gcmsg.result = 0
	return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
end