module("WiringDrawMoney", package.seeall)

function execute(packetID, operateID, buffer)

	local cgmsg = msg_agent_pb.cgwiringdrawmoney()
	local gcmsg = msg_agent_pb.gcwiringdrawmoney()
	
	cgmsg:ParseFromString(buffer)
	
	local checkMsg = RedisHelper.CheckRedis(cgmsg.userid,operateID)
	if checkMsg ~= nil then
		LogBehavior.Warning(cgmsg.userid, "wiring", "WiringDrawMoney", 0,"缓存已存在")
		return cgmsg.userid,0,string.len(checkMsg),checkMsg
	end	
	
	local pInfo = PlayerModel.GetPlayerInfo(cgmsg.userid)
	if pInfo == nil then
		LogBehavior.Error(cgmsg.userid,"wiring","WiringDrawMoney", ReturnCode["player_not_exist"], "该玩家不存在")
		gcmsg.result = ReturnCode["player_not_exist"]
		return cgmsg.userid, gcmsg.result, gcmsg:ByteSize(), gcmsg:SerializeToString()		
	end
	
	if pInfo.silent == 1 then
		gcmsg.result = ReturnCode["function_limit"]
		return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
	end
	
	--提现预提都要超过一百
	if cgmsg.drawtype == 1 then
		if cgmsg.accounttype == 2 and tonumber(cgmsg.drawnum) < g_withdrawdepositminjetton then
			gcmsg.result = ReturnCode["Tx_error_1"]
			return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
		elseif cgmsg.accounttype == 3 and tonumber(cgmsg.drawnum) <= 0 then
			gcmsg.result = ReturnCode["Tx_error_1"]
			return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
		end
	end
	
	local sqlCase = "select * from ag_player where userid="..cgmsg.userid
	mysqlItem:executeQuery(sqlCase)
	local sqlData = mysqlItem:fetch({})
	if sqlData ~= nil then
		if cgmsg.drawtype == 1 then
			if tonumber(sqlData[16]) < tonumber(cgmsg.drawnum) then
				gcmsg.result = ReturnCode["draw_error_1"]
				return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
			end
			
			if cgmsg.accounttype == 2 and sqlData[27] == "" then
				gcmsg.result = ReturnCode["Tx_error_4"]
				return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
			end
			if cgmsg.accounttype == 1 and sqlData[33] == "" then
				gcmsg.result = ReturnCode["Tx_error_4"]
				return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
			end
		elseif cgmsg.drawtype == 2 then
			cgmsg.accounttype = 3

			local tempNum = 0
			if tempNum < tonumber(cgmsg.drawnum) then
				gcmsg.result = ReturnCode["rep_error"]
				return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()				
			end
			
		end
	end
	

	local userid = cgmsg.userid
	local nickname = pInfo.nickname
	local phone = sqlData[6]
	local wechat = sqlData[7]
	local state = 1
	local drawjetton = tonumber(cgmsg.drawnum)
	local realname = ""
	local alipay = sqlData[33]
	local bankacount = sqlData[27]
	local bankname = sqlData[28]
	local bankaddress = sqlData[29]
	local drawmtype = cgmsg.accounttype
	local alipaypayee = sqlData[34]
	local bankpayee = sqlData[32]
	local taketype = cgmsg.drawtype
	local drawnum = drawjetton
	local ratenum = 0
	local bankprovince = sqlData[42]
	local bankcity = sqlData[43]
	local bankidnumber = sqlData[44]
	
	
	local userDrawNum = 0
	local sqlCase = "select count(*) from ag_drawmoney where userid="..userid.." and state!=5 and drawmtype!=3 and to_days(rsdate)=to_days(now())"
	mysqlItem:executeQuery(sqlCase) 
	local sqlData = mysqlItem:fetch()
	if sqlData ~= nil then
		userDrawNum = tonumber(sqlData) == nil and 0 or  tonumber(sqlData)
	end
	local userDrawNum = userDrawNum + 1
	if userDrawNum > 1 and cgmsg.accounttype ~= 3 then
		ratenum = drawjetton * 0.02
		drawnum = drawnum - ratenum
	end
	
	
	if cgmsg.accounttype == 3 then
		state = 3
	end
	
	local orderid = TimeUtils.GetTime()..cgmsg.userid..math.myrandom(100,999)
	
	local pInfo = PlayerModel.GetPlayerInfo(userid)
	local prechannel = GameUtils.GetChannel_login(pInfo.channel)
	
	local sqlCase = "insert ag_drawmoney(userid, nickname, phone, wechat, drawnum, state, drawjetton, realname, alipay, bankacount, bankname, bankaddress, orderid, drawmtype, alipaypayee, bankpayee, taketype, ratenum, bankprovince, bankcity, bankidnumber,channel,prechannel) values("
		.."'"..userid.."'"..", ".."'"..nickname.."'"..", ".."'"..phone.."'"..", ".."'"..wechat.."'"..", ".."'"..drawnum.."'"..", "
		.."'"..state.."'"..", ".."'"..drawjetton.."'"..", ".."'"..realname.."'"..", ".."'"..alipay.."'"..", ".."'"..bankacount.."'"..", "
		.."'"..bankname.."'"..", ".."'"..bankaddress.."'"..", ".."'"..orderid.."'"..", ".."'"..drawmtype.."'"..", ".."'"..alipaypayee.."'"..
		", ".."'"..bankpayee.."'"..",".."'"..taketype.."'"..",".."'"..ratenum.."'"..",".."'"..bankprovince.."'"..",".."'"..bankcity.."'"..",".."'"..bankidnumber.."','"
		..pInfo.channel.."','"..prechannel.."')"
	mysqlItem:executeQuery(sqlCase)

	local sqlCase = "select * from ag_drawmoney where orderid="..orderid
	mysqlItem:executeQuery(sqlCase)
	local sqlData = mysqlItem:fetch({})
	if sqlData == nil then
		if drawtype == 1 then
			gcmsg.result = ReturnCode["draw_error_1"]
			return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
		elseif drawtype == 2 then
			gcmsg.result = ReturnCode["rep_error_1"]
			return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
		end
	end
	 
	if taketype == 1 then
		local sqlCase = "update ag_player set takemoney=takemoney-"..drawjetton..", extractedmoney=extractedmoney+"..drawjetton.." where userid="..cgmsg.userid
		mysqlItem:execute(sqlCase)
	elseif taketype == 2 then
		local sqlCase = "update ag_player set premoney=premoney+"..drawjetton..", extractedmoney=extractedmoney+"..drawjetton..",allmoney=allmoney+"..drawjetton.." where userid="..cgmsg.userid
		mysqlItem:execute(sqlCase)
	end
	
	--提到余额直接到账
	if cgmsg.accounttype == 3 then
		PlayerModel.AddJetton(pInfo, drawjetton, "player", "WiringDrawMoney")
		PlayerModel.SetPlayerInfo(pInfo)
		PlayerModel.SendJetton(pInfo)
		
		
		LogDispatch.CommissionChange(pInfo, drawjetton, TimeUtils.GetTime())
		
		-- 生成交易记录
		LogServer.addRecords(pInfo.userid, drawjetton >= 0 and 1 or 2, "领取代理佣金", drawjetton, orderid)
		
	else
		
		--实时监控系统
		RTMModel.addWithdrawMoneyRecord(pInfo.userid, pInfo.nickname, TimeUtils.GetTime(), orderid, cgmsg.accounttype, drawjetton)
		LogDispatch.WithDrawCountCom(pInfo, drawjetton, TimeUtils.GetTime())
	end
	
	
	gcmsg.userid = userid
	gcmsg.drawtype = drawmtype
	gcmsg.result = 0
	return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
end

