
module("GetNationalDirUserInfo", package.seeall)


function execute(packetID, operateID, buffer)

	local cgmsg = msg_agent2_pb.cggetnationaldiruserinfo()
	local gcmsg = msg_agent2_pb.gcgetnationaldiruserinfo()
	
	cgmsg:ParseFromString(buffer)

	local checkMsg = RedisHelper.CheckRedis(cgmsg.userid,operateID)
	if checkMsg ~= nil then
		LogBehavior.Warning(cgmsg.userid, "agent", "GetNationalDirUserInfo", 0,"�����Ѵ���")
		return cgmsg.userid,0,string.len(checkMsg),checkMsg 
	end	
	
	local userID = cgmsg.diruserid
	local pInfo = PlayerModel.GetPlayerInfo(userID)
	if pInfo == nil then
		gcmsg.result = 0
		return cgmsg.userid, 0, gcmsg:ByteSize(), gcmsg:SerializeToString()
	end
	
	gcmsg.tiprate = UnlimitedModel.GetUserRateNum(userID, AgentModel.GetChannel(pInfo.channel))
	gcmsg.baotips = gcmsg.tiprate
	gcmsg.allteamnum = UnlimitedModel.GetUserTeamUserNum(userID);
	gcmsg.allactivenum = gcmsg.allteamnum
	gcmsg.allvalidnum = gcmsg.allteamnum
	gcmsg.name = pInfo.nickname
	
	local sqlCase = "select achamount,userincome,teamincome,feeamount,winamount from log_player where userid="..userID
	mysqlLog:executeQuery(sqlCase)
	local sqlData = mysqlLog:fetch({})
	if sqlData ~= nil then
		gcmsg.allpour = sqlData[1]
		gcmsg.allincome = tonumber(sqlData[2]) + tonumber(sqlData[3])
		gcmsg.alltip = tonumber(sqlData[4])
		gcmsg.alldeposit = tonumber(pInfo.jetton) + tonumber(pInfo.bank_jetton)
		gcmsg.allwin = tonumber(sqlData[5])
	end
	
	gcmsg.result = 0
	return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
end
