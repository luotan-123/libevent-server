module("WiringAppointmentWithDraw", package.seeall)


function execute(packetID, operateID, buffer)

	local cgmsg = msg_agent_pb.cgwiringappointmentwithdraw()
	local gcmsg = msg_agent_pb.gcwiringappointmentwithdraw()
	
	cgmsg:ParseFromString(buffer)
	
	local checkMsg = RedisHelper.CheckRedis(cgmsg.userid,operateID)
	if checkMsg ~= nil then
		LogBehavior.Warning(cgmsg.userid, "wiring", "WiringAppointmentWithDraw", 0,"缓存已存在")
		return cgmsg.userid,0,string.len(checkMsg),checkMsg
	end	
	
	local pInfo = PlayerModel.GetPlayerInfo(cgmsg.userid)
	if pInfo == nil then
		LogBehavior.Error(cgmsg.userid,"wiring","WiringAppointmentWithDraw", ReturnCode["player_not_exist"], "该玩家不存在")
		gcmsg.result = ReturnCode["player_not_exist"]
		return cgmsg.userid, gcmsg.result, gcmsg:ByteSize(), gcmsg:SerializeToString()		
	end
	
	gcmsg.result = 0

	return cgmsg.userid, 0 , gcmsg:ByteSize(), gcmsg:SerializeToString()
end

