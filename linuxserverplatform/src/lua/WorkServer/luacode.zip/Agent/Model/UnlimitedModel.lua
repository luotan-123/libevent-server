

--无限代理

--1.自动排线功能。当玩家扫二维码后，会在后台产生一个记录，改记录表示排线的位置。如果这个用户5分钟内创建角色，
--那么，这个排线功能就会有效过，如果超过5分钟没有注册，那么，实际的位置，就会以最后注册拍的位置为准。


UnlimitedModel = {}
UnlimitedModel.redis_index = "redis_unlimited"

UnlimitedModel.wiring_info = "wiring_info_"    --存放wiring的信息
UnlimitedModel.wiring_curr = "wiring_curr"     --哈希表，保存用户自己所在的排线的ID，keys是userID，values是自己所在的wiringid，如果不在任何排线，那么就是0


UnlimitedModel.wiring_user_day_team_ach = "wiring_u_d_team_ach"  --这是一个哈希列表, 在一个排线中， 每个人的总业绩，后面加的是wiringid. field是userid，value是值。
UnlimitedModel.wiring_user_day_self_ach = "wiring_u_d_self_ach" --这是一个哈希列表，个人单自己玩的业绩。后面加的是userid，value是个人玩的业绩
UnlimitedModel.wiring_user_day_dir_ach = "wiring_u_d_dir_ach" --这是一个哈希列表，每个人的直属下级的收益。key是userid，value是直属业绩的总和

UnlimitedModel.wiring_user_day_not_dir = "wiring_u_d_not_dir"  --这是一个哈希列表, 在一个排线中， 每个人的总业绩，后面加的是wiringid. field是userid，value是值。


UnlimitedModel.wiring_userid_set = "wiring_u_zset_"     --对应的ID列表，这是一个有序集合，保存的是注册玩家的排位和userid
UnlimitedModel.wiring_user_wiringlist = "wiring_u_wlist_"   --列表，保存用户个人的排线ID，首先，需要坚持自己所在的排线，然后再检查自己的排线


UnlimitedModel.wiring_user_teamusernum = "wiring_user_tunum"     --哈希列表，个人团队中，自己的团人数，keys是userid,value是值


UnlimitedModel.Wiring_user_ratenum = "Wiring_user_ratenum"  --记录这里是否做了统计的变量


UnlimitedModel.Wiring_per_num = "wiring_prenum_"       --保存预分配的数量
UnlimitedModel.wiring_team_usernum = "wiring_team_usernum"     --哈希列表，个人团队中，自己的团人数，keys是userid,value是值

UnlimitedModel.Wiring_per_agent = "wiring_user_pre_agent"     --代理的上个agent


UnlimitedModel.wiring_day_count = "wiring_day_count"    --如果是正在计算佣金，那么就停止流水的更新

UnlimitedModel.wiring_day_mark_ach = "wiring_day_mark_ach"   --每日流水的计算
UnlimitedModel.wiring_day_mark_six = "wiring_day_mark_six"   --6级分销的计算


UnlimitedModel.wiring_new_teamusernum = "wiring_new_teamusernum_"   --保存每个新增

UnlimitedModel.wiring_active_teamusernum = "wiring_active_teamusernum_"   --保存每个新增

--创建排线，
--入参：userID，最大数量，排线名字
--出参:排线结构体:wInfo
function UnlimitedModel.CreateWiringInfo(userID, maxNum, name,wInfo)	
	local sqlCase = "insert into dy_unlimitedwiring(name,ownerid,maxnum,isexist) values('"..name.."',"..userID..","..maxNum..",1)"
	
	mysqlItem:execute(sqlCase)
	
	sqlCase = "select id from dy_unlimitedwiring where ownerid="..userID.." order by id desc limit 1"
	mysqlItem:executeQuery(sqlCase)

	local sqlData = mysqlItem:fetch()
	if sqlData == nil then
		wInfo.id = 0
		return wInfo
	end
	
	wInfo.id = tonumber(sqlData)
	wInfo.name = name
	wInfo.ownerid = tonumber(userID)
	wInfo.maxnum = maxNum
	wInfo.createdate = TimeUtils.GetDayString()
	wInfo.qrcodeurl = AgentModel.CreateWiringQrcode( userID, wInfo.id)
	
	redisItem:set(UnlimitedModel.wiring_info..wInfo.id, wInfo:SerializeToString(), UnlimitedModel.redis_index)
	
	redisItem:lpush( UnlimitedModel.wiring_user_wiringlist..userID, wInfo.id,  UnlimitedModel.redis_index)
	
	UnlimitedModel.AddUserIDToWiring(wInfo.id, userID, 1)   --创建者的ID是1.
	return wInfo
end



--通过用户ID，或者改用户最新的一个排线
function UnlimitedModel.GetWiringInfoByUserID(userID, wInfo)

	if wInfo == nil then
		wInfo = st_agent_pb.wiringinfo()
	end
	
	local currID = UnlimitedModel.GetUserCurrWiringID(userID)
	
	
	if currID == 0 then
		wInfo.id = 0 
		return wInfo
	end
	
	UnlimitedModel.GetWiringInfoByID(currID, wInfo)
end

--加载改用户的排线
function UnlimitedModel.LoadUserWiringList(userID)
	

	--首先，检查自己所在的排线
	local currID = 0
	local myAgent = AgentModel.GetAgentInfo(userID)
	
	currID = myAgent.wiringid

	local sqlCase = "select * from dy_unlimitedwiring where ownerid="..userID.." and isexist = 1 order by id desc"
	mysqlItem:executeQuery(sqlCase)
	
	
	local wiringIDList = {}
	
	while true do
		
		local sqlData = mysqlItem:fetch({})
		if sqlData == nil then
			break
		end
		

		local wInfo = st_agent_pb.wiringinfo()
		wInfo.id = tonumber(sqlData[1])
		wInfo.name = sqlData[2]
		wInfo.ownerid = tonumber(sqlData[3])
		wInfo.createdate = sqlData[4]
		wInfo.currnum = tonumber(sqlData[5])
		wInfo.maxnum = tonumber(sqlData[6])
		wInfo.usernum = tonumber(sqlData[7])
		wInfo.qrcodeurl = sqlData[8]
		
		redisItem:set(UnlimitedModel.wiring_info..wInfo.id, wInfo:SerializeToString(), UnlimitedModel.redis_index)
		
		redisItem:rpush(UnlimitedModel.wiring_user_wiringlist..userID, wInfo.id,  UnlimitedModel.redis_index)
		
		table.insert(wiringIDList, wInfo.id)   --把对应的ID保存下来
	end
	
	
	for k,v in ipairs(wiringIDList) do
				
		sqlCase = "select count(*) from ag_author where wiringid="..v
		mysqlItem:executeQuery(sqlCase)
		sqlData = mysqlItem:fetch()
		if sqlData ~= nil then
			redisItem:hset(UnlimitedModel.Wiring_per_num, v , tonumber(sqlData), UnlimitedModel.redis_index)
		end
		
		--这里还需要加载用户的排名信息
		
		sqlCase = "select userid,grade from ag_player where wiringid="..v.." and grade > 0"
		mysqlItem:executeQuery(sqlCase)
		while true do
			sqlData = mysqlItem:fetch({})
			if sqlData == nil then
				break
			end
			
			UnlimitedModel.AddUserIDToWiring(v, sqlData[1],sqlData[2])
		end
		
		
	end
	
	redisItem:hset(UnlimitedModel.wiring_curr, userID, currID, UnlimitedModel.redis_index)
	return currID
end

function UnlimitedModel.GetWiringInfoByID(wiringID, wInfo)
	if wInfo == nil then
		wInfo = st_agent_pb.wiringinfo()
	end

	local strGet = redisItem:get( UnlimitedModel.wiring_info..wiringID,  UnlimitedModel.redis_index)
	if strGet == nil then
		UnlimitedModel.LoadWiringInfoByID(wiringID, wInfo)
	else
		wInfo:ParseFromString(strGet)
	end
	return wInfo
end

function UnlimitedModel.LoadWiringInfoByID(wiringID, wInfo)
	if wInfo == nil then
		wInfo = st_agent_pb.wiringinfo()
	end

	local sqlCase = "select * from dy_unlimitedwiring where id="..wiringID.." and isexist=1"
	mysqlItem:executeQuery(sqlCase)
	
	local sqlData = mysqlItem:fetch({})
	if sqlData == nil then
		wInfo.id = 0
		return wInfo
	end
	wInfo.id = tonumber(sqlData[1])
	wInfo.name = sqlData[2]
	wInfo.ownerid = tonumber(sqlData[3])
	wInfo.createdate = sqlData[4]
	wInfo.currnum = tonumber(sqlData[5])
	wInfo.maxnum = tonumber(sqlData[6])
	wInfo.usernum = tonumber(sqlData[7])
	wInfo.qrcodeurl = sqlData[8]
	
	redisItem:set(UnlimitedModel.wiring_info..wInfo.id, wInfo:SerializeToString(), UnlimitedModel.redis_index)	
	
	
	
	sqlCase = "select userid,grade from ag_player where wiringid="..wiringID.." and grade > 0"
	mysqlItem:executeQuery(sqlCase)
	local countNum = 0
	while true do
		sqlData = mysqlItem:fetch({})
		if sqlData == nil then
			break
		end
		
		UnlimitedModel.AddUserIDToWiring(wiringID, sqlData[1],sqlData[2])
	end	
	UnlimitedModel.AddUserIDToWiring(wiringID, wInfo.ownerid, 1)
	return wInfo
end


--获取这个人的团队总数,包含裂变的数据
function UnlimitedModel.GetUserTeamUserNum(userID)

	
	--这里去查数据库
	local retNum = redisItem:hget(UnlimitedModel.wiring_user_teamusernum, userID, UnlimitedModel.redis_index)
	
	if retNum == nil then
		local sqlCase = "select teamusernum from log_player where userid="..userID
		mysqlLog:executeQuery(sqlCase)
		retNum = mysqlLog:fetch()	
		retNum = retNum == nil and 0 or retNum
		redisItem:hincrby(UnlimitedModel.wiring_user_teamusernum, userID , retNum, UnlimitedModel.redis_index)		
	end

	return tonumber(retNum)
end



function UnlimitedModel.GetWiringIDList(userID)
	
	local currID = UnlimitedModel.GetUserCurrWiringID(userID)

	--if tonumber(currID) == 0 then
	--	return {}
	--end
	return redisItem:lrange( UnlimitedModel.wiring_user_wiringlist..userID, 0, 99999,  UnlimitedModel.redis_index)
end

function UnlimitedModel.GetUserCurrWiringID(userID)
	local currID = redisItem:hget(UnlimitedModel.wiring_curr, userID, UnlimitedModel.redis_index)
	if currID == nil then
		UnlimitedModel.LoadUserWiringList(userID)
		currID = redisItem:hget(UnlimitedModel.wiring_curr, userID, UnlimitedModel.redis_index)
	end	
	return tonumber(currID)
end


function UnlimitedModel.AddUserIDToWiring(wiringID, userID, grade)
	
	redisItem:zadd(UnlimitedModel.wiring_userid_set..wiringID, tonumber(grade), tonumber(userID), UnlimitedModel.redis_index)
	
end

--设置上一级代理的ID
function UnlimitedModel.SetUserPreAgentID(userID, agent1)
	redisItem:hset(UnlimitedModel.Wiring_per_agent, userID, agent1, UnlimitedModel.redis_index)
end

--获取上一级代理的userid
function UnlimitedModel.GetUserPreAgentID(userID)
	
	local preAgentID = redisItem:hget(UnlimitedModel.Wiring_per_agent, userID, UnlimitedModel.redis_index)
	
	if preAgentID == nil then
		local sqlCase = "select agent1 from ag_player where userid="..userID
		mysqlItem:executeQuery(sqlCase)
		preAgentID = mysqlItem:fetch()
		preAgentID = preAgentID == nil and 0 or preAgentID
		
		redisItem:hset( UnlimitedModel.Wiring_per_agent, userID, preAgentID ,UnlimitedModel.redis_index)
	end
	return tonumber(preAgentID)
end

function UnlimitedModel.IncrUserTeamAch(userID, achNum, isDir, dayStr)
	--把每个人的业绩加入到玩家的日业绩和周业绩中
	redisItem:hincrby( UnlimitedModel.wiring_user_day_team_ach..dayStr, userID, achNum,  UnlimitedModel.redis_index)
	
	if isDir == false then
		redisItem:hincrby( UnlimitedModel.wiring_user_day_not_dir..dayStr, userID, achNum,  UnlimitedModel.redis_index)		
	end
	
end

function UnlimitedModel.GetUserTeamDayAch(userID, dayStr)

	local retNum = redisItem:hget( UnlimitedModel.wiring_user_day_team_ach..dayStr, userID, UnlimitedModel.redis_index )
	if retNum == nil then
		local sqlCase = "select achteamamount from log_playerdaily where userid="..userID.." and dateid='"..dayStr.."'"
		mysqlLog:executeQuery(sqlCase)
		retNum = mysqlLog:fetch()
		retNum = retNum == nil and 0 or tonumber(retNum)
		redisItem:hset( UnlimitedModel.wiring_user_day_team_ach..dayStr, userID, retNum,  UnlimitedModel.redis_index)
	end
	return tonumber(retNum)
	
end

function UnlimitedModel.IncrUserDirAch(userID, achNum, dayStr)
	redisItem:hincrby( UnlimitedModel.wiring_user_day_dir_ach..dayStr, userID, achNum, UnlimitedModel.redis_index)
	
end


function UnlimitedModel.GetUserDayDirAch(userID, dayStr)
	local retNum = redisItem:hget( UnlimitedModel.wiring_user_day_dir_ach..dayStr, userID, UnlimitedModel.redis_index )
	if retNum == nil then
		local sqlCase = "select achteamdiramount from log_playerdaily where userid="..userID.." and dateid='"..dayStr.."'"
		mysqlLog:executeQuery(sqlCase)
		retNum = mysqlLog:fetch()
		retNum = retNum == nil and 0 or tonumber(retNum)
		redisItem:hset( UnlimitedModel.wiring_user_day_dir_ach..dayStr, userID, retNum,  UnlimitedModel.redis_index)		
		retNum = 0
	end
	return tonumber(retNum)
end




function UnlimitedModel.IncrUserSelfAch(userID, achNum)
	redisItem:hincrby( UnlimitedModel.wiring_user_day_self_ach, userID, achNum, UnlimitedModel.redis_index)
end


function UnlimitedModel.GetUserRateNum(userID, channel)

	local ratenum = 0
	
	--[[if channel then
		
		local weekStr = TimeUtils.GetWeekString()
		
		-- 查询本周，团队流水和个人流水
		local allach = 0
		local sqlCase = "select achamount,achteamamount from log_playerweek where userid="..userID.." and dateid='"..weekStr.."'"
		mysqlLog:executeQuery(sqlCase)
		local sqlData = mysqlLog:fetch({})
		if sqlData ~= nil then
			allach = tonumber(sqlData[1]) + tonumber(sqlData[2])
		end
	
		ratenum = AgentAward.GetTeamAchAward(channel, allach);
		
	end--]]

	local retNum = redisItem:hget( UnlimitedModel.Wiring_user_ratenum, userID, UnlimitedModel.redis_index )
	if retNum == nil then
		local sqlCase = "select getrate from ag_player where userid="..userID
		mysqlItem:executeQuery(sqlCase)
		retNum = mysqlItem:fetch()
		retNum = retNum == nil and 0 or tonumber(retNum)
		redisItem:hset( UnlimitedModel.Wiring_user_ratenum, userID, retNum,  UnlimitedModel.redis_index)
	end
	
	return ratenum >= tonumber(retNum) and ratenum or tonumber(retNum)
end


function UnlimitedModel.IsMarkDayAch(userID,nickName)
	
	
	
	local rdsKey = UnlimitedModel.wiring_day_mark_ach..userID..TimeUtils.GetDayString()
	
	if true == redisItem:exists( rdsKey, UnlimitedModel.redis_index ) then
		return true
	end
	
	local sqlCase = "select id from log_unlimiteddayaward where userid="..userID.." and datestr='"..TimeUtils.GetDayString().."'"
	mysqlLog:executeQuery(sqlCase)
	local sqlData = mysqlLog:fetch()
	
	if sqlData ~= nil then
		redisItem:setex( rdsKey, g_daySeconds*3 , userID,   UnlimitedModel.redis_index)
		return true
	end	
	
	nickName = nickName == nil and '' or nickName
	sqlCase = "insert log_unlimiteddayaward(userid,nickname,datestr) values("..userID..",'"..nickName.."','"..TimeUtils.GetDayString().."')"
	mysqlLog:execute(sqlCase)
	
	sqlCase = "select id from log_unlimiteddayaward where userid="..userID.." and datestr='"..TimeUtils.GetDayString().."'"
	mysqlLog:executeQuery(sqlCase)
	local sqlData = mysqlLog:fetch()
	
	if sqlData == nil then
		LogFile("error", "UnlimitedModel.IsMarkDayAch="..rdsKey)
		return false
	end
	
	redisItem:setex( rdsKey, g_daySeconds*3 , userID,   UnlimitedModel.redis_index)
	
	return true
	
end


function UnlimitedModel.IsMarkDaySix(userID)
	
	
	local rdsKey = UnlimitedModel.wiring_day_mark_six..userID..TimeUtils.GetDayString()
	
	if true == redisItem:exists( rdsKey, UnlimitedModel.redis_index ) then
		return true
	end
	
	local sqlCase = "select id from log_daylevelaward where userid="..userID.." and datestr='"..TimeUtils.GetDayString().."'"
	mysqlLog:executeQuery(sqlCase)
	local sqlData = mysqlLog:fetch()
	
	if sqlData ~= nil then
		LogFile("error", "UnlimitedModel.IsMarkDayAch="..rdsKey)
		redisItem:setex( rdsKey, g_daySeconds*3 , userID,   UnlimitedModel.redis_index)
		return true
	end	

	
	
	nickName = nickName == nil and '' or nickName
	sqlCase = "insert log_daylevelaward(userid,datestr) values("..userID..",'"..TimeUtils.GetDayString().."')"
	mysqlLog:execute(sqlCase)
	
	sqlCase = "select id from log_daylevelaward where userid="..userID.." and datestr='"..TimeUtils.GetDayString().."'"
	mysqlLog:executeQuery(sqlCase)
	local sqlData = mysqlLog:fetch()
	
	if sqlData == nil then
		LogFile("error", "UnlimitedModel.IsMarkDayAch="..rdsKey)
		return false
	end
	
	redisItem:setex( rdsKey, g_daySeconds*3 , userID,   UnlimitedModel.redis_index)
	
	return true
	
end

function UnlimitedModel.GetUserNewTeamUserNum(userID, dayStr)  --获取玩家的新增
	
	local redisKey = UnlimitedModel.wiring_new_teamusernum..dayStr
	if false == redisItem:hexists(redisKey, userID, UnlimitedModel.redis_index) then
		
		
		local sqlCase = "select newuserday,activityday,achteamamount from log_playerdaily where userid="..userID.." and dateid='"..dayStr.."'"	
		mysqlLog:executeQuery(sqlCase)
		local sqlData = mysqlLog:fetch({})
		if sqlData ~= nil then
			redisItem:hset( redisKey, userID, tonumber(sqlData[1]), UnlimitedModel.redis_index )
			redisItem:hset( UnlimitedModel.wiring_active_teamusernum..dayStr,userID, tonumber(sqlData[2]), UnlimitedModel.redis_index )
		else
			redisItem:hset( redisKey, userID, 0, UnlimitedModel.redis_index )
			redisItem:hset( UnlimitedModel.wiring_active_teamusernum, userID, 0, UnlimitedModel.redis_index )			
		end
	end
	
	return tonumber(redisItem:hget( redisKey, userID, UnlimitedModel.redis_index ))
end

function UnlimitedModel.IncrUserNewTeamUserNum(userID, dayStr)  --获取玩家的新增
	
	local redisKey = UnlimitedModel.wiring_new_teamusernum..dayStr
	if false == redisItem:hexists(redisKey, userID, UnlimitedModel.redis_index) then
		

		local sqlCase = "select newuserday,activityday,achteamamount from log_playerdaily where userid="..userID.." and dateid='"..dayStr.."'"	
		mysqlLog:executeQuery(sqlCase)
		local sqlData = mysqlLog:fetch({})
		if sqlData ~= nil then
			redisItem:hset( redisKey, userID, tonumber(sqlData[1]), UnlimitedModel.redis_index )
			redisItem:hset( UnlimitedModel.wiring_active_teamusernum..dayStr,userID, tonumber(sqlData[2]), UnlimitedModel.redis_index )
		else
			redisItem:hset( redisKey, userID, 0, UnlimitedModel.redis_index )
			redisItem:hset( UnlimitedModel.wiring_active_teamusernum, userID, 0, UnlimitedModel.redis_index )			
		end
	end
	
	redisItem:hincrby( redisKey, userID, 1, UnlimitedModel.redis_index )
end


function UnlimitedModel.GetUserActiveTeamUserNum(userID, dayStr)  --获取玩家的新增
	
	local redisKey = UnlimitedModel.wiring_active_teamusernum..dayStr
	if false == redisItem:hexists(redisKey, userID, UnlimitedModel.redis_index) then
		

		local sqlCase = "select newuserday,activityday,achteamamount from log_playerdaily where userid="..userID.." and dateid='"..dayStr.."'"	
		mysqlLog:executeQuery(sqlCase)
		local sqlData = mysqlLog:fetch({})
		if sqlData ~= nil then
			redisItem:hset( redisKey, userID, tonumber(sqlData[1]), UnlimitedModel.redis_index )
			redisItem:hset( UnlimitedModel.wiring_new_teamusernum..dayStr,userID, tonumber(sqlData[2]), UnlimitedModel.redis_index )
		else
			redisItem:hset( redisKey, userID, 0, UnlimitedModel.redis_index )
			redisItem:hset( UnlimitedModel.wiring_new_teamusernum, userID, 0, UnlimitedModel.redis_index )			
		end
	end
	
	return tonumber(redisItem:hget( redisKey, userID, UnlimitedModel.redis_index ))
end

function UnlimitedModel.IncrUserActiveTeamUserNum(userID, dayStr)  --获取玩家的新增
	
	local redisKey = UnlimitedModel.wiring_active_teamusernum..dayStr
	if false == redisItem:hexists(redisKey, userID, UnlimitedModel.redis_index) then
		UnlimitedModel.GetUserActiveTeamUserNum(userID, dayStr)
	end
	
	redisItem:hincrby( redisKey, userID, 1, UnlimitedModel.redis_index )
end

-- 三级代理，获取本周，某个玩家的下级，对它上级代理的贡献
function UnlimitedModel.GetUserTeamWeekPump(userID, weekStr)
	-- 查询 log_playerweek表获得数据
	local sqlCase = "select teampumpamount from log_playerweek where userid="..userID.." and ".."dateid='"..weekStr.."'"
	mysqlLog:executeQuery(sqlCase)
	local sqlData = mysqlLog:fetch({})
	local teamNum = 0;
	if sqlData ~= nil then
		teamNum = tonumber(sqlData[1]);
	end
	
	return teamNum;
end

-- 三级代理，获取本周，某个玩家对它上级代理的贡献
function UnlimitedModel.GetUserDirWeekPump(userID, weekStr)
	-- 查询 log_playerweek表获得数据
	local sqlCase = "select dirpumpamount from log_playerweek where userid="..userID.." and ".."dateid='"..weekStr.."'"
	mysqlLog:executeQuery(sqlCase)
	local sqlData = mysqlLog:fetch({})
	local dirNum = 0;
	if sqlData ~= nil then
		dirNum = tonumber(sqlData[1]);
	end
	
	return dirNum;
end
