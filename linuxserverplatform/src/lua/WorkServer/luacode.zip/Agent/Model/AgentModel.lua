
AgentModel = {}
AgentModel.redis_index = "redis_agent"

AgentModel.agent_info = "agent_"
AgentModel.agent_commission = "agent_commission"

AgentModel.agent_daymark = "agent_daymark"     --用于标记抽佣分成的时间，每天只统计一遍。

AgentModel.agent_ratio = "agent_ratio"
AgentModel.agent_achievement = "agent_achievement"   --用于保存每个玩家的流水

AgentModel.agent_player_fee = "agent_player_fee"   --抽水列表，哈希列表，keys是 userid，values是值 代理中，玩家抽水的统计
AgentModel.agent_player_pour = "agent_player_pour"  --下注列表，哈希列表，keys是 userid，values是值 
AgentModel.agent_player_win = "agent_player_win"    --赢钱列表，哈希列表，keys是 userid，values是值 
AgentModel.agent_shui_shou = "agent_shui_shou"   --税收列表(流水*5%/2)，哈希列表，keys是 userid，values是值 代理中，玩家抽水的统计
AgentModel.agent_zhanji = "agent_zhanji"   --战绩统计，只统计赢，不统计输，哈希列表，keys是 userid，values是值 代理中，玩家抽水的统计
AgentModel.agent_changci = "agent_changci"   --场次统计

AgentModel.agent_sys_commission = "agent_sys_commission"  --系统的佣金总额


AgentModel.agent_user_pre = "agent_user_pre_"   --保存玩家的下级列表


AgentModel.count_expert_rate = "count_expert_rate"


AgentModel.agent_game_achievement = "agent_game_achievement"   --游戏系统流水

function AgentModel.GetAgentInfo(userID, agyInfo)
	if userID == nil or userID == 0 then
		return nil
	end

	--获取代理的信息
	if agyInfo == nil then
		agyInfo = st_agent_pb.agentinfo()
	end
	local strGet = redisItem:get(AgentModel.agent_info..userID, AgentModel.redis_index)

	if strGet ~= nil then
		agyInfo:ParseFromString(strGet)
		agyInfo.qrcodeurl = AgentModel.GetQrcodeUrl(userID)
		agyInfo.exclusiveurl = AgentModel.GetQrcodeUrl(userID)

		return agyInfo
	else
		
		return AgentModel.LoadAgentInfo(userID,agyInfo)
	end
end

function AgentModel.SetAgent(userID, agyInfo)
	redisItem:set(AgentModel.agent_info..userID, agyInfo:SerializeToString(), AgentModel.redis_index)
end

function AgentModel.LoadAgentInfo(userID,agyInfo)
	

	if agyInfo == nil then
		agyInfo = st_agent_pb.agentinfo()
	end

	local sqlCase = "select * from ag_player where userid="..userID
	mysqlItem:executeQuery(sqlCase)
	local sqlData = mysqlItem:fetch({})
	
	if sqlData ~= nil then

		agyInfo.invitestr = sqlData[9]
		agyInfo.level = tonumber(sqlData[14])
		agyInfo.soleagent = tonumber(sqlData[19])
		agyInfo.agent1 = tonumber(sqlData[20])
		agyInfo.agent2 = tonumber(sqlData[21])
		agyInfo.agent3 = tonumber(sqlData[22])
		agyInfo.agent4 = tonumber(sqlData[23])
		agyInfo.qrcodeurl = AgentModel.GetQrcodeUrl(userID)
		agyInfo.datemark = sqlData[25]
		agyInfo.moneymark = tonumber(sqlData[26])
		agyInfo.weekmoney = tonumber(sqlData[18])
		agyInfo.alipay = sqlData[33]
		agyInfo.bankaccount = sqlData[27]
		agyInfo.exclusiveurl = AgentModel.GetQrcodeUrl(userID)
		
		agyInfo.grade = tonumber(sqlData[37])
		agyInfo.wiringid = tonumber(sqlData[38])
		agyInfo.userid  = tonumber(userID)

	else

		local pInfo = PlayerModel.GetPlayerInfo(userID)
		
		if pInfo ~= nil then
			agyInfo.userid = tonumber(userID)
			agyInfo.invitestr = tostring(userID)
			agyInfo.level = 91
			agyInfo.qrcodeurl = AgentModel.GetQrcodeUrl(userID)
			agyInfo.exclusiveurl = AgentModel.GetQrcodeUrl(userID)
			agyInfo.soleagent = 0
			agyInfo.agent1 = 0
			agyInfo.agent2 = 0
			agyInfo.agent3 = 0
			agyInfo.agent4 = 0
			agyInfo.grade = -1
			agyInfo.wiringid = 0
			AgentModel.InsertAgent(pInfo, agyInfo)
		else
			LogFile("error", "PlayerModel.GetPlayerInfo="..userID)
		end
	end
	redisItem:set(AgentModel.agent_info..userID, agyInfo:SerializeToString(), AgentModel.redis_index)
	return agyInfo
end

--付费的ID，付费的金额

function AgentModel.InsertAgent(pInfo, myAgent)
	
	local bigChannel = GameUtils.GetChannel_login(pInfo.channel)
	local sqlCase = "insert into ag_player(userid,nickname,account,expandcode,state,level,soleagent,agent1,agent2,agent3,agent4,qrcodeurl,grade,wiringid,channel,prechannel) values("
		..pInfo.userid..",'"..pInfo.nickname.."','"..pInfo.userid.."','"..pInfo.userid.."',0,"..myAgent.level..","..myAgent.soleagent..","
		..myAgent.agent1..","..myAgent.agent2..","..myAgent.agent3..","..myAgent.agent4..",'"..myAgent.qrcodeurl.."',"..myAgent.grade..","..myAgent.wiringid..",'"..pInfo.channel.."','"..bigChannel.."')" 
	
	mysqlItem:execute(sqlCase)
end



function AgentModel.Exclusiveurl(userID)
	--根据不同的服务器，配置不同的二维吗分享
	
	return g_webUrl.."/Public/share/"..g_gamename..".html?bindcode="..userID.."&platfromid="..g_gamename
end


function AgentModel.CreateWiringQrcode(userID, wiringID)
	if g_gamename == "uudwc" then
		return g_webUrl.."/index.php/dwcgame/client/uudwcauthor?userid="..userID.."&wiringid="..wiringID
	else
		return g_webUrl.."/index.php/"..g_gamename.."/client/wechatauthor?userid="..userID.."&wiringid="..wiringID
	end
end

function AgentModel.GetQrcodeUrl(userID)
	
	
	if g_gamename == "uudwc" then
		return g_webUrl.."?userid="..userID
	else
		return g_webUrl.."?userid="..userID
	end
	
end


--feeall ：收税总额
--pourAll：下注总额：在斗地主中，抢庄牛牛，拼三张中，是真是玩家投到桌子上的金币数
--winAll:系统赢玩家的钱
--gameType:游戏类型
--tableType：牌桌类型
function AgentModel.GameDataCommit(feeall, pourAll, winAll, gameType, tableType)
	
	if feeall == 0 and pourAll == 0 and winAll == 0 then
		return 
	end
	
--[[	local tmpsql = "" 
	if gameType == g_DdzDefine.game_type then 	--斗地主
		tmpsql = tmpsql.."doudizhu=doudizhu+"..feeall..", ach_doudizhu=ach_doudizhu+"..pourAll..", win_doudizhu=win_doudizhu+"..winAll
	elseif gameType == g_lhdDefine.game_type then	--龙虎斗
		tmpsql = tmpsql.."longhuddou=longhuddou+"..feeall..", ach_longhudou=ach_longhudou+"..pourAll..", win_longhudou=win_longhudou+"..winAll
	elseif gameType == g_hongheiDefine.game_type then --红黑大战
		tmpsql = tmpsql.."honghei=honghei+"..feeall..", ach_honghei=ach_honghei+"..pourAll..", win_honghei=win_honghei+"..winAll
	elseif gameType == g_barccatatDefine.game_type then	--百家乐
		tmpsql = tmpsql.."baijiale=baijiale+"..feeall..", ach_baijiale=ach_baijiale+"..pourAll..", win_baijiale=win_baijiale+"..winAll
	elseif gameType == g_douNiuDefine.game_type then	--抢庄牛牛
		tmpsql = tmpsql.."qiangzhuangniuniu=qiangzhuangniuniu+"..feeall..", ach_qiangzhuangniuniu=ach_qiangzhuangniuniu+"..pourAll..", win_qiangzhuangniuniu=win_qiangzhuangniuniu+"..winAll
	elseif gameType == g_brnnDefine.game_type then		--百人牛牛
		tmpsql = tmpsql.."bairenniuniu=bairenniuniu+"..feeall..", ach_bairenniuniu=ach_bairenniuniu+"..pourAll..", win_bairenniuniu=win_bairenniuniu+"..winAll
	elseif gameType == g_PszDefine.game_type then		--扎金花
		tmpsql = tmpsql.."zhajinhua=zhajinhua+"..feeall..", ach_zhajinhua=ach_zhajinhua+"..pourAll..", win_zhajinhua=win_zhajinhua+"..winAll
	elseif gameType == g_bcbmDefine.game_type then		--奔驰宝马
		tmpsql = tmpsql.."benchibaoma=benchibaoma+"..feeall..", ach_beichibaoma=ach_beichibaoma+"..pourAll..", win_beichibaoma=win_beichibaoma+"..winAll
	elseif gameType == g_fqzsDefine.game_type then		--狮子王国
		tmpsql = tmpsql.."shiziwanghuo=shiziwanghuo+"..feeall..", ach_shiziwangguo=ach_shiziwangguo+"..pourAll..", win_shiziwangguo=win_shiziwangguo+"..winAll
	elseif gameType == g_sicboDefine.game_type  then	--骰宝
		tmpsql = tmpsql.."toubao=toubao+"..feeall..", ach_toubao=ach_toubao+"..pourAll..", win_toubao=win_toubao+"..winAll
	end
	
	
	local strDay = TimeUtils.GetDayString()
	
	local moneyIn = 0
	local moneyOut = feeall
	if winAll > 0 then
		--系统赢钱，钱流走
		moneyOut = winAll + feeall
	else
		--系统输钱，钱流入
		moneyIn = 0 - winAll
	end
	
	--local sqlCase = "update log_gameday set moneyout=moneyout-"..moneyOut..", allfee=allfee+"..feeall..", allach=allach+"..pourAll..", allwin=allwin+"..winAll..", "..tmpsql.." where datestr='"..strDay.."'"
	
	--LogModel.LogGameDetail(sqlCase)

	
	local sqlCase = "update log_syschannel set feeamount=feeamount+"..feeall..",syswinamount=syswinamount+"..winAll.." where id>0 and channel='"..g_channelname.."'"
	LogModel.LogSysdailyPush(sqlCase)
	
	sqlCase = "update log_sysdaily set feeamount=feeamount+"..feeall..",syswinamount=syswinamount+"..winAll.." where id>0 and dateid='"..TimeUtils.GetDayString().."' and channel='"..g_channelname.."'"
	LogModel.LogSysdailyPush(sqlCase)	


	sqlCase = "update log_sysweek set feeamount=feeamount+"..feeall..",syswinamount=syswinamount+"..winAll.." where id>0 and dateid='"..TimeUtils.GetWeekString().."' and channel='"..g_channelname.."'"
	LogModel.LogSysdailyPush(sqlCase)	

	sqlCase = "update log_sysmonth set feeamount=feeamount+"..feeall..",syswinamount=syswinamount+"..winAll.." where id>0 and dateid='"..TimeUtils.GetMonthString().."' and channel='"..g_channelname.."'"
	LogModel.LogSysdailyPush(sqlCase)
	--]]
end


-- 统计抽水
function AgentModel.CommissionCount(userid, commission)
	
	commission = math.floor(commission) 
	
	if RobotService.IsRobot(userid) == false and userid > 1 and commission ~= 0 then
		
		redisItem:hincrby(AgentModel.agent_player_fee,userid,commission,AgentModel.redis_index)
	end
	
end


-- 统计战绩
function AgentModel.UserWinCount(userid, Count)
	
	Count = math.floor(Count)
	
	if RobotService.IsRobot(userid) == false and userid > 1 and Count ~= 0 then
		
		redisItem:hincrby(AgentModel.agent_zhanji, userid, Count, AgentModel.redis_index)
	end
	
end


--统计玩家的流水,游戏这边流水和赛事系统分开计算 （赛事系统流水就是投注量）
function AgentModel.AchievementCount(userid, Count)
	
	Count = math.floor(Count)
	
	if RobotService.IsRobot(userid) == false and userid > 1 and Count ~= 0 then
		
		redisItem:hincrby(AgentModel.agent_achievement, userid, Count, AgentModel.redis_index)
	end
	
end



--统计平均赔率
function AgentModel.CountAveRate(userid, planrebateRatio, channel)
	local pInfo = PlayerModel.GetPlayerInfo(userid)
	if pInfo == nil then
		return
	end
	
	--生成sql语句
	local dayStr = TimeUtils.GetDayString()
	local weekStr = TimeUtils.GetWeekString()
	local monthStr = TimeUtils.GetMonthString()	
	
	LogDBCheck.CheckPlayerDaily(userid, dayStr, channel)
	
	-- 统计专家跟投订单数量
	local sqlCase = "update log_player set palnordercount=palnordercount+1 where userid="..userid
	LogModel.LoglogOneMin(sqlCase)

	sqlCase = "update log_playerdaily set palnordercount=palnordercount+1 where userid="..userid.." and dateid='"..dayStr.."'"
	LogModel.LoglogOneMin(sqlCase)
	
	sqlCase = "update log_playerweek set palnordercount=palnordercount+1 where userid="..userid.." and dateid='"..weekStr.."'"
	LogModel.LoglogOneMin(sqlCase)
	
	sqlCase = "update log_playermonth set palnordercount=palnordercount+1 where userid="..userid.." and dateid='"..monthStr.."'"
	LogModel.LoglogOneMin(sqlCase)
	
	
	-- 统计专家赔率
	sqlCase = "update log_player set planrebateRatio=planrebateRatio+"..planrebateRatio.." where userid="..userid
	LogModel.LoglogOneMin(sqlCase)
	
	sqlCase = "update log_playerdaily set planrebateRatio=planrebateRatio+"..planrebateRatio.." where userid="..userid.." and dateid='"..dayStr.."'"
	LogModel.LoglogOneMin(sqlCase)
	
	sqlCase = "update log_playerweek set planrebateRatio=planrebateRatio+"..planrebateRatio.." where userid="..userid.." and dateid='"..weekStr.."'"
	LogModel.LoglogOneMin(sqlCase)
	
	sqlCase = "update log_playermonth set planrebateRatio=planrebateRatio+"..planrebateRatio.." where userid="..userid.." and dateid='"..monthStr.."'"
	LogModel.LoglogOneMin(sqlCase)
	
	redisItem:sadd(AgentModel.count_expert_rate, userid, AgentModel.redis_index)
end



-- 统计场次
function AgentModel.PlayCount(userid, raceid)
	
	local field = userid.."|"..raceid
	
	if redisItem:hexists(AgentModel.agent_changci, field, AgentModel.redis_index) then
		return
	end
	
	redisItem:hset(AgentModel.agent_changci, field, 1, AgentModel.redis_index)
	
	--生成sql语句
	local dayStr = TimeUtils.GetDayString()
	local weekStr = TimeUtils.GetWeekString()
	local monthStr = TimeUtils.GetMonthString()	
	
	
	local sqlCase = "update log_player set playcount=playcount+1 where userid="..userid
	LogModel.LoglogOneMin(sqlCase)

	sqlCase = "update log_playerdaily set playcount=playcount+1 where userid="..userid.." and dateid='"..dayStr.."'"
	LogModel.LoglogOneMin(sqlCase)
	
	sqlCase = "update log_playerweek set playcount=playcount+1 where userid="..userid.." and dateid='"..weekStr.."'"
	LogModel.LoglogOneMin(sqlCase)
	
	sqlCase = "update log_playermonth set playcount=playcount+1 where userid="..userid.." and dateid='"..monthStr.."'"
	LogModel.LoglogOneMin(sqlCase)

end


-- 统计订单数量
function AgentModel.OrderCount(userid, channel)
	
	--生成sql语句
	local dayStr = TimeUtils.GetDayString()
	local weekStr = TimeUtils.GetWeekString()
	local monthStr = TimeUtils.GetMonthString()	
	
	LogDBCheck.CheckPlayerDaily(userid, dayStr, channel)
	
	local sqlCase = "update log_player set ordercount=ordercount+1 where userid="..userid
	LogModel.LoglogOneMin(sqlCase)

	sqlCase = "update log_playerdaily set ordercount=ordercount+1 where userid="..userid.." and dateid='"..dayStr.."'"
	LogModel.LoglogOneMin(sqlCase)
	
	sqlCase = "update log_playerweek set ordercount=ordercount+1 where userid="..userid.." and dateid='"..weekStr.."'"
	LogModel.LoglogOneMin(sqlCase)
	
	sqlCase = "update log_playermonth set ordercount=ordercount+1 where userid="..userid.." and dateid='"..monthStr.."'"
	LogModel.LoglogOneMin(sqlCase)

end



-- 删除统计场次相关临时数据
function AgentModel.DelPlayCountData()
	
	redisItem:del(AgentModel.agent_changci, AgentModel.redis_index)
end

function AgentModel.getGameCommissionRatio(gameType, tableType)
	return g_Ratio
	--local ratio = redisItem:hget(AgentModel.agent_ratio, gameType..tableType, AgentModel.redis_index)
	--return ratio == nil and AgentModel.LoadGameCommissionRatio( gameType, tableType ) or tonumber(ratio)
end


function AgentModel.LoadGameCommissionRatio(gameType, tableType)
	local sqlCase = "select feerate from dy_gamelist where gametype="..gameType.." and tabletype="..tableType
	mysqlItem:executeQuery(sqlCase)

	local ratio = mysqlItem:fetch()
	
	ratio = ratio == nil and 7 or tonumber(ratio)
	ratio = ratio/100
	redisItem:hset(AgentModel.agent_ratio, gameType..tableType, ratio, AgentModel.redis_index)
	return ratio
end


function AgentModel.StatisticsCommission(userid, commission)
	redisItem:hincrby(AgentModel.agent_commission, userid, commission,AgentModel.redis_index)
end

function AgentModel.GetUserCommission()
	return redisItem:hgetall(AgentModel.agent_commission, AgentModel.redis_index)
end


function AgentModel.SetAgentDaymark(dateSec)
	redisItem:set( AgentModel.agent_daymark, dateSec, AgentModel.redis_index)
end

function AgentModel.GetAgentDaymark()
	redisItem:get( AgentModel.agent_daymark, AgentModel.redis_index )
end


function AgentModel.DayFirstLogin(userID)

	--processWork("UnlimitedIncrUserActivity", userID)
	
end



function AgentModel.CheckIsWiringBind(pInfo, unionID)
	
	
	--在每个玩家创建角色的时候，检查是否绑定代理了。
	local wiringID = 0
	local toAgencyUserID = 0
	
	LogFile("agent","unionID="..unionID)

		if unionID == nil or unionID == '' then
			return nil
		end
		local sqlCase = "select id,binduserid,wiringid from ag_author where unionid='"..unionID.."' order by id desc limit 1"
		
		LogFile("agent","sqlCase="..sqlCase)
		mysqlItem:executeQuery(sqlCase)
		local sqlData = mysqlItem:fetch({})

		if sqlData == nil then
			return nil
		end	
		LogFile("agent","sqlData="..luajson.encode( sqlData ))
		local wiringID =  sqlData[3] == nil and 0 or tonumber(sqlData[3])
		
		local toAgencyUserID = sqlData[2] == nil and 0 or tonumber(sqlData[2])
		LogFile("agent","toAgencyUserID="..toAgencyUserID)
		if toAgencyUserID == 0 then
			return
		end
		
	local toAgency = AgentModel.GetAgentInfo(toAgencyUserID)

	
	if toAgency == nil or toAgency.userid == 0 then
		return
	end

	
	local myAgent = st_agent_pb.agentinfo()
	local grade = wiringID > 0 and 0 or -1
	myAgent.qrcodeurl = AgentModel.GetQrcodeUrl(pInfo.userid)
	myAgent.invitestr = tostring(pInfo.userid)
	myAgent.userid = pInfo.userid
	myAgent.level = 91
	myAgent.wiringid = wiringID
	myAgent.grade = grade
	
	if wiringID == 0 then
		--如果排线ID为0，那么就说明这个兄弟扫的是直属玩家
		
	
		myAgent.soleagent = toAgency.level > 98 and toAgency.userid or toAgency.soleagent
		myAgent.agent1 = toAgency.userid
		myAgent.agent2 = toAgency.agent1
		myAgent.agent3 = toAgency.agent2
		myAgent.agent4 = toAgency.agent3
		myAgent.wiringid = 0 --toAgency.wiringid   --这里如果传入的排线ID是0，那么这里也应该是0,直属的玩家

	end	

	
	AgentModel.InsertAgent(pInfo, myAgent)
	
	local isPaixian = 0
	if wiringID ~= 0 then
		--如果排线ID不为0，那么这里留需要找到他的上级了。
		local sqlCase = "select count(userid) from ag_player where wiringid="..wiringID.." and userid<"..pInfo.userid.." and grade >= 0" 
		mysqlItem:executeQuery(sqlCase)
		grade = mysqlItem:fetch()
		
		sqlCase = "select userid from ag_player where wiringid="..wiringID.." and userid<"..pInfo.userid.." and grade >=0 order by userid desc limit 1"
		mysqlItem:executeQuery(sqlCase)
		
		local agent1 = mysqlItem:fetch()
		
		grade = grade ==  nil and  1 or (tonumber(grade) + 1)
		agent1 = agent1 == nil and sqlData[2] or agent1

		sqlCase = "update ag_player set grade="..grade..",agent1="..agent1.." where userid="..pInfo.userid
	
		mysqlItem:execute(sqlCase)
		myAgent.grade = grade
		myAgent.agent1 = tonumber(agent1)
		UnlimitedModel.AddUserIDToWiring(wiringID, pInfo.userid, grade)
		
		isPaixian = 1
		
	end
	
	UnlimitedModel.SetUserPreAgentID(pInfo.userid, myAgent.agent1)  --设置上级的ID
	
	local sendData = {}
	sendData['userid'] = pInfo.userid
	sendData['wiringid'] = myAgent.wiringid
	sendData['paixian'] = myAgent.wiringid
	
	
	AgentModel.SetAgent(pInfo.userid, myAgent)
	

end


function AgentModel.CheckBindAgent(pInfo, unionID)
	
	if unionID == nil or unionID == '' then
		return nil
	end	
	local toAgency = AgentModel.GetAgentInfo(unionID)  --取到上级的userid

	
	if toAgency == nil or toAgency.userid == 0 then
		return
	end

    --代理必须同一个渠道 内部测试账户只能绑定内部测试账户
    local agpInfo = PlayerModel.GetPlayerInfo(toAgency.userid)
    --0 普通账户 1 内部测试账户 2 股东合伙人
    if GameUtils.GetChannel_login(pInfo.channel) ~= GameUtils.GetChannel_login(agpInfo.channel) or (pInfo.usertype == 1 and agpInfo.usertype ~= pInfo.usertype) then
    	return nil
    end


	local myAgent = st_agent_pb.agentinfo()

	myAgent.qrcodeurl = AgentModel.GetQrcodeUrl(pInfo.userid)
	myAgent.invitestr = tostring(pInfo.userid)
	myAgent.userid = pInfo.userid
	myAgent.level = 91

	

	myAgent.soleagent = toAgency.level > 98 and toAgency.userid or toAgency.soleagent
	myAgent.agent1 = toAgency.userid
	myAgent.agent2 = toAgency.agent1
	myAgent.agent3 = toAgency.agent2
	myAgent.agent4 = toAgency.agent3
	
	AgentModel.InsertAgent(pInfo, myAgent)	
    VipMgrModel.SetVipUserInvalidFriends(toAgency.userid,pInfo.userid)
	LogDispatch.UserBindAgent(pInfo, toAgency.userid)
	--这边把对上级绑定的关系发送到utils服务器那边
end


function AgentModel.CheckIsWiringBindPre(pInfo, unionID, bindUserID)
	
	
	--在每个玩家创建角色的时候，检查是否绑定代理了。
	local wiringID = 0
	local toAgencyUserID = bindUserID
	
	local toAgency = AgentModel.GetAgentInfo(toAgencyUserID)

	
	if toAgency == nil or toAgency.userid == 0 then
		return
	end

	
	local myAgent = st_agent_pb.agentinfo()
	local grade = wiringID > 0 and 0 or -1
	myAgent.qrcodeurl = AgentModel.GetQrcodeUrl(pInfo.userid)
	myAgent.invitestr = tostring(pInfo.userid)
	myAgent.userid = pInfo.userid
	myAgent.level = 91
	myAgent.wiringid = wiringID
	myAgent.grade = grade	
	
	
	
	
	
	if wiringID == 0 then
		--如果排线ID为0，那么就说明这个兄弟扫的是直属玩家
		
		myAgent.soleagent = toAgency.level > 98 and toAgency.userid or toAgency.soleagent
		myAgent.agent1 = toAgency.userid
		myAgent.agent2 = toAgency.agent1
		myAgent.agent3 = toAgency.agent2
		myAgent.agent4 = toAgency.agent3
		myAgent.wiringid = toAgency.wiringid

	end	

	
	AgentModel.InsertAgent(pInfo, myAgent)
	
	local isPaixian = 0
	if wiringID ~= 0 then
		--如果排线ID不为0，那么这里留需要找到他的上级了。
		local sqlCase = "select count(userid) from ag_player where wiringid="..wiringID.." and userid<"..pInfo.userid.." and grade >= 0" 
		mysqlItem:executeQuery(sqlCase)
		grade = mysqlItem:fetch()
		
		sqlCase = "select userid from ag_player where wiringid="..wiringID.." and userid<"..pInfo.userid.." and grade >=0 order by userid desc limit 1"
		mysqlItem:executeQuery(sqlCase)
		
		local agent1 = mysqlItem:fetch()
		
		grade = grade ==  nil and  1 or (tonumber(grade) + 1)
		agent1 = agent1 == nil and sqlData[2] or agent1

		sqlCase = "update ag_player set grade="..grade..",agent1="..agent1.." where userid="..pInfo.userid
	
		mysqlItem:execute(sqlCase)
		myAgent.grade = grade
		myAgent.agent1 = tonumber(agent1)
		UnlimitedModel.AddUserIDToWiring(wiringID, pInfo.userid, grade)
		
		isPaixian = 1
		
	end
	
	UnlimitedModel.SetUserPreAgentID(pInfo.userid, myAgent.agent1)  --设置上级的ID
	
	local sendData = {}
	sendData['userid'] = pInfo.userid
	sendData['wiringid'] = myAgent.wiringid
	sendData['paixian'] = isPaixian
	
	
	AgentModel.SetAgent(pInfo.userid, myAgent)
	

end


function AgentModel.isSaoMa(unionID)

	if g_gamename ~= "uudwc" then
		return true
	end
 	
	if unionID == nil or unionID == '' then
		return false
	end

	local sqlCase = "select id,binduserid,wiringid from ag_author where unionid='"..unionID.."' order by id desc limit 1"
	
	
	mysqlItem:executeQuery(sqlCase)
	local sqlData = mysqlItem:fetch({})


	if sqlData == nil then
		return false
	end	
	return true
end


function AgentModel.IncrSysCommission(amount)
	
	redisItem:incrby( AgentModel.agent_sys_commission, amount, AgentModel.redis_index)
	
end


function AgentModel.IsSubordinate(userid, checkid)
	local sqlCase = "select wiringid,grade from ag_player where userid="..userid
	mysqlItem:executeQuery(sqlCase)
	local sqlData = mysqlItem:fetch({})
	if sqlData == nil then
		return false
	end
	
	local cWiringID = tonumber(sqlData[1]) --所在的排线ID
	local cGrade = tonumber(sqlData[2])    --所在排线ID的等级

	local function CheckSubordinate(bUserID)
		
		sqlCase = "select agent1,wiringid,grade from ag_player where userid="..bUserID
		mysqlItem:executeQuery(sqlCase)
		sqlData = mysqlItem:fetch({})
		
		if sqlData == nil then
			return false
		end
		
		local bAgent1 = tonumber(sqlData[1])
		local bwiringID = tonumber(sqlData[2])
		local bGrade = tonumber(sqlData[3])
		
		if bAgent1 == userid then
			--如果上级刚好相等，就停止。
			return true
		end
		
		if bwiringID ~= 0 and bwiringID == cWiringID then
			--如果排线相等，也停止
			if cGrade < bGrade then
				return true
			else
				return false
			end
			
		end
		
		--sqlCase = "select ownerid from dy_unlimitedwiring where "
		if bAgent1 == 0 then
			--如果上级是0，就停止了。
			return false
			
		end
		local bCheckID = bAgent1
		if bwiringID ~= 0 then
			--如果排线存在，那么就需要查排线主了。
			sqlCase = "select ownerid from dy_unlimitedwiring where id="..bwiringID
			mysqlItem:executeQuery(sqlCase)
			local bOwnerID= mysqlItem:fetch()
			if bOwnerID == nil then
				return false
			end
			bOwnerID = tonumber(bOwnerID)
			if bOwnerID == userid then
				return true
			end
			bCheckID = bOwnerID
		end
		return CheckSubordinate(bCheckID)
	end

	return CheckSubordinate(checkid)

end



function AgentModel.GetUserDirUserIDList(userID, startPos, endPos)
	
	local redisKey = AgentModel.agent_user_pre..userID
	
	if false == redisItem:exists( redisKey,  AgentModel.redis_index) then
		
		local sqlCase = "select userid from ag_player where agent1="..userID.." and userid > 0 order by userid"
	
		mysqlItem:executeQuery(sqlCase)	
		

		redisItem:rpush(redisKey, tonumber(userID), AgentModel.redis_index )    --把第一个放为自己的。保证里面一定有一个。
		while true do
			
			local sqlData = mysqlItem:fetch()
			
			if sqlData == nil then
				break
			end
			redisItem:rpush(redisKey, tonumber(sqlData), AgentModel.redis_index )
		end
		
	end
	return redisItem:lrange( redisKey, startPos + 1, endPos, AgentModel.redis_index )
end


function AgentModel.GetUserDirUserLen(userID)
	--这里为什么要放第一个呢。是因为第一个保持每个人都有一个自己的列表
	local redisKey = AgentModel.agent_user_pre..userID
	if false == redisItem:exists( redisKey,  AgentModel.redis_index) then
		AgentModel.GetUserDirUserIDList(userID, 0 ,-1)
	end
	local len = redisItem:llen( redisKey,  AgentModel.redis_index )
	return (tonumber(len) - 1)
end


function AgentModel.AddToUserDirList(userID, DiruserID)   --往自己的记录中加入一个
	local redisKey = AgentModel.agent_user_pre..userID
	if false == redisItem:exists( redisKey,  AgentModel.redis_index) then
		AgentModel.GetUserDirUserIDList(userID, 0 ,-1)
	end
	redisItem:rpush(redisKey, tonumber(DiruserID), AgentModel.redis_index )
end

function AgentModel.GetChannel(channel)
	local pos = string.find(channel, '_')
	if pos == nil then
		return channel
	end
	
	return string.sub( channel, 1, pos - 1 )
end

function AgentModel.GetAllChannel()
	
	return g_race_channel or g_agentAllChannel
end