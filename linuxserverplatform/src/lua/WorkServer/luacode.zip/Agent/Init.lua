
--鉴于代理系统的复杂性。把代理系统单独出来作为一个模块来进行处理

require("common.st_agent_pb")
require("common.msg_agent_pb")
require("common.msg_agent2_pb")

require("common.define.AgentDefine")
require("common.packet.packet_agent")

require("Agent.Model.AgentModel")
require("Agent.Model.UnlimitedModel")

require("Agent.Services.UnlimitedAward")

require("Agent.Controller.AgenctOpt")
require("Agent.Controller.CreateWiring")
require("Agent.Controller.GetAgenctInfo")
require("Agent.Controller.GetAgentIncome")
require("Agent.Controller.GetWiringInfo")
require("Agent.Controller.GetWiringList")
require("Agent.Controller.InviteBind")
require("Agent.Controller.WiringAchievement")
require("Agent.Controller.WiringAwardList")
require("Agent.Controller.WiringDrawMoney")
require("Agent.Controller.WiringUserList")
require("Agent.Controller.WiringWithDraw")
require("Agent.Controller.WiringAppointmentWithDraw")
require("Agent.Controller.SubordinateCheck")
require("Agent.Controller.AgentSetRateNum")
require("Agent.Controller.GetPumpAgentInfo")
require("Agent.Controller.GetAgentPromoteRank")
require("Agent.Controller.GetAgentPromoteInfo")
require("Agent.Controller.GetNationalAgentInfo")
require("Agent.Controller.GetNationalDirUserInfo")
require("Agent.Controller.NationalIncomeHis")
require("Agent.Controller.NationalWiringUserList")

require("Agent.Award.AgentAward")
require("Agent.Award.XyylAward")
require("Agent.Award.CfylAward")
require("Agent.Award.DefaultAward")
require("Agent.Award.HyylAward")
require("Agent.Award.KllmAward")
require("Agent.Award.QmzqAward")
require("Agent.Award.TtyAward")
require("Agent.Award.QmtyAward")
require("Agent.Award.GjlmAward")

g_redisIndex[AgentModel.redis_index] = {index = g_redisInfo.redis_two, key = AgentModel.redis_index, link = 1}
g_redisIndex[UnlimitedModel.redis_index] = {index = g_redisInfo.redis_three, key = AgentModel.redis_index, link = 1}
