
GjlmAward = {}

--全民体育代理系统


--该函数是用来判断自己玩的流水是否算入自己的奖励中。
--例如，A玩家玩了10000流水，A是否从这1万流水中拿到分佣。
function GjlmAward.IsSelfAchCount(level)
	return false
end

--获取流水的返佣，这个是流水多级返佣
--例如，前面三级或者六级有返佣，三级或者六级以后就没有了。
function GjlmAward.GetAchLevelAward(level)
	return 0;
end


--获取抽水的分佣，多级抽水的分佣，请区别流水返佣
--例如，前面三级或者六级有返佣，三级或者六级以后就没有了。
function GjlmAward.GetFeeAward(level)
	local indexList = {15,8,4,2,1,0}
	if level > 5 or level < 1 then
		return 0
	end
	return indexList[level]
end


--获取团队流水所在的团队分佣级别，用于无限代模式
--例如，总团队流水500万。所处于的返佣级别
function GjlmAward.GetTeamAchAward(achNum)
	
	if achNum <= 2000000 then
		return 0
	elseif achNum <= 5000000 then
		return 10
	elseif achNum <= 15000000 then
		return 20
	elseif achNum <= 30000000 then
		return 30
	elseif achNum <= 60000000 then
		return 40
	elseif achNum <= 100000000 then
		return 50
	elseif achNum <= 200000000 then
		return 60
	elseif achNum <= 500000000 then
		return 70
	elseif achNum <= 1000000000 then
		return 80
	else
		return 90
	end

end

--获取代理等级
--如无限代理需要将[流水、抽水、充值]无限递归，而3级代理只需要递归三级
function GjlmAward.GetAgentLevel()
	return 0;
end

--获取代理的返佣模式
-- 如，有些是抽水返，有些是流水返
-- 1、流水分佣
-- 2、抽水分成
function GjlmAward.GetAgentAwardModel()
	return 2;
end


--根据流水获得代理等级
function GjlmAward.GetAgentLevelByAch(achNum)
	
	if achNum <= 2000000 then
		return 0
	elseif achNum <= 5000000 then
		return 1
	elseif achNum <= 15000000 then
		return 2
	elseif achNum <= 30000000 then
		return 3
	elseif achNum <= 60000000 then
		return 4
	elseif achNum <= 100000000 then
		return 5
	elseif achNum <= 200000000 then
		return 6
	elseif achNum <= 500000000 then
		return 7
	elseif achNum <= 1000000000 then
		return 8
	else
		return 9
	end
	
end

--获得等级总流水
function GjlmAward.GetAgentLevelAllAch(achNum)
	
	if achNum <= 2000000 then
		return 2000000
	elseif achNum <= 5000000 then
		return 5000000 - 2000000
	elseif achNum <= 15000000 then
		return 15000000 - 5000000
	elseif achNum <= 30000000 then
		return 30000000 - 15000000
	elseif achNum <= 60000000 then
		return 60000000 - 30000000
	elseif achNum <= 100000000 then
		return 100000000 - 60000000
	elseif achNum <= 200000000 then
		return 200000000 - 100000000
	elseif achNum <= 500000000 then
		return 500000000 - 200000000
	elseif achNum <= 1000000000 then
		return 1000000000 - 500000000
	else
		return 0
	end
	
end

--获得升级所需流水
function GjlmAward.GetAgentLevelNeedAch(achNum)
	
	if achNum <= 2000000 then
		return 2000000 - achNum + 1
	elseif achNum <= 5000000 then
		return 5000000 - achNum + 1
	elseif achNum <= 15000000 then
		return 15000000 - achNum + 1
	elseif achNum <= 30000000 then
		return 30000000 - achNum + 1
	elseif achNum <= 60000000 then
		return 60000000 - achNum + 1
	elseif achNum <= 100000000 then
		return 100000000 - achNum + 1
	elseif achNum <= 200000000 then
		return 200000000 - achNum + 1
	elseif achNum <= 500000000 then
		return 500000000 - achNum + 1
	elseif achNum <= 1000000000 then
		return 1000000000 - achNum + 1
	else
		return 0
	end
	
end


--判断这个代理是否包含5级代理
function GjlmAward.IsHaveFiveAgent()
	return false
end


--判断抽水，自己是否有奖励
function GjlmAward.IsSelfFeeCount()
	return false
end