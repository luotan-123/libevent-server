
TtyAward = {}

--全民足球的分成奖励


--该函数是用来判断自己玩的流水是否算入自己的奖励中。
--例如，A玩家玩了10000流水，A是否从这1万流水中拿到分佣。
function TtyAward.IsSelfAchCount(level)
	return false
end

--获取流水的返佣，这个是流水多级返佣
--例如，前面三级或者六级有返佣，三级或者六级以后就没有了。
function TtyAward.GetAchLevelAward(level)
	return 0;
end


--获取抽水的分佣，多级抽水的分佣，请区别流水返佣
--例如，前面三级或者六级有返佣，三级或者六级以后就没有了。
function TtyAward.GetFeeAward(level)
	return 0
end


--获取团队流水所在的团队分佣级别，用于无限代模式
--例如，总团队流水500万。所处于的返佣级别
function TtyAward.GetTeamAchAward(achNum)
	
	if achNum <= 200000 then
		return 0
	elseif achNum <= 500000 then
		return 5
	elseif achNum <= 1500000 then
		return 10
	elseif achNum <= 3000000 then
		return 15
	elseif achNum <= 6000000 then
		return 20
	elseif achNum <= 10000000 then
		return 25
	elseif achNum <= 20000000 then
		return 30
	elseif achNum <= 50000000 then
		return 35
	elseif achNum <= 100000000 then
		return 40
	else
		return 45
	end

end

--获取代理等级
--如无限代理需要将[流水、抽水、充值]无限递归，而3级代理只需要递归三级
function TtyAward.GetAgentLevel()
	return 0;
end

--获取代理的返佣模式
-- 如，有些是抽水返，有些是流水返
-- 1、流水分佣
-- 2、抽水分成
function TtyAward.GetAgentAwardModel()
	return 2;
end


--根据流水获得代理等级
function TtyAward.GetAgentLevelByAch(achNum)
	
	if achNum <= 200000 then
		return 0
	elseif achNum <= 500000 then
		return 1
	elseif achNum <= 1500000 then
		return 2
	elseif achNum <= 3000000 then
		return 3
	elseif achNum <= 6000000 then
		return 4
	elseif achNum <= 10000000 then
		return 5
	elseif achNum <= 20000000 then
		return 6
	elseif achNum <= 50000000 then
		return 7
	elseif achNum <= 100000000 then
		return 8
	else
		return 9
	end
	
end

--获得等级总流水
function TtyAward.GetAgentLevelAllAch(achNum)
	
	if achNum <= 200000 then
		return 200000
	elseif achNum <= 500000 then
		return 500000 - 200000
	elseif achNum <= 1500000 then
		return 1500000 - 500000
	elseif achNum <= 3000000 then
		return 3000000 - 1500000
	elseif achNum <= 6000000 then
		return 6000000 - 3000000
	elseif achNum <= 10000000 then
		return 10000000 - 6000000
	elseif achNum <= 20000000 then
		return 20000000 - 10000000
	elseif achNum <= 50000000 then
		return 50000000 - 20000000
	elseif achNum <= 100000000 then
		return 100000000 - 50000000
	else
		return 0
	end
	
end

--获得升级所需流水
function TtyAward.GetAgentLevelNeedAch(achNum)
	
	if achNum <= 200000 then
		return 200000 - achNum + 1
	elseif achNum <= 500000 then
		return 500000 - achNum + 1
	elseif achNum <= 1500000 then
		return 1500000 - achNum + 1
	elseif achNum <= 3000000 then
		return 3000000 - achNum + 1
	elseif achNum <= 6000000 then
		return 6000000 - achNum + 1
	elseif achNum <= 10000000 then
		return 10000000 - achNum + 1
	elseif achNum <= 20000000 then
		return 20000000 - achNum + 1
	elseif achNum <= 50000000 then
		return 50000000 - achNum + 1
	elseif achNum <= 100000000 then
		return 100000000 - achNum + 1
	else
		return 0
	end
	
end