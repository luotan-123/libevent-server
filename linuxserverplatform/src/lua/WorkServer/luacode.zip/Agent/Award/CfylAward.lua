
CfylAward = {}

--超凡娱乐的分成奖励


--该函数是用来判断自己玩的流水是否算入自己的奖励中。
--例如，A玩家玩了10000流水，A是否从这1万流水中拿到分佣。
function CfylAward.IsSelfAchCount(level)
	return true
end

--获取流水的返佣，这个是流水多级返佣
--例如，前面三级或者六级有返佣，三级或者六级以后就没有了。
function CfylAward.GetAchLevelAward(level)
	local indexList = {2,2,2,2,2,0}
	if level > 5 or level < 1 then
		return 0
	end
	return indexList[level]	
end


--获取抽水的分佣，多级抽水的分佣，请区别流水返佣
--例如，前面三级或者六级有返佣，三级或者六级以后就没有了。
function CfylAward.GetFeeAward(level)
	return 0
end


--获取团队流水所在的团队分佣级别，用于无限代模式
--例如，总团队流水500万。所处于的返佣级别
function CfylAward.GetTeamAchAward(achNum)
	achNum = achNum/100
	local tempNum = 0
	if achNum < 1000 then
		tempNum =  60
	elseif achNum < 7000 then
		tempNum = 70
	elseif achNum < 12000 then
		tempNum = 80
	elseif achNum < 40000 then
		tempNum = 100
	elseif achNum < 80000 then
		tempNum = 120 
	elseif achNum < 120000 then
		tempNum = 140
	elseif achNum < 250000 then
		tempNum = 160
	elseif achNum < 500000 then
		tempNum = 180
	elseif achNum < 800000 then
		tempNum = 200
	elseif achNum < 1000000 then
		tempNum = 220
	elseif achNum < 1200000 then
		tempNum = 240
	elseif achNum < 3600000 then
		tempNum = 260
	elseif achNum < 5000000 then
		tempNum = 270
	elseif achNum < 10000000 then
		tempNum =  280
	elseif achNum < 15000000 then
		tempNum = 290
	else
		tempNum = 300
	end	
	return tempNum
end

--获取代理等级
--如无限代理需要将[流水、抽水、充值]无限递归，而3级代理只需要递归三级
function CfylAward.GetAgentLevel()
	return 0;
end

--获取代理的返佣模式
-- 如，有些是抽水返，有些是流水返
-- 1、流水分佣
-- 2、抽水分成
function CfylAward.GetAgentAwardModel()
	return 1;
end