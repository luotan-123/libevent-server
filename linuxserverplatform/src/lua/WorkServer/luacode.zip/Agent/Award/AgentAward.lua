
AgentAward = {}


AgentAwardList = {
	["hyyl"] = "HyylAward",  	-- 鸿运
	["thyl"] = "HyylAward",  	-- 天河
	["xyyl"] = "XyylAward",		-- 轩辕
	["cfyl"] = "CfylAward",		-- 超凡
	["kllm"] = "KllmAward",		-- 快乐联盟（房卡游戏）
	["yylm"] = "KllmAward",		-- 友友联盟（房卡游戏）
	["qmzq"] = "QmzqAward",		-- 全民足球
	["tty"] = "QmtyAward",		-- 天天赢
	["qmty"] = "QmtyAward",		-- 全民体育
	["gjlm"] = "GjlmAward",		-- 冠军联盟
	["dblm"] = "GjlmAward",		-- 夺宝联盟
	["default"] = "QmtyAward",
}


function AgentAward:GetAwradControll(channel)

	return _G[AgentAwardList[channel]] == nil and _G[AgentAwardList['default']] or _G[AgentAwardList[channel]]
	
end


--该函数是用来判断自己玩的流水是否算入自己的奖励中。
--例如，A玩家玩了10000流水，A是否从这1万流水中拿到分佣。
function AgentAward.IsSelfAchCount(channel,userid,addNum)
	local awardItem = AgentAward:GetAwradControll(channel)
	--	awardItem(level)
	return awardItem['IsSelfAchCount'] == nil and true or awardItem['IsSelfAchCount'](userid,addNum)
end

--获取流水的返佣，这个是流水多级返佣
--例如，前面三级或者六级有返佣，三级或者六级以后就没有了。
function AgentAward.GetAchLevelAward(channel,level)
	local awardItem = AgentAward:GetAwradControll(channel)
	--	awardItem(level)
	return awardItem['GetAchLevelAward'] == nil and 0 or awardItem['GetAchLevelAward'](level)	
end


--获取抽水的分佣，多级抽水的分佣，请区别流水返佣
--例如，前面三级或者六级有返佣，三级或者六级以后就没有了。
function AgentAward.GetFeeAward(channel,level)
	local awardItem = AgentAward:GetAwradControll(channel)
	--awardItem(level)
	return awardItem['GetFeeAward'] == nil and 0 or awardItem['GetFeeAward'](level)	
end



--获取团队流水所在的团队分佣级别，用于无限代模式
--例如，总团队流水500万。所处于的返佣级别
function AgentAward.GetTeamAchAward(channel,achNum)
	local awardItem = AgentAward:GetAwradControll(channel)
	--	awardItem(level)
	return awardItem['GetTeamAchAward'] == nil and 0 or awardItem['GetTeamAchAward'](achNum)	
end


--获取代理等级
--如无限代理需要将[流水、抽水、充值]无限递归，而3级代理只需要递归三级
function AgentAward.GetAgentLevel(channel)
	local awardItem = AgentAward:GetAwradControll(channel)
	return awardItem['GetAgentLevel'] == nil and 0 or awardItem['GetAgentLevel']()	
end


--获取代理的返佣模式
-- 如，有些是抽水返，有些是流水返
-- 1、流水分佣
-- 2、抽水分成
function AgentAward.GetAgentAwardModel(channel)
	local awardItem = AgentAward:GetAwradControll(channel)
	return awardItem['GetAgentAwardModel'] == nil and 1 or awardItem['GetAgentAwardModel']()
end


--根据流水获得代理等级
function AgentAward.GetAgentLevelByAch(channel,achNum)
	local awardItem = AgentAward:GetAwradControll(channel)
	return awardItem['GetAgentLevelByAch'] == nil and 0 or awardItem['GetAgentLevelByAch'](achNum)	
end

--获得等级总流水
function AgentAward.GetAgentLevelAllAch(channel,achNum)
	local awardItem = AgentAward:GetAwradControll(channel)
	return awardItem['GetAgentLevelAllAch'] == nil and 0 or awardItem['GetAgentLevelAllAch'](achNum)	
end

--获得升级所需流水
function AgentAward.GetAgentLevelNeedAch(channel,achNum)
	local awardItem = AgentAward:GetAwradControll(channel)
	return awardItem['GetAgentLevelNeedAch'] == nil and 0 or awardItem['GetAgentLevelNeedAch'](achNum)	
end


--判断这个代理是否包含5级代理
function AgentAward.IsHaveFiveAgent(channel)
	local awardItem = AgentAward:GetAwradControll(channel)
	return awardItem['IsHaveFiveAgent'] == nil and 0 or awardItem['IsHaveFiveAgent']()	
end


--判断抽水，自己是否有奖励
function AgentAward.IsSelfFeeCount(channel)
	local awardItem = AgentAward:GetAwradControll(channel)
	return awardItem['IsSelfFeeCount'] == nil and true or awardItem['IsSelfFeeCount']()
end