
--该文件是调试使用的，正式环境中，不使用该文件

module("HttpDebug", package.seeall)

function gettablelist(rcvData)

	if g_isDebug ~= 1 then
		return "error"
	end
	local jsonArr = luajson.decode(rcvData)
	
	if jsonArr['category'] == '20' then
		--欢乐赢豆
	elseif jsonArr['category'] == '21' then
		--欢乐竞技
	elseif jsonArr['category'] == '22' then
		--广东麻将
		if package.loaded["Gdmj.Model.GdmjModel"] == nil then
			return "error"
		end
		retList = GdmjModel.GetTableList()
	elseif jsonArr['category'] == '23' then
		--跑胡子
	elseif jsonArr['category'] == '24' then
		--欢乐牛牛
	elseif jsonArr['category'] == '25' then
		--百人牛牛
	elseif jsonArr['category'] == '26' then
		--老虎机
	elseif jsonArr['category'] == '27' then
		--火锅英雄
	elseif jsonArr['category'] == '28' then
		--湖北麻将
		if package.loaded["Hubmj.Model.HubmjModel"] == nil then
			return "error"
		end	
		retList = HubmjModel.GetTableList()
	elseif jsonArr['category'] == '29' then
		--十点半
		if package.loaded["Sdb.Model.SdbModel"] == nil then
			return "error"
		end
		retList = SdbModel.SdbGetTableList()
	elseif jsonArr['category'] == '30' then
		--斗牛
		
		retList = DouNiuModel.GetTableList()
	elseif jsonArr['category'] == '31' then
		--炸金花
		retList = PszModel.GetTableList()
	elseif jsonArr['category'] == '32' then
		--牌九
		retList = {}
	elseif jsonArr['category'] == '33' then
		--红黑大战
		retList = HongHeiModel.GetTableIDList()
	elseif jsonArr['category'] == '34' then
		--龙虎斗
		retList = LhdModel.GetTableIDList()
	elseif jsonArr['category'] == '35' then
		--百人牛牛
		retList =BrnnModel.GetTableIDList()
	elseif jsonArr['category'] == '36' then
		--百家乐
		retList = BarccatatModel.GetTableIDList()
	elseif jsonArr['category'] == '37' then
		--斗地主
		retList = DdzModel.GetTableList()
	elseif jsonArr['category'] == '38' then	
		--奔驰宝马
		retList = BcbmModel.GetTableIDList()
	end
	return luajson.encode(retList)
end

function getuserlist(rcvData)
	if g_isDebug ~= 1 then
		return "error"
	end
	local jsonArr = luajson.decode(rcvData)
	local retList = {}	
	if jsonArr['category'] == '20' then
		--欢乐赢豆
	elseif jsonArr['category'] == '21' then
		--欢乐竞技
	elseif jsonArr['category'] == '22' then
		--广东麻将
		local tInfo = GdmjModel.GetTableInfo(jsonArr['tableid'])
		if tInfo == nil then
			return "error"
		end
		for k,v in ipairs(tInfo.situser) do
			table.insert(retList, v.userid)
		end		
	elseif jsonArr['category'] == '23' then
		--跑胡子
	elseif jsonArr['category'] == '24' then
		--欢乐牛牛
		
		local tInfo = DouNiuModel.GetTableInfo( jsonArr['tableid'] )
		if tInfo ~= nil then
			for k,v in ipairs(tInfo.situser) do
				table.insert(retList, v.userid)
			end
		end
	elseif jsonArr['category'] == '25' then
		--百人牛牛
		table.insert( retList, "黑桃" )
		table.insert( retList, "红桃" )
		table.insert( retList, "梅花" )
		table.insert( retList, "方块" )
	elseif jsonArr['category'] == '26' then
		--老虎机
	elseif jsonArr['category'] == '27' then
		--火锅英雄
	elseif jsonArr['category'] == '28' then
		--湖北麻将
		local tInfo = HubmjModel.GetTableInfo(jsonArr['tableid'])
		if tInfo == nil then
			return "error"
		end
		for k,v in ipairs(tInfo.publicpoker) do
			table.insert(retList, v)
		end			
	elseif jsonArr['category'] == '29' then
		--十点半
		local tInfo = SdbModel.SdbGetTableInfo(jsonArr['tableid'])
		if tInfo == nil then
			return "error"
		end
		for k,v in ipairs(tInfo.pokerlist) do
			table.insert(retList, v)
		end
	elseif jsonArr['category'] == '30' then
		--抢庄牛牛
		local tInfo = DouNiuModel.GetTableInfo( jsonArr['tableid'] )
		if tInfo ~= nil then
			for k,v in ipairs(tInfo.situser) do
				table.insert(retList, v.userid)
			end
		end		
	elseif jsonArr['category'] == '31' then
		--炸金花
		local tInfo = PszModel.GetTableInfo( jsonArr['tableid'] )
		if tInfo ~= nil then
			for k,v in ipairs(tInfo.situser) do
				table.insert(retList, v.userid)
			end
		end		
	elseif jsonArr['category'] == '32' then
		--牌九
		
	elseif jsonArr['category'] == '33' then
		--红黑大战
		table.insert( retList, "黑" )
		table.insert( retList, "红" )
	elseif jsonArr['category'] == '34' then
		--龙虎斗
		table.insert( retList, "龙" )
		table.insert( retList, "虎" )
	elseif jsonArr['category'] == '35' then
		--百人牛牛
		table.insert( retList, "黑桃" )
		table.insert( retList, "红桃" )
		table.insert( retList, "梅花" )
		table.insert( retList, "方块" )	
		table.insert( retList, "庄家" )	
	elseif jsonArr['category'] == '36' then
		--百家乐
		table.insert( retList, "庄" )
		table.insert( retList, "闲" )		
	elseif jsonArr['category'] == '37' then
		--斗地主
		local tInfo = PszModel.GetTableInfo( jsonArr['tableid'] )
		if tInfo ~= nil then
			for k,v in ipairs(tInfo.situser) do
				table.insert(retList, v.userid)
			end
		end		
	elseif jsonArr['category'] == '38' then	
		--奔驰宝马
		table.insert( retList, "奥迪X5" )
		table.insert( retList, "宝马X5" )
		table.insert( retList, "奔驰X5" )
		table.insert( retList, "大众X5" )
		table.insert( retList, "奥迪X40" )
		table.insert( retList, "宝马X30" )
		table.insert( retList, "奔驰X20" )
		table.insert( retList, "大众X10" )	
	end
	table.sort(retList, function(a,b) return a < b end)
	return luajson.encode(retList)	
	
end

function getpubpoker(rcvData)


	if g_isDebug ~= 1 then
		return "error"
	end
	local jsonArr = luajson.decode(rcvData)
	
	local retList = {}	
	if jsonArr['category'] == '20' then
		--欢乐赢豆
	elseif jsonArr['category'] == '21' then
		--欢乐竞技
	elseif jsonArr['category'] == '22' then
		--广东麻将
		
		local tInfo = GdmjModel.GetTableInfo(jsonArr['tableid'])
		if tInfo == nil then
			return "error"
		end
		for k,v in ipairs(tInfo.publicpoker) do
			table.insert(retList, v)
		end		
	elseif jsonArr['category'] == '23' then
		--跑胡子
	elseif jsonArr['category'] == '24' then
		--欢乐牛牛
	elseif jsonArr['category'] == '25' then
		--百人牛牛
	elseif jsonArr['category'] == '26' then
		--老虎机
	elseif jsonArr['category'] == '27' then
		--火锅英雄
	elseif jsonArr['category'] == '28' then
		--湖北麻将
		local tInfo = HubmjModel.GetTableInfo(jsonArr['tableid'])
		if tInfo == nil then
			return "error"
		end
		for k,v in ipairs(tInfo.publicpoker) do
			table.insert(retList, v)
		end			
	elseif jsonArr['category'] == '29' then
		--十点半
		local tInfo = SdbModel.SdbGetTableInfo(jsonArr['tableid'])
		if tInfo == nil then
			return "error"
		end
		for k,v in ipairs(tInfo.pokerlist) do
			table.insert(retList, v)
		end
	elseif jsonArr['category'] == '30' then
		--抢庄牛牛
	elseif jsonArr['category'] == '31' then
		--炸金花
	elseif jsonArr['category'] == '32' then
		--牌九
	elseif jsonArr['category'] == '33' then
		--红黑大战
		
	elseif jsonArr['category'] == '34' then
		--龙虎斗
	elseif jsonArr['category'] == '35' then
		--百人牛牛
	elseif jsonArr['category'] == '36' then
		--百家乐
	elseif jsonArr['category'] == '37' then
		--斗地主
	elseif jsonArr['category'] == '38' then	
		--奔驰宝马
	end
	table.sort(retList, function(a,b) return a < b end)
	return luajson.encode(retList)
end

function nextpoker(rcvData)

	if g_isDebug ~= 1 then
		return "error"
	end
	local jsonArr = luajson.decode(rcvData)
	
	local retList = {}	
	if jsonArr['category'] == '20' then
		--欢乐赢豆
	elseif jsonArr['category'] == '21' then
		--欢乐竞技
	elseif jsonArr['category'] == '22' then
		--广东麻将
		
		GdmjModel.SetNextCard(jsonArr['tableid'],jsonArr['nextcard'])
	elseif jsonArr['category'] == '23' then
		--跑胡子
	elseif jsonArr['category'] == '24' then
		--欢乐牛牛
	elseif jsonArr['category'] == '25' then
		--百人牛牛
	elseif jsonArr['category'] == '26' then
		--老虎机
	elseif jsonArr['category'] == '27' then
		--火锅英雄
	elseif jsonArr['category'] == '28' then
		--湖北麻将
		HubmjModel.SetNextCard(jsonArr['tableid'],jsonArr['nextcard'])	
	elseif jsonArr['category'] == '29' then
		--十点半
		SdbModel.SetNextCard(jsonArr['tableid'],jsonArr['nextcard'])	
	elseif jsonArr['category'] == '30' then
		--斗牛
		--斗地主
		if jsonArr['tableid'] ~= nil and jsonArr['userid'] ~= nil and jsonArr['nextcard'] ~= nil then
			DouNiuModel.SetDebugNextCard(jsonArr['tableid'], jsonArr['userid'], luajson.encode(jsonArr['nextcard']))
		end				
	elseif jsonArr['category'] == '31' then
		--炸金花
		--斗地主
		if jsonArr['tableid'] ~= nil and jsonArr['userid'] ~= nil and jsonArr['nextcard'] ~= nil then
			PszModel.SetDebugNextCard(jsonArr['tableid'], jsonArr['userid'], luajson.encode(jsonArr['nextcard']))
		end				
	elseif jsonArr['category'] == '32' then
		--牌九
	elseif jsonArr['category'] == '33' then
		--红黑大战
		if jsonArr['tableid'] ~= nil and jsonArr['userid'] ~= nil and jsonArr['nextcard'] ~= nil then
			local userType = jsonArr['userid'] == '黑' and 1 or 2
			HongHeiModel.SetDebugNextCard(jsonArr['tableid'], userType, luajson.encode(jsonArr['nextcard']))
		end
	elseif jsonArr['category'] == '34' then
		--龙虎斗
		if jsonArr['tableid'] ~= nil and jsonArr['userid'] ~= nil and jsonArr['nextcard'] ~= nil then
			local userType = jsonArr['userid'] == '龙' and 1 or 2
			LhdModel.SetDebugNextCard(jsonArr['tableid'], userType, luajson.encode(jsonArr['nextcard']))
		end
	elseif jsonArr['category'] == '35' then
		--百人牛牛
		if jsonArr['tableid'] ~= nil and jsonArr['userid'] ~= nil and jsonArr['nextcard'] ~= nil then
			local userType = 1
			if jsonArr['userid'] == "黑桃" then
				userType = 1
			elseif jsonArr['userid'] == "红桃" then
				userType = 2
			elseif jsonArr['userid'] == "梅花" then
				userType = 3
			elseif jsonArr['userid'] == "方块" then
				userType = 4
			elseif jsonArr['userid'] == "庄家" then
				userType = 5
			end
			BrnnModel.SetDebugNextCard(jsonArr['tableid'], userType, luajson.encode(jsonArr['nextcard']))
		end
	elseif jsonArr['category'] == '36' then
		--百家乐
		if jsonArr['tableid'] ~= nil and jsonArr['userid'] ~= nil and jsonArr['nextcard'] ~= nil then
			local userType = jsonArr['userid'] == '闲' and 1 or 2
			BarccatatModel.SetDebugNextCard(jsonArr['tableid'], userType, luajson.encode(jsonArr['nextcard']))
		end		
	elseif jsonArr['category'] == '37' then
		--斗地主
		if jsonArr['tableid'] ~= nil and jsonArr['userid'] ~= nil and jsonArr['nextcard'] ~= nil then
			DdzModel.SetDebugNextCard(jsonArr['tableid'], jsonArr['userid'], luajson.encode(jsonArr['nextcard']))
		end		
	elseif jsonArr['category'] == '38' then	
		--奔驰宝马	
		--斗地主
		if jsonArr['tableid'] ~= nil and jsonArr['userid'] ~= nil and jsonArr['nextcard'] ~= nil then
			
			local userType = 1
			if jsonArr['userid'] == "奥迪X5" then
				userType = 1
			elseif jsonArr['userid'] == "宝马X5" then
				userType = 2
			elseif jsonArr['userid'] == "奔驰X5" then
				userType = 3
			elseif jsonArr['userid'] == "大众X5" then
				userType = 4
			elseif jsonArr['userid'] == "奥迪X40" then
				userType = 5
			elseif jsonArr['userid'] == "宝马X30" then
				userType = 6
			elseif jsonArr['userid'] == "奔驰X20" then
				userType = 7
			elseif jsonArr['userid'] == "大众X10" then
				userType = 8
			end		


			BcbmModel.SetDebugNextCard(jsonArr['tableid'], jsonArr['userid'], jsonArr['nextcard'])
		end		
	else
		
	end
	table.sort(retList, function(a,b) return a < b end)
	return luajson.encode(retList)
end


function getstate(rcvData)
	if rcvData == nil or rcvData == "" then
		return "error"
	end
	local getList = {}
	if rcvData == "brnn" then
		
		for k = 1,#g_brnnDefine.init_data do
			--这里开始初始化牌桌了
			
			for k1,v1 in ipairs(g_brnnDefine.init_data[k]['tableid']) do
				
				getList[tostring(v1)] = {}
				getList[tostring(v1)]['state'] = BrnnModel.GetBrnnState(v1)
				getList[tostring(v1)]['timemark'] = BrnnModel.GetBrnnTime(v1)
			end
		end
	elseif rcvData == "bcbm" then
		for k = 1,#g_bcbmDefine.init_data do
			--这里开始初始化牌桌了
			
			for k1,v1 in ipairs(g_bcbmDefine.init_data[k]['tableid']) do
				getList[tostring(v1)] = {}
				getList[tostring(v1)]['state'] = BcbmModel.GetBcbmState(v1)
				getList[tostring(v1)]['timemark'] = BrnnModel.GetBrnnTime(v1)
			end
		end	
	elseif rcvData == "bjl" then
		for k = 1,#g_barccatatDefine.init_data do
			--这里开始初始化牌桌了
			
			for k1,v1 in ipairs(g_barccatatDefine.init_data[k]['tableid']) do
				getList[tostring(v1)] = {}
				getList[tostring(v1)]['state'] = BarccatatModel.GetBarccatatState(v1)
				getList[tostring(v1)]['timemark'] = BarccatatModel.GetBarccatatTime(v1)
			end
		end	
	elseif rcvData == "hhdz" then
		for k = 1,#g_hongheiDefine.init_data do
			--这里开始初始化牌桌了
			
			for k1,v1 in ipairs(g_hongheiDefine.init_data[k]['tableid']) do
				getList[tostring(v1)] = {}
				getList[tostring(v1)]['state'] = HongHeiModel.GetHongHeiState(v1)
				getList[tostring(v1)]['timemark'] = HongHeiModel.GetHongHeiTime(v1)
			end
		end	
	elseif rcvData == "lhd" then
		for k = 1,#g_lhdDefine.init_data do
			--这里开始初始化牌桌了
			
			for k1,v1 in ipairs(g_lhdDefine.init_data[k]['tableid']) do
				getList[tostring(v1)] = {}
				getList[tostring(v1)]['state'] = LhdModel.GetLhdState(v1)
				getList[tostring(v1)]['timemark'] = LhdModel.GetLhdTime(v1)
			end
		end			
	end
	--luaDump(getList)
	--luaDump(luajson.encode(getList))
	return luajson.encode(getList)

end

function serverinfo(rcvData)
	local retList = {0,0,0,0}
	
	retList[1],retList[2],retList[3],retList[4] = GetServerInfo()
	return luajson.encode(retList)
end

function rename()
	
	local sqlList = {}
	local count = 0
	for i = 1,100 do
		local start = (i - 1)*10
		local endNum = start + 100
		local sqlCase = "select userid,province,city from dy_player where userid <= 101000 limit "..start..",10"
		
		mysqlItem:executeQuery(sqlCase)
		
		while true do
			local sqlData = mysqlItem:fetch({})
			if sqlData == nil then
				break
			end
			local pInfo = PlayerModel.GetPlayerInfo(sqlData[1])
			pInfo.nickname = sqlData[2]..sqlData[3]
			local sqlTemp = "update dy_player set nickname='"..pInfo.nickname.."' where userid="..sqlData[1]
			table.insert(sqlList, sqlTemp)
			PlayerModel.SetPlayerInfo(pInfo)
			count = count+1
		end
	end
	print("count========"..count)
	for k,v in ipairs(sqlList) do
		mysqlItem:execute(v)
	end	
end
