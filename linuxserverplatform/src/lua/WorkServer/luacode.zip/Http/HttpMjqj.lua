module("HttpMjqj", package.seeall)
--麻将全集的


function impower(rcvData)
	
	if rcvData == nil then
		LogFile("error","impower rcvData is nil")
		return error
	end
	local pInfo = PlayerModel.GetPlayerInfo(rcvData)
	if pInfo == nil then
		LogFile("error","impower pInfo is nil")
		return error
	end
	AgentModel.LoadAgencyInfo(tonumber(rcvData))   --重新加载代理系统
	return "success"
end


