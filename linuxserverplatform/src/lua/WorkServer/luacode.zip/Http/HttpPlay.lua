module("HttpPlay", package.seeall)


function roster(rcvData)
	
	local jsonData = luajson.decode(rcvData)
	if jsonData['userid'] == nil or jsonData['sign'] == nil then
		return 'error'
	end
	
	local signStr = 'userid='..jsonData['userid'].."&key="..g_signKey
	
	if jsonData['sign'] ~= md5(signStr) then
		LogFile("error","roster sign error rcvData="..rcvData)
		return "sign error"
	end
	
	RosterModel.LoadRoster(jsonData['userid'])
	return "success"
end


--添加一个渠道号做区分
--channel
function shopconf(rcvData)
	local jsonData = luajson.decode(rcvData)
	if jsonData['channel'] == nil or jsonData['shopid'] == nil or jsonData['sign'] == nil then
		return "error"
	end
	local signStr = md5("channel="..jsonData['channel'].."&shopid="..jsonData['shopid'].."&key="..g_signKey)
	
	if jsonData['sign'] ~= signStr then
		LogFile("error", "shop conf sign error rcvData="..rcvData)
		return "sign error"
	end
	local channel = jsonData['channel']
	
	ShopModel.LoadShopConf(nil, channel)
	return "success"
end

function gameedit(rcvData)
	local jsonData = luajson.decode(rcvData)
	if jsonData['gametype'] == nil or jsonData['tabletype'] == nil or jsonData['sign'] == nil then
		return "error"
	end
	local signStr = md5("gametype="..jsonData['gametype'].."&tabletype="..jsonData['tabletype'].."&key="..g_signKey)
	if jsonData['sign'] ~= signStr then
		LogFile("error", "gameedit sign error rcvData="..rcvData)
	end
	AgentModel.LoadGameCommissionRatio(jsonData['gametype'], jsonData['tabletype'])
	return "success"
end

function playerlistinfo(rcvData)   --获取当前玩家的状态参数
	
	local jsonData = luajson.decode(rcvData)
	if jsonData['useridlist'] == nil or jsonData['sign'] == nil then
		return "error"
	end
	
	local signStr = md5('useridlist='..jsonData['useridlist'].."&key="..g_signKey)
	
	if jsonData['sign'] ~= signStr then
		LogFile("error", "playerlistinfo sign error rcvData="..rcvData)
		return "error"
	end 

	local userList = luajson.decode(jsonData['useridlist'])
	
	local retArr = {}
	
	
	for k,v_userid in ipairs(userList) do
		local tempArr = {}
		tempArr['userid'] = tonumber(v_userid)
		
		local onTime = OnlineModel.CheckOnline(v_userid)
		
		if nil ~= onTime then
			tempArr['online'] = 1
			tempArr['ontime'] = TimeUtils.DifferentTime(tonumber(onTime))
		else
			tempArr['online'] = 0
			tempArr['ontime'] = 0
		end
		
		tempArr['tableid'] = PlayerModel.GetCurrTableID(v_userid)
		table.insert(retArr, tempArr)
	end
	return luajson.encode(retArr)
	--暂时返回三个参数	
end

function tableinfo(rcvData)
	
	local jsonData = luajson.decode(rcvData)
	if jsonData['gametype'] == nil or jsonData['tabletype'] == nil or jsonData['sign'] == nil then
		return "error"
	end
	local signStr = md5("gametype="..jsonData['gametype'].."&tabletype="..jsonData['tabletype'].."&key="..g_signKey)
	if jsonData['sign'] ~= signStr then
		LogFile("error", "tableinfo sign error rcvData="..rcvData)
		return "error"		
	end
	
	
	
	local retList = LogConstantly.GetPlayerList(jsonData['gametype'], jsonData['tabletype'])
	
	local gametype = tonumber(jsonData['gametype'])
	
	if gametype == g_DdzDefine.game_type or gametype == g_douNiuDefine.game_type or gametype == g_PszDefine.game_type then
		
		local getAllList = table.clone(retList) 
		for k,v in pairs(getAllList) do
			
			local tableID,gameType = PlayerModel.GetCurrTableID(k)
			
			if tableID == 0 then
				LogConstantly.DelPlayer(jsonData['gametype'], jsonData['tabletype'], k)
				retList[k] = nil
			end
		end		
	end
	
	return luajson.encode(retList)
	
end

function vipaddjetton(rcvData)
	local jsonData = luajson.decode(rcvData)
	local retMSg = {}
	retMSg['code'] = "success"
	retMSg['msg'] = "success"
	if jsonData['userid'] == nil or jsonData['vipid'] == nil or jsonData['amount'] == nil or jsonData['sign'] == nil then
		retMSg['code'] = "error"
		retMSg['msg'] = "参数缺失"		
		return luajson.encode(retMSg)
	end
	
	local signStr = md5("amount="..jsonData['amount'].."&userid="..jsonData['userid'].."&vipid="..jsonData['vipid'].."&key="..g_signKey)
	
	if signStr ~= jsonData['sign'] then
		LogFile("error", "vipaddjetton sign error rcvData="..rcvData)
		retMSg['code'] = "error"
		retMSg['msg'] = "验签失败"		
		return luajson.encode(retMSg)		
	end
	
	local pInfo = PlayerModel.GetPlayerInfo(jsonData['userid'])
	if pInfo == nil then
		LogFile("error", "vipaddjetton player not exist rcvData="..rcvData)
		retMSg['code'] = "error"
		retMSg['msg'] = "用户不存在"
		return luajson.encode(retMSg)
	end
	
	local sqlCase = "select money from dy_shopvip where id="..jsonData['vipid']
	mysqlItem:executeQuery(sqlCase)
	
	local sqlData = mysqlItem:fetch()
	if sqlData == nil then
		LogFile("error", "vipaddjetton get vip error rcvData="..rcvData)
		retMSg['code'] = "error"
		retMSg['msg'] = "vip客服被禁用"	
		return luajson.encode(retMSg)		
	end
	
	if tonumber(sqlData) < tonumber(jsonData['amount']) then
		LogFile("error", "vipaddjetton get vip money not enough rcvData="..rcvData)
		retMSg['code'] = "error"
		retMSg['msg'] = "vip金额不足"
		
		return luajson.encode(retMSg)
	end
	
	sqlCase = "update dy_shopvip set money=money-"..jsonData['amount'].." where id="..jsonData['vipid']
	mysqlItem:execute(sqlCase)
	
	PlayerModel.AddJetton(pInfo, jsonData['amount'], "vippay", "VIP充值")
	
	
	LogDispatch.VIPPay(pInfo, jsonData['amount'],jsonData['vipid'] )
	PlayerModel.SendJetton(pInfo)
	return luajson.encode(retMSg)
end


function currtableinfo(rcvData)
	
	local jsonData = luajson.decode(rcvData)
	
	local retList = {}
	if jsonData['gametype'] == nil or jsonData['tabletype'] == nil or jsonData['tableid'] == nil or jsonData['sign'] == nil then
	
		return luajson.encode(retList)
	end	
	
	local signStr = md5("gametype="..jsonData['gametype'].."&tableid="..jsonData['tableid'].."&tabletype="..jsonData['tabletype'].."&key="..g_signKey)
	if signStr ~= jsonData['sign'] then
		LogFile("error", "currinfo sign error rcvData="..rcvData)
	
		return luajson.encode(retMSg)		
	end	
	
	local gameType = tonumber(jsonData['gametype'])
	
	if gameType == g_PszDefine.game_type then
		--拼三张
	elseif gameType == g_douNiuDefine.game_type then
		--抢庄拼十
	elseif gameType == g_DdzDefine.game_type then
		--斗地主
	elseif gameType == g_brnnDefine.game_type then
		--百人牛牛
		local tInfo = BrnnModel.GetTableInfo(jsonData['tableid'])
		
		if tInfo == nil then
			return luajson.encode(retList)
		end
		
		for k,v_userid in ipairs(tInfo.situser) do
			
			local pInfo = PlayerModel.GetPlayerInfo(v_userid)
			local addItem = {}
			addItem['userid'] = v_userid
			addItem['nickname'] = pInfo.nickname
			addItem['jetton'] = pInfo.jetton
			addItem['bankjetton'] = pInfo.bank_jetton
			addItem['gamenum'] = LogConstantly.GetPlayerGameNum(gameType, jsonData['tableid'], v_userid)
			addItem['winjetton'] = LogConstantly.GetGameWinJetton(gameType, jsonData['tableid'], v_userid)
			addItem['pourjetton'] =LogConstantly.GetGamePourJetton(gameType, jsonData['tableid'], v_userid) 
			addItem['isrobot'] = RobotService.IsRobot(v_userid)
			table.insert(retList, addItem)
		end
		
		for k, v_userid in ipairs(tInfo.standuser) do
			local pInfo = PlayerModel.GetPlayerInfo(v_userid)
			local addItem = {}
			addItem['userid'] = v_userid
			addItem['nickname'] = pInfo.nickname
			addItem['jetton'] = pInfo.jetton
			addItem['bankjetton'] = pInfo.bank_jetton
			addItem['gamenum'] = LogConstantly.GetPlayerGameNum(gameType, jsonData['tableid'], v_userid)
			addItem['winjetton'] = LogConstantly.GetGameWinJetton(gameType, jsonData['tableid'], v_userid)
			addItem['pourjetton'] =LogConstantly.GetGamePourJetton(gameType, jsonData['tableid'], v_userid) 
			addItem['isrobot'] = RobotService.IsRobot(v_userid)		
			table.insert(retList, addItem)
		end
		
	elseif gameType == g_barccatatDefine.game_type then
		--百家乐
		local tInfo = BarccatatModel.GetTableInfo(jsonData['tableid'])
		if tInfo == nil then
			return luajson.encode(retList)
		end	
		for k,v_userid in ipairs(tInfo.situser) do
			
			local pInfo = PlayerModel.GetPlayerInfo(v_userid)
			local addItem = {}
			addItem['userid'] = v_userid
			addItem['nickname'] = pInfo.nickname
			addItem['jetton'] = pInfo.jetton
			addItem['bankjetton'] = pInfo.bank_jetton
			addItem['gamenum'] = LogConstantly.GetPlayerGameNum(gameType, jsonData['tableid'], v_userid)
			addItem['winjetton'] = LogConstantly.GetGameWinJetton(gameType, jsonData['tableid'], v_userid)
			addItem['pourjetton'] =LogConstantly.GetGamePourJetton(gameType, jsonData['tableid'], v_userid) 
			addItem['isrobot'] = RobotService.IsRobot(v_userid)
			table.insert(retList, addItem)
		end
		for k, v_userid in ipairs(tInfo.standuser) do
			local pInfo = PlayerModel.GetPlayerInfo(v_userid)
			local addItem = {}
			addItem['userid'] = v_userid
			addItem['nickname'] = pInfo.nickname
			addItem['jetton'] = pInfo.jetton
			addItem['bankjetton'] = pInfo.bank_jetton
			addItem['gamenum'] = LogConstantly.GetPlayerGameNum(gameType, jsonData['tableid'], v_userid)
			addItem['winjetton'] = LogConstantly.GetGameWinJetton(gameType, jsonData['tableid'], v_userid)
			addItem['pourjetton'] =LogConstantly.GetGamePourJetton(gameType, jsonData['tableid'], v_userid) 
			addItem['isrobot'] = RobotService.IsRobot(v_userid)	
			table.insert(retList, addItem)		
		end		
	elseif gameType == g_hongheiDefine.game_type then
		--红黑大战
		local tInfo = HongHeiModel.GetTableInfo(jsonData['tableid'])
		if tInfo == nil then
			return luajson.encode(retList)
		end		
		for k,v_userid in ipairs(tInfo.situser) do
			
			local pInfo = PlayerModel.GetPlayerInfo(v_userid)
			local addItem = {}
			addItem['userid'] = v_userid
			addItem['nickname'] = pInfo.nickname
			addItem['jetton'] = pInfo.jetton
			addItem['bankjetton'] = pInfo.bank_jetton
			addItem['gamenum'] = LogConstantly.GetPlayerGameNum(gameType, jsonData['tableid'], v_userid)
			addItem['winjetton'] = LogConstantly.GetGameWinJetton(gameType, jsonData['tableid'], v_userid)
			addItem['pourjetton'] =LogConstantly.GetGamePourJetton(gameType, jsonData['tableid'], v_userid) 
			addItem['isrobot'] = RobotService.IsRobot(v_userid)
			table.insert(retList, addItem)
		end	
		for k, v_userid in ipairs(tInfo.standuser) do
			local pInfo = PlayerModel.GetPlayerInfo(v_userid)
			local addItem = {}
			addItem['userid'] = v_userid
			addItem['nickname'] = pInfo.nickname
			addItem['jetton'] = pInfo.jetton
			addItem['bankjetton'] = pInfo.bank_jetton
			addItem['gamenum'] = LogConstantly.GetPlayerGameNum(gameType, jsonData['tableid'], v_userid)
			addItem['winjetton'] = LogConstantly.GetGameWinJetton(gameType, jsonData['tableid'], v_userid)
			addItem['pourjetton'] =LogConstantly.GetGamePourJetton(gameType, jsonData['tableid'], v_userid) 
			addItem['isrobot'] = RobotService.IsRobot(v_userid)
			table.insert(retList, addItem)			
		end		
	elseif gameType == g_lhdDefine.game_type then
		--龙虎斗
		local tInfo = LhdModel.GetTableInfo(jsonData['tableid'])
		if tInfo == nil then
			return luajson.encode(retList)
		end		
		for k,v_userid in ipairs(tInfo.situser) do
			
			local pInfo = PlayerModel.GetPlayerInfo(v_userid)
			local addItem = {}
			addItem['userid'] = v_userid
			addItem['nickname'] = pInfo.nickname
			addItem['jetton'] = pInfo.jetton
			addItem['bankjetton'] = pInfo.bank_jetton
			addItem['gamenum'] = LogConstantly.GetPlayerGameNum(gameType, jsonData['tableid'], v_userid)
			addItem['winjetton'] = LogConstantly.GetGameWinJetton(gameType, jsonData['tableid'], v_userid)
			addItem['pourjetton'] =LogConstantly.GetGamePourJetton(gameType, jsonData['tableid'], v_userid) 
			addItem['isrobot'] = RobotService.IsRobot(v_userid)
			table.insert(retList, addItem)
		end	
		for k, v_userid in ipairs(tInfo.standuser) do
			local pInfo = PlayerModel.GetPlayerInfo(v_userid)
			local addItem = {}
			addItem['userid'] = v_userid
			addItem['nickname'] = pInfo.nickname
			addItem['jetton'] = pInfo.jetton
			addItem['bankjetton'] = pInfo.bank_jetton
			addItem['gamenum'] = LogConstantly.GetPlayerGameNum(gameType, jsonData['tableid'], v_userid)
			addItem['winjetton'] = LogConstantly.GetGameWinJetton(gameType, jsonData['tableid'], v_userid)
			addItem['pourjetton'] =LogConstantly.GetGamePourJetton(gameType, jsonData['tableid'], v_userid) 
			addItem['isrobot'] = RobotService.IsRobot(v_userid)
			table.insert(retList, addItem)
		end			
		
	elseif gameType == g_bcbmDefine.game_type then
		--奔驰宝马
		local tInfo = BcbmModel.GetTableInfo(jsonData['tableid'])
		if tInfo == nil then
			return luajson.encode(retList)
		end		
		for k,v_userid in ipairs(tInfo.useridlist) do
			
			local pInfo = PlayerModel.GetPlayerInfo(v_userid)
			local addItem = {}
			addItem['userid'] = v_userid
			addItem['nickname'] = pInfo.nickname
			addItem['jetton'] = pInfo.jetton
			addItem['bankjetton'] = pInfo.bank_jetton
			addItem['gamenum'] = LogConstantly.GetPlayerGameNum(gameType, jsonData['tableid'], v_userid)
			addItem['winjetton'] = LogConstantly.GetGameWinJetton(gameType, jsonData['tableid'], v_userid)
			addItem['pourjetton'] =LogConstantly.GetGamePourJetton(gameType, jsonData['tableid'], v_userid) 
			addItem['isrobot'] = RobotService.IsRobot(v_userid)
			table.insert(retList, addItem)
		end	
	
	elseif gameType == g_fqzsDefine.game_type then
		--飞禽走兽
		local tInfo = FqzsModel.GetTableInfo(jsonData['tableid'])
		if tInfo == nil then
			return luajson.encode(retList)
		end		
		for k,v_userid in ipairs(tInfo.useridlist) do
			
			local pInfo = PlayerModel.GetPlayerInfo(v_userid)
			local addItem = {}
			addItem['userid'] = v_userid
			addItem['nickname'] = pInfo.nickname
			addItem['jetton'] = pInfo.jetton
			addItem['bankjetton'] = pInfo.bank_jetton
			addItem['gamenum'] = LogConstantly.GetPlayerGameNum(gameType, jsonData['tableid'], v_userid)
			addItem['winjetton'] = LogConstantly.GetGameWinJetton(gameType, jsonData['tableid'], v_userid)
			addItem['pourjetton'] =LogConstantly.GetGamePourJetton(gameType, jsonData['tableid'], v_userid) 
			addItem['isrobot'] = RobotService.IsRobot(v_userid)
			table.insert(retList, addItem)
		end			
		
	elseif gameType == g_sicboDefine.game_type then
		--骰宝
		local tInfo = SicboModel.GetTableInfo(jsonData['tableid'])
		if tInfo == nil then
			return luajson.encode(retList)
		end		
		for k,v_userid in ipairs(tInfo.situser) do
			
			local pInfo = PlayerModel.GetPlayerInfo(v_userid)
			local addItem = {}
			addItem['userid'] = v_userid
			addItem['nickname'] = pInfo.nickname
			addItem['jetton'] = pInfo.jetton
			addItem['bankjetton'] = pInfo.bank_jetton
			addItem['gamenum'] = LogConstantly.GetPlayerGameNum(gameType, jsonData['tableid'], v_userid)
			addItem['winjetton'] = LogConstantly.GetGameWinJetton(gameType, jsonData['tableid'], v_userid)
			addItem['pourjetton'] =LogConstantly.GetGamePourJetton(gameType, jsonData['tableid'], v_userid) 
			addItem['isrobot'] = RobotService.IsRobot(v_userid)
			table.insert(retList, addItem)
		end	
		for k, v_userid in ipairs(tInfo.standuser) do
			local pInfo = PlayerModel.GetPlayerInfo(v_userid)
			local addItem = {}
			addItem['userid'] = v_userid
			addItem['nickname'] = pInfo.nickname
			addItem['jetton'] = pInfo.jetton
			addItem['bankjetton'] = pInfo.bank_jetton
			addItem['gamenum'] = LogConstantly.GetPlayerGameNum(gameType, jsonData['tableid'], v_userid)
			addItem['winjetton'] = LogConstantly.GetGameWinJetton(gameType, jsonData['tableid'], v_userid)
			addItem['pourjetton'] =LogConstantly.GetGamePourJetton(gameType, jsonData['tableid'], v_userid) 
			addItem['isrobot'] = RobotService.IsRobot(v_userid)
			table.insert(retList, addItem)			
		end		
	end
	return luajson.encode(retList)
end

function userban(rcvData)
	
	local jsonData = luajson.decode(rcvData)
	local retMSg = {}
	retMSg['code'] = "success"
	retMSg['msg'] = "操作成功"
	if jsonData['userid'] == nil or jsonData['sign'] == nil then
		retMSg['code'] = "error"
		retMSg['msg'] = "参数缺失"
		return luajson.encode(retMSg)
	end
	
	local signStr = md5("userid="..jsonData['userid'].."&key="..g_signKey)
	if signStr ~= jsonData['sign'] then
		retMSg['code'] = "error"
		retMSg['msg'] = "验签失败"
		return luajson.encode(retMSg)		
	end
	
	local pInfo = PlayerModel.GetPlayerInfo(jsonData['userid'])
	if pInfo == nil then
		retMSg['code'] = "error"
		retMSg['msg'] = "用户不存在"
		return luajson.encode(retMSg)			
	end
	
	pInfo.isban = pInfo.isban == 0 and 1 or 0
	PlayerModel.SetPlayerInfo(pInfo)
	local sqlCase = "update dy_player set isban="..pInfo.isban.." where userid="..jsonData['userid']
	mysqlItem:execute(sqlCase)
	
	return luajson.encode(retMSg)
end


function userlimit(rcvData)
	
	local jsonData = luajson.decode(rcvData)
	local retMSg = {}
	retMSg['code'] = "success"
	retMSg['msg'] = "操作成功"
	--if jsonData['userid'] == nil or jsonData['sign'] == nil then
	--	retMSg['code'] = "error"
	--	retMSg['msg'] = "参数缺失"
	--	return luajson.encode(retMSg)
	--end
	
	--local signStr = md5("userid="..jsonData['userid'].."&key="..g_signKey)
	--if signStr ~= jsonData['sign'] then
	--	retMSg['code'] = "error"
	--	retMSg['msg'] = "验签失败"
	--	return luajson.encode(retMSg)		
	--end
	--
	local pInfo = PlayerModel.GetPlayerInfo(jsonData['userid'])
	if pInfo == nil then
		retMSg['code'] = "error"
		retMSg['msg'] = "用户不存在"
		return luajson.encode(retMSg)			
	end
	
	pInfo.silent = pInfo.silent == 0 and 1 or 0
	PlayerModel.SetPlayerInfo(pInfo)
	local sqlCase = "update dy_player set silent="..pInfo.silent.." where userid="..jsonData['userid']
	mysqlItem:execute(sqlCase)
	
	return luajson.encode(retMSg)
end



function getonline(rcvData)
	local jsonData = luajson.decode(rcvData)
	local retList = {}
	retList['online'] = 0
	retList['onrobot'] = 0
	if jsonData['timesamp'] == nil or jsonData['sign'] == nil then
		return luajson.encode(retList)
	end

	local signStr = md5("timesamp="..jsonData['timesamp'].."&key="..g_signKey)
	if jsonData['sign'] ~= signStr then
		return luajson.encode(retList)
	end
	
	local onList = OnlineModel.GetAllOnline()
	retList['online'] = OnlineModel.GetOnlineNum()
	
	
	for k,v in ipairs(onList) do
		if tonumber(v) <= 101000 then
			retList['onrobot'] = retList['onrobot'] + 1
		end
	end
	return luajson.encode(retList)
end


function getplayeringame(rcvData)
	local jsonData = luajson.decode(rcvData)
	local retMSg = {}
	retMSg['code'] = "success"
	retMSg['msg'] = "操作成功"
	retMSg['userid'] = ""
	retMSg['nickname'] = ""
	retMSg['jetton'] = ""
	retMSg['gameType'] = ""
	retMSg['tableid'] = ""
	
	if jsonData['userid'] == nil or jsonData['sign'] == nil then
		retMSg['code'] = "error"
		retMSg['msg'] = "参数缺失"
		return luajson.encode(retMSg)
	end
	
	local signStr = md5("userid="..jsonData['userid'].."&key="..g_signKey)
	if signStr ~= jsonData['sign'] then
		retMSg['code'] = "error"
		retMSg['msg'] = "验签失败"
		return luajson.encode(retMSg)		
	end
	
	local pInfo = PlayerModel.GetPlayerInfo(jsonData['userid'])
	if pInfo == nil then
		retMSg['code'] = "error"
		retMSg['msg'] = "用户不存在"
		return luajson.encode(retMSg)			
	end
	
	local tableid, tabletype = PlayerModel.GetCurrTableID(jsonData['userid'])
	if tabletype ~= 0 and tableid ~= 0 then
		retMSg['gameType'] = tabletype
		retMSg['tableid'] = tableid
	end
	
	retMSg['userid'] = tostring(pInfo.userid)
	retMSg['nickname'] = pInfo.nickname
	retMSg['jetton'] = pInfo.jetton
	
	
	
	return luajson.encode(retMSg)
end

function forceeliminateplayer(rcvData)
	
	local jsonData = luajson.decode(rcvData)
	local retMSg = {}
	retMSg['code'] = "success"
	retMSg['msg'] = "操作成功"
	if jsonData['userid'] == nil or jsonData['sign'] == nil then
		retMSg['code'] = "error"
		retMSg['msg'] = "参数缺失"
		return luajson.encode(retMSg)
	end
	
	local signStr = md5("userid="..jsonData['userid'].."&key="..g_signKey)
	if signStr ~= jsonData['sign'] then
		retMSg['code'] = "error"
		retMSg['msg'] = "验签失败"
		return luajson.encode(retMSg)		
	end
	
	local pInfo = PlayerModel.GetPlayerInfo(jsonData['userid'])
	if pInfo == nil then
		retMSg['code'] = "error"
		retMSg['msg'] = "用户不存在"
		return luajson.encode(retMSg)			
	end
	
	local tableid, tabletype = PlayerModel.GetCurrTableID(jsonData['userid'])
	if tabletype ~= 0 and tableid ~= 0 then
		if tabletype == g_DdzDefine.game_type then
			DdzModel.SetDdzDelGame(tableid)
		elseif tabletype == g_douNiuDefine.game_type then
			DouNiuModel.SetDouNiuDelGame(tableid)
		elseif tabletype == g_PszDefine.game_type then
			PszModel.SetPszDelGame(tableid)
		elseif tabletype == g_barccatatDefine.game_type then
			local msg = BarccatatNewService.getUserPourInfo(tableid,tonumber(jsonData['userid']))
			LogFile("BackstageDeleteTable", "Barccatat: "..msg)
			BarccatatModel.DelUserTableID(tonumber(jsonData['userid']))
		elseif tabletype == g_bcbmDefine.game_type then
			local msg = BcbmNewService.getUserPourInfo(tableid,tonumber(jsonData['userid']))
			LogFile("BackstageDeleteTable", "Bcbm: "..msg)
			BcbmModel.DelUserTableID(tonumber(jsonData['userid']))
		elseif tabletype == g_brnnDefine.game_type then
			local msg = BrnnNewService.getUserPourInfo(tableid,tonumber(jsonData['userid']))
			LogFile("BackstageDeleteTable", "Brnn: "..msg)
			BrnnModel.DelUserTableID(tonumber(jsonData['userid']))
		elseif tabletype == g_fqzsDefine.game_type then
			local msg = FqzsNewService.getUserPourInfo(tableid,tonumber(jsonData['userid']))
			LogFile("BackstageDeleteTable", "Fqzs: "..msg)
			FqzsModel.DelUserTableID(tonumber(jsonData['userid']))
		elseif tabletype == g_lhdDefine.game_type then
			local msg = LhdNewService.getUserPourInfo(tableid,tonumber(jsonData['userid']))
			LogFile("BackstageDeleteTable", "Lhd: "..msg)
			LhdModel.DelUserTableID(tonumber(jsonData['userid']))
		elseif tabletype == g_hongheiDefine.game_type then
			local msg = HongHeiNewService.getUserPourInfo(tableid,tonumber(jsonData['userid']))
			LogFile("BackstageDeleteTable", "HongHei: "..msg)
			HongHeiModel.DelUserTableID(jsonData['userid'])
		elseif tabletype == g_sicboDefine.game_type then
			local msg = SicboNewService.getUserPourInfo(tableid,tonumber(jsonData['userid']))
			LogFile("BackstageDeleteTable", "Sicbo: "..msg)
			SicboModel.DelUserTableID(jsonData['userid'])
		elseif tabletype == g_TexasDefine.game_type then
			TexasModel.SetTexasDelGame(tableid)
		elseif tabletype == g_slhbDefine.game_type then
			local msg = SlhbNewService.getUserPourInfo(tableid,tonumber(jsonData['userid']))
			LogFile("BackstageDeleteTable", "Slhb: "..msg)
			SlhbModel.DelUserTableID(jsonData['userid'])    
        elseif tabletype == g_yqsDefine.game_type then
            local msg = YqsNewService.getUserInfo(tableid,tonumber(jsonData['userid']))
            LogFile("BackstageDeleteTable", "Yqs: "..msg)
			YqsModel.DelUserTableID(jsonData['userid'])
        elseif tabletype == g_caipiaoDefine.xyft_game_type then
			CaiPiaoXyftModel.DelUserTableID(jsonData['userid'])
        elseif tabletype == g_caipiaoDefine.bjsc_game_type then
			CaiPiaoBjscModel.DelUserTableID(jsonData['userid'])
        elseif tabletype == g_caipiaoDefine.lhc_game_type then
			CaiPiaoLhcModel.DelUserTableID(jsonData['userid'])
        elseif tabletype == g_cjmpDefine.game_type then
			local msg = CjmpNewService.getUserPourInfo(tableid,tonumber(jsonData['userid']))
			LogFile("BackstageDeleteTable", "Cjmp: "..msg)
			CjmpModel.DelUserTableID(jsonData['userid'])
        elseif tabletype == g_sxyxDefine.game_type then
			SxyxModel.DelUserTableID(jsonData['userid'])
		end
	end
	
	
	
	
	return luajson.encode(retMSg)
end

