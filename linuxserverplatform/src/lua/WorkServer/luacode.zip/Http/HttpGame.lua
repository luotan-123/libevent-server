
module("HttpGame", package.seeall)

function index(operateIndex, buffer)
	MailModel.LoadGMMail()
 	return "success"
end


--该函数是GM给玩家发送物品的时候用
function buydiamond(rcvData)
	if rcvData == nil then
		return "error";
	end

	if rcvData == nil then
		LogFile("payerror","recv data orderid is nil")
		return "error";
	end
	
	local jsonArr = luajson.decode(rcvData)
	
	
	local function updateMysql(status)
		local sqlCase = "update dy_order set status="..status.." where id="..jsonArr['orderid']
		mysqlItem:execute(sqlCase)
		--SqlServer.rpush(sqlCase)
	end
	
	if jsonArr["orderid"] == nil then
		LogFile("payerror","recv data orderid is nil")

		return "error";
	end

	if jsonArr["ch_orderid"] == nil then
		LogFile("payerror","recv data ch_orderid is nil")

		return "error";
	end	
	
	local signStr = md5("orderid="..jsonArr["orderid"].."&ch_orderid="..jsonArr["ch_orderid"].."&key="..g_signKey)
	
	if signStr ~= jsonArr['sign'] then
		
		LogFile("payerror","recv data sign error rcvData="..rcvData)
		return "error"
	end



	local sqlCase = "select id,total_fee,userid,state from dy_orderinfo where ch_orderid='"..jsonArr["ch_orderid"].."' and orderid="..jsonArr["ch_orderid"]
	

	mysqlItem:executeQuery(sqlCase)
	
	
	local sqlData = mysqlItem:fetch({})
	if sqlData == nil then
		
		LogFile("payerror","recv data item not exist rcvData="..rcvData)
		return "error"		
		
	end
	
	
	local pInfo = PlayerModel.GetPlayerInfo(sqlData[3])
	
	if pInfo == nil then
		LogFile("payerror", "recv data pInfo is nil, orderid="..jsonArr["orderid"]..",userid="..sqlData[3])
		updateMysql(-5)
		return "success"
	end

	PlayerModel.AddMoney(pInfo, tonumber(sqlData[2]), "pay", "支付购买")

	PlayerModel.SendMoneyJetton(pInfo)
	PlayerModel.SetPlayerInfo(pInfo)
	updateMysql(1)
		
	LogServer.PaySuccess( pInfo.userid,  tonumber(sqlData[2]))
	
	sqlCase = "update dy_orderinfo set state=2, remark='发货成功' where id="..sqlData[1]
	mysqlItem:execute(sqlCase)
	return "success"
end

--给玩家添加附件
function usermail(rcvData)
	if rcvData == nil then
		return "success";
	end
	local jsonArr = luajson.decode(rcvData)
	--
	--luaDump(jsonArr)
	MailModel.LoadMailList(jsonArr["userid"])
	
	NoticeModel.SendNotice(jsonArr["userid"], g_noticeType.mail_unread)	
	
	return "success";
end

--给玩家添加附件
function usermailadjunct(rcvData)
	if rcvData == nil then
		
		return "success";
	end
	local jsonArr = luajson.decode(rcvData)
	--
	--luaDump(jsonArr)
	MailModel.LoadMailList(jsonArr["userid"])
	
	NoticeModel.SendNotice(jsonArr["userid"], g_noticeType.mail_unget)	
	
	return "success";
end


function shoplist(rcvData)


	--MailModel.LoadGMMail()

	local dataList = {}
	for k,v in pairs(db_shop) do
		if type(k) == "number"  and tonumber(v[db_shopIndex.isexist]) > 0 then
			table.insert(dataList, v)
		end
	end
	
	table.sort(dataList, function(a, b)
		return tonumber(a[1]) < tonumber(b[1])
	end)
	dataList = luajson.encode(dataList)
 	
	return dataList
end

function goodslist(rcvData)

	local dataList = {}
	for k,v in pairs(db_goods) do
		if type(k) == "number"  and tonumber(v[db_goodsIndex.isexist]) > 0 then
			table.insert(dataList, v)
		end
	end
	
	table.sort(dataList, function(a, b)
		return tonumber(a[1]) < tonumber(b[1])
	end)
	dataList = luajson.encode(dataList)
 	return dataList
end

function give(recvData)
	
	local jsonArr = luajson.decode(recvData)
	
	local signStrTemp = 'userid='..jsonArr['userid']..'&amount='..jsonArr['amount']..'&sign=w2ctsethjcyu7r9b'
	local sign = md5(signStrTemp)

	if sign ~= jsonArr['sign'] then
		return 'error'
	end
	
	local pInfo = PlayerModel.GetPlayerInfo(jsonArr["userid"])
	if pInfo == nil then
		return 'error'
	end
	PlayerModel.AddJetton(pInfo,jsonArr["amount"],"give","give")
	PlayerModel.SetPlayerInfo(pInfo)

	PlayerModel.SendJetton(pInfo)	
	return "success"
end

function  recycle( recvData )
	local jsonArr = luajson.decode(recvData)
	local signStrTemp = 'userid='..jsonArr['userid']..'&amount='..jsonArr['amount']..'&sign=w2ctsethjcyu7r9b'
	local sign = md5(signStrTemp)

	if sign ~= jsonArr['sign'] then
		return 'error'
	end
	local pInfo = PlayerModel.GetPlayerInfo(jsonArr["userid"])
	if tonumber(pInfo.jetton) < tonumber(jsonArr["amount"]) then
		--如果对方的钱不够
		return error
	end
	PlayerModel.DecJetton(pInfo, jsonArr["amount"],"jetton","recycle")
	PlayerModel.SetPlayerInfo(pInfo)
	PlayerModel.SendJetton(pInfo)
	return "success"
end

function  zhuangzhang( recvData )
	local jsonArr = luajson.decode(recvData)
	local signStrTemp = 'amount='..jsonArr['amount']..'&userid='..jsonArr['userid']..'&key=w2ctsethjcyu7r9b'
	local sign = md5(signStrTemp)

	if sign ~= jsonArr['sign'] then
		LogFile("zhuangzhang", "zhuangzhang sign error, recvData="..recvData)
		return 'error'
	end
	local pInfo = PlayerModel.GetPlayerInfo(jsonArr["userid"])
	if pInfo == nil then
		--如果对方的钱不够
		return 'fail'
	end
	
	if tonumber(jsonArr['amount']) < 0  then
		if math.abs(tonumber(jsonArr['amount'])) > tonumber(pInfo.jetton) then
			return 'fail'
		end
		PlayerModel.DecJetton(pInfo, math.abs(jsonArr["amount"]),"zhuangzhang","转出")
	else
		PlayerModel.AddJetton(pInfo, tonumber(jsonArr["amount"]),"zhuangzhang","转入")
	end
	
	--local sqlCase = "insert into log_gift"
	
	PlayerModel.SetPlayerInfo(pInfo)
	PlayerModel.SendJetton(pInfo)
	return "success"
end

function  jiangchi( recvData )
	local jsonArr = luajson.decode(recvData)

	local JiangList = {}
	
	local gameType = tonumber(jsonArr['gametype'])
	if gameType == 2500 then
		if BrnnModel ~= nil then
			BrnnModel.SetPondUpdate(tonumber(jsonArr['tabletype']))
		end
	elseif gameType == 3000 then
		if DouNiuModel ~= nil then
			DouNiuModel.SetPondUpdate(tonumber(jsonArr['tabletype']))
		end		
	elseif gameType == 3300 then
		if PszModel ~= nil then
			PszModel.SetPondUpdate(tonumber(jsonArr['tabletype']))
		end
	elseif gameType == 3500 then
		if ForestModel ~= nil then
			ForestModel.SetPondUpdate(tonumber(jsonArr['tabletype']))
		end
	elseif gameType == 3600 then
		if FruitModel ~= nil then
			FruitModel.SetPondUpdate(tonumber(jsonArr['tabletype']))
		end	
	elseif gameType == 3900 then
		if DdzModel ~= nil then
			DdzModel.SetPondUpdate(tonumber(jsonArr['tabletype']))
		end
	elseif gameType == 4100 then
		if ErshModel ~= nil then
			ErshModel.SetPondUpdate(tonumber(jsonArr['tabletype']))
		end
	elseif gameType == 4200 then
		if BcbmModel ~= nil then
			BcbmModel.SetPondUpdate(tonumber(jsonArr['tabletype']))
		end
	elseif gameType == 4300 then
		if FqzsModel ~= nil then
			FqzsModel.SetPondUpdate(tonumber(jsonArr['tabletype']))
		end
	elseif gameType == 4400 then
		if BarccatatModel ~= nil then
			BarccatatModel.SetPondUpdate(tonumber(jsonArr['tabletype']))
		end
	elseif gameType == 4500 then
		if LhdbModel ~= nil then
			--BarccatatModel.SetPondUpdate(jsonArr['tabletype'])
		end
	elseif gameType == 4600 then
		if TgpdModel ~= nil then
			
		end
	elseif gameType == 4700 then
		if LkpyModel ~= nil then
			LkpyPond.LoadPondInfo(tonumber(jsonArr['tabletype']), tonumber(jsonArr['gradetype']))
		end
	elseif gameType == 4900 then
		if YqsPond ~= nil then
			YqsPond.LoadPondInfo(tonumber(jsonArr['tabletype']), tonumber(jsonArr['gradetype']))
		end		
	elseif gameType == 5300 then
		if LhdModel ~= nil then
			--LhdModel.LoadPondInfo(tonumber(jsonArr['tabletype']))
			LhdModel.SetPondUpdate(tonumber(jsonArr['tabletype']))
		end
	elseif gameType == 3700 then
		if HongHeiModel ~= nil then
			HongHeiModel.SetPondUpdate(tonumber(jsonArr['tabletype']))
		end
	elseif gameType == 5400 then
		if CjmpModel ~= nil then
			CjmpModel.SetPondUpdate(tonumber(jsonArr['tabletype']))
		end
	elseif gameType == 5600 then
		if SicboModel ~= nil then
			SicboModel.SetPondUpdate(tonumber(jsonArr['tabletype']))
		end
	end

	local i = 0
	return 'success'
end

function addbroadcast(rcvData)
	
	BroadCastModel.Init()
	
end

function delbroadcast(rcvData)
	BroadCastModel.Init()
end

function broadcast(rcvData)
	
	BroadCastModel.Init()
	
end

function tablelist(rcvData)

	local jsonArr = luajson.decode(rcvData)
	local tableList = {}

	if jsonArr['type'] == 'ernn' then
		if DouNiuModel ~= nil then
			local IDList = DouNiuModel.GetTableList()
			for k_id,v_id in ipairs(IDList) do
				local tInfo = DouNiuModel.GetTableInfo(v_id)
				if tInfo ~= nil then
					local addItem = {}
					addItem['tableid'] = tInfo.tableid
					
					for k,v in ipairs(tInfo.situser) do
						addItem['userid'..k] = v.userid
						addItem['nickname'..k] = v.nickname
						addItem['jetton'..k] = v.carryjetton
					end
					table.insert(tableList, addItem)
				end
			end			
		end
	elseif jsonArr['type'] == 'ersh' then
		if ErshModel ~= nil then
			local IDList = ErshModel.GetTableList()
			for k_id,v_id in ipairs(IDList) do
				local tInfo = ErshModel.GetTableInfo(v_id)
				if tInfo ~= nil then
					local addItem = {}
					addItem['tableid'] = tInfo.tableid
					
					for k,v in ipairs(tInfo.situser) do
						addItem['userid'..k] = v.userid
						addItem['nickname'..k] = v.nickname
						addItem['jetton'..k] = v.jifen
					end
					table.insert(tableList, addItem)
				end
			end			
		end	
	elseif jsonArr['type'] == 'psz' then
		if PszModel ~= nil then
			local IDList = PszModel.GetTableList()
			for k_id,v_id in ipairs(IDList) do
				local tInfo = PszModel.GetTableInfo(v_id)
				if tInfo ~= nil then
					local addItem = {}
					addItem['tableid'] = tInfo.tableid
					for k,v in ipairs(tInfo.situser) do
						addItem['userid'..k] = v.userid						
						addItem['nickname'..k] = v.nickname
						addItem['jetton'..k] = v.jifen
					end
					table.insert(tableList, addItem)
				end
			end			
		end		
	end
	return luajson.encode(tableList)
end

function tableinfo(rcvData)
	local jsonArr = luajson.decode(rcvData)
	local tableInfo = {}

	if jsonArr['type'] == 'ernn' then
		if DouNiuModel ~= nil then

			local tInfo = DouNiuModel.GetTableInfo(jsonArr['tableid'])
			if tInfo ~= nil then

				tableInfo['tableid'] = tInfo.tableid
				tableInfo['userlist'] = {}
				for k,v in ipairs(tInfo.situser) do
					local userItem = {}
					userItem['userid'] = v.userid
					userItem['nickname'] = v.nickname
					userItem['jetton'] = v.carryjetton
					table.insert(tableInfo['userlist'], userItem)
				end
			end
		end
	elseif jsonArr['type'] == 'ersh' then
		if ErshModel ~= nil then
			local tInfo = ErshModel.GetTableInfo(jsonArr['tableid'])
			if tInfo ~= nil then
				tableInfo['tableid'] = tInfo.tableid
				tableInfo['userlist'] = {}
				for k,v in ipairs(tInfo.situser) do
					local userItem = {}
					userItem['userid'] = v.userid
					userItem['nickname'] = v.nickname
					userItem['jetton'] = v.jifen
					table.insert(tableInfo['userlist'], userItem)
				end
			end
		end
	elseif jsonArr['type'] == 'psz' then
		if PszModel ~= nil then
			local tInfo = PszModel.GetTableInfo(jsonArr['tableid'])
			if tInfo ~= nil then
				tableInfo['tableid'] = tInfo.tableid
				tableInfo['userlist'] = {}
				for k,v in ipairs(tInfo.situser) do
					local userItem = {}
					userItem['userid'] = v.userid
					userItem['nickname'] = v.nickname
					userItem['jetton'] = v.jifen
					table.insert(tableInfo['userlist'], userItem)
				end
			end
		end		
	end
	return luajson.encode(tableInfo)
end



function bairenlist()
	local tGradeList = {"初级场","中级场","高级场","至尊场","富贵场","百赢场"}
	local tableList = {}
	if BrnnService ~= nil then
		--百人牛牛存在
		tGradeList = {"荣耀厅01","荣耀厅02","传奇厅01","传奇厅02","富贵厅01","富贵厅02"}
		for k,v in ipairs(g_brnnDefine.init_data) do
			local tInfo = BrnnModel.GetTableInfo(v['tableid'][1])
			if tInfo ~= nil then
				local addItem = {}
				addItem["name"] = "百人牛牛"
				addItem["grade"] = tGradeList[k]
				addItem["tableid"] = v['tableid'][1]
				addItem["type"] = "brnn"
				local robotNum = 0
				local userNum = 0
				for k_sit,v_sit in ipairs(tInfo.situser) do
					if v_sit ~= 0 then
						if true == RobotService.IsRobot(v_sit) then
							robotNum = robotNum + 1
						else
							userNum = userNum + 1
						end
					end
				end
				for k_stand,v_stand in ipairs(tInfo.standuser) do
					if true == RobotService.IsRobot(v_stand) then
						robotNum = robotNum + 1
					else
						userNum = userNum + 1
					end
				end
				addItem['robotNum'] = robotNum
				addItem['userNum'] = userNum
				addItem['bankerid'] = tInfo.bankerid
				addItem['bankername'] = tInfo.bankername
				addItem['maxrobotnum'] = tInfo.maxrobotnum
				table.insert(tableList, addItem)
			end
		end		
	end
	if BarccatatModel ~= nil then
		--
		tGradeList = {"荣耀厅01","荣耀厅02","传奇厅01","传奇厅02","富贵厅01","富贵厅02"}
		for k,v in ipairs(g_barccatatDefine.init_data) do
			local tInfo = BarccatatModel.GetTableInfo(v['tableid'][1])
			if tInfo ~= nil then
				local addItem = {}
				addItem["name"] = "百家乐"
				addItem["grade"] = tGradeList[k]
				addItem["tableid"] = v['tableid'][1]
				addItem["type"] = "barccatat"
				local robotNum = 0
				local userNum = 0
				for k_sit,v_sit in ipairs(tInfo.situser) do
					if v_sit ~= 0 then
						if true == RobotService.IsRobot(v_sit) then
							robotNum = robotNum + 1
						else
							userNum = userNum + 1
						end
					end
				end
				for k_stand,v_stand in ipairs(tInfo.standuser) do
					if true == RobotService.IsRobot(v_stand) then
						robotNum = robotNum + 1
					else
						userNum = userNum + 1
					end
				end
				addItem['robotNum'] = robotNum
				addItem['userNum'] = userNum
				addItem['bankerid'] = tInfo.bankerid
				addItem['bankername'] = tInfo.bankername
				addItem['maxrobotnum'] = tInfo.maxrobotnum
				table.insert(tableList, addItem)
			end
		end			
	end

	if HongHeiModel ~= nil then
		tGradeList = {"荣耀厅01","荣耀厅02","荣耀厅03","荣耀厅04","荣耀厅05","荣耀厅06"}
		for k,v in ipairs(g_hongheiDefine.init_data) do
			local tInfo = HongHeiModel.GetTableInfo(v['tableid'][1])
			if tInfo ~= nil then
				local addItem = {}
				addItem["name"] = "红黑大战"
				addItem["grade"] = tGradeList[k]
				addItem["tableid"] = v['tableid'][1]
				addItem["type"] = "honghei"
				local robotNum = 0
				local userNum = 0
				for k_sit,v_sit in ipairs(tInfo.situser) do
					if v_sit ~= 0 then
						if true == RobotService.IsRobot(v_sit) then
							robotNum = robotNum + 1
						else
							userNum = userNum + 1
						end
					end
				end
				for k_stand,v_stand in ipairs(tInfo.standuser) do
					if true == RobotService.IsRobot(v_stand) then
						robotNum = robotNum + 1
					else
						userNum = userNum + 1
					end
				end
				addItem['robotNum'] = robotNum
				addItem['userNum'] = userNum
				addItem['bankerid'] = tInfo.bankerid
				addItem['bankername'] = tInfo.bankername
				addItem['maxrobotnum'] = tInfo.maxrobotnum
				table.insert(tableList, addItem)
			end
		end			
	end
	
	if LhdModel ~= nil then
		tGradeList = {"荣耀厅01","荣耀厅02","荣耀厅03","荣耀厅04","荣耀厅05","荣耀厅06"}
		for k,v in ipairs(g_lhdDefine.init_data) do
			local tInfo = LhdModel.GetTableInfo(v['tableid'][1])
			if tInfo ~= nil then
				local addItem = {}
				addItem["name"] = "龙虎斗"
				addItem["grade"] = tGradeList[k]
				addItem["tableid"] = v['tableid'][1]
				addItem["type"] = "lhd"
				local robotNum = 0
				local userNum = 0
				for k_sit,v_sit in ipairs(tInfo.situser) do
					if v_sit ~= 0 then
						if true == RobotService.IsRobot(v_sit) then
							robotNum = robotNum + 1
						else
							userNum = userNum + 1
						end
					end
				end
				for k_stand,v_stand in ipairs(tInfo.standuser) do
					if true == RobotService.IsRobot(v_stand) then
						robotNum = robotNum + 1
					else
						userNum = userNum + 1
					end
				end
				addItem['robotNum'] = robotNum
				addItem['userNum'] = userNum
				addItem['bankerid'] = tInfo.bankerid
				addItem['bankername'] = tInfo.bankername
				addItem['maxrobotnum'] = tInfo.maxrobotnum
				table.insert(tableList, addItem)
			end
		end			
	end

	
	
	if BcbmModel ~= nil then
		--
		tGradeList = {"荣耀厅01","荣耀厅02","传奇厅01","传奇厅02","富贵厅01","富贵厅02"}
		for k,v in ipairs(g_bcbmDefine.init_data) do
			local tInfo = BcbmModel.GetTableInfo(v['tableid'][1])
			if tInfo ~= nil then
				local addItem = {}
				addItem["name"] = "奔驰宝马"
				addItem["grade"] = tGradeList[k]
				addItem["tableid"] = v['tableid'][1]
				addItem["type"] = "bcbm"
				local robotNum = 0
				local userNum = 0
				for k_stand,v_stand in ipairs(tInfo.useridlist) do
					if true == RobotService.IsRobot(v_stand) then
						robotNum = robotNum + 1
					else
						userNum = userNum + 1
					end
				end
				addItem['robotNum'] = robotNum
				addItem['userNum'] = userNum
				addItem['bankerid'] = tInfo.bankerid
				addItem['bankername'] = tInfo.bankername	
				addItem['maxrobotnum'] = tInfo.maxrobotnum			
				table.insert(tableList, addItem)
			end
		end			
	end
	if FqzsModel ~= nil then
		--
		tGradeList = {"荣耀厅01","荣耀厅02","传奇厅01","传奇厅02","富贵厅01","富贵厅02"}
		for k,v in ipairs(g_fqzsDefine.init_data) do
			local tInfo = FqzsModel.GetTableInfo(v['tableid'][1])
			if tInfo ~= nil then
				local addItem = {}
				addItem["name"] = "狮子王国"
				addItem["grade"] = tGradeList[k]
				addItem["tableid"] = v['tableid'][1]
				addItem["type"] = "fqzs"
				local robotNum = 0
				local userNum = 0
				for k_stand,v_stand in ipairs(tInfo.useridlist) do
					if true == RobotService.IsRobot(v_stand) then
						robotNum = robotNum + 1
					else
						userNum = userNum + 1
					end
				end
				addItem['robotNum'] = robotNum
				addItem['userNum'] = userNum
				addItem['bankerid'] = tInfo.bankerid
				addItem['bankername'] = tInfo.bankername
				addItem['maxrobotnum'] = tInfo.maxrobotnum				
				table.insert(tableList, addItem)
			end
		end			
	end
	
	if SicboModel ~= nil then
		--
		tGradeList = {"荣耀厅01","荣耀厅02","传奇厅01","传奇厅02","富贵厅01","富贵厅02"}
		for k,v in ipairs(g_sicboDefine.init_data) do
			local tInfo = SicboModel.GetTableInfo(v['tableid'][1])
			if tInfo ~= nil then
				local addItem = {}
				addItem["name"] = "骰宝"
				addItem["grade"] = tGradeList[k]
				addItem["tableid"] = v['tableid'][1]
				addItem["type"] = "sicbo"
				local robotNum = 0
				local userNum = 0
				for k_stand,v_stand in ipairs(tInfo.standuser) do
					if true == RobotService.IsRobot(v_stand) then
						robotNum = robotNum + 1
					else
						userNum = userNum + 1
					end
				end

				
				addItem['robotNum'] = robotNum
				addItem['userNum'] = userNum
				addItem['bankerid'] = tInfo.bankerid
				addItem['bankername'] = tInfo.bankername
				addItem['maxrobotnum'] = tInfo.maxrobotnum
				table.insert(tableList, addItem)
			end
		end			
	end

	
	return luajson.encode(tableList)	
end


function setbairenrobot(rcvData)


	
	local jsonArr = luajson.decode(rcvData)
	
	if jsonArr['type'] == "brnn" then
		
		ThreadManager.BrnnLock(jsonArr['tableid'])
		local tInfo = BrnnModel.GetTableInfo(jsonArr['tableid'])
		if tInfo ~= nil then
			tInfo.maxrobotnum = tonumber(jsonArr['robotnum'])
			BrnnModel.SetTableInfo(tInfo, 1)
		end
		ThreadManager.BrnnUnLock(jsonArr['tableid'])
	elseif jsonArr['type'] == "barccatat" then
		
		ThreadManager.BarccatatLock(jsonArr['tableid'])
		local tInfo = BarccatatModel.GetTableInfo(jsonArr['tableid'])
		if tInfo ~= nil then
			tInfo.maxrobotnum = tonumber(jsonArr['robotnum'])
			BarccatatModel.SetTableInfo(tInfo, 1)
		end
		ThreadManager.BarccatatUnLock(jsonArr['tableid'])
	elseif jsonArr['type'] == "bcbm" then
		
		ThreadManager.BcbmLock(jsonArr['tableid'])
		local tInfo = BcbmModel.GetTableInfo(jsonArr['tableid'])
		if tInfo ~= nil then
			tInfo.maxrobotnum = tonumber(jsonArr['robotnum'])
			BcbmModel.SetTableInfo(tInfo, 1)
		end
		ThreadManager.BcbmUnLock(jsonArr['tableid'])
	elseif jsonArr['type'] == "fqzs" then
		
		ThreadManager.FqzsLock(jsonArr['tableid'])
		local tInfo = FqzsModel.GetTableInfo(jsonArr['tableid'])
		if tInfo ~= nil then
			tInfo.maxrobotnum = tonumber(jsonArr['robotnum'])
			FqzsModel.SetTableInfo(tInfo, 1)
		end
		ThreadManager.FqzsUnLock(jsonArr['tableid'])
	elseif jsonArr['type'] == "fruit" then
		
		ThreadManager.FruitLock(jsonArr['tableid'])
		local tInfo = FruitModel.GetTableInfo(jsonArr['tableid'])
		if tInfo ~= nil then
			tInfo.maxrobotnum = tonumber(jsonArr['robotnum'])
			FruitModel.SetTableInfo(tInfo, 1)
		end
		ThreadManager.FruitUnLock(jsonArr['tableid'])	
	elseif jsonArr['type'] == "honghei" then
		ThreadManager.HongHeiLock(jsonArr['tableid'])
		local tInfo = HongHeiModel.GetTableInfo(jsonArr['tableid'])
		if tInfo ~= nil then
			tInfo.maxrobotnum = tonumber(jsonArr['robotnum'])
			HongHeiModel.SetTableInfo(tInfo)
		end
		ThreadManager.HongHeiUnLock(jsonArr['tableid'])
	elseif jsonArr['type'] == "lhd" then
		ThreadManager.LhdLock(jsonArr['tableid'])
		local tInfo = LhdModel.GetTableInfo(jsonArr['tableid'])
		if tInfo ~= nil then
			tInfo.maxrobotnum = tonumber(jsonArr['robotnum'])
			LhdModel.SetTableInfo(tInfo)
		end
		ThreadManager.LhdUnLock(jsonArr['tableid'])	
	elseif jsonArr['type'] == "sicbo" then
		ThreadManager.SicboLock(jsonArr['tableid'])
		local tInfo = SicboModel.GetTableInfo(jsonArr['tableid'])
		if tInfo ~= nil then
			tInfo.maxrobotnum = tonumber(jsonArr['robotnum'])
			SicboModel.SetTableInfo(tInfo)
		end
		ThreadManager.SicboUnLock(jsonArr['tableid'])		
	end
	return "success"
end

function setcard(rcvData)
	local jsonArr = luajson.decode(rcvData)
	if jsonArr['type'] == "ernn" then
		--斗牛
		local cardList = {}
		for k,v in pairs(jsonArr) do
			if k == v then
				table.insert(cardList, k)
			end
		end
		if jsonArr['tableid'] ~= nil and jsonArr['userid'] ~= nil and #cardList > 0 then
			DouNiuModel.SetDebugNextCard(jsonArr['tableid'],jsonArr['userid'],luajson.encode(cardList))
		end
	elseif jsonArr['type'] == "ersh" then
		local cardList = {}
		for k,v in pairs(jsonArr) do
			if k == v then
				table.insert(cardList, k)
			end
		end
		if jsonArr['tableid'] ~= nil and jsonArr['userid'] ~= nil and #cardList > 0 then
			ErshModel.SetDebugNextCard(jsonArr['tableid'],jsonArr['userid'],luajson.encode(cardList))
		end		
	elseif jsonArr['type'] == "psz" then
		local cardList = {}
		for k,v in pairs(jsonArr) do
			if k == v then
				table.insert(cardList, k)
			end
		end
		if jsonArr['tableid'] ~= nil and jsonArr['userid'] ~= nil and #cardList > 0 then
			PszModel.SetDebugNextCard(jsonArr['tableid'],jsonArr['userid'],luajson.encode(cardList))
		end
	end
	
end

function notify(rcvData)
	
	if rcvData == nil then
		return "error";
	end

	if rcvData == nil then
		LogFile("payerror","recv data orderid is nil")
		return "error";
	end
	
	local jsonArr = luajson.decode(rcvData)
	
	
	local function updateMysql(status)
		local sqlCase = "update dy_order set status="..status.." where id="..jsonArr['orderid']
		mysqlItem:execute(sqlCase)
	end
	
	if jsonArr["orderid"] == nil then
		LogFile("payerror","recv data orderid is nil")
		return "error";
	end

	if jsonArr["ch_orderid"] == nil then
		LogFile("payerror","recv data ch_orderid is nil")

		return "error";
	end	
	
	local signStr = md5("orderid="..jsonArr["orderid"].."&ch_orderid="..jsonArr["ch_orderid"].."&key="..g_signKey)
	
	if signStr ~= jsonArr['sign'] then
		
		LogFile("payerror","recv data sign error rcvData="..rcvData)
		return "error"
	end


	local sqlCase = "select id,total_fee,userid,state from dy_orderinfo where ch_ordderid='"..jsonArr["ch_orderid"].."' and orderid="..jsonArr["orderid"]
	

	mysqlItem:executeQuery(sqlCase)
	
	
	local sqlData = mysqlItem:fetch({})
	if sqlData == nil then
		
		LogFile("payerror","recv data item not exist rcvData="..rcvData)
		return "error"		
		
	end
	
	if tonumber(sqlData[4]) ~= 0 then
		LogFile("payerror","recv data state error not exist rcvData="..rcvData..",userid="..sqlData[3]..",state="..sqlData[4])
		return "error"			
	end
	
	if tonumber(sqlData[4]) == 2 then
		LogFile("payerror","recv data state error not exist rcvData="..rcvData..",userid="..sqlData[3]..",state="..sqlData[4])
		return "error"			
	end		
	local pInfo = PlayerModel.GetPlayerInfo(sqlData[3])
	
	if pInfo == nil then
		LogFile("payerror", "recv data pInfo is nil, orderid="..jsonArr["orderid"]..",userid="..sqlData[3])
		updateMysql(-5)
		return "success"
	end

	PlayerModel.AddJetton(pInfo, tonumber(sqlData[2]), "pay", "支付购买")

	PlayerModel.SendJetton(pInfo)
	PlayerModel.SetPlayerInfo(pInfo)
	updateMysql(1)
			
	LogDispatch.PaySuccess(pInfo, tonumber(sqlData[2]), jsonArr["ch_orderid"])
	sqlCase = "update dy_orderinfo set state=2, remark='发货成功' where id="..sqlData[1]
	mysqlItem:execute(sqlCase)
	return "success"
end

function bairenuserlist(rcvData)
	local jsonArr = luajson.decode(rcvData)
	
	local retUserList = {}
	local function addUserItem(userID)
		if true == RobotService.IsRobot(userID) then
			return
		end
		local pInfo = PlayerModel.GetPlayerInfo(userID)
		
		local addItem = {}
		addItem['userid'] = pInfo.userid
		addItem['nickname'] = pInfo.nickname
		addItem['jetton'] = pInfo.jetton
		table.insert(retUserList, addItem)
	end
	
	if jsonArr['type'] == "brnn" then
		

		local tInfo = BrnnModel.GetTableInfo(jsonArr['tableid'])
		
		
		for k,v in ipairs(tInfo.situser) do
			addUserItem(v)
		end
		for k,v in ipairs(tInfo.standuser) do
			addUserItem(v)
		end

	elseif jsonArr['type'] == "barccatat" then
		
		local tInfo = BarccatatModel.GetTableInfo(jsonArr['tableid'])
		for k,v in ipairs(tInfo.situser) do
			addUserItem(v)
		end
		for k,v in ipairs(tInfo.standuser) do
			addUserItem(v)
		end
	elseif jsonArr['type'] == "bcbm" then
		

		local tInfo = BcbmModel.GetTableInfo(jsonArr['tableid'])

		for k,v in ipairs(tInfo.useridlist) do
			addUserItem(v)
		end
	elseif jsonArr['type'] == "fqzs" then
		

		local tInfo = FqzsModel.GetTableInfo(jsonArr['tableid'])

		for k,v in ipairs(tInfo.useridlist) do
			addUserItem(v)
		end
	elseif jsonArr['type'] == "fruit" then
		

		local tInfo = FruitModel.GetTableInfo(jsonArr['tableid'])
		
		for k,v in ipairs(tInfo.useridlist) do
			addUserItem(v)
		end		
	elseif jsonArr['type'] == "forest" then
		local tInfo = ForestModel.GetTableInfo(jsonArr['tableid'])
		for k,v in ipairs(tInfo.useridlist) do
			addUserItem(v)
		end				
	end
	--return "success"	
	return luajson.encode(retUserList)
end


function drawrefuse(rcvData)
	--state = 1 申请中。
	--state = 2 驳回中
	--state = 3 成功
	--state = 4 失败
	--state = 5 驳回
	local jsonArr = luajson.decode(rcvData)
	
	local sqlCase = " select userid,drawjetton from ag_drawmoney where state=2 and id="..jsonArr['id']
	mysqlItem:executeQuery(sqlCase)
	local sqlData = mysqlItem:fetch({})
	if sqlData == nil then
		return "error"
	end
	

	
	local pInfo = PlayerModel.GetPlayerInfo(sqlData[1])
	if pInfo == nil then
		return "error"
	end
	
	PlayerModel.AddJetton(pInfo, tonumber(sqlData[2]), "pay", "refuse money="..sqlData[2])
	
	PlayerModel.SetPlayerInfo(pInfo)
	PlayerModel.SendJetton(pInfo)
	
	
	if jsonArr['remark'] == nil then
		sqlCase = " update ag_drawmoney set state=5,opttime='"..TimeUtils.GetTimeString().."' where id="..jsonArr['id']
	else
		sqlCase = " update ag_drawmoney set state=5,opttime='"..TimeUtils.GetTimeString().."',remark='"..jsonArr['remark'].."' where id="..jsonArr['id']
	end
	
	
	mysqlItem:execute(sqlCase)
	

	
	LogDispatch.WithDrawRefuse(pInfo, tonumber(sqlData[2]), jsonArr['remark'], jsonArr['id'] )
	return "success"
end

function setgamestate(rcvData)
	
	local jsonData = luajson.decode(rcvData)
	local retMSg = {}
	retMSg['code'] = "success"
	retMSg['msg'] = "操作成功"
	if jsonData['gametype'] == nil or jsonData['gamestate'] == nil or jsonData['sign'] == nil then
		retMSg['code'] = "error"
		retMSg['msg'] = "参数错误"
		return luajson.encode(retMSg)	
	end
	
	local signStr = 'gamestate='..jsonData['gamestate']..'&gametype='..jsonData['gametype'].."&key="..g_signKey
	if jsonData['sign'] ~= md5(signStr) then
		retMSg['code'] = "error"
		retMSg['msg'] = "验签失败"
		return luajson.encode(retMSg)
	end
	
	local sqlCase = " update dy_gamestate set state='"..tonumber(jsonData['gamestate']).."' where gametype='"..tonumber(jsonData['gametype']).."'"
	
	mysqlItem:execute(sqlCase)
	GameModel.loadGameStateList()
	
	return luajson.encode(retMSg)
end

function register(rcvData)

	local jsonData = luajson.decode(rcvData)
	local retMSg = {}
	retMSg['code'] = "success"
	retMSg['msg'] = "操作成功"

	if jsonData['phonenum'] == nil or jsonData['codenum'] == nil or jsonData['password'] == nil or jsonData['expend'] == nil or jsonData['sign'] == nil then
		retMSg['code'] = "error"
		retMSg['msg'] = "请输入正确的手机号码和验证码"		
	end
	local signStr = md5("codenum="..jsonData['codenum'].."&password="..jsonData['password'].."&peruserid="..jsonData['peruserid'].."&phonenum="..jsonData['phonenum'].."&key="..g_signKey)
	
	if jsonData['sign'] ~= signStr then
		retMSg['code'] = "error"
		retMSg['msg'] = "验签失败"
		return luajson.encode(retMSg)		
	end

	


	local cgmsg = msg_human_pb.cgaccountlogin()
	cgmsg.account = jsonArr['phonenum']
	cgmsg.password = jsonArr['password']
	cgmsg.nickname = jsonArr['phonenum']
	cgmsg.cid = jsonArr['phonenum']
	--cgmsg.channel = "uudwc_ard_002

	local pInfo = st_human_pb.playerinfo()
	PlayerModel.CreatePlayer(cgmsg)	
	
	
	if PlayerModel.GetPlayerInfoByCID(cgmsg.account, cgmsg.password, pInfo) ~= 0 then
		
		retMSg['code'] = "error"
		retMSg['msg'] = "创建玩家失败"
		return luajson.encode(retMSg)
		
	end	
	
	PlayerModel.PlayerLogin(pInfo, true)

end

--获取在线列表
function getonline(rcvData)
	local retMsg = {}
	retMsg['code'] = "success"
	retMsg['msg'] = "操作成功"
	
	--[[
	if rcvData == nil then
		
		retMsg['code'] = "error"
		retMsg['msg'] = "参数不能为空"		
		
		return luajson.encode( retMsg )
	end
	
	local jsonArr = luajson.decode( rcvData )
	
	if jsonArr['timesamp'] == nil or jsonArr['sign'] == nil then
		
		retMsg['code'] = "error"
		retMsg['msg'] = "缺少参数"			
		return luajson.encode( retMsg )
	end
	
	local signStr = md5( "timesamp="..jsonArr['timesamp'].."&key="..g_signKey )
	
	if jsonData['sign'] ~= signStr then
		retMSg['code'] = "error"
		retMSg['msg'] = "验签失败"
		return luajson.encode(retMSg)		
	end	
	]]
	--下面开始取在线列表
	
	local onlineList = OnlineModel.GetAllOnline()
	--需要下发的参数：房间ID，房间类型，牌桌类型，当前IP，携带的金币，保险箱金币，一个小时内输赢，三个小时呢输赢
	
	retMsg['userlist'] = {}
	for k,v_userid in pairs( onlineList ) do
		
		local addItem = {}
		
		local currTableID = PlayerModel.GetCurrTableID( v_userid )
		currTableID = tonumber(currTableID)
		if currTableID == nil or currTableID == 0 then
			addItem['gamename'] = "无"
			addItem['tablename'] = "无"
			addItem['tableid'] = 0
		else
			addItem['gamename'],addItem['tablename'] = GameUtils.GetTableInfoByID(currTableID)

			addItem['tableid'] = currTableID		
			
		end
		addItem['userid'] = v_userid
		table.insert( retMsg['userlist'], addItem )
		
	end	
	return luajson.encode( retMsg )
end

--捕鱼调控方式
function setyqscontrolmethod(rcvData)
    local jsonData = luajson.decode(rcvData)
	local retMSg = {}
	retMSg['code'] = "success"
	retMSg['msg'] = "操作成功"
	if jsonData['method'] == nil or jsonData['ratenum'] == nil or jsonData['tabletype'] == nil or jsonData['wavenum'] == nil or jsonData['sign'] == nil then
        retMSg['code'] = "error"
		retMSg['msg'] = "参数错误"
		return luajson.encode(retMSg)	
	end
	
	local signStr = 'method='..jsonData['method']..'&ratenum='..jsonData['ratenum']..'&tabletype='..jsonData['tabletype']..'&wavenum='..jsonData['wavenum'].."&key="..g_signKey
	if jsonData['sign'] ~= md5(signStr) then
		retMSg['code'] = "error"
		retMSg['msg'] = "验签失败"
		return luajson.encode(retMSg)
	end
	
	YqsModel.SetRoomControlMethod(jsonData['tabletype'],jsonData['method'],jsonData['ratenum'],jsonData['wavenum'])
	return luajson.encode(retMSg)
end


--捕鱼房间难度
function setyqsroomconefficient(rcvData)
	
	local jsonData = luajson.decode(rcvData)
	local retMSg = {}
	retMSg['code'] = "success"
	retMSg['msg'] = "操作成功"
	if jsonData['conefficient'] == nil or jsonData['tabletype'] == nil or jsonData['sign'] == nil then
		retMSg['code'] = "error"
		retMSg['msg'] = "参数错误"
		return luajson.encode(retMSg)	
	end
	
	local signStr = 'conefficient='..jsonData['conefficient']..'&tabletype='..jsonData['tabletype'].."&key="..g_signKey
	if jsonData['sign'] ~= md5(signStr) then
		retMSg['code'] = "error"
		retMSg['msg'] = "验签失败"
		return luajson.encode(retMSg)
	end
	
	YqsModel.SetRoomCoefficient(jsonData['tabletype'],jsonData['conefficient'])
	return luajson.encode(retMSg)
end

--捕鱼个人难度
function setyqsuserconefficient(rcvData)
	
	local jsonData = luajson.decode(rcvData)
	local retMSg = {}
	retMSg['code'] = "success"
	retMSg['msg'] = "操作成功"
	if jsonData['conefficient'] == nil or jsonData['tabletype'] == nil or jsonData['userid'] == nil or jsonData['sign'] == nil then
        retMSg['code'] = "error"
		retMSg['msg'] = "参数错误"
		return luajson.encode(retMSg)	
	end
	
	local signStr = 'conefficient='..jsonData['conefficient']..'&tabletype='..jsonData['tabletype']..'&userid='..jsonData['userid'].."&key="..g_signKey
	if jsonData['sign'] ~= md5(signStr) then
		retMSg['code'] = "error"
		retMSg['msg'] = "验签失败"
		return luajson.encode(retMSg)
	end
	
	YqsModel.SetUserCoefficient(jsonData['tabletype'],jsonData['userid'],jsonData['conefficient'])
	return luajson.encode(retMSg)
end


--获取波动实时系数
function getqyswaveconefficient(rcvData)
    local jsonData = luajson.decode(rcvData)
	local retMSg = {}
	retMSg['code'] = "success"
	retMSg['msg'] = "操作成功"
    retMSg['data'] = {}
	if jsonData['sign'] == nil then
        retMSg['code'] = "error"
		retMSg['msg'] = "参数错误"
		return luajson.encode(retMSg)	
	end

	local signStr = "key="..g_signKey
	if jsonData['sign'] ~= md5(signStr) then
		retMSg['code'] = "error"
		retMSg['msg'] = "验签失败"
		return luajson.encode(retMSg)
	end
	
    for i=1,3  do
        local wavedata = {}
        wavedata["tabletype"] = i
        wavedata["value"] = string.format( "%0.8f",YqsModel.GetRoomWaveConefficient(i))
        retMSg['data'][i] = wavedata
    end
    
    return luajson.encode(retMSg)

end



--彩票撤单
function caipiaorevocation(rcvData)
    	
	local jsonData = luajson.decode(rcvData)
	local retMSg = {}
	retMSg['code'] = "success"
	retMSg['msg'] = "操作成功"
	if jsonData['gamekey'] == nil or jsonData['gid'] == nil or jsonData['orderid'] == nil or jsonData['type'] == nil or jsonData['sign'] == nil then
        retMSg['code'] = "error"
		retMSg['msg'] = "参数错误"
		return luajson.encode(retMSg)	
	end

	local signStr = 'gamekey='..jsonData['gamekey']..'&gid='..jsonData['gid']..'&orderid='..jsonData['orderid'].."&type="..jsonData['type'].."&key="..g_signKey
	if jsonData['sign'] ~= md5(signStr) then
		retMSg['code'] = "error"
		retMSg['msg'] = "验签失败"
		return luajson.encode(retMSg)
	end
	local gid = jsonData['gid']
    local gamekey = jsonData['gamekey']
    local orderid = jsonData['orderid']
    local oprtype = jsonData['type']

    CaiPiaoModel.SysRevocation(gid,gamekey,orderid,oprtype) 
	return luajson.encode(retMSg)

end

--彩票手动开奖
function handopenaward(rcvData)
    	
	local jsonData = luajson.decode(rcvData)
	local retMSg = {}
	retMSg['code'] = "success"
	retMSg['msg'] = "操作成功"
	if jsonData['award'] == nil or jsonData['gamekey'] == nil or jsonData['gid'] == nil or jsonData['sign'] == nil then
		retMSg['code'] = "error"
		retMSg['msg'] = "参数错误"
		return luajson.encode(retMSg)	
	end

	local signStr = 'award='..jsonData['award']..'&gamekey='..jsonData['gamekey'].."&gid="..jsonData['gid'].."&key="..g_signKey
	if jsonData['sign'] ~= md5(signStr) then
		retMSg['code'] = "error"
		retMSg['msg'] = "验签失败"
		return luajson.encode(retMSg)
	end
	local gid = jsonData['gid']
    local gamekey = jsonData['gamekey']
    local award = jsonData['award']
    CaiPiaoModel.HandOpenAward(gamekey,gid,award) 
	return luajson.encode(retMSg)

end



