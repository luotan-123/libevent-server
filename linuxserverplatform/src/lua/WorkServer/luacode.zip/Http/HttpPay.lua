module("HttpPay", package.seeall)

function mmmjpay(rcvData)
	--LogFile("pay",rcvData)
	
	

	
end

